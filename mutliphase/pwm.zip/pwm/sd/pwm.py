#!/usr/bin/python
# -*- coding: utf-8 -*-

import math
# 2..16, pro CHANNELT uint32_t až 32 kanálů
CHANNELS = 10
CHANNELT = 'uint16_t'

header = '''/* Generated file */
#ifndef PWM_H
#define PWM_H
#include <stdint.h>
#include <vector>

static constexpr int CHANNELS = {0:d}; // počet kanálů (fází)
typedef {1:s} channel_t;
    
class SigmaDelta {{
    static constexpr int      INPUT_BITS = 16;
    static constexpr unsigned SIGMA_MASK = (1u << INPUT_BITS) - 1u;
    static constexpr double   WDIV       = 1.0 / double (CHANNELS);
    /***********************************************************************/
    unsigned                  sigma;
    unsigned                  state;
    std::vector< uint8_t >    sdm;
    std::vector<channel_t>    out;
    /***********************************************************************/
  public:
    explicit SigmaDelta () noexcept : sigma (0u), state (0u), sdm (), out () {{}};
    void test  (const char * input);
    void usage (const char * str  );
  protected:
    uint8_t sample (const unsigned input);
    void pass      (const unsigned n);
    void multiplex ();
    ////////// pomocné metody /////////////
    void fill_sd   (const int len, const int val) {{
      for (int n=0; n<len; n++) sdm.push_back (sample (val));
    }}
    void plot      (const char * imgname);
    void show_sd   () const;
    int  show_out  () const;
}};

#endif // PWM_H
'''

c_code = '''/* Generated file */
#include <stdint.h>
const {3:s} pwm_tab[{1:d}][{2:d}] = {{
{0:s}
}};
'''
def shifted (n, i):
  m = (1 << n) - 1
  k = m << i
  l = k & ((1 << CHANNELS) - 1)
  w = l |  (k >> CHANNELS)
  s = '0x{0:08X}u, '.format(w)
  return s
def generate ():
  ro = range (0, CHANNELS + 1)
  rs = range (0, CHANNELS)
  s = ''
  for j in ro:
    p = ''
    for i in rs: p += shifted (j, i);
    s += '{ ' + p [:-2] + ' },\n'
  return c_code.format(s[:-2], CHANNELS + 1, CHANNELS, CHANNELT)
def write_file (name, s):
  f = open (name,'w')
  f.write  (s)
  f.close  ()
if __name__ == '__main__':
  s = generate()
  write_file ('table.c', s)
  write_file ('pwm.h', header.format(CHANNELS, CHANNELT))
