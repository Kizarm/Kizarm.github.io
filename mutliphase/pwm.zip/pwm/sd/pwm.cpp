/***************************************************************************
 *   Copyright (C) 2021 by Kizarm <mrazik@volny.cz>                        *
 *                                                                         *
 *   Vylepšený algoritmus, funguje stejně jako optimální, rychlejší.       *
 *                                                                         *
 ***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pwm.h"
/// run time výpočet (možná i rychlejší)
static inline unsigned pwm_run (const unsigned num, const unsigned ofs) {
  const unsigned n = ((1u << num) - 1u) << ofs;
  return (n & ((1u << CHANNELS) - 1u)) | (n >> CHANNELS); 
}
/// generovaná tabulka
extern "C" const channel_t pwm_tab [CHANNELS + 1][CHANNELS];
/** Hlavní metoda - počítá S/D vzorky, ale nikoli v rozsahu <0,1>,
 *  ale v rozsahu <0,CHANNELS> (v celých číslech), přičemž vstup je
 *  v rozsahu <0,2^INPUT_BITS>.
 * */
uint8_t SigmaDelta::sample (const unsigned input) {
  const unsigned samp = input * CHANNELS;
  sigma &= SIGMA_MASK;          // v podstatě se odečte přetečení
  sigma += samp;                // integrace prostým součtem
  return static_cast<uint8_t> (sigma >> INPUT_BITS);
}
/** Algoritmus rozsekání jedniček do jednotlivých kanálů,
 *  data bere z konstantní tabulky generované skriptem,
 *  takže výpočty jsou redukovány na minimum.
 */
void SigmaDelta::pass (const unsigned n) {
  unsigned sdv = sdm [n];             // hodnota SD = počet výstupních jednotek
  const channel_t nch = pwm_tab [sdv][state];
//const channel_t nch = pwm_run (sdv, state); // lze počítat i run time
  out.push_back  (nch);
  state += sdv;
  if (state >= CHANNELS) state -= CHANNELS;
}
void SigmaDelta::multiplex () {
  const size_t m = sdm.size();
  for (unsigned n=0; n<m; n++) pass (n);
}
/******************  Pomocné rutiny  ***********************************/
void SigmaDelta::show_sd () const {
  const int len = sdm.size();
  printf ("\tOriginální SIGMA-DELTA: [data - desítky / jednotky pod sebou]\n[");
  if (CHANNELS >= 10) {
    for (int n=0; n<len; n++) {
      const uint8_t v = sdm.at (n) / 10;
      if (v) printf ("%d", v);
      else   printf (" ");
    }
    printf ("]\n[");
  }
  for (int n=0; n<len; n++) printf ("%d", sdm.at (n) % 10);
  printf ("]\n");
}
int SigmaDelta::show_out () const {
  int total = 0;
  printf ("\tJednotlivé kanály: [data][počet 1]\n");
  const int len = out.size();
  for (int i=0; i<CHANNELS; i++) {
    int ones = 0;
    printf ("[");
    for (int n=0; n<len; n++) {
      const int    v = (out[n] & (1 << i)) ? 1 : 0;
    //const char * s = v ?  "1" : "0";
      const char * s = v ?  "█" : "▁";
      printf ("%s", s);
      ones += v;
    }
    total += ones;
    printf ("][%03d]\n", ones);
  }
  return total;
}
void SigmaDelta::test (const char * input) {
  double per = strtod (input, nullptr);
  if (per < 0.0  ) per =   0.0;
  if (per > 100.0) per = 100.0;
  const unsigned val = lround ((double (1u << INPUT_BITS) * per) * 0.01);
  printf ("Vstup = %d (%g%%)\n", val, per);
  fill_sd   (128, val);
  show_sd   ();
  multiplex ();
  
  const int ones = show_out ();
  // testy
  const size_t l1 = sdm.size(), l2 = out.size();
  if (l1 != l2) { printf ("size error\n"); return; }
  unsigned err = 0u;
  for (unsigned n=0; n<l1; n++) {
    const channel_t & ch = out [n];
    uint8_t s = 0;
    for (int i=0; i<CHANNELS; i++) s += ch & (1 << i) ? 1 : 0;
    if (s != sdm [n]) err += 1u;
  }
  printf ("Počet chyb = %d, celkový počet jednotek = %d\n", err, ones);
  plot   ("outi.png");
  
}
void SigmaDelta::usage (const char * str) {
  printf ("Použití: %s [dekadické číslo v intervalu (0,100.0)]\n"
          "\tčíslo udává činitel plnění v %%\n", str);
}
static std::vector<std::vector<double>> create_plot_data (const std::vector<channel_t> & out, const double wdiv) {
  std::vector<std::vector<double>> res;
  static std::vector<double> row (CHANNELS);
  for (channel_t c: out) {
    for (int n=0; n<CHANNELS; n++) {
      double     & r = row [n];
      const double v = c & (1 << n) ? 100.0 : 0.0;
      r = (r * double(CHANNELS - 1) + v) * wdiv;
    }
    res.push_back(row);
  }
  return res;
}
static const char * plot_cmd = R"---(set terminal png transparent size 1024,360
set grid
set key box opaque
set output '%s'
set title "Časování vícekanálové PWM/SD"
set xlabel 't[μs]'
set ylabel 'A[%%]'
set xrange [400:]
#set yrange [0:1.0]
)---";
void SigmaDelta::plot (const char * imgname) {
  const char * filename = "x.dat";
  FILE * dat = fopen (filename, "w");
  int order = 0;
  const std::vector<std::vector<double>> plt = create_plot_data (out, WDIV);
  for (const std::vector<double> & row: plt) {
    double suma = 0.0;
    fprintf (dat, "%4d ", order);
    order += 10;  // us, 100 kHz
    for (const double & d: row) {
      fprintf (dat, "%f ", d);
      suma += d;
    }
    fprintf (dat, "%f\n", suma * WDIV);
  }
  fclose (dat);
  const size_t buflen = 0x1000;
  char buffer [buflen];
  int ofs = 0;
  ofs += snprintf (buffer + ofs, buflen - ofs, plot_cmd, imgname);
  ofs += snprintf (buffer + ofs, buflen - ofs, "plot ");
  for (int n=0; n<CHANNELS; n++) {
    ofs += snprintf (buffer + ofs, buflen - ofs, "\'%s\' u 1:%d w l lw 2 t \'CH%d(t)\',", filename, n + 2, n + 1);
  }
  ofs += snprintf (buffer + ofs, buflen - ofs, "\'%s\' u 1:%d w l lw 4 t \'AVG(t)\',", filename, CHANNELS + 2);
  buffer [ofs - 1] = '\n';    // přemaž poslední čárku novým řádkem
  // printf("%s\n", buffer);
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) {
    printf ("Pro vytvoření grafu je potřeba gnuplot\n");
    remove (filename);
    return;
  }
  fprintf (cmd, "%s", buffer);
  fflush  (cmd);
  pclose  (cmd);
  remove  (filename);
}
/***********************************************************************/
int main (int argc, char * argv[]) {
  SigmaDelta sd;
  if (argc < 2) {
    sd.usage (argv [0]);
    return 0;
  }
  sd.test (argv [1]);
  return 0;
}
