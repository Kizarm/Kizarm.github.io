/***************************************************************************
 *   Copyright (C) 2021 by Kizarm <mrazik@volny.cz>                        *
 ***************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <vector>
/** Fakticky vektor s pevnou délkou (např. pro MCU) */
template<typename T, const int N> class StaticArray {
  T data [N];
  public:
    explicit StaticArray () noexcept {
      memset (data, 0, N * sizeof (T));
    }
    explicit StaticArray (const StaticArray /*<T,N>*/ & other) noexcept {
      memcpy (data, other.data, N * sizeof (T));
    }
    T & operator[] (const int index) {
      return data [index];
    }
    const T & operator[] (const int index) const {
      return data [index];
    }
    /** @class iterator
     *  @brief range-based for () */
    class iterator {
      const T * ptr;
      public:
        iterator(const T * _ptr) : ptr (_ptr) {}
        iterator  operator++ ()                             { ++ptr;   return * this;    }
        bool      operator!= (const iterator & other) const { return   ptr != other.ptr; }
        const T & operator*  ()                       const { return * ptr;              }
    };
    iterator begin () const { return iterator (data    ); }
    iterator end   () const { return iterator (data + N); }
};
/*****************************************************************************************/
class SigmaDelta {
    static constexpr int      CHANNELS   = 10; // počet kanálů (fází)
    static constexpr int      INPUT_BITS = 16;
    static constexpr unsigned SIGMA_MASK = (1u << INPUT_BITS) - 1u;
    static constexpr unsigned WMUL       = (1u << 12) / CHANNELS;
    static constexpr unsigned YSCALE     = 1000u;
    static constexpr double   WDIV       = 1.0 / double (CHANNELS);
    struct Descriptor {
      int      no;
      unsigned st;
    };
    typedef StaticArray<Descriptor, CHANNELS> Descriptors;
    typedef StaticArray<uint8_t,    CHANNELS> Channels;
    /***********************************************************************/
    unsigned                 sigma;
    Descriptors              state;
    std::vector<uint8_t>     sdm;
    std::vector<Channels>    out;
    std::vector<Descriptors> plt;
    /***********************************************************************/
  public:
    explicit SigmaDelta () noexcept : sigma (0u), state (), sdm (), out (), plt () {};
    void test  (const char * input);
    void usage (const char * str  );
  protected:
    uint8_t sample (const unsigned input);
    void pass      (const unsigned n);
    void multiplex ();
    ////////// pomocné metody /////////////
    void plot      (const char * imgname);
    void fill_sd   (const int len, const int val) {
      for (int n=0; n<len; n++) sdm.push_back (sample (val));
    }
    void show_sd () const {
      const int len = sdm.size();
      printf ("\tOriginální PWM/SIGMA-DELTA: [data - desítky / jednotky pod sebou]\n[");
      if (CHANNELS >= 10) {
        for (int n=0; n<len; n++) printf ("%d", sdm.at (n) / 10);
        printf ("]\n[");
      }
      for (int n=0; n<len; n++) printf ("%d", sdm.at (n) % 10);
      printf ("]\n");
    }
    int show_out () const {
      int total = 0;
      printf ("\tJednotlivé kanály: [data][počet 1]\n");
      const int len = out.size();
      for (int i=0; i<CHANNELS; i++) {
        int ones = 0;
        printf ("[");
        for (int n=0; n<len; n++) {
          const uint8_t v = out[n][i];
          printf ("%d", v);
          ones += v;
        }
        total += ones;
        printf ("][%03d]\n", ones);
      }
      return total;
    }
};
/** Hlavní metoda - počítá S/D vzorky, ale nikoli v rozsahu <0,1>,
 *  ale v rozsahu <0,CHANNELS> (v celých číslech), přičemž vstup je
 *  v rozsahu <0,2^INPUT_BITS>.
 * */
uint8_t SigmaDelta::sample (const unsigned input) {
  const unsigned sample = input * CHANNELS;
  sigma &= SIGMA_MASK;          // v podstatě se odečte přetečení
  sigma += sample;              // integrace prostým součtem
  return static_cast<uint8_t> (sigma >> INPUT_BITS);
}
/** Algoritmus počítá pro každý kanál klouzavý průměr s postupným zapomínáním,
 * tím se dá zjístit, kam už může dát 1, musí se ale 2x procházet kanály.
 * Takže je to výpočetně náročné, čas výpočtu není přesně definován.
 * 
 * Tanto algoritmus je přesný, ale jak se ukázalo stejně se nijak neprohazují
 * jednotlivé bity nastavované do jedničky, není to potřeba. Takže to jde
 * hodně podstatně zjednodušit. Výsledek je v souboru pwm.cpp.
 */
void SigmaDelta::pass (const unsigned n) {
  unsigned sdv = sdm [n];             // hodnota SD = počet 1
  Descriptors copy (state);
  Channels nch;
  while (sdv) {                       // dokud zbývá zapsat nějaká jednotka
    int i, j =  -1;
    unsigned m = 2u * YSCALE;
    for (i=0; i<CHANNELS; i++) {      // najdi minimum
      const Descriptor & d = copy [i];
      if (d.no < 0) continue;         // jen ve zbývajících kanálech
      if (d.st < m) {
        m = d.st; j = i;
      }
    }
    if (j >= 0) {
      copy[j].no =-1;                 // zneplatni kanál
      nch [j]    = 1;                 // zapiš jednotku
      sdv       -= 1;                 // a zmenši počet zbývajících
    }
  }
  for (int i=0; i<CHANNELS; i++) {      // update status
    const unsigned v = YSCALE * nch[i];
    Descriptor   & d = state [i];
    // klouzavý průměr s postupným zapomínáním (lze i v celých číslech)
    d.st = ((d.st * (CHANNELS - 1) + v) * WMUL) >> 12;
  }
  out.push_back (nch);
  plt.push_back (state);
}
void SigmaDelta::multiplex () {
  const size_t m = sdm.size();
  for (unsigned n=0; n<m; n++) pass (n);
}
/******************  Pomocné rutiny  ***********************************/
void SigmaDelta::test (const char * input) {
  double per = strtod (input, nullptr);
  if (per < 0.0  ) per =   0.0;
  if (per > 100.0) per = 100.0;
  const unsigned val = lround ((double (1u << INPUT_BITS) * per) * 0.01);
  printf ("Vstup = %d (%g%%)\n", val, per);
  fill_sd   (128, val);
  show_sd   ();
  multiplex ();

  const int ones = show_out ();
  // testy
  const size_t l1 = sdm.size(), l2 = out.size();
  if (l1 != l2) { printf ("size error\n"); return; }
  unsigned err = 0u;
  for (unsigned n=0; n<l1; n++) {
    const Channels & ch = out [n];
    uint8_t s = 0;
    for (int i=0; i<CHANNELS; i++) s += ch [i];
    if (s != sdm [n]) err += 1u;
  }
  printf ("Počet chyb = %d, celkový počet jednotek = %d\n", err, ones);
  plot   ("outi.png");
}
void SigmaDelta::usage (const char * str) {
  printf ("Použití: %s [dekadické číslo v intervalu (0,100.0)]\n"
          "\tčíslo udává činitel plnění v %%\n", str);
}
static const char * plot_cmd = R"---(set terminal png size 1800,360
set grid
set key box opaque
set output '%s'
set title "Časování vícekanálové PWM/SD"
set xlabel 't[μs]'
set ylabel 'I[A]'
#set yrange [0:%d]
)---";
void SigmaDelta::plot(const char * imgname) {
  const char * filename = "x.dat";
  FILE * dat = fopen (filename, "w");
  int order = 0;
  for (const Descriptors & row: plt) {
    double suma = 0.0;
    fprintf (dat, "%4d ", order);
    order += 10;  // us, 100 kHz
    for (const Descriptor & d: row) {
      fprintf (dat, "%3d ", d.st);
      suma += static_cast <double> (d.st);
    }
    fprintf (dat, "%f\n", suma * WDIV);
  }
  fclose (dat);
  const size_t buflen = 0x1000;
  char buffer [buflen];
  int ofs = 0;
  ofs += snprintf (buffer + ofs, buflen - ofs, plot_cmd, imgname, YSCALE);
  ofs += snprintf (buffer + ofs, buflen - ofs, "plot ");
  for (int n=0; n<CHANNELS; n++) {
    ofs += snprintf (buffer + ofs, buflen - ofs, "\'%s\' u 1:%d w l lw 2 t \'CH%d(t)\',", filename, n + 2, n + 1);
  }
  ofs += snprintf (buffer + ofs, buflen - ofs, "\'%s\' u 1:%d w l lw 4 t \'AVG(t)\',", filename, CHANNELS + 2);
  buffer [ofs - 1] = '\n';    // přemaž poslední čárku novým řádkem
  // printf("%s\n", buffer);
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) {
    printf ("Pro vytvoření grafu je potřeba gnuplot\n");
    remove (filename);
    return;
  }
  fprintf (cmd, "%s", buffer);
  fflush  (cmd);
  pclose  (cmd);
  remove  (filename);
}
/***********************************************************************/
int main (int argc, char * argv[]) {
  SigmaDelta sd;
  if (argc < 2) {
    sd.usage (argv [0]);
    return 0;
  }
  sd.test (argv [1]);
  return 0;
}
