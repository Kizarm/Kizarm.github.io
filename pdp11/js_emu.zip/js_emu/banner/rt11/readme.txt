
Jak dostat soubory banner.mac, bansta.mac do systému RT11,
předpoklad je použití SIMH (zde s názvem pdp11).
Soubory musí mít ukončení řádky znaky <CR><LF>!

1. Přes děrnou pásku (RT11 musí podporovat zařízení PC).
$./pdp11 pdp.ini<ENTER>
sim> att ptr banner.mac<ENTER>
sim> boot rk<ENTER>
RT-11SJ  V04.00C
...
.R PIP<ENTER>
*BANNER.MAC=PC:/A<ENTER>
*<CTRL-E>
Simulation stopped, PC: 153034 (BR 152622)
sim> att ptr bansta.mac<ENTER>
sim> c<ENTER>
BANSTA.MAC=PC:/A<ENTER>
*<CTRL-C>

.MACRO BANNER<ENTER>
ERRORS DETECTED:  0

.MACRO BANSTA<ENTER>
ERRORS DETECTED:  0

.LINK BANNER,BANSTA<ENTER>
.R BANNER<ENTER>
Banner Text? ...<ENTER>

A je hotovo.

2. Malý soubor editorem, např. bansta.mac.
Soubor otevřeme normálním textovým editorem jako je např. gedit,
pomocí <CTRL-A><CTRL-C> zkopírujeme do schránky. V simulaci RT11
pak provedeme
.EDIT/C BANSTA.MAC<ENTER>
$I<ENTER>
{zde vložíme schránku pomocí <SHIFT-INSERT>, <CTRL-V> nefunguje}
<ESC>EX<ESC><ESC>

A je hotovo. Pro textový soubor větší než asi 10KiB to fakt nefunguje.
