#ifndef CONSOLE_H
#define CONSOLE_H
/*
 * Jediné dvě systémové funkce, které mohou programy
 * používat jsou výstup znaku na konzoli a vstup znaku
 * z konzole. Tím je usnadněno portování do různých
 * systémů jako je třeba RT11.
*/
void cputc(char c);
char cgetc();
#endif
