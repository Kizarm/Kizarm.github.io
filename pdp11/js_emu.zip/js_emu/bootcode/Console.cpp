#include "Console.h"

void Console::puts (const char * const s) const {
  for (unsigned n=0; ; n++) {
    const char c = s[n];
    if (c == '\0') break;
    if (c == '\n') putc ('\r');
    putc (c);
  }
}

const Console console;

extern "C" void main_cpp () {
  console.puts("Test C++ compiler\n");
}
