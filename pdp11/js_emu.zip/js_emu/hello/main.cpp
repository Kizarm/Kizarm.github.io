#include "Console.h"
extern void sin_test  ();     // from test.cpp
extern void size_test ();
extern void endian_test ();
extern "C" char * print_text; // from startup.s
extern "C" int    entry;
int main() {
  console.printf("\r\n\tProgram start at 0x%04X (0%06o)\r\n\n", & entry, & entry);
  size_test();
  console.puts ("\n\tText main.cpp:\n\n");
  console.puts (print_text);
  sin_test ();
  asm volatile (R"---(
    bpt
  )---");
  endian_test ();
  return 0;
}
