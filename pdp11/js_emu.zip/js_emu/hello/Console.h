#ifndef CONSOLE_H
#define CONSOLE_H
#include <stdarg.h>
#include <stdint-gcc.h>
extern "C" int mvsnprintf (char *pStr, int length, const char * pFormat, va_list ap);
/* Zápis bitových polí je stejný jako little endien */
struct DL11_REG {
  union {
    volatile struct {
      uint16_t unused0 : 6; // nejnižší bity
      uint16_t IE      : 1; // 0x0040
      uint16_t DONE    : 1; // 0x0080
      uint16_t unused1 : 7;
      uint16_t ERR     : 1; // nejvyšší bit 0x8000
    } B;
    volatile uint16_t R;
  } RCSR;
  volatile uint16_t RBUF;
  union {
    volatile struct {
      uint16_t unused0 : 6;
      uint16_t IE      : 1;
      uint16_t READY   : 1;
      uint16_t unused1 : 7;
      uint16_t ERR     : 1;
    } B;
    volatile uint16_t R;
  } XCSR;
  volatile uint16_t XBUF;
};
static DL11_REG & DL11 = * reinterpret_cast <DL11_REG * const> (0177560);
/* nepoužité funkce necháme v hlavičce - pdp11 gcc neumí gc-sections */
class Console {
  public:
    explicit constexpr Console () noexcept {}
    void putc (const char c) const {
      while (!DL11.XCSR.B.READY);
      DL11.XBUF = static_cast<uint16_t> (c);
    }
    char getc () const {
      while (!DL11.RCSR.B.DONE);
      return static_cast<char> (DL11.RBUF & 0x7F);
    }
    void gets (char * const buffer, const int size) const {
      char c, * p = buffer;
      while (true) {
        c = getc();
        if ( (c == '\b') || (c == 0x7F)) {
          if (p > buffer) {
            putc ('#');
            p--;
          } else {
            putc (7); // Ring Bell
          }
        } else if (c >= ' ') {
          if (p < buffer + size - 2) {
            * (p++) = c;
            putc (c);
          }
        } else if (c == '\r') {
          putc (c);
          putc ('\n');
          return;
        }
        *p = 0;
      }
    }
    void puts (const char * const s) const;
    void puts (const char * const s, const int size) const {
      for (int n=0; n<size; n++) putc (s [n]);
    }
    int printf (const char * fmt, ...) const;
};
extern Console console;

#endif // CONSOLE_H
