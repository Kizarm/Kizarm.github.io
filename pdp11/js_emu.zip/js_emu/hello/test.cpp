#include "Console.h"

static double to_rad (const double x) {
  return x * (3.14159265358979323846 / 180.0);
}
static double dabs (const double a) { return a < 0.0 ? -a : +a; }
static double sincos (const double x, const bool even) {
  double result (0.0), element(1.0), divider(0.0);
  if (even) { element *= x; divider += 1.0; }
  const double eps = 1.0e-15;      // maximální chyba výpočtu
  const double aa  = - (x * x);
  for (;;) {
    result  += element;
    if (dabs  (element) < eps) break;
    divider += 1.0;
    double fact = divider;
    divider += 1.0;
    fact    *= divider;
    element *= aa / fact;
  }
  return result;
}
static void line (const unsigned len = 87) {
  for (unsigned n=0; n<len; n++) console.putc('+');
  console.puts("\n");
}
static const double table [] = {
  0.0, 30.0, 45.0, 60.0, 90.0,
  135.0, 180.0, 270.0, 360.0
};

void sin_test () {
  console.puts("\tCompute double (FPU) test:\n");
  line ();
  console.puts("arg[deg]: sin (arg)"
  "                cos(arg)"
  "                 => sin^2(arg) + cos^2(arg)\n");
  line ();
  for (double x : table) {
    const double a = to_rad (x);
    const double s = sincos (a, true);
    const double c = sincos (a, false);
    const double w = s*s + c*c;
    console.printf("%8d: %f %f => %f\r\n", (int) x, s, c, w);
  }
  line ();
}

void size_test () {
  console.printf("sizeof short     = %d\r\n", (int) sizeof (short));
  console.printf("sizeof int       = %d\r\n", (int) sizeof (int));
  console.printf("sizeof long      = %d\r\n", (int) sizeof (long));
  console.printf("sizeof long long = %d\r\n", (int) sizeof (long long));
  console.printf("sizeof float     = %d\r\n", (int) sizeof (float));
  console.printf("sizeof double    = %d\r\n", (int) sizeof (double));
}

static void shifted (const int64_t & x) {
  uint64_t nn = x;
  for (unsigned n=0; n<8; n++) {
    const uint8_t k = (nn >> 56) & 0xFF;
    console.printf("%02X", static_cast<unsigned> (k));
    nn <<= 8;
  }
  console.puts(" - shifted = OK\n");
}
static void union_1 (const int64_t & nn) {
  union ull_bf_u {
    uint64_t ull;
    uint8_t  bf [8];
  } ull_bf;
  ull_bf.ull = nn;
  for (unsigned n=0; n<8; n++) {
    console.printf("%02X", static_cast<unsigned> (ull_bf.bf[n]));
  }
  console.puts(" - by bytes union\n\n");
}
static void union_2 (const int64_t & nn) {
  union ull_wf_u {
    uint64_t ull;
    uint16_t wf [4];
  } ull_wf;
  ull_wf.ull = nn;
  for (unsigned n=0; n<4; n++) {
    console.printf("%04X", static_cast<unsigned> (ull_wf.wf[n]));
  }
  console.puts(" - by words union\n");
}
static void cons_reg () {
  console.puts("\tConsole registers:\n");
  console.printf("DL11.RCSR = 0%06o\r\n", (unsigned) & DL11.RCSR);
  console.printf("DL11.RBUF = 0%06o\r\n", (unsigned) & DL11.RBUF);
  console.printf("DL11.XCSR = 0%06o\r\n", (unsigned) & DL11.XCSR);
  console.printf("DL11.XBUF = 0%06o\r\n", (unsigned) & DL11.XBUF);
  console.puts("\n");
}
/** Byte v 16.bit word jsou uloženy v little endian,
 *  ale jednotlivé word jako big endian. Je to dost divné.
 * V little musí jednotlivé položky union musí vystupovat v opačném pořadí,
 * ale pak je jedno, zda vystupují jako 8.bitové byty nebo 16.bitové wordy,
 * vyleze vždy "0123456789ABCDEF"
 * __ORDER_LITTLE_ENDIAN__ 1234
 * __ORDER_BIG_ENDIAN__    4321
 * __ORDER_PDP_ENDIAN__    3412
 * __BYTE_ORDER__ __ORDER_PDP_ENDIAN__
 * */
void endian_test () {
  console.printf("\r\n\tEndian test (__BYTE_ORDER__ = %d):\r\n", __BYTE_ORDER__);
  const uint64_t nn = 0x123456789ABCDEF0ull;
  shifted (nn);
  union_2 (nn);
  union_1 (nn);
  cons_reg();
}
