#include "double_to_str.h"
/** Reprezentace double pdp-11 je divna */
typedef union {
  double f;
  unsigned long long u;
} double_unsigned;
// výstupní znaky
static const char * dec = "0123456789ABCDEF";
// decimální exponent
static unsigned exp_str (char * buf, const int e) {
  unsigned n = 0;
  int exp  = 0;
  buf [n++] = 'E';
  if (e > 0) {
    buf [n++] = '+';
    exp = +e;
  } else if (e < 0) {
    buf [n++] = '-';
    exp = -e;
  } else {
    buf [n++] = '+';
    buf [n++] = '0';
    buf [n++] = '0';
    return n;
  }
  n += 2;
  buf [n - 1] = dec [exp % 10];
  exp /= 10;
  buf [n - 2] = dec [exp % 10];
  return n;
}
// konstanty pro decimální normalizaci
static const double exp_plus [] = {
  1.0e+1, 1.0e+2, 1.0e+4, 1.0e+8, 1.0e+16, 1.0e+32, 
};
static const double exp_minus [] = {
  1.0e-1, 1.0e-2, 1.0e-4, 1.0e-8, 1.0e-16, 1.0e-32, 
};
// decimální normalizace f do rozsahu <0.1, 1.0)
static int f_norm (double * f) {
  int pe = 0;
  unsigned n = 5u;
  if (* f >= 1.0) {
    do {
      if (* f >= exp_plus [n]) { * f *= exp_minus [n];  pe += 1 << n; }
    } while (n--);
    *f *= 0.1;
    pe += 1;
  } else {
    do {
      if (* f < exp_minus [n]) { * f *= exp_plus [n];   pe -= 1 << n; }
    } while (n--);
  }
  return pe;
}
/*
static void bcopy (void * dst, const void * src, const unsigned len) {
  unsigned       char * d = (unsigned       char *) dst;
  const unsigned char * s = (const unsigned char *) src;
  for (unsigned n=0; n<len; n++) d[n] = s[n];
}
*/
unsigned double_to_str (char * buf, const double x) {
  double f = x;
  int sign = 0;
  if (x < 0.0) {
    f = -x; sign = 1;
  }
  int dec_exp = f_norm (& f);
  //bcopy (& um, & f, 8);
  double_unsigned du;
  du.f = f;
  uint64_t um = du.u;       // místo bcopy
  int bin_exp = (int) ((um >> 55) & 0xFFu);
  // převod formátu pro výstup číslic pomocí celočíselného násobení 10
  um  &= (1ull << 55) - 1u;
  um  |=  1ull << 55;
  um <<=  bin_exp - 124u;
  unsigned n = 0;
  if (sign) buf [n++] = '-';
  else      buf [n++] = '+';
  if (f != 0.0) {
    for (;;) {              // exportuj decimální číslice
      um = (um << 3) + (um << 1);     // násobení 10 funguje divně
      const unsigned ix = (um >> 60) & 0xF;
      const char c = dec [ix];
      um &= (1ull << 60) - 1;
      if (n == 2) buf [n++] = '.';
      buf [n++] = c;
      if  (n >= 20) break;  // 18 platnych cislic
    }
    n += exp_str (buf + n, dec_exp - 1);
  } else {                  // 0.0f
    buf [n++] = '0';
    for (unsigned i=0; i<22; i++) buf[n++] = ' ';
  }
  buf [n] = '\0';           // ukončení
  return n;
}
