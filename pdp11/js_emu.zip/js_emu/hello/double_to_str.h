/* inclusion guard */
#ifndef __DOUBLE_TO_STR_H__
#define __DOUBLE_TO_STR_H__
#include <stdint-gcc.h>

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
  /**
   * @author <mrazik@volny.cz>
   *         licence : <a href="https://cs.wikipedia.org/wiki/Licence_MIT">MIT</a>
   * 
   * @function float_to_str
   * @brief Funkce převádí double (64 bit) na c-string ve formátu zhruba "+.14E"
   *        Velmi zjednodušená, nezaokrouhluje.
   *
   * @param buf char buffer o minimální délce 22 bytů (není kontrolováno)
   * @param f float vstup (předpoklad je formát podle IEEE 754 v little endien)
   * @return počet zapsaných bytů (mimo ukončovací 0)
   * */
  extern unsigned double_to_str (char * buf, const double f);
#ifdef __cplusplus
};
#endif //__cplusplus

#endif /* __DOUBLE_TO_STR_H__ */
