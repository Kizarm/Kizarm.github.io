/// all in one function
extern "C" int main_wrap (int argc, char *argv[]);

int main (int argc, char *argv[]) {
  return main_wrap(argc, argv);
}
