#include "Console.h"


int Console::printf (const char * fmt, ...) const {
  static constexpr int length = 0x100;
  /* static */ char buf [length]; // je celkem jedno jestli je to na zásobníku
  va_list   ap;
  va_start (ap, fmt);
  const int rc = mvsnprintf (buf, length, fmt, ap);
  va_end   (ap);
  puts (buf);
  return rc;
}
void Console::puts (const char * const s) const {
  for (unsigned n=0; ; n++) {
    const char c = s[n];
    if (c == '\0') break;
    if (c == '\n') putc ('\r');
    putc (c);
  }
}

Console console;
/*
extern "C" unsigned * reg_ptr;
extern "C" void bpt_print () {
  console.puts("Break detected :\n");
  for (unsigned n=0; n<8; n++) {
    const unsigned m = reg_ptr [n];
    console.printf("\tR%d = 0x%04X (0%06o)\r\n", n, m, m);
  }
}
*/
