#include <stdarg.h>
#include <stdint-gcc.h>

extern int mvsnprintf (char *pStr, int length, const char * pFormat, va_list ap);

/*
int msnprintf (char * buf, int length, const char *fmt, ...) {
  va_list    ap;
  signed int rc;

  va_start (ap, fmt);
  rc = mvsnprintf (buf, length, fmt, ap);
  va_end (ap);

  return rc;
}
*/
//------------------------------------------------------------------------------
// Writes a character inside the given string. Returns 1.
// \param pStr  Storage string.
// \param c  Character to write.
//------------------------------------------------------------------------------
static signed int PutChar (char *pStr, char c) {
  *pStr = c;
  return 1;
}
//------------------------------------------------------------------------------
// Writes a string inside the given string.
// Returns the size of the written
// string.
// \param pStr  Storage string.
// \param pSource  Source string.
//------------------------------------------------------------------------------
static signed int PutString (char *pStr, const char *pSource) {
  signed int num = 0;

  while (*pSource != 0) {

    *pStr++ = *pSource++;
    num++;
  }

  return num;
}
///////////////////////////////////////////////////////
struct div_t {
  unsigned rem;
  unsigned quo;
};
/// Tohle odstraní knihovní funkce libc, ale potřebuje EIS (PDP11/70)
void udiv (struct div_t * dt) {
  asm volatile (
  "clr r4\t\n"
  "mov (%0)+, r5\t\n"
  "div (%0) , r4\t\n"
  "mov r4,  (%0)\t\n"
  "mov r5, -(%0)\t\n"
  ::"r"(dt):"r4","r5");
}
///////////////////////////////////////////////////////
//------------------------------------------------------------------------------
// Writes an hexadecimal value into a string, using the given fill, width &
// capital parameters.
// Returns the number of char written.
// \param pStr  Storage string.
// \param fill  Fill character.
// \param width  Minimum integer width.
// \param base   Base
// \param value  Hexadecimal value.
//------------------------------------------------------------------------------
static signed int PutUnsigned (
  char *pStr,
  char fill,
  signed int width,
  unsigned char base,
  unsigned int value) {
  signed int num = 0;

  // Decrement width
  width--;
  // Recursively output upper digits
  struct div_t dt;
  dt.quo = base;    // Dělitel !
  dt.rem = value;   // Dělenec !
  udiv (& dt);      // Výsledek je quo = podíl, rem = zbytek
  if (dt.quo > 0) {
    num  += PutUnsigned (pStr, fill, width, base, dt.quo);
    pStr += num;
  }
  // Write filler chars
  else {
    while (width > 0) {
      PutChar (pStr, fill);
      pStr++;
      num++;
      width--;
    }
  }
  // Write current digit
  if (dt.rem < 10) {
    PutChar (pStr, dt.rem + '0');
  } else {
    PutChar (pStr, dt.rem - 10 + 'A');
  }
  num++;
  return num;
}
//------------------------------------------------------------------------------
// Writes a signed int inside the given string, using the provided fill & width
// parameters.
// Returns the size of the written integer.
// \param pStr  Storage string.
// \param fill  Fill character.
// \param width  Minimum integer width.
// \param value  Signed integer value.
//------------------------------------------------------------------------------
static signed int PutSigned (
  char *pStr,
  char fill,
  signed int width,
  signed int value) {
  signed int num = 0;
  unsigned int absolute;

  // Compute absolute value
  if (value < 0) {
    absolute = -value;
  } else {
    absolute =  value;
  }
  // Write sign
  if (value < 0) {
    num += PutChar (pStr, '-');
    pStr++;
  }
  num += PutUnsigned (pStr, fill, width, 10, absolute);
  return num;
}
/// Stores the result of a formatted string into another string. Format
/// arguments are given in a va_list instance.
/// Return the number of characters written.
/// \param pStr    Destination string.
/// \param length  Length of Destination string.
/// \param pFormat Format string.
/// \param ap      Argument list.
//------------------------------------------------------------------------------
int mvsnprintf (char *pStr, int length, const char * pFormat, va_list ap) {
  char          fill;
  unsigned char width;
  signed int    num = 0;
  signed int    size = 0;
  // Clear the string
  if (pStr) {
    *pStr = 0;
  }
  // Phase string
  while (*pFormat != 0 && size < length) {
    // Normal character
    if (*pFormat != '%') {
      *pStr++ = *pFormat++;
      size++;
    }
    // Escaped '%'
    else if (* (pFormat+1) == '%') {
      *pStr++ = '%';
      pFormat += 2;
      size++;
    }
    // Token delimiter
    else {
      fill = ' ';
      width = 0;
      pFormat++;
      // Parse filler
      if (*pFormat == '0') {
        fill = '0';
        pFormat++;
      }
      // Parse width
      while ( (*pFormat >= '0') && (*pFormat <= '9')) {
        unsigned char dwidth = (width << 3) + (width << 1); // 10 * width = 8 * width + 2 * width
        width = (dwidth) + *pFormat-'0';
        pFormat++;
      }
      // Check if there is enough space
      if (size + width > length) {
        width = length - size;
      }

      // Parse type
      switch (*pFormat) {
      case 'd':
      case 'i': num = PutSigned   (pStr, fill, width,     va_arg (ap, signed   int)); break;
      case 'o': num = PutUnsigned (pStr, fill, width,  8, va_arg (ap, unsigned int)); break;
      case 'u': num = PutUnsigned (pStr, fill, width, 10, va_arg (ap, unsigned int)); break;
      case 'x':
      case 'X': num = PutUnsigned (pStr, fill, width, 16, va_arg (ap, unsigned int)); break;
      case 's': num = PutString   (pStr, va_arg (ap, char *));       break;
      case 'c': num = PutChar     (pStr, va_arg (ap, unsigned int)); break;
      default:
        return 0;
      }
      pFormat++;
      pStr += num;
      size += num;
    }
  }

  // NULL-terminated (final \0 is not counted)
  if (size < length) {
    *pStr = 0;
  } else {
    * (--pStr) = 0;
    size--;
  }

  return size;
}

