#include "Number.h"

static void factorial () {
  static constexpr unsigned N = 21u;
  console.printf("\t(W=%u bits) Vypocet faktorialu:\n", N<<4);
  uint16_t n = 1u;
  Number<N> fact (1u), sum;
  for (;;) {
    const uint16_t r = fact.mul (n);
    if (r) break;
    sum.add(fact);
    console.printf("%4u : ", n);
    fact.printf();
    n += 1u;
  }
  console.puts("Suma : ");
  sum.printf();
}

int main() {
  factorial();
  console.puts("\nKonec\n\n");
  return 0;
}

