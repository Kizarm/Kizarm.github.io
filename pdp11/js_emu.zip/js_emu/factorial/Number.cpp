#include "Number.h"
// Konstanty
const OutFmt FMT [2] = {
  {10u, 5u}, {16u, 4u}
};
const char * HEXSTRING = "0123456789ABCDEF";
/// Převod znaku na (hexa)decimální hodnotu, neplatný znak vrací 0
uint16_t cvalue (const char c) {
  const char cc = c | '\x20';
  if ((cc >= 'a') and (cc <= 'f')) return static_cast<unsigned> (cc - 'a') + 10u;
  if ((cc >= '0') and (cc <= '9')) return static_cast<unsigned> (cc - '0');
  return 0u;
}
/* Rutiny v assembleru jsou v C++, které umí raw string, je to přehlednější
*/
uint16_t AsmAdd (uint16_t * left, const uint16_t * right, const unsigned n, const uint16_t carry) {
  uint16_t result = 0;
  asm volatile (R"---(
  clr  %0
  bic  $0xFFFE,%4         # carry &= 1
LOOP:
  ror  %4                 # carry z minuleho kola
  adc  (%1)               # carry do dalsiho kola muze vzniknout bud zde
  bcc  NEXT1              # a to v jedinem pripade - (%2) = 0xFFFF a carry=1
  rol  %4
NEXT1:
  add  (%2)+, (%1)+       # nebo zde, nikdy ne oba najednou
  bcc  NEXT2
  rol  %4                 # pokud neni zadny carry, neroluje se vlevo a %4 je vzdy 0
NEXT2:                    # protoze na zacatku se rolovalo vpravo
  inc  %0
  cmp  %3, %0
  bne  LOOP
  
  clr  %0                 # zaverem prenest carry z %4 do %0 (result)
  ror  %4
  rol  %0
  #bpt
)---"
  :"=&r"(result) : "r"(left), "r"(right), "r"(n), "r"(carry) :);
  return result;
}
uint16_t AsmAdc (uint16_t * left, const unsigned n, const uint16_t carry) {
  uint16_t result = 0;
  asm volatile (R"---(
  clr  %0
  bic  $0xFFFE,%3         # carry &= 1
LOOPC:
  ror  %3                 # carry z minuleho kola
  adc  (%1)+
  rol  %3                 # carry do dalsiho kola

  inc  %0
  cmp  %2, %0
  bne  LOOPC
  
  clr  %0                 # zaverem prenest carry z %3 do %0 (result)
  ror  %3
  rol  %0
)---"
  :"=&r"(result) : "r"(left), "r"(n), "r"(carry) :);
  return result;
}
/***********************************************************/
uint16_t AsmShiftLeft (uint16_t * left, const unsigned n, const uint16_t carry) {
  uint16_t result = 0;
  asm volatile (R"---(
  clr  %0
  bic  $0xFFFE,%3         # carry &= 1
LOOPSL:
  ror  %3                 # carry z minuleho kola
  rol  (%1)+
  rol  %3

  inc  %0
  cmp  %2, %0
  bne  LOOPSL
  
  clr  %0
  ror  %3
  rol  %0
  #bpt
)---"
  :"=&r"(result) : "r"(left), "r"(n), "r"(carry) :);
  return result;
}

uint16_t AsmShiftRight (uint16_t * left, const unsigned n, const uint16_t carry) {
  unsigned result = 0;
  asm volatile (R"---(
  mov  %2, %0
  asl  %0                 # n * 2
  add  %0, %1             # od konce
  clr  %0
  bic  $0xFFFE,%3         # carry &= 1
LOOPSR:
  ror  %3                 # carry z minuleho kola
  ror  -(%1)
  rol  %3

  inc  %0
  cmp  %2, %0
  bne  LOOPSR
  
  clr  %0
  ror  %3
  rol  %0
  #bpt
)---"
  :"=&r"(result) : "r"(left), "r"(n), "r"(carry) :);
  return result;
}
/***********************************************************/

