#include "Console.h"

#if 0
int Console::printf (const char * fmt, ...) const {
  static constexpr int length = 0x100;
  /* static */ char buf [length]; // je celkem jedno jestli je to na zásobníku
  va_list   ap;
  va_start (ap, fmt);
  const int rc = mvsnprintf (buf, length, fmt, ap);
  va_end   (ap);
  puts (buf);
  return rc;
}
#endif // 0
void Console::puts (const char * const s) const {
  for (unsigned n=0; ; n++) {
    const char c = s[n];
    if (c == '\0') break;
    if (c == '\n') putc ('\r');
    putc (c);
  }
}

Console console;
