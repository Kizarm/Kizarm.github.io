#ifndef BIGFLOAT_H
#define BIGFLOAT_H
#include <stdint-gcc.h>
#include "Number.h"
static constexpr uint16_t ONE = 1u;
#ifdef PRECISION
static constexpr unsigned BigDimension = PRECISION;
#else
static constexpr unsigned BigDimension = 14u;
#endif // PRECISION
static constexpr uint16_t BigOffsetExp = (ONE<<14);
static constexpr unsigned MaxDecZeros  = 12u;      // maximalni dekadicky exponent je 2^MaxDecZeros

enum COMPARE {IS_LT=0, IS_EQ, IS_GT};

struct div_t {
  unsigned rem;
  unsigned quo;
};
extern void udiv (struct div_t * dt);

class BigFloat {
  union {
    struct {
      uint16_t e : 15;
      uint16_t s :  1;
    } s;
    uint16_t w;
  } u;
  Number<BigDimension> m;
  public:
    BigFloat () { clear (); u.s.e = BigOffsetExp; }
    BigFloat (const int16_t n)       {* this = n; }
    BigFloat (const BigFloat & n)    {* this = n; }
    BigFloat (const uint16_t  *  array);
    BigFloat (const char * const array);
    BigFloat & operator = (const BigFloat & n);
    BigFloat & operator = (const int16_t n);
    BigFloat & operator+= (const BigFloat & n);
    BigFloat & operator+= (const int16_t n) {*this += BigFloat(n); return * this;}
    BigFloat & operator-= (const BigFloat & n);
    BigFloat & operator-= (const int16_t n) {*this -= BigFloat(n); return * this;}
    BigFloat & operator*= (const BigFloat & n);
    BigFloat & operator*= (const int16_t n) {*this *= BigFloat(n); return * this;}
    BigFloat & operator/= (const BigFloat & n);
    BigFloat & operator/= (const int16_t n) {*this /= BigFloat(n); return * this;}
    
    const BigFloat operator+ (const BigFloat & n) const {
      BigFloat t(*this); t += n; return t;
    }
    const BigFloat operator- (const BigFloat & n) const {
      BigFloat t(*this); t -= n; return t;
    }
    const BigFloat operator* (const BigFloat & n) const {
      BigFloat t(*this); t *= n; return t;
    }
    const BigFloat operator/ (const BigFloat & n) const {
      BigFloat t(*this); t /= n; return t;
    }
    // porovnávat float na rovnost je asi dost blbost
    const bool operator== (const BigFloat & n) const {
      return compare (n) == IS_EQ ? true : false;
    }
    const bool operator!= (const BigFloat & n) const {
      return compare (n) != IS_EQ ? true : false;
    }
    const bool operator<= (const BigFloat & n) const {
      return compare (n) <= IS_EQ ? true : false;
    }
    const bool operator>  (const BigFloat & n) const {
      return compare (n) >  IS_EQ ? true : false;
    }
    const bool operator>= (const BigFloat & n) const {
      return compare (n) >= IS_EQ ? true : false;
    }
    const bool operator<  (const BigFloat & n) const {
      return compare (n) <  IS_EQ ? true : false;
    }
    BigFloat         operator-   () const { BigFloat t(*this); t.u.s.s ^= 1u; return t; }
    const BigFloat & operator+   () const { return * this; }
    
    BigFloat mul_pow_two (const int no) const { BigFloat t(*this); t.u.s.e += no; return t;  }
    BigFloat abs         () const { BigFloat t(*this); t.u.s.s  = 0u; return t; }
    bool     signbit     () const { return u.s.s ? true : false; }
    int16_t  bin_exponent() const { return u.s.e - BigOffsetExp; }
    bool     separe      (BigFloat & c, BigFloat & d) const;    // c ~ trunc (), d je desetinna cast
    BigFloat round       (const unsigned num = 0)     const;
    bool     is_small    () const; // pouze pro testy v iteraci, kde se zacina cislem kolem 1.0
    uint16_t to_u16      () const; // pouze mala kladna cisla
    unsigned to_string   (char * const str, const unsigned max) const;
    
    void     row     () const;
  protected:
    void     add (const BigFloat & right);
    void     sub (const BigFloat & right);
    void     mul (const BigFloat & right);
    void     div (const BigFloat & right);
    
    void     clear   (const bool mantisa_only = false);
    int      clz     () const;
    void     norm    (void);
    void     eque    (BigFloat & right);
    bool     bit_at  (const unsigned pos) const;
    void     set_at  (const unsigned pos, const bool b = true);
    bool     is_zero () const { return m.is_zero(); }
    int      decimals();
    COMPARE  compare (const BigFloat & n) const;
  //private:
};

#endif // BIGFLOAT_H
