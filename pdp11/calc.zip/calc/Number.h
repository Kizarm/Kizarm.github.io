#ifndef NUMBER_H
#define NUMBER_H
#include <stdint-gcc.h>
#include "Console.h"
// Pomocné externí funkce, částečně v assembleru.
extern "C" uint16_t AsmAdd (uint16_t * left, const uint16_t * right, const unsigned n, const uint16_t carry);
extern "C" uint16_t AsmAdc (uint16_t * left, const unsigned n, const uint16_t carry);
extern "C" uint16_t AsmShiftLeft  (uint16_t * left, const unsigned n, const uint16_t carry);
extern "C" uint16_t AsmShiftRight (uint16_t * left, const unsigned n, const uint16_t carry);
extern "C" uint16_t cvalue (const char c);
// Výstupní báze - lze přidávat např. octal, binary ...
enum BASES {
  DEC_BASE = 0, HEX_BASE, 
};
struct OutFmt {
  unsigned base;  // číselná báze (10, 16, ...)
  unsigned size;  // počet číslic v dané soustavě na uint16_t
};
extern const OutFmt FMT [2];
extern const char * HEXSTRING;

/** @class
 * Celočíselná aritmetika pro širší bezznaménková čísla.
 * Parametr N šablony určuje počet uint16_t slov, které aritmetika používá.
 * */

template<const unsigned N>class Number {
  static constexpr unsigned PN = N + 1u, TN = N + 2u, DN = N << 1, WN = N << 4;
  uint16_t data [N];        //!< vlastní data čísla
  public:
    /** Všechny možné použité konstruktory.
     * */
    explicit Number () noexcept {
      clear();
    }
    explicit Number (const uint16_t n) noexcept {
      clear(); data [0] = n;
    }
    template<const unsigned M> explicit Number (const Number<M> & other) noexcept {
      for (unsigned n=0u; n<M; n++) data [n] = other [n];
    }
    explicit Number (const Number<N-1u> & other) noexcept {
      clear(); for (unsigned n=0u; n<N-1; n++) data [n] = other [n];
    }
    explicit Number (const char * str, const uint16_t base = 10u) noexcept {
      for (unsigned n=0; n<N; n++) data [n] = 0u;
      unsigned n = 0u;
      for (;;) {
        const char c = str [n++];
        if (c == '\0') break;
        if (mul (base)) {
          console.puts("Input string owerflow\n");
          break;
        }
        add (Number(cvalue (c)));
      }
    }
    /** Velmi neefektivní metoda výstupu - opakované dělení hodně zdržuje.
     * Protože číslice vystupují odzadu, je potřeba bufer.
     *********************************************************************/
    void prints (const BASES b = DEC_BASE) const {
      const unsigned buflen = FMT [b].size * N + 2u;
      const unsigned base   = FMT [b].base;
      char buffer [buflen];
      int n = buflen;
      buffer [--n] = '\0';
      buffer [--n] = '\n';
      Number out (* this);
      bool flag = true;
      while (n > 0) {
        char c;
        if (flag) {
          const uint16_t v = out.div (base) & 0x0F;
          c = HEXSTRING [v];
          if (out.is_zero()) flag = false;
        } else c = ' ';
        buffer [--n] = c;
      }
      console.puts (buffer);
    }
    /** Efektivnější metoda.
     * Dělení je jen jedno, na začátku. Vtip je v tom, že metodou fra()
     * se vytvoří něco jako "desetinná část", ze které je pak možné
     * nechat vystupovat jednotlivé číslice v normálním pořadí pomocí násobení.
     * */
    void printf (const BASES b = DEC_BASE) const {
      const unsigned blen = FMT [b].size * N;
      const unsigned base = FMT [b].base;
      Number<TN> res = fra (blen, base);
      bool flag = false;
      for (unsigned n=0; n<blen; n++) {
        const uint16_t v = res.mul (base);
        if (v) flag = true;
        if (flag) console.putc (HEXSTRING [v]);
        else      console.putc (' ');
      }
      console.puts("\n");
    }
    /** Součet a rozdíl
     *********************************************************************/
    uint16_t add (const Number & other) {
      return AsmAdd (data, other.data, N, 0u);
    }
    uint16_t sub (const Number & other) {
      Number tmp (other);
      tmp.cpl();
      return add (tmp);
    }
    /** Násobení
     *********************************************************************/
    uint16_t mul (const uint16_t x) {
      Number<PN> dst, tmp (*this);
      for (int n=0; n<16; n++) {
        const uint16_t m = 1u << n;
        const uint16_t c = m & x ? 1u : 0u;
        if (c) dst.add (tmp);
        AsmShiftLeft  (tmp.addr(), PN, 0u);
      }
      for (unsigned n=0u; n<N; n++) data [n] = dst [n];
      return dst[N];    // preteceni
    }
    Number<DN> mul (const Number<N> & other) const {
      Number<DN> src, dst, tmp;
      for (unsigned n=0u; n<N; n++) {
        tmp [n] = data [n]; src [n] = other [n];
      }
      for (unsigned n=0u; n<WN;  n++) {
        const uint16_t c = AsmShiftRight(src.addr(), DN, 0u);
        if (c) dst.add (tmp);
        AsmShiftLeft  (tmp.addr(), DN, 0u);
      }
      return dst;   // vrací se dvojnásobná šířka, vlastní číslo se nemění !!!
    }
    /** Dělení
     *********************************************************************/
    uint16_t div (const uint16_t x) {
      Number<PN> src, dst (*this);
      src [N] = x;
      clear();
      for (unsigned n=0u; n<WN;  n++) {
        AsmShiftRight (src.addr(), PN, 0u);
        Number<PN> tmp (dst);
        const uint16_t c = tmp.sub (src);   // porovnáme
        if (c) {                            // lze odečíst, do dst dáme tedy rozdíl
          for (unsigned i=0; i<PN; i++) dst [i] = tmp [i];
        }
        AsmShiftLeft (data, N, c);          // 1 bit podílu
      }
      return dst[0];                        // zbytek,
      // podíl je v původním čísle
    }
    Number<N> div (const Number<N> & other) {
      Number<DN> src, dst;
      for (unsigned n=0u; n<N; n++) {
        src [N + n] = other [n];
        dst [n] = data [n];
      }
      clear();                              // začínáme od nuly
      for (unsigned n=0u; n<WN;  n++) {
        AsmShiftRight (src.addr(), DN, 0u);
        Number<DN> tmp (dst);
        const uint16_t c = tmp.sub (src);
        if (c) {
          for (unsigned i=0; i<DN; i++) dst [i] = tmp [i];
        }
        AsmShiftLeft (data, N, c);
      }
      Number<N> res;
      for (unsigned n=0u; n<N; n++) res [n] = dst [n];
      return res;                           // zbytek,
      // podíl je v původním čísle
    }
    bool is_zero () const {
      for (unsigned n=0; n<N; n++) {
        if (data [n]) return false;
      }
      return true;
    }
  protected:
    /** Pomocná metoda pro efektivnější výstup číslic, je to vlastně dělení.
     *********************************************************************/
    Number<TN> fra (const unsigned blen, const unsigned base) const {
      Number<TN> src, dst, res;
      src [1u] = 1u;
      for (unsigned n=0u; n<blen; n++) src.mul (base);
      for (unsigned n=0u; n<N; n++) dst [n+1u] = data [n];
      for (unsigned n=0u; n<(TN<<4);  n++) {
        AsmShiftRight (src.addr(), TN, 0u);
        Number<TN> tmp (dst);
        const uint16_t c = tmp.sub (src);   // porovnáme
        if (c) {                            // lze odečíst, do dst dáme tedy rozdíl
          for (unsigned i=0; i<TN; i++) dst [i] = tmp [i];
        }
        AsmShiftLeft (res.addr(), TN, c);          // 1 bit podílu
      }
      return res;
    }
    /// Nulování
    void clear () {
      for (unsigned n=0u; n<N; n++) data [n] = 0u;
    }
    /// Dvojkový komplement.
    void cpl () {
      for (unsigned n=0u; n<N; n++) data [n] = ~ data [n];
      AsmAdc (data, N, 1u);
    }
    /// Test na nenulový obsah.
  public:
    /** Pomocné metody
     *********************************************************************/
          uint16_t * addr () { return data; }
          uint16_t & operator[] (const unsigned n)       { return data [n]; }
    const uint16_t & operator[] (const unsigned n) const { return data [n]; }
};

#endif // NUMBER_H
