#include "Console.h"
#include "calc.h"

#define JS 1

static signed int PutChar (char * pStr, char c) {
  *pStr = c;
  return 1;
}
static signed int PutUnsignedInt (char * pStr, char fill, signed int width, unsigned int value) {
  signed int num = 0;
  // Take current digit into account when calculating width
  width--;
  // Recursively write upper digits
  struct div_t dt;
  dt.quo = 10u;     // Dělitel !
  dt.rem = value;   // Dělenec !
  udiv (& dt);      // Výsledek je quo = podíl, rem = zbytek
  if (dt.quo > 0) {
    num = PutUnsignedInt (pStr, fill, width, dt.quo);
    pStr += num;
  }
  // Write filler characters
  else {
    while (width > 0) {
      PutChar (pStr, fill);
      pStr++;
      num++;
      width--;
    }
  }
  // Write lower digit
  num += PutChar (pStr, dt.rem + '0');
  return num;
}

/************************************************************************************************/
static BigFloat add (const BigFloat & a, const BigFloat & b) {
  return a + b;
}
static BigFloat sub (const BigFloat & a, const BigFloat & b) {
  return a - b;
}
static BigFloat mul (const BigFloat & a, const BigFloat & b) {
  return a * b;
}
static BigFloat div (const BigFloat & a, const BigFloat & b) {
  return a / b;
}
/************************************************************************************************/
const char * const help_str = "RPN kalkulator se zvysenou presnosti\r\n"
"\tZadani cisla : dekadicke cislice \'.\' \'E\'\r\n"
"\tklavesa TAB meni znamenko, po E u exponentu\r\n"
"\tBACKSPACE maze posledni zadany znak, ESC cele cislo.\r\n"
"\tENTER ulozi cislo na zasobnik, ESC pak vyjme cislo ze zasobniku,\r\n"
"\t\'r\' maze cely zasobnik\r\n"
"\tZnaky \" + - * / \" - aritmeticke operace, \'p\' - ulozi na zasobnik PI\r\n"
"\t\'s\' - sin (x) \'c\' - cos (x) \'e\' - exp  (x) \'x\' - x^y\r\n"
"\t\'q\' - sqrt(x) \'l\' - log (x) \'L\' - log10(x) \'d\' - dup stack top\r\n"
"\t\'w\' - prohodi 2 vrchni polozky na zasobniku (pokud tam jsou)\r\n"
"\t\'h\' - vypise tento text, SPACE cely zasobnik\r\n"
;

void Calc::init() {
  stack.init();
  index = 0u;
  ty    = TYPE_OPERATION;
  put_str(help_str);
}
void Calc::newline() { // hack - JS emulátor VT52 nepřepíše znaky po <CR>
#if JS
  // takže je smažeme takto
  for (unsigned n=0; n<index; n++) console.putc('\b');
#endif
}

void Calc::show () {
  newline();
  console.putc ('\r');
  int m;
  const BigFloat b = stack.top (m);
  if (m < 0) {
    put_str ("Empty Stack !\r\n");
  } else {
    unsigned l = show_num (b, m);
    console.puts (buffer, l);
  }
  index = 0;
}
void Calc::show_all () {
  int m=0;
  put_str ("\rStack:\r\n");
  for (const BigFloat & b: stack) {
    unsigned l = show_num (b, m++);
    console.puts (buffer, l);
  }
  index = 0;
}
unsigned Calc::show_num (const BigFloat& b, const int order) {
  unsigned l = b.to_string(buffer, number_len);
  while (l < (number_len - 28)) buffer [l++] = ' ';
  l += PutChar (buffer + l, '(');
  l += PutUnsignedInt (buffer + l, '0', 2, order);
  l += PutChar (buffer + l, ')');
  l += PutChar (buffer + l, '\r');
  l += PutChar (buffer + l, '\n');
  return l;
}

void Calc::handle_enter() {
  if (index and (ty < TYPE_OPERATION)) {
    buffer [index] = '\0';
    BigFloat a (buffer);
    stack.push(a);
    show();
  }
  ty = TYPE_OPERATION;
  index = 0;
}
void Calc::handle_escape() {
  if (ty == TYPE_OPERATION) {
    BigFloat x, y;
    if (!stack.pop(x)) stack.push(y);
    show();
    return;
  }
  unsigned i = 0;
  buffer [i++] = '\r';
  for (unsigned n=0; n<index; n++) buffer [i++] = ' ';
  buffer [i++] = '\r';
  console.puts (buffer, i);
  ty = TYPE_OPERATION;
  index = 0;
}
void Calc::handle_backspace() {
  if (ty == TYPE_OPERATION) return;
  if (index > 0) {
    unsigned n = index - 1;
    if ((buffer[n] != '+') or (buffer[n] != '-')) {
      buffer [n] = '\0';
      index = n;
      console.puts("\b \b");
    }
  }
}
void Calc::handle_number (const char c) {
  if (ty == TYPE_OPERATION) {
    ty = TYPE_MANTISA;
    buffer [index++] = '+';
    buffer [index++] = c;
    console.putc ('\r');
    console.puts (buffer, index);
    return;
  }
  buffer [index++] = c;
  console.putc (c);
}
void Calc::handle_dot() {
  if (ty == TYPE_MANTISA) {
    buffer [index++] = '.';
    console.putc ('.');
  }
}
void Calc::handle_exp() {
  if (ty == TYPE_MANTISA) {
    ty = TYPE_EXPONENT;
    buffer [index++] = 'E';
    buffer [index++] = '+';
    console.puts("E+");
    return;
  }
}
void Calc::handle_sign() {
  if (ty == TYPE_OPERATION) return;
  int k = index;
  if (k < 1) return;
  while (k--) {
    if (buffer[k] == '+') {
      buffer[k] = '-';
      break;
    }
    if (buffer[k] == '-') {
      buffer[k] = '+';
      break;
    }
  }
  newline();
  console.putc ('\r');
  console.puts (buffer, index);
}
void Calc::put_str (const char * str) {
  console.puts (str);
}

void Calc::handle_f1 (const char * dsc, f_1 f) {
  if (ty != TYPE_OPERATION) return;
  put_str (dsc);
  BigFloat a;
  stack.pop(a);
  a = wrap_f1 (a, f);
  stack.push(a);
  show();
}
void Calc::handle_f2 (const char * dsc, f_2 f) {
  if (ty != TYPE_OPERATION) return;
  put_str (dsc);
  BigFloat a,b;
  stack.pop(a);
  stack.pop(b);
  b = wrap_f2 (b, a, f);
  stack.push(b);
  show();
}
bool Calc::loop() {
  char c = console.getc();
  if (c == '\x7F') {        // backspace
    handle_backspace();
  } else if (c == ' ') {    // SPACE
    show_all();
  } else if (c == '\r') {   // ENTER
    handle_enter();
  } else if (c == '\x1B') { // ESCAPE
    handle_escape();
  } else if (c == '\t') {   // CHANGE SIGN MANTISA / EXPONENT
    handle_sign();
  } else if (c == '.') {
    handle_dot();
  } else if (c == 'E') {
    handle_exp();
  } else if (c == 'h') {
    put_str (help_str);
  } else if (c == 'd') {    // DUPLICATE STACK TOP
    BigFloat a;
    stack.pop (a);
    stack.push(a);
    stack.push(a);
    show();
  } else if (c == 'w') {    // SWAP STACK TOP <-> TOP-1
    stack.swap();
    show();
  } else if (c == 'r') {    // RESET
    stack.clear();
    show();
  } else if ((c >= '0') and (c <= '9')) {
    handle_number (c);
  } else if (c == '+') {    // Základní operace
    handle_f2 ("x+y\r\n", add);
  } else if (c == '-') {
    handle_f2 ("x-y\r\n", sub);
  } else if (c == '*') {
    handle_f2 ("x*y\r\n", mul);
  } else if (c == '/') {
    handle_f2 ("x/y\r\n", div);
#if 1
  } else if (c == 'p') {  // PI
    const BigFloat pi (table_m_pi);
    stack.push (pi);
    show();
  } else if (c == 'q') {  // SQRT , funkce
    handle_f1 ("sqrt\r\n", sqrt);
  } else if (c == 'e') {  // EXP
    handle_f1 ("exp\r\n",  exp);
  } else if (c == 'l') {  // LN
    handle_f1 ("log\r\n",  log);
  } else if (c == 'L') {  // LOG
    handle_f1 ("log10\r\n",log10);
  } else if (c == 's') {  // SIN
    handle_f1 ("sin\r\n",  sin);
  } else if (c == 'c') {  // COS
    handle_f1 ("cos\r\n",  cos);
  } else if (c == 'x') {  // POW
    handle_f2 ("x^y\r\n",  pow);
#endif
  } else {
    if (c == '\x03') {
      put_str("Ctrl-C pressed\r\n");
      return false;
    }
  }
  return true;
}

static Calc calc;

int main () {
  calc.init ();
  while (calc.loop()) {
  }
  console.puts("Bye\n");
}
