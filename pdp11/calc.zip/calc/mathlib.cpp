//#include <stdio.h>
#include "mathlib.h"
#include "pdp_tab.h"

// sqrt(a), Newtonova metoda
BigFloat sqrt (const BigFloat & a) {
  if (a <= (int16_t)0) return BigFloat((int16_t)0);
  const int exp = a.bin_exponent();
  BigFloat x0(a.mul_pow_two(-(exp >> 1))), x1;
  unsigned n;
  for (n=0; n<50; n++) {
    x1 = (x0 + a / x0).mul_pow_two(-1);
    const BigFloat e = (x1 - x0).abs();
    const int k = (BigDimension << 5) + e.bin_exponent() - (exp >> 1);
    if (k < 2) break;   // relativně malé číslo
    x0 = x1;
  }
  return x1;
}
static BigFloat euler (const BigFloat & a) {
  BigFloat suma, element;
  int counter;
  
  element = (int16_t) 1;
  suma    = (int16_t) 0;
  counter = 1;
  for (unsigned n=0; n<100; n++) {
    suma    += element;
    if (element.is_small()) break;
    element *= a / (int16_t) counter;
    counter += 1;
  }
  return suma;
}
extern "C" int wrap_clz (const uint16_t a);
static BigFloat exp_mul (const uint16_t n) {
  const uint16_t me = ((ONE << (MaxDecZeros-1)) * 589u) >> 8;
  const uint16_t k = n > me ? me : n;
  // TODO : osetrit chybu preteceni
  const int m = 16 - wrap_clz (k);
  BigFloat x (table_m_e), y((int16_t)1);
  for (int i=0; i<m; i++) {
    const uint16_t si = 1u << i;
    if (k & si) y *= x;
    x *= x;
  }
  return y;
}
static BigFloat u_exp (const BigFloat & a) {
  BigFloat c,d;
  if (a.separe (c,d)) {
    return exp_mul (c.to_u16()) * euler (d);
  } else {
    return euler (a);
  }
}
BigFloat exp (const BigFloat & a) {
  if (a > (int16_t)0) {
    return u_exp (a);
  }
  if (a < (int16_t)0) {
    const BigFloat one ((int16_t)1);
    return one / u_exp (-a);
  }
  return BigFloat ((int16_t)0);
}
// even = true -> sin(a), false -> cos(a), z definice
static BigFloat z_fnc (const BigFloat & a, const bool even) {
  BigFloat result((int16_t)0), element = even ? a : (int16_t)1, temp;
  int16_t divider = even ? 1 : 0;
  const BigFloat aa = a * a;
  for (unsigned n=0; n<100; n++) {
    result  += element;
    if (element.is_small()) break;
    divider += 1;
    temp     = divider;
    divider += 1;
    temp    *= divider;
    element *= - (aa / temp);
  }
  return result;
}
static BigFloat r_fnc (const BigFloat & a, const bool even) {
  const BigFloat mpi (table_m_pi);
  if (a > mpi) {
    // obě funkce mají opačnou hodnotu po polovině periody
    return -r_fnc (a - mpi, even);
  } else {
    const BigFloat hpi (mpi.mul_pow_two(-1));
    if (a > hpi) {
      // lichá funkce je symetrická kolem čtvrtperiody
      if (even) return +r_fnc (mpi - a, even);
      // sudá funkce je antisymetrická kolem čtvrtperiody
      else      return -r_fnc (mpi - a, even);
    } else {
      // zde už bude argument menší než pi-4
      const BigFloat qpi (hpi.mul_pow_two(-1));
      if (a > qpi) {    // ukončení rekurze
        // cos(x) = sin(pi/2-x), sin(x) = cos(pi/2-x)
        return z_fnc (hpi - a, !even);
      } else {
        return z_fnc (a,        even);
      }
    }
  }
}

static BigFloat w_fnc (const BigFloat & a, const bool even) {
  // počítat budeme jen pro kladný argument
  const BigFloat arg = a < 0.0 ? -a : +a;
  // odstraníme periodičnost
  const BigFloat ipd (BigFloat (table_r_pi).mul_pow_two(-1));
  const BigFloat phi = arg * ipd;
  BigFloat c, d;
  if (phi.separe (c, d)) {
    const BigFloat dpi (BigFloat (table_m_pi).mul_pow_two(+1));
    d *= dpi;
  } else {
    d = arg;
  }
  const BigFloat result = r_fnc (d, even);
  // lichá funkce je antisymetrická kolem počátku
  if (even) return a < (int16_t) 0 ? -result : +result;
  // sudá funkce je symetrická kolem počátku
  return result;
}
BigFloat sin (const BigFloat & a) {
  return w_fnc (a, true);
}
BigFloat cos (const BigFloat & a) {
  return w_fnc (a, false);
}
static BigFloat ln_r (const BigFloat & a) {
  const BigFloat m (a*a);
  BigFloat s (a), e (a);
  int n = 1, i;
  for (i=0; i<1000; i++) {
    n += 2;
    e *= m;
    s += e / (int16_t) n;
    if (e.is_small()) break;
  }
  s *= 2;
  return s;
}
BigFloat log (const BigFloat & a) {
  if (a <= (int16_t)0) return BigFloat ((int16_t)0);
  // upravit argument do mezí <1/sqrt(2), sqrt(2)>
  const int16_t k = a.bin_exponent();
  BigFloat arg (a.mul_pow_two(-k)), e (k);
  do {  // pro rychlejší konvergenci
    const BigFloat sq2 (table_sq2), sqi (sq2.mul_pow_two(-1)), half (BigFloat((int16_t)1).mul_pow_two(-1));
    if (arg > sqi) {
      arg *= sqi;
      e += half;
    }
    if (arg < sq2) {
      arg *= sq2;
      e -= half;
    }
  } while (false);
  // takhle se to počítá např. v newlib
  const BigFloat f = arg - (int16_t)1;
  const BigFloat s = f / (f + (int16_t)2);
  // pak ln (1+f) = ln (1+s) - ln (1-s), kolem 1 se do Taylorovy řady rozvine pravá strana -> rychlejší, vypadnou sudé členy
  e *= BigFloat (table_ln2);
  return ln_r (s) + e;
}
BigFloat log10 (const BigFloat & a) {
  const BigFloat ln10i (table_10i);
  return ln10i * log (a);
}
BigFloat pow (const BigFloat & z, const BigFloat & n) {
  return exp (n * log(z));
}
/******************************************************************************/
