#ifndef _BIG_MATH_H
#define _BIG_MATH_H
#include "bigfloat.h"

extern BigFloat sqrt (const BigFloat & a);
extern BigFloat exp  (const BigFloat & a);
extern BigFloat sin  (const BigFloat & a);
extern BigFloat cos  (const BigFloat & a);
extern BigFloat log  (const BigFloat & a);
extern BigFloat log10(const BigFloat & a);
extern BigFloat pow  (const BigFloat & z, const BigFloat & n);

#endif //  _BIG_MATH_H
