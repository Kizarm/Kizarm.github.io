#include <stdio.h>
#include <string>
#include "table.h"

using namespace std;

static const char * header = R"---(#ifndef _TABLE_BIG_H_
#define _TABLE_BIG_H_
#include <stdint-gcc.h>
static constexpr unsigned TabDimension = %du;
static constexpr unsigned TabDecZeros  = %du;
extern const uint16_t table_high [TabDecZeros][TabDimension+1u];
extern const uint16_t table_low  [TabDecZeros][TabDimension+1u];
extern const uint16_t table_m_pi [TabDimension+1u];
extern const uint16_t table_r_pi [TabDimension+1u];
extern const uint16_t table_m_e  [TabDimension+1u];
extern const uint16_t table_r_e  [TabDimension+1u];

extern const uint16_t table_sq2  [TabDimension+1u];
extern const uint16_t table_ln2  [TabDimension+1u];
extern const uint16_t table_10i  [TabDimension+1u];
#endif //  _TABLE_BIG_H_
)---";
static unsigned TDM = 0u;
static unsigned TDZ = 12u;

static bool print_row (FILE * out, const uint32_t * const number) {
  const unsigned O_32 = (1u<<30), O_16 = (1u<<14);
  union {
    struct {
      uint32_t e : 31;
      uint32_t s :  1;
    } s;
    uint32_t w;
  } u_32n;
  union {
    struct {
      uint16_t e : 15;
      uint16_t s :  1;
    } s;
    uint16_t w;
  } u_16n;
  const uint32_t p = number [0];
  u_32n.w = p;
  int e = u_32n.s.e - O_32;
  if ((e >= (int) O_16) or (e <= -(int) O_16)) {
    printf ("Exponent overflow %08X\n", e);
    return false;
  }
  u_16n.w = 0u;
  u_16n.s.e = e + O_16;
  fprintf(out, "  { 0x%04Xu, ", u_16n.w);
  unsigned m = TabDimension + 1u;
  for (unsigned n=1u; n<m; n++) {
    const uint32_t w = number [n];
    fprintf (out, "0x%04Xu, 0x%04Xu, ", w >> 16, w & 0xFFFFu);
  }
  fprintf(out, "}");
  return true;
}

static void print_table (FILE * out, bool hi) {
  const char * tn = hi ? "table_high" : "table_low";
  auto const * const nb = hi ? table_high : table_low;
  fprintf (out, "const uint16_t %s [TabDecZeros][TabDimension+1u] = {\n", tn);
  for (unsigned n=0; n<TDZ; n++) {
    if (print_row (out, nb [n])) fprintf(out, ",\n");
    else { break; }
  }
  fprintf (out, "};\n");
}
static void print_const (FILE * out, const char * name, const uint32_t * const number) {
  fprintf(out, "const uint16_t %11s [TabDimension+1u] = ", name);
  print_row (out, number);
  fprintf(out, ";\n");
}

static void print_code (const char * name) {
  string hn = string (name) + ".h";
  string cn = string("../") + string (name) + ".cpp";
  FILE * out = fopen (cn.c_str(), "w");
  fprintf(out, "#include \"%s\"\n", hn.c_str());
  print_table (out, true);
  print_table (out, false);
  print_const (out, "table_m_pi", table_m_pi);
  print_const (out, "table_r_pi", table_r_pi);
  print_const (out, "table_m_e", table_m_e);
  print_const (out, "table_r_e", table_r_e);
  print_const (out, "table_sq2", table_sq2);
  print_const (out, "table_ln2", table_ln2);
  print_const (out, "table_10i", table_10i);
  fclose (out);
}
static void print_header (const char * name) {
  string hn = string("../") +  string (name) + ".h";
  FILE * out = fopen (hn.c_str(), "w");
  fprintf(out, header, TDM, TDZ);
  fclose (out);
}

int main (void) {
  const char * name = "pdp_tab";
  TDM = TabDimension * 2u;
  print_code   (name);
  print_header (name);
  return 0;
}
