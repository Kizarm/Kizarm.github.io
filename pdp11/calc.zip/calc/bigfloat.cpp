#include "bigfloat.h"

#define assert(p) (void)(p)
#define debug(...)

//#define GEN_TABLE
#ifdef GEN_TABLE
const uint16_t table_high [][1] = {};
const uint16_t table_low  [][1] = {};
#else
#include "pdp_tab.h"
static_assert (BigDimension <= TabDimension, "generate large table (BigDimension)");
static_assert (MaxDecZeros  <= TabDecZeros , "generate large table (MaxDecZeros)");
#endif

extern "C" int wrap_clz (const uint16_t a);
/// Tohle odstraní knihovní funkce libc, ale potřebuje EIS (PDP11/70)
void udiv (struct div_t * dt) {
  asm volatile (
  "clr r4\t\n"
  "mov (%0)+, r5\t\n"
  "div (%0) , r4\t\n"
  "mov r4,  (%0)\t\n"
  "mov r5, -(%0)\t\n"
  ::"r"(dt):"r4","r5");
}
///////////////////////////////////////////////////////

static const char * decimal_string = "0123456789";
static unsigned exp_to_dec (char * const ptr, int num) {
  unsigned res = 0;
  ptr [res++] = 'E';
  if (num < 0) { ptr[res++] = '-'; num = - num; }
  else         { ptr[res++] = '+';              }
  int k = (res - 1) + 4;
  while (--k) {
    struct div_t dt;
    dt.quo = 10u;     // Dělitel !
    dt.rem = num;     // Dělenec !
    udiv (& dt);      // Výsledek je quo = podíl, rem = zbytek
    ptr [k+1] = decimal_string [dt.rem];
    res += 1;
    num = dt.quo;
  }
  return res;
}
static void negation  (uint16_t * const m, const unsigned len) {
  for (unsigned n=0; n<len; n++) m[n] = ~ m[n];
}
static void shift_left  (uint16_t * const m, const unsigned len, const unsigned bits) {
  const unsigned int c = bits >> 4;
  const unsigned int b = bits & 0xF;
  const unsigned int d = 16 - b;
  unsigned int i = len;
  if (!b) {
    while (i--) {
      const int l = i - c;
      uint16_t  t;
      if (l>=0) t = m[l];
      else      t = 0u;
      m [i] = t;
    }
    return;
  }
  while (i--) {
    uint16_t r;
    const int l = i - c;
    const int k = l - 1;
    if (k>=0) r = m[k] >> (d);
    else      r = 0u;
    uint16_t t;
    if (l>=0) t = (m[l] << b);
    else      t = 0u;
    m [i] = t | r;
  }
}
static void shift_right (uint16_t * const m, const unsigned len, const unsigned bits) {
  const unsigned int c = bits >> 4;
  const unsigned int b = bits & 0xF;
  const unsigned int d = 16 - b;
  unsigned int i = 0;
  const int mm = (int) len;
  if (!b) {
    while (i < len) {
      const int l = i + c;
      uint16_t  t;
      if (l<mm) t = m[l];
      else      t = 0u;
      m [i] = t;
      i += 1;
    }
    return;
  }
  while (i < len) {
    uint16_t r;
    const int l = i + c;
    const int k = l + 1;
    if (k<mm) r = m[k] << d;
    else      r = 0u;
    uint16_t t;
    if (l<mm) t = (m[l] >> b);
    else    t = 0u;
    m [i] = t | r;
    i += 1;
  }
}
static inline void shift (uint16_t * const m, const unsigned len, const int offset) {
  if (!offset) return;
  if (offset > 0) return shift_left  (m, len, +offset);
  if (offset < 0) return shift_right (m, len, -offset);
}
static inline void shift_div (uint16_t * const m, const unsigned len) {
  unsigned i = 0;
  while (i < len) {
    const unsigned k = i + 1;
    uint16_t r;
    if (k<len) r = m[k] << 15;
    else       r = 0x8000u;
    uint16_t t = m[i] >> 1;
    m [i] = t | r;
    i += 1;
  }
}
/********************************************************************/
BigFloat::BigFloat (const uint16_t * array) {
  unsigned k=0;
  u.w = array[k];
  k = BigDimension;
  for (unsigned i=0; i<BigDimension; i++) m [i] = array[k--];
}
BigFloat::BigFloat (const char * const array) {
  clear ();
  u.s.e = BigOffsetExp;
  unsigned n = 0;
  int  exp  = 0, pdp = 0;
  bool pdpc = false;
  bool mantisa = true, signm = false, signe = false;
  for (;;) {
    const char c = array [n++];
    if (c == '\0') break;
    if (c == '-') {
      if (mantisa) {
        signm = true;
      } else {
        signe = true;
      }
    } else if (c == '+') {
      // do nothing
    } else if (c == '.') {
      pdpc = true;
    } else if ((c == 'e') or (c == 'E')) {
      pdpc = false;
      mantisa = false;
    } else {
      const int res = c - '0';
      if (res < 0) continue;
      if (res > 9) continue;
      if (mantisa) {
        mul ((int16_t)10);
        add ((int16_t)res);
        if (pdpc) pdp += 1;
      } else {
        exp *= 10;
        exp += res;
      }
    }
  }
  if (signm) u.s.s = 1u;
  if (signe) exp = - exp;
  exp -= pdp;
  if (exp > 0) {
    const uint16_t mask = + exp;
    for (unsigned k=0; k<MaxDecZeros; k++) {
      const uint16_t bpos = 1u << k;
      if (mask & bpos) {
        BigFloat x (table_high [k]);
        mul (x);
      }
    }
  }
  if (exp < 0) {
    const uint16_t mask = - exp;
    for (unsigned k=0; k<MaxDecZeros; k++) {
      const uint16_t bpos = 1u << k;
      if (mask & bpos) {
        BigFloat x (table_low [k]);
        mul (x);
      }
    }
  }
  norm();
}

/********************************************************************/
BigFloat & BigFloat::operator= (const BigFloat & n) {
  u.w = n.u.w;
  for (unsigned i=0; i<BigDimension; i++) m [i] = n.m [i];
  return * this;
}
BigFloat & BigFloat::operator= (const int16_t n) {
  int16_t k = n;
  clear ();
  if (!k) {
    u.s.e = BigOffsetExp;
    return * this;
  }
  if (k < 0) {
    u.s.s = 1;
    k =-n;
  } 
  m[0] = static_cast<uint16_t> (k);
  u.s.e  = BigOffsetExp + (BigDimension << 4);
  norm ();
  return * this;
}
/********************************************************************/
BigFloat& BigFloat::operator+= (const BigFloat& n) {
  debug("call: \"%s\"\n", __FUNCTION__);
  if (n.is_zero()) return * this;
  BigFloat t (n);     // local copy
  if (u.s.s) {
    u.s.s = 0u;
    if (t.u.s.s) {
      t.u.s.s = 0u;
      add (t);        // - -
      u.s.s ^= 1u;
    } else   {
      t.sub (*this);  // - +
      *this = t;
    }
  } else {
    if (t.u.s.s) {
      t.u.s.s = 0u;
      sub (t);        // + -
    } else   {
      add (t);        // + +
    }
  }
  return * this;
}
BigFloat& BigFloat::operator-= (const BigFloat& n) {
  debug("call: \"%s\"\n", __FUNCTION__);
  if (n.is_zero()) return * this;
  BigFloat t (n);     // local copy
  if (u.s.s) {
    u.s.s = 0u;
    if (t.u.s.s) {
      t.u.s.s = 0u;
      sub (t);        // - -
    } else   {
      t.add (*this);  // - +
      *this = t;
    }
    u.s.s ^= 1u;
  } else {
    if (t.u.s.s) {
      t.u.s.s = 0u;
      add (t);        // + -
    } else   {
      sub (t);        // + +
    }
  }
  return * this;
}
BigFloat& BigFloat::operator*= (const BigFloat& n) {
  mul (n);
  return * this;
}
BigFloat& BigFloat::operator/= (const BigFloat& n) {
  div (n);
  return * this;
}

/********************************************************************/
void BigFloat::clear (const bool mantisa_only) {
  if (!mantisa_only) u.w = 0u;
  for (unsigned i=0; i<BigDimension; i++) m [i] = 0u;
}
void BigFloat::norm (void) {
  if (m.is_zero()) {
    u.s.e = BigOffsetExp;
    u.s.s = 0u;
    return;
  }
  const int un = clz ();
  //console.printf("clz = %u\r\n", un);
  if (!un) return;
  shift_left (m.addr(), BigDimension, un);
  u.s.e -= un;
}
int BigFloat::clz (void) const {
  int res = 0;
  int i   = BigDimension;
  while (i--) {
    if (m[i] == 0u) res += 16;
    else {
      res += wrap_clz (m[i]);
      break;
    }
  }
  return res;
}
void BigFloat::eque (BigFloat & right) {
  if (u.s.e > right.u.s.e) {
    const unsigned b = u.s.e - right.u.s.e;
    shift_right (right.m.addr(), BigDimension, b);
    right.u.s.e = u.s.e;
  }
  if (right.u.s.e > u.s.e) {
    const unsigned b = right.u.s.e - u.s.e;
    shift_right (m.addr(), BigDimension, b);
    u.s.e = right.u.s.e;
  }
}

void BigFloat::add (const BigFloat & right) {
  assert ((u.s.s == 0u) and (right.u.s.s == 0));
  debug("call: \"%s\"\n", __FUNCTION__);
  BigFloat cp (right);
  eque (cp);
  const unsigned b = AsmAdd (m.addr(), cp.m.addr(), BigDimension, 0u);
  if (b) {
    shift_right (m.addr(), BigDimension, 1);
    m[BigDimension-1] |= (ONE<<15);
    u.s.e += 1;
  }
  norm();
}
void BigFloat::sub (const BigFloat& right) {
  assert ((u.s.s == 0u) and (right.u.s.s == 0));
  debug("call: \"%s\"\n", __FUNCTION__);
  BigFloat cp (right);
  eque (cp);
  negation (cp.m.addr(), BigDimension);
  const unsigned b = AsmAdd (m.addr(), cp.m.addr(), BigDimension, 1u);
  if (!b) { // vysledek je zaporny
    u.s.s = 1;
    BigFloat t0;
    negation (m.addr(), BigDimension);
    AsmAdd (m.addr(), t0.m.addr(), BigDimension, 1u);
  }
  norm();
}
bool BigFloat::bit_at (const unsigned int pos) const {
  const unsigned c = pos >> 4;
  const unsigned b = pos & 0xF;
  const uint16_t r = m [c] & (1u << b);
  return r ? true : false;
}
void BigFloat::set_at (const unsigned int pos, const bool value) {
  const unsigned c = pos >> 4;
  const unsigned b = pos & 0xF;
  if (value) m[c] |=  (1u << b);
  else       m[c] &= ~(1u << b);
}
void BigFloat::mul (const BigFloat& right) {
  u.s.e += right.u.s.e - BigOffsetExp;
  u.s.s ^= right.u.s.s;
  const unsigned dm = BigDimension << 1;
  Number<dm> tt = m.mul (right.m);
  for (unsigned n=0; n<BigDimension; n++) {
    m [n] = tt [n + BigDimension];
  }
  norm();
}

void BigFloat::div (const BigFloat& right) {
  assert (!right.is_zero());
  if (is_zero()) return;
  debug("call: \"%s\"\n", __FUNCTION__);
  u.s.e -= right.u.s.e - BigOffsetExp;
  u.s.s ^= right.u.s.s;

  const unsigned dm = BigDimension << 1;
  uint16_t tt[dm], td[dm], ts[dm];
  for (unsigned n=0; n<dm; n++) {
    td[n] = 0u; ts[n] = ~0u;
  }
  for (unsigned n=0; n<BigDimension; n++) {
    ts[BigDimension + n] = ~right.m[n]; td[BigDimension + n] = m[n];
  }
  clear (true);
  const unsigned cycles = BigDimension << 4;
  for (unsigned n=0; n<cycles; n++) {
    for (unsigned k=0; k<dm; k++) tt [k] = td [k];    // local copy
    //print_buf (td, dm);
    //print_buf (ts, dm);
    unsigned r = AsmAdd (td, ts, dm, 1u);
    //printf("%3d div : carry=%d\n", n, r);
    if (r == 0) {
      for (unsigned k=0; k<dm; k++) td [k] = tt [k];  // restore
    } else {
      set_at (cycles - (n + 1));
    }
    shift_div (ts, dm);
  }
  u.s.e += 1u; // ???
  norm();
  //print();
}
COMPARE BigFloat::compare (const BigFloat & n) const {
  BigFloat a (*this), b (n);
  a.norm(); b.norm();
  if (!a.u.s.s and  b.u.s.s) {return IS_GT;}  // +a -b
  if ( a.u.s.s and !b.u.s.s) {return IS_LT;}  // -a +b
  if (!a.u.s.s and !b.u.s.s) {                // +a +b
    int16_t k = a.u.s.e - b.u.s.e;
    const int16_t l = (BigDimension << 4) - 16u;
    if (k > +l) {return IS_GT;}
    if (k < -l) {return IS_LT;}
    a -= b;
    if (a.is_zero()) {return IS_EQ;}
    if (a.u.s.s)     {return IS_LT;}
    else             {return IS_GT;}
  }
  if ( a.u.s.s and  b.u.s.s) {                // -a -b
    int16_t k = a.u.s.e - b.u.s.e;
    const int16_t l = (BigDimension << 4) - 16u;
    if (k > +l) {return IS_LT;}
    if (k < -l) {return IS_GT;}
    a -= b;
    if (a.is_zero()) {return IS_EQ;}
    if (a.u.s.s)     {return IS_LT;}
    else             {return IS_GT;}
  }
  return IS_EQ;
}

bool BigFloat::is_small () const {
  int e = BigOffsetExp - u.s.e;
  if (e >= (int) (BigDimension << 4) - 2) return true;
  return false;
}

uint16_t BigFloat::to_u16() const {
  BigFloat t (*this);
  int texp = t.u.s.e - BigOffsetExp;
  if (texp <= 0)       return  0u;
  if (texp > (1 << 4)) return ~0u;
  shift_right (t.m.addr(), BigDimension, (BigDimension << 4) - texp);
  return t.m [0];
}

unsigned int BigFloat::to_string (char * const str, const unsigned int max) const {
  const unsigned mchars = (BigDimension * 5u) - 4u;
  unsigned  res = 0u;
  if (max < mchars + 12u) {     // input is short
    str [res] = '\0';
    return res;
  }
  if (is_zero()) {
    str [res++] = '0';
    str [res]   = '\0';
    return res;
  }
  BigFloat cp (*this);
  
  do { // hack dame sem - kdyz to vyjde vetsi, vadi to mene
    BigFloat z;
    z.m[0] = 0x60u;  // nejnizsi hexadecimalni cislice
    if  (AsmAdd (cp.m.addr(), z.m.addr(), BigDimension, 0u)) {
      shift_right (cp.m.addr(), BigDimension, 1);
      cp.m[BigDimension-1] |= (ONE<<15);
      cp.u.s.e += 1;
    }
    cp.norm();
  } while (false);
  
  if (cp.u.s.s) str [res++] = '-';
  else          str [res++] = '+';
  cp.u.s.s = 0;
  const int dec = cp.decimals();
  shift (cp.m.addr(), BigDimension, cp.u.s.e - BigOffsetExp);
  const bool format = ((dec > 0) and (dec < (int) mchars)) ? false : true;
  for (unsigned k=0; k<mchars; k++) {
    uint16_t top = cp.m.mul (10u);
    str [res++] = decimal_string [top];
    if (format) {
      if (res == 2) str [res++] = '.';
    } else {
      if ((int) res == dec + 1) str [res++] = '.';
    }
  }
  
  if (format) res += exp_to_dec (str + res, dec - 1);
  str [res] = '\0';
  return res;
}
int BigFloat::decimals() { // jen kladna cisla
  //print();
  assert (u.s.s == 0u);
  const uint16_t cmp = u.s.e;
  uint16_t exp = 0u;
  int k = MaxDecZeros, result;
  if        (cmp < BigOffsetExp) {  // low
    while (k--) {
      if (*this < BigFloat (table_low [k])) {
        mul (BigFloat (table_high [k]));
        exp |= (ONE << k);
      }
    }
    result = - exp;
  } else if (cmp > BigOffsetExp) {  // high
    while (k--) {
      if (*this >= BigFloat (table_high [k])) {
        mul (BigFloat (table_low [k]));
        exp |= (ONE << k);
      }
    }
    if (cmp > BigOffsetExp) {
      mul (BigFloat(table_low[0]));
      exp += 1;
    }
    result = + exp;
  } else {
    return 0u;
  }
  return result;
}
bool BigFloat::separe (BigFloat & c, BigFloat & d) const {
  if (u.s.e > BigOffsetExp) {
    c = * this; d = * this;
    const unsigned shl = u.s.e - BigOffsetExp;
    shift_left  (d.m.addr(), BigDimension, shl);
    d.u.s.e -= shl;
    d.norm();
    const unsigned shr = (BigDimension << 4) - shl;
    shift_right (c.m.addr(), BigDimension, shr);
    c.u.s.e += shr;
    c.norm();
    return true;
  } else
    return false;
}
BigFloat BigFloat::round (const unsigned int num) const {
  BigFloat t (*this);
  for (unsigned n=0; n<MaxDecZeros; n++) {
    if ((num & (1u << n))) t.mul (table_high [n]);
  }
  if (t.u.s.e > BigOffsetExp) {
    BigFloat c(t), d(t);
    const unsigned shl = t.u.s.e - BigOffsetExp;
    shift_left  (d.m.addr(), BigDimension, shl);
    const unsigned shr = (BigDimension << 4) - shl;
    shift_right (c.m.addr(), BigDimension, shr);
    c.u.s.e += shr;
    BigFloat zero;
    if (d.m[BigDimension-1] & (ONE << 15)) AsmAdd (c.m.addr(), zero.m.addr(), BigDimension, 1u);
    c.norm();
    for (unsigned n=0; n<MaxDecZeros; n++) {
      if ((num & (1u << n))) c.mul (table_low [n]);
    }
    // TODO : pro zaporna cisla to muze byt jinak (ceil(), floor() a trunc())
    return c;
  } else return * this;
}
extern "C" int wrap_clz (const uint16_t a) {
  int n = 0, k=15;
  do {
    const uint16_t m = ONE << k;
    if (m & a) break;
    k -= 1;
    n += 1;
  } while (k);
  return n;
}

#ifdef GEN_TABLE
void BigFloat::row () const {
  console.printf ( "  { 0x%04Xu,", u.w);
  for (unsigned i=0; i<BigDimension; i++) {
    console.printf ( "0x%04Xu,", m[BigDimension - (i+1)]);
  }
  console.printf ( " },\r\n");
}
#endif