#ifndef WEBDEF_H
#define WEBDEF_H
//----------------------------- Webassembly block -----------------------------
/* Poznámky k úpravě pro webassembly.
 * 1. Celý blok webassembly je na začátku, překlad je řízen makrem EMSCRIPTEN,
 * jež je defaultně definováno překladačem em++.
 * 2. To nijak neomezuje překlad jako nativní aplikace (v Makefile např. TARGET?=NAT).
 * 3. V prostředí prohlížeče funguje smyčka v hlavním programu jinak - je volán vždy
 * jeden průchod smyčkou ve smyčce javascriptového prostředí obsluhy událostí.
 * Nejméně bolestivá metoda, jak to přepsat je použít lambda výraz, označit jím
 * původní smyčku a celé to pak zabalit do funkce main_loop (), kterou už může
 * akceptovat metoda emscripten_set_main_loop() pro tento účel speciálně určená.
 * Pro nativní aplikaci pak tuto funkci prostě předefinujeme tak, aby běžela stejně
 * jako tomu bylo původně.
 * 4. Smyčka by měla proběhnout v co nejkratším čase a proto jsem vyhodil
 * (jen pro webassembly) čekání na konci smyčky i když moc nevím k čemu to tam je.
 * Chtělo by to se zamyslet nad tím, jak to optimalizovat, nicméně pro první nástřel
 * to celkem vyhovuje - nějak to funguje.
 * 5. Vyvolání menu je provedeno klávesou GRAVE v levém horním konci ASCII bloku klávesnice.
 * Všechny ty kombinace Alt+Fn nejsou použitelné, sežere to systém a to i nativně.
 * Možná by to chtělo promyslet a přemapovat jinak, ale já nevím, jaké klávesy PMD vlastně
 * používá, byla to jen zábava po dlouhé době si zavzpomínat na první "počítače",
 * které mi přisly do ruky a dnes jsou dávno ve šrotu. 
 * */
#include <functional>
static std::function<void()> loop;
static void main_loop () { loop(); }

#ifdef EMSCRIPTEN
#include <emscripten.h>
#define PATH_ROOT "/files"
static inline void loop_delay (const DWORD) {}
static void set_environ_paths () {
  PathUserHome    = strdup (PATH_ROOT);
  PathApplication = strdup (PATH_ROOT);
  PathResources = (char *) malloc(strlen(PATH_ROOT DIR_RESOURCES) + 1);
  PathAppConfig = (char *) malloc(strlen(PathUserHome) + 16);
  strcpy(PathResources, PATH_ROOT DIR_RESOURCES);
  sprintf(PathAppConfig, "%s%c.%s", PathUserHome, DIR_DELIMITER, PACKAGE_TARNAME);
  printf ("Toto je webová verze - první nástřel KIZARM\n"); // jen test shellu, vyhodit
}
static inline void set_main_loop (void (*f) (void)) {
  emscripten_set_main_loop (f, 0, true);
}
#else // ! EMSCRIPTEN
#define PATH_ROOT "./files"
static inline void set_main_loop (void (*f) (void)) {
  while (Emulator->isActive)  f();
}
static inline void loop_delay (const DWORD nextTick) {
  while (SDL_GetTicks() < nextTick)
    SDL_Delay(1);
}
static void set_environ_paths () {
  // V COMPAT módu používá nativní aplikace stejné soubory jako webassembly (adresář ./files).
  // Je to pro rychlou kontrolu, že je tam vše potřebné a umožní změnit konfiguraci.
#ifdef COMPAT
  PathUserHome    = strdup (PATH_ROOT);
  PathApplication = strdup (PATH_ROOT);
#else  // ! COMPAT
  PathUserHome    = SDL_getenv("HOME");
  PathApplication = getcwd(NULL, PATH_MAX);
#undef  PATH_ROOT
#define PATH_ROOT ""
#endif // ! COMPAT
  PathResources = (char *) malloc(strlen(PATH_ROOT DIR_RESOURCES) + 1);
  PathAppConfig = (char *) malloc(strlen(PathUserHome) + 16);
  strcpy(PathResources, PATH_ROOT DIR_RESOURCES);
  sprintf(PathAppConfig, "%s%c.%s", PathUserHome, DIR_DELIMITER, PACKAGE_TARNAME);
  IntroMessage();   // nezobrazí se ve webassembly (nemusí být kam)
}
#endif // ! EMSCRIPTEN
//------------------------- End Webassembly block -----------------------------
#endif // WEBDEF_H
