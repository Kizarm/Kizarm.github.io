#include <emscripten/bind.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <string>
#include "canvas.h"
#include "cim.h"

#define CHUNK 16384

static Canvas canvas (288,256);

static int decompress (const char * gzmame, const char * p32name) {
  FILE * source = fopen (gzmame,  "rb");
  if (!source) return Z_STREAM_ERROR;
  FILE * dest   = fopen (p32name, "wb");
  if (!dest)   return Z_STREAM_ERROR;
  int ret;
  unsigned have;
  z_stream strm;
  unsigned char in [CHUNK];
  unsigned char out[CHUNK];
  /* allocate inflate state */
  strm.zalloc   = Z_NULL;
  strm.zfree    = Z_NULL;
  strm.opaque   = Z_NULL;
  strm.avail_in = 0;
  strm.next_in  = Z_NULL;
  ret = inflateInit (&strm);
  if (ret != Z_OK) return ret;
  /* decompress until deflate stream ends or end of file */
  do {
    strm.avail_in = fread (in, 1, CHUNK, source);
    if (ferror (source)) {
      (void) inflateEnd (&strm);
      return Z_ERRNO;
    }
    if (strm.avail_in == 0) break;
    strm.next_in = in;
    /* run inflate() on input until output buffer not full */
    do {
      strm.avail_out = CHUNK;
      strm.next_out = out;
      ret = inflate (&strm, Z_NO_FLUSH);
      assert (ret != Z_STREAM_ERROR); /* state not clobbered */
      switch (ret) {
      case Z_NEED_DICT:
        ret = Z_DATA_ERROR;     /* and fall through */
      case Z_DATA_ERROR:
      case Z_MEM_ERROR:
        (void) inflateEnd (&strm);
        return ret;
      }
      have = CHUNK - strm.avail_out;
      if (fwrite (out, 1, have, dest) != have || ferror (dest)) {
        (void) inflateEnd (&strm);
        return Z_ERRNO;
      }
    } while (strm.avail_out == 0);
    /* done when inflate() says it's done */
  } while (ret != Z_STREAM_END);
  /* clean up and return */
  (void) inflateEnd (&strm);
  fclose (source);
  fclose (dest);
  return ret == Z_STREAM_END ? Z_OK : Z_DATA_ERROR;
}
struct DiskImage {
  uint8_t * data;
  size_t    size;
};
static DiskImage disk_image = {
  .data = nullptr,
  .size = 0
};
static void create_p32 () {
  BOOL writeDir = FALSE;
  const char * disk_name = "/files/data.p32";
  int res = decompress ("/files/data.p32.gz",disk_name);
  //int res = def ("data.p32.gz",disk_name, Z_BEST_COMPRESSION);
  if (res != Z_OK) return;
  SetAddParams (disk_name, "/files/img/*.*");
  ReadConfig();
  do {
    if (OpenImage ( (oper & (OP_ADD_FILE | OP_CREATE)) != 0) == FALSE)  break;
    // reading directory
    if (ReadDirectory() == FALSE) break;
    if (oper & OP_ADD_FILE) {    // adding file(s)
      AddFiles();
      writeDir = TRUE;
    }
  } while (FALSE);
  if (writeDir == TRUE) {
    if (WriteDirectory() == FALSE) PrintError (ERR_WRITE_IMAGE);
  }
  CloseImage();
  CleanUp();
  
  struct stat info;
  res = stat (disk_name, &info);
  if (res) return;
  disk_image.size = info.st_size;
  if (disk_image.data) delete [] disk_image.data;
  disk_image.data = new uint8_t [disk_image.size];
  
  FILE * f = fopen (disk_name, "rb");
  if (!f) return;
  fread (disk_image.data, 1, disk_image.size, f);
  fclose (f);
}
/****************************************************************************************/

static emscripten::val src_data () {
  return emscripten::val (emscripten::typed_memory_view (canvas.getSize(), canvas.getSrc()));
}
static emscripten::val dst_data () {
  return emscripten::val (emscripten::typed_memory_view (canvas.getSize(), canvas.getDst()));
}
static emscripten::val bin_data () {
  create_p32();
  return emscripten::val (emscripten::typed_memory_view (disk_image.size, disk_image.data));
}
static void gReset () {
}
static void setData (std::string data , const int w, const int h, std::string name) {
  size_t n = name.find_last_of('/');
  if (n != std::string::npos) {
    name = name.substr (n+1, name.length());
  }
  // printf("w=%d, h=%d, x=%ld (%s)\n", w, h, data.length(), name.c_str());
  if (w != canvas.getMaxX()) return;
  if (h != canvas.getMaxY()) return;
  canvas.setData (data, name);
}
static void setTrig (int c, int v) {
  canvas.setTrig (c, v);
}
static int getTrig (int no) {
  return canvas.getTrig(no);
}
static std::string getAsm (int no) {
  return canvas.getAsm(no);
}
static std::string AddFile () {
  std::string name ("/files/img/");
  const uint8_t * ptr = canvas.getCom();
  name += canvas.getComName();
  // printf("adding file \"%s\"\n", name.c_str());
  std::string result = canvas.getComName();
  const size_t len = canvas.getComSize();

  int res = access (name.c_str(), F_OK);
  if (!res) result.clear();
  
  FILE * f = fopen (name.c_str(), "wb");
  if (!f) {
    printf("Cannot open %s\n", name.c_str());
    return result;
  }
  fwrite (ptr, 1, len, f);
  fclose(f);
  
  return result;
}
static void setDef () {
  canvas.setDefaults ();
}

EMSCRIPTEN_BINDINGS (hello) {
  emscripten::function ("src_data", &src_data);
  emscripten::function ("dst_data", &dst_data);
  emscripten::function ("bin_data", &bin_data);
  emscripten::function ("gReset",   &gReset);
  emscripten::function ("setData",  &setData);
  emscripten::function ("setTrig",  &setTrig);
  emscripten::function ("getTrig",  &getTrig);
  emscripten::function ("getAsm",   &getAsm);
  emscripten::function ("AddFile",  &AddFile);
  emscripten::function ("setDef",   &setDef);
}
