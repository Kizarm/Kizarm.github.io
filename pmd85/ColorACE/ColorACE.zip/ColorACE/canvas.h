#ifndef CANVAS_H
#define CANVAS_H
#include <string>
#include <stdint.h>
#include <stdlib.h>
#include <vector>

struct TRIGGER {
  TRIGGER () {
    setDefaults();
  }
  void setDefaults () {
    r = 0x80; g = 0x80; b = 0x80; c = 0x80;
  }
  unsigned r, g, b, c;
};

struct RGBI;

struct RGBA {
  RGBA (const uint32_t col = 0u) {
    color = col;
  }
  RGBA (const RGBA & o) { color = o.color; }
  RGBA (const unsigned attr, const unsigned v);
  RGBA (const RGBI & o);
  union {
    struct {
      uint8_t r,g,b,a;
    };
    uint32_t color;
  };
};
/* Musí se to počítat v celých znaménkových číslech, jinak přetéká. */
struct RGBI {
  int r,g,b;
  RGBI () {
    r = 0, g = 0, b = 0;
  }
  RGBI (const RGBA & i) {
    r = i.r, g = i.g, b = i.b;
  }
  RGBI find_closest_palette_color (const TRIGGER & t) const;
  RGBI & operator-= (const RGBI & c);
  RGBI & operator+= (const RGBI & c);
  RGBI m16 (const unsigned n) const;
};

class Canvas {
  TRIGGER   trig;
  const int width, height;
  uint8_t * out_bytes;
  uint8_t * com_bytes;
  size_t total_bytes;
  RGBA * dataSrc;
  RGBA * dataDst;
  std::string imagename;
  
  RGBI      dummy;
  std::vector<RGBI>    pixels;
  public:
    Canvas (const int w, const int h);
    ~Canvas();
    uint8_t * getSrc  () const { return reinterpret_cast<uint8_t*>(dataSrc); };
    uint8_t * getDst  () const { return reinterpret_cast<uint8_t*>(dataDst); };
    uint8_t * getCom  () const;
    size_t    getComSize () const;
    size_t    getSize () const { return (width * height * sizeof(RGBA)); };
    int       getMaxX () const { return width;  };
    int       getMaxY () const { return height; };
    
    void setData (const std::string & src, const std::string & name);
    void setTrig (const int color, const int value);
    int  getTrig (const int color) const;
    std::string getAsm (const int order) const;
    std::string getComName ();
    void setDefaults () {
      trig.setDefaults();
      transformation();
    }
  protected:
    bool inRange (const unsigned x, const unsigned y) const;
    RGBI & at    (const unsigned x, const unsigned y);
    
    void   dithering ();
    void   transformation ();
    void   img2bin ();
    void   bin2img ();
};

#endif // CANVAS_H
