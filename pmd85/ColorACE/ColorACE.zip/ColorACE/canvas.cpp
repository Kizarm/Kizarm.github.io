#include "math.h"
#include <vector>
#include <string>
#include <algorithm>
#include <string.h>
#include "canvas.h"

extern "C" const unsigned com_lenght;
extern "C" const unsigned char com_base [];

static inline uint8_t u8sat (const int n) {
  if (n < 0x00) return 0x00u;
  if (n > 0xFF) return 0xFFu;
  uint8_t res = n;
  return res;
}
RGBA::RGBA (const RGBI & o) {
  r = u8sat (o.r), g = u8sat (o.g), b = u8sat (o.b);
}
static const uint32_t color_table [16] = {
  0xFF00FF00, 0xFF00FFFF, 0xFFFFFF00, 0xFFFFFFFF,
  0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF00FF,
  0xFFFFFF00, 0xFFFF00FF, 0xFFFF0000, 0xFFFF00FF,
  0xFF000000, 0xFFFF00FF, 0xFFFF00FF, 0xFFFF00FF
};
RGBA::RGBA (const unsigned int index, const unsigned int v) {
  color = 0xFF000000;
  if (!v) return;
  color = color_table [index];
}

RGBI RGBI::find_closest_palette_color(const TRIGGER & t) const {
  RGBI res;
  const int trg = t.c + 0x7F;
  if (r >= trg) res.r = 0xFF;
  if (g >= trg) res.g = 0xFF;
  if (b >= trg) res.b = 0xFF;
  return res;
}

RGBI RGBI::m16 (const unsigned int n) const {
  RGBI res;
  res.r = (r * n) >> 4;
  res.g = (g * n) >> 4;
  res.b = (b * n) >> 4;
  return res;
}
RGBI & RGBI::operator-= (const RGBI & c) {
  r -= c.r, g -= c.g, b -= c.b; 
  return * this;
}
RGBI & RGBI::operator+= (const RGBI & c) {
  r += c.r, g += c.g, b += c.b;
  return * this;
}
/*****************************************************************************/

struct SUMC {
  unsigned ar,ag,ab;
  SUMC () {
    ar = 0u, ag = 0u, ab = 0u;
  }
  unsigned get (const RGBI & c, const TRIGGER & trg) {
    int            max = c.r;
    if (c.g > max) max = c.g;
    if (c.b > max) max = c.b;
    if (max >= (int) trg.c) return 1u;
    return 0u;
  }
  void clear () {
    ar = 0u, ag = 0u, ab = 0u;
  }
};
struct CL12 {
  unsigned r,g,b;
  CL12 () {
    r = 0u, g = 0u, b = 0u;
  }
  void add (const RGBI & c) {
    r += c.r; g += c.g; b += c.b;
  }
  unsigned get (const TRIGGER & trig, const unsigned pix);
};
static const unsigned inverse_table [8] {
//   0     1     2     3     4     5     6     7
  0x0C, 0x05, 0x00, 0x04, 0x0A, 0x0F, 0x08, 0x0C 
};
unsigned int CL12::get(const TRIGGER & trig, const unsigned pix) {
  if (!pix) return 0u;
  const unsigned count = pix;
  const unsigned ar = r / count, ag = g / count, ab = b / count;
  unsigned index = 0u;
  if (ar > trig.r) index |= 1u << 0;
  if (ag > trig.g) index |= 1u << 1;
  if (ab > trig.b) index |= 1u << 2;
  
  r = 0u, g = 0u, b = 0u;
  return inverse_table [index];
}
static unsigned ace_pixels (const uint8_t byte) {
  unsigned result = 0;
  for (unsigned n=0; n<6; n++) {
    if (byte & (1 << n)) result += 1;
  }
  return result;
}
/*****************************************************************************/


Canvas::Canvas(const int w, const int h) : trig(), width(w), height(h) {
  dataSrc = new RGBA [w * h];
  dataDst = new RGBA [w * h];
  const unsigned tot_len = width * height / 6;
  out_bytes = new uint8_t [tot_len];
  
  total_bytes = tot_len + com_lenght;
  com_bytes = new uint8_t [total_bytes];
  
  const size_t len = width * height;
  if (pixels.size() != len) {
    pixels.resize (len);
  }
}

Canvas::~Canvas() {
  delete [] com_bytes;
  delete [] out_bytes;
  delete [] dataSrc;
  delete [] dataDst;
}
size_t Canvas::getComSize() const {
  return total_bytes;
}
uint8_t* Canvas::getCom() const {
  memcpy (com_bytes, com_base, com_lenght);
  memcpy (com_bytes + com_lenght, out_bytes, width * height / 6);
  return com_bytes;
}
std::string Canvas::getComName() {
  std::string result ("noname");
  size_t n = imagename.find_first_of('.');
  if (n != std::string::npos) result = imagename.substr(0, n);
  const size_t max = 8;
  if (result.length() > max) result = result.substr(0, max);
  result += ".com";
  std::transform(result.begin(), result.end(),result.begin(), ::toupper);
  return result;
}

void Canvas::setData (const std::string & src, const std::string & name) {
  // printf("setting data ...\n");
  imagename = name;
  const unsigned len = src.length();
  memcpy (dataSrc, src.c_str(), len);
  transformation();
}
void Canvas::setTrig (const int color, const int value) {
  // printf ("color = %d, value = %d\n", color, value);
  switch (color) {
    case 0: trig.r = value; break;
    case 1: trig.g = value; break;
    case 2: trig.b = value; break;
    case 3: trig.c = value; break;
    default : break;
  }
  transformation();
}
int Canvas::getTrig (const int color) const {
  int result = 0;
  switch (color) {
    case 0: result = trig.r; break;
    case 1: result = trig.g; break;
    case 2: result = trig.b; break;
    case 3: result = trig.c; break;
    default : break;
  }
  return result;
}

std::string Canvas::getAsm(const int order) const {
  std::string result;
  unsigned count6 = 0;
  unsigned tot_bytes = width * height / 6;
  const unsigned bufmax = 1024;
  char buffer [bufmax];
  unsigned li = 0;
  li += snprintf (buffer + li, bufmax - li, "\t.section .rodata\n\t.globl image_data_%02d\n\t.align 4\nimage_data_%02d:\n", order, order);
  buffer[li] = '\0';
  result += buffer;
  li = 0;
  count6 = 0;
  for (unsigned i=0; i<tot_bytes; i++) {
    if (count6 == 0) {
      li += snprintf(buffer + li, bufmax - li, "\t.db");
    }
    li += snprintf (buffer + li, bufmax - li, " 0x%02X,", out_bytes[i]);
    count6 += 1;
    if (count6 == 16) {
      count6 = 0;
      li += snprintf(buffer + li - 1, bufmax - li, "\n");
      result += buffer;
      li = 0;
    }
  }
  result += ".end\n";
  return result;
}
bool Canvas::inRange(const unsigned int x, const unsigned int y) const {
  if (x >= width)  return false;
  if (y >= height) return false;
  return true;
}
RGBI & Canvas::at (const unsigned int x, const unsigned int y) {
  if (!inRange(x,y)) return dummy;
  const unsigned index = width * y + x;
  return pixels [index];
}


void Canvas::transformation () {
  const unsigned dl = width * height;
  const RGBA * data = dataSrc;
  for (unsigned n=0; n<dl; n++) pixels[n] = data [n];
  dithering();
  img2bin();
  bin2img();
}
/* Floyd–Steinberg dithering */
void Canvas::dithering() {
  for (unsigned y=0; y<height; y++) {
    for (unsigned x=0; x<width; x++) {
      RGBI & t0 = at (x, y);
      RGBI oldpixel (t0);
      RGBI newpixel (oldpixel.find_closest_palette_color(trig));
      t0 = newpixel;
      RGBI quant_error (oldpixel);
      quant_error    -= newpixel;
      at(x + 1, y    ) += quant_error.m16 (7u);
      at(x - 1, y + 1) += quant_error.m16 (3u);
      at(x    , y + 1) += quant_error.m16 (5u);
      at(x + 1, y + 1) += quant_error.m16 (1u);
    }
  }
}
// zobrazeni COLORACE
void Canvas::bin2img() {
  RGBA * cd = (RGBA *) dataDst;
  // rekonstrukce z dat
  const int my = height;
  const int mx = width, m6 = mx / 6;
  for (int y = 0; y < my; y+=2) {
    RGBA    * dlpo = cd + y * mx;         // zacatky radku
    uint8_t * slpo = out_bytes + y * m6;
    RGBA    * dlpe = dlpo + mx;
    uint8_t * slpe = slpo + m6;
    for (int x = 0; x < mx; x++) {
      const unsigned si  = x / 6;
      const unsigned sm  = 1 << (x % 6);
      const uint8_t  sbo = slpo [si];
      const unsigned bio = sbo & sm;      
      const uint8_t  sbe = slpe [si];
      const unsigned bie = sbe & sm;
      const unsigned cie = (sbo >> 6) | ((sbe >> 4) & 0x0C);
      dlpo [x] = RGBA(cie, bio);
      dlpe [x] = RGBA(cie, bie);
    }
  }
}

void Canvas::img2bin() {
  const int my = height;
  const int mx = width, m6 = mx / 6;
  const RGBI * cs = pixels.data();
  SUMC avgo, avge;
  CL12 color;
  for (int y = 0; y < my; y+=2) {
    const RGBI * slpo = cs + y * mx;         // zacatky radku
    uint8_t    * dlpo = out_bytes + y * m6;
    const RGBI * slpe = slpo + mx;
    uint8_t    * dlpe = dlpo + m6;
    uint8_t  byto = 0, byte = 0;
    unsigned cnt6 = 0;
    for (int x = 0; x < mx; x++) {
      cnt6 += 1;
      const unsigned di  = x / 6;
      const unsigned dm  = 1 << (x % 6);
      const RGBI co = slpo [x];
      const RGBI ce = slpe [x];
      color.add (co);
      color.add (ce);
      const unsigned bito = avgo.get (co, trig);
      const unsigned bite = avge.get (ce, trig);
      if (bito) byto |= dm;
      if (bite) byte |= dm;
      
      if (cnt6 >= 6) {  // zapis bytu
        const unsigned tc = color.get (trig, ace_pixels(byte) + ace_pixels(byto));
        byte |= (tc & 0x03) << 6;
        byto |= (tc & 0x0C) << 4;
        dlpe [di] = byte;
        dlpo [di] = byto;
        byto = 0, byte = 0;
        cnt6 = 0;
      }
    }
  }
}

