#include "swd-api.h"
#include "flash.h"
#include "LPC11Uxx.h"
/**
 * @mainpage Standalone programátor čipů STM32Fx.
 * 
 * Procesory STM32F a nakonec ARM Cortex-Mx obecně používají pro ladění a zavádění programu do flash
 * rozhraní SWD, které nahrazuje dřívější JTAG. Bylo by sice možné použít interní bootloader, ale
 * v tomto případě je nutné propojit BOOT pin na plus a pak propojku odstranit, což zdržuje. A tak
 * abych babám ve výrobě usnadnil práci, vyrobil jsem jednoduchý standalone programátor, který se
 * umí bavit s cílovým procesorem přes SWD.
 * 
 * @author Mrazik <mrazik@volny.cz> s použitím různých zdrojů z Webu
 * 
 * @section a00 Jak to funguje.
 * Funguje to tak, že se do RAM cílového procesoru STM32F0 po SWD nahraje stub, tedy program pro zápis
 * do flash a zároveň data pro zápis. Pak se stub spustí, čímž dojde k přepisu z RAM do FLASH.
 * Do FLASH totiž nejde zapisovat přímo, zapisuje se po 16.bit slovech
 * a po každém zápisu je nutné počkat, až se provede. Takhle řečeno to vypadá jednoduše,
 * ono to jednoduché také je, ale SWD je opravdu oříšek. Má sice jen dva
 * dráty, komunikace je dobře zdokumentovaná, ale donutit to ke spolupráci s ARM není tak snadné.
 * Dokumentace ARM je asi dělána nějak automaticky, obsahuje neuvěřitelné množství
 * informací, ale čert aby poznal, co je podstatné a co ne. Lecos by šlo vykoumat ze zdrojáků k
 * openocd, blackmagic a jiného, ale i zde tomu poněkud brání velká komplikovanost tohoto software,
 * které se snaží postihnout všechny možnosti, takže to vlastní jádro se v tom ztratí. No a to jádro
 * jsem nakonec vyhrabal z hloubi Webu někde na lpcware.com (viz swd.c), dopatlal k tomu kousky kódu
 * z STM std. periph. library a nakonec se povedlo i zamknout procesor proti nechtěnému přepisu.
 * 
 * To, že je použit jako zdrojový procesor LPC11U24 má jediný důvod - byl v šuplíku. Tedy druhým důvodem
 * bylo, po pravdě řečeno i to, že umožňuje změnit velice jednoduše firmware po USB, ale nic
 * nebrání použít jakýkoli jiný procesor, třeba i 8-bit. Pak je ovšem nutné předělat ty low-level
 * rutiny, které cvičí s piny, což by nemělo být tak hrozné. Stejně tak je možné upravit funkce
 * pro zápis do flash pro jiný procesor. Zde byl jako cílový procesor použit STM32F051.
 * 
 * Za zmínku stojí soubor bindata.S. Není to jediný kousek kódu v assembleru, jsou v něm i rutiny
 * pro zápis do flash (adresář stub) a zápis do option (adresář optb), to je však jen kvůli tomu,
 * že jsem to takhle našel hotové a funkční v blackmagic. Tohle je hezký trik, jak zahrnout do
 * zdrojového kódu i binárky pro cílovou platformu aniž by bylo nutné je jakkoli upravovat.
 * 
 * @section a01 Hardware.
 * Pokud možno co nejjednodušší. USB je použito pro změnu firmware zdrojového procesoru, zároveň
 * je pak použito pro napájení jak zdrojové, tak cílové platformy. Doporučuji pak použít nějakou
 * USB nabíječku, mít to připojené k PC v režimu programování cíle není dobré - USB se snaží
 * vyčíslovat a moc mu to nejde. Stejně to bylo vymyšleno jen proto, aby ve výrobě nemuseli mít
 * zapnuté PC.
 * @image html boot.png
 * <b>Pozn.</b><i> Pin PA18 (označený jako RxD) je použit jako SWCLK pro cílový procesor, PA19 (TxD) jako SWDIO.</i>
 * 
 * A protože je to umístěno v prostředí, kde je potřeba už trochu ochrana, najdeme zde omezovač
 * proudu (40 mA, stačí i pro cílový procesor) a ochranné odpory na SWCLK i SWDIO. A protože
 * je to kompaktní, je to zároveň i svižné - nahrání 8KB firmware včetně verifikace proběhne
 * za sekundu. Spínačem SW1 pustíme šťávu do zdrojového i cílového systému, což indikuje LED D2,
 * systém chvíli počká až se poměry ustálí, LED D1 pak indikuje průběh a dokončení operace.
 * Pokud je cílový procesor už od počátku chráněn proti zápisu, programování neproběhne ale
 * ochrana se zruší a D1 10x blikne. Pak už je možné postup opakovat (vypnout a znovu zapnout SW1),
 * cílový procesor se normálně naprogramuje a prvních 8KB flash se zamkne proti zápisu.
 * Bylo by možné zamykat ho i proti čtení, viz komentář ve funkci writeProtection(), soubor
 * flash.c.
 * 
 * @section a02 Závěr.
 * Asi to moc lidí nevyužije i když standalone programovátka na různé ty Atmely byl oblíbený
 * námět konstrukcí. Ale věřím, že pro seznámení s principem komunikace SWD je to celkem slušný
 * základ. Snad právě proto, že jsem vyházel vše zbytečné a zbylo jen nezbytné jádro,
 * zůstalo to poměrně přehledné, takže je to otevřeno pro lidovou tvořivost.
 * 
 * @section a03 Doplňky.
 * - 02.06.2016 doplněn jako další target LPC11.. Ověřeno na LPC11U34, nechodí verifikace, pokud
 * nesedí kontrolní suma vektorů.
 * Zároveň jsem z toho udělal knihovny, finálně stačí assemblerem zkompilovat jeden soubor
 * a celé to zlinkovat. Takže stačí binutils pro ARM.
 * - 04.06.2016 Nastavení souboru pro upload je v Makefile. Soubor např. firmware.bin nakopírujeme
 * do kořenového adresáře projektu (kde je i tt. Makefile) a spustíme příkaz <i>make FWFILE=firmware.bin</i>.
 * Default je make nastaveno tak, že se do cílového procesoru LPC11U.. nakopíruje vlastní (self) firmware - je to tedy
 * jakýsi "virus", který kopíruje sám sebe pomocí SWD. To je samosebou k ničemu, je to jen demo,
 * z kterého je vidět velikost kódu, potřebného pro upload.
 *
 * @section a04 Download.
 * Archiv boot.zip se zdrojáky je možné stáhnout <a href="../boot.zip">zde</a>.

  @file
  @brief Download firmware do STM32F0, LPC11xx prostřednictvím SWD vytvořeného na pinech LPC11U24
  
  SWD převzato z blogu na lpcware.com, upraveno pomocí blackmagic a jiných zdrojů.
    
*/
#define LEDY 17
/**
 * @brief Inicialice LED a pinů SWD (jen hodiny do periferie)
 *
 * @return void
 **/
static inline void GPIO_Init (void) {
  LPC_SYSCON->SYSAHBCLKCTRL |= (1<<6);
  LPC_GPIO->DIR[0] |= (1<<LEDY);
}
static inline void LedOn (void) {
  LPC_GPIO->CLR[0] = 1 << LEDY;
}
static inline void LedOff (void) {
  LPC_GPIO->SET[0] = 1 << LEDY;
}

/**
 * @brief Zpoždění velmi jednoduše a blbě.
 *
 * @param ms milisekund (hooodně přibližně)
 * @return void
 **/
void SystemDelay (uint32_t ms) {
  volatile uint32_t delay = 6000 * ms;
  while (delay--) asm volatile ("nop");
}
/**
 * @brief Blikni LEDkou
 *
 * @param count kolikrát
 * @return void
 **/
void LedBlink (int count) {
  while (count--) {
    LedOff();
    SystemDelay(200);
    LedOn();
    SystemDelay(200);
  }
}
/**
 * @brief Main
 *
 * @param  ...
 * @return int nepoužito
 **/
int main (void) {
  // Načti skutečnou hodnotu proměnné SystemCoreClock
  SystemCoreClockUpdate ();
  GPIO_Init();
  LedOff();
 
  SystemDelay (500);
  LedOn();
  int result = FlashProgram();
  //printf ("FlashProgram result = %d\n", result);
  if (result) LedBlink (result);
  LedOff();

  while (1) {
  }
}

