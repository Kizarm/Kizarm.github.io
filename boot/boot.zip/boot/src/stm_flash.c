#include "flash.h"
#include "swd.h"
#include "swd-api.h"

#define printf(fmt,...)

static int cmd_erase_mass (void);
static int flash_write    (uint32_t dest, const uint32_t *src, uint32_t len);

/* Flash Program ad Erase Controller Register Map */
#define FPEC_BASE       0x40022000
#define FLASH_ACR       (FPEC_BASE+0x00)
#define FLASH_KEYR      (FPEC_BASE+0x04)
#define FLASH_OPTKEYR   (FPEC_BASE+0x08)
#define FLASH_SR        (FPEC_BASE+0x0C)
#define FLASH_CR        (FPEC_BASE+0x10)
#define FLASH_AR        (FPEC_BASE+0x14)
#define FLASH_OBR       (FPEC_BASE+0x1C)
#define FLASH_WRPR      (FPEC_BASE+0x20)

#define FLASH_CR_OBL_LAUNCH (1<<13)
#define FLASH_CR_OPTWRE (1 << 9)
#define FLASH_CR_STRT   (1 << 6)
#define FLASH_CR_OPTER  (1 << 5)
#define FLASH_CR_OPTPG  (1 << 4)
#define FLASH_CR_MER    (1 << 2)
#define FLASH_CR_PER    (1 << 1)

#define FLASH_SR_BSY    (1 << 0)

#define FLASH_OBP_RDP 0x1FFFF800
#define FLASH_OBP_RDP_KEY    0x5aa5
#define FLASH_OBP_RDP_KEY_F3 0x55AA

#define KEY1 0x45670123
#define KEY2 0xCDEF89AB

#define SR_ERROR_MASK   0x14U
#define SR_EOP          0x20U

#define DBGMCU_IDCODE     0xE0042000
#define DBGMCU_IDCODE_F0  0x40015800

extern uint32_t flash_write_stub[];
extern uint32_t flash_write_stub_len;

extern uint32_t options_write_stub[];
extern uint32_t options_write_stub_len;

static const  uint32_t RamBase   = 0x20000000;
static const  uint32_t FlashBase = 0x08000000;

const uint32_t BlockLenMax = 0x80;
uint32_t       gReadBuffer[0x80];

extern uint8_t  WaitHalt (void);

static void flash_unlock (void) {
  WriteMemory (FLASH_KEYR, KEY1);
  WriteMemory (FLASH_KEYR, KEY2);
}

static int flash_write (uint32_t dest, const uint32_t *src, uint32_t len) {
  uint8_t  sta;
  uint32_t mask;
  uint32_t blen = flash_write_stub_len >> 2;
  uint32_t rofs = flash_write_stub_len  - 4;
  
  // printf("flash write %p, %d, 0x%X\n", src, len, rofs);
  blen -= 1;
  flash_write_stub [blen - 2] = dest;
  flash_write_stub [blen - 1] = 4 * len;

  /* Write stub and data to target ram and set PC */
  sta = WriteMemoryArray (RamBase + rofs, src, len);
  if (sta != OR_STATUS_ACK) return 1;
  sta = WriteMemoryArray (RamBase, flash_write_stub, blen);
  if (sta != OR_STATUS_ACK) return 1;
  
  sta = WriteCore (CORE_SP, RamBase + 0x1000);
  sta = WriteCore (CORE_PC, RamBase);
  if (sta != OR_STATUS_ACK) return 1;

  
  /* Execute the stub */
  sta = Run ();
  if (sta != OR_STATUS_ACK) return 1;
  sta = WaitHalt ();
  if (sta != OR_STATUS_ACK) return 1;

  /* Check for error */
  sta = ReadMemory (FLASH_SR, &mask);
  if (sta != OR_STATUS_ACK) return 1;
  if (mask & SR_ERROR_MASK) return 1;

  return 0;
}

static int cmd_erase_mass (void) {
  uint8_t sta;
  flash_unlock ();

  /* Flash mass erase start instruction */
  sta = WriteMemory (FLASH_CR, FLASH_CR_MER);
  sta = WriteMemory (FLASH_CR, FLASH_CR_STRT | FLASH_CR_MER);
  if (sta != OR_STATUS_ACK) return 1;

  uint32_t data;
  /* Read FLASH_SR to poll for BSY bit */
  while (1) {
    sta = ReadMemory (FLASH_SR, &data);
    if (sta != OR_STATUS_ACK)       return 1;
    if ((data & FLASH_SR_BSY) == 0) break;
  }

  /* Check for error */
  sta = ReadMemory (FLASH_SR, &data);
  if (sta != OR_STATUS_ACK) return 1;
  if ((data & SR_ERROR_MASK) || !(data & SR_EOP)) return 1;

  return 0;
}
/*
static int readOptions (void) {
  uint32_t buf[3];
  uint8_t res = ReadMemoryArray(0x1FFFF800, buf, 3);
  if (res != OR_STATUS_ACK) return 1;
  printf ("Options: 0x%08X,0x%08X,0x%08X\n", buf[0], buf[1], buf[2]);
  return 0;
}
*/
static int eraseOptions (void) {
  uint8_t  sta;
  uint32_t data;

  sta = Reset();
  flash_unlock ();
  // enable option bytes
  sta = WriteMemory (FLASH_OPTKEYR, KEY1);
  sta = WriteMemory (FLASH_OPTKEYR, KEY2);

  sta = ReadMemory (FLASH_CR, &data);
  // printf ("FCR (%d) CR = 0x%08X\n", sta, data);
  /* Erase option bytes instruction */
  data |= FLASH_CR_OPTER;
  sta = WriteMemory (FLASH_CR, data);
  if (sta != OR_STATUS_ACK) return 1;
  /* And start operation */
  data |= FLASH_CR_STRT;
  sta = WriteMemory (FLASH_CR, data);
  if (sta != OR_STATUS_ACK) return 1;
  /* Read FLASH_SR to poll for BSY bit */
  while (1) {
    sta = ReadMemory (FLASH_SR, &data);
    // printf ("EOB (%d) SR = 0x%08X\n", sta, data);
    if (sta != OR_STATUS_ACK)       return 1;
    if ((data & FLASH_SR_BSY) == 0) break;
  }
  return 0;
}
static int writeOptions (void) {
  uint8_t  sta;
  uint32_t mask;
  uint32_t blen = options_write_stub_len >> 2;
  
  sta = WriteMemoryArray (RamBase, options_write_stub, blen);
  if (sta != OR_STATUS_ACK) return 1;
  
  sta = WriteCore (CORE_SP, RamBase + 0x1000);
  sta = WriteCore (CORE_PC, RamBase);
  if (sta != OR_STATUS_ACK) return 1;

  
  /* Execute the stub */
  sta = Run ();
  if (sta != OR_STATUS_ACK) return 1;
  sta = WaitHalt ();
  if (sta != OR_STATUS_ACK) return 1;

  /* Check for error */
  sta = ReadMemory (FLASH_SR, &mask);
  if (sta != OR_STATUS_ACK) return 1;
  // printf("options write res = 0x%08X\n", mask);
  if (mask & SR_ERROR_MASK) return 1;

  return 0;
}
// Maximalni delka bloku dat je 0.5 Kb
static int memCompare (uint32_t base, const uint32_t *data, uint32_t len) {
  uint8_t  res;
  uint32_t i;
  int      k;

  res = ReadMemoryArray (base, gReadBuffer, len);
  k   = 0;
  if (res == OR_STATUS_ACK) {
    for (i=0; i<len; i++) {
      if (gReadBuffer[i] != data[i]) k++;
    }
  } else return -1;
  printf ("%s [l=0x%02X]: Error count = %d\n", __func__, len, k);
  return k;
}
static int verifyImage (void) {
  int result;
  uint32_t  block, wlen;
  uint32_t  waddr = FlashBase;
  uint32_t* rwptr = (uint32_t*) flashDataSource;
  wlen = flashDataLenght >> 2;
  if (flashDataLenght & 3) wlen++;
  while (wlen) {
    if (wlen > BlockLenMax) block = BlockLenMax;
    else                    block = wlen;
    result = memCompare (waddr, rwptr, block);
    if (result) return 1;
    waddr += 4 * block;
    rwptr += block;
    wlen  -= block;
  }
  return 0;
}
static int writeImage (void) {
  int       result;
  uint32_t  block, wlen;
  uint32_t  waddr = FlashBase;
  uint32_t* rwptr = (uint32_t*) flashDataSource;
  wlen = flashDataLenght >> 2;
  if (flashDataLenght & 3) wlen++;
  while (wlen) {
    if (wlen > BlockLenMax) block = BlockLenMax;
    else                    block = wlen;
    result = flash_write (waddr, rwptr, block);
    if (result) return 1;
    waddr += 4 * block;
    rwptr += block;
    wlen  -= block;
  }
  return 0;
}
static int chipInit (void) {
  uint8_t  res;
  uint32_t CoreID;
  res = Connect (&CoreID);
  printf ("CoreID=%08X, res=%d\n", CoreID, res);
  if (res != OR_STATUS_ACK) return 1;
  res = Attach ();
  printf ("Attach = %d\n", res);
  if (res != OR_STATUS_ACK) return 2;

  res = Reset();
  printf ("RESET = %d\n", res);
  if (res != OR_STATUS_ACK) return 3;
  return 0;
}
static int programStart (void) {
  uint8_t  res;
  
  res = Reset();
  printf ("RESET  = %d\n", res);
  if (res != OR_STATUS_ACK) return 1;
  res = Run();
  if (res != OR_STATUS_ACK) return 2;
  return 0;
}
/**
 * @brief Zapsání nové hodnoty do všech option bytů
 *
 * @param wmask Určuje, které bloky flash budou chráněny proti zápisu. Blok má 4KB, jednička
 * ve wmask znamená ochranu. Např. 0x0003 značí ochranu prvních 8 KB flash. 
 * @return int Návratový kód, 0 značí úspěch.
 **/
static int writeProtection (uint16_t wmask) {
  uint32_t blen = options_write_stub_len >> 2;
  blen -= 1;
  wmask = ~wmask;
  uint32_t wopt = (uint32_t)(wmask & 0x00FF) | ((uint32_t)(wmask & 0xFF00) << 8);
  printf ("wopt=0x%08X\n", wopt);
  options_write_stub[blen] = wopt;
  /* Pokud je potřeba zamknout procesor i proti čtení (Level 1), odkomentuj následující 2 řádky:
  blen -= 2;
  options_write_stub[blen] = 0x00FF0055;
  
  Level 2 (0x00FF00CC) je totálně destrukční a není !!! žádné !!! cesty zpátky.
  Nakonec i tohle je spíš pro paranoiky, nezkoušel jsem to a ani nebudu */
  if (eraseOptions())   return 1;
  if (writeOptions())   return 2;
  // readOptions();
  return 0;
}
static int isProtected (void) {
  uint32_t wrpr;
  uint8_t  sta = ReadMemory(FLASH_WRPR, &wrpr);
  if (sta != OR_STATUS_ACK) return 0;
  wrpr = ~ wrpr;
  printf ("Flash WRPR=0x%08X\n", wrpr);
  if (wrpr) return 1;
  return 0;
}
static int clearProtection (void) {
  if (eraseOptions())   return 1;
  if (writeOptions())   return 2;
  return 0;
}
int FlashProgram (void) {
  if (chipInit())       return 1;

  if (isProtected()) {
    if (clearProtection()) return 7;
                        return 10;
  }
  if (cmd_erase_mass()) return 2;
  if (writeImage())     return 3;
  if (verifyImage())    return 4;
  
  if (writeProtection (0x0003))
                        return 5;
  if (programStart())   return 6;
  return 0;
}
