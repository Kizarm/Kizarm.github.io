#include "swd.h"
#include "swd-api.h"

volatile uint32_t APSelect = 0, TAR = 0xFFFFFFFF;

uint8_t ReadDP (uint8_t address, uint32_t *data) {
  uint8_t status;

  do {
    status = swd_read (0, address, (unsigned long *) data);
  } while (status == OR_STATUS_WAIT);
  return status;
}
uint8_t WriteDP (uint8_t address, uint32_t data) {
  uint8_t status;

  do {
    status = swd_write (0, address, data);
  } while (status == OR_STATUS_WAIT);
  return status;
}
uint8_t SetAPSelect (uint8_t address) {
  uint32_t new_APSelect = (APSelect & (~0xF0)) | (address & 0xF0);
  uint8_t status = OR_STATUS_ACK;

  if (new_APSelect != APSelect) {
    status = WriteDP (8, new_APSelect);
    if (status == OR_STATUS_ACK)
      APSelect = new_APSelect;
  }
  return status;
}
uint8_t ReadAP (uint8_t address, uint32_t *data) {
  if (address == 0x04 && TAR != 0xFFFFFFFF)
    return TAR;
  uint8_t status = SetAPSelect (address);

  if (status == OR_STATUS_ACK) {
    do {
      status = swd_read (1, address & 0x0F, (unsigned long *) data);
    } while (status == OR_STATUS_WAIT);
  }
  return status;
}
uint8_t ReadAP2 (uint8_t address, uint32_t *data) {
  uint8_t status;

  status = ReadAP (address, data);
  if (status == OR_STATUS_ACK)
    status = ReadAP (address, data);
  return status;
}
uint8_t WriteAP (uint8_t address, uint32_t data) {
  uint8_t status = SetAPSelect (address);

  if (status == OR_STATUS_ACK) {
    do {
      status = swd_write (1, address & 0x0F, data);
    } while (status == OR_STATUS_WAIT);
  }
  return status;
}

uint8_t Connect (uint32_t *CoreID) {
  uint32_t data;
  uint8_t status;

  swd_enable();
  status = ReadDP (0, &data);
  if (CoreID)
    *CoreID = data;
  if ( (data & 1) != 1 || ( (data >> 1) & 0x7FF) != 0x23B)
    return OR_STATUS_FAULT;

  // Reset sticky error bits
  if (status == OR_STATUS_ACK)
    status = WriteDP (0, 0x1E);

  // Turn on SWD debug port
  if (status == OR_STATUS_ACK)
    status = ReadDP (0x4, &data);
  data |= (1 << 28) | (1 << 30); // turn on debug interface
  if (status == OR_STATUS_ACK)
    status = WriteDP (0x4, data);

  // Read AP IDR- Mandatory or the AP will not work
  if (status == OR_STATUS_ACK)
    status = ReadAP2 (0xFC, &data);

  // Configure memory accesses for auto-increment, 32-bit mode
  if (status == OR_STATUS_ACK)
    status = ReadAP2 (0, &data);
  data &= ~0x7;
  data |=  0x2;  // Set 32-bit access size
  data &= ~0x30;
  data |=  0x10; // increment single
  if (status == OR_STATUS_ACK)
    status = WriteAP (0, data);
  if (status == OR_STATUS_ACK)
    swd_flush();
  return status;
}
uint8_t Attach (void) {
  uint32_t data;
  uint8_t status = Stop();
  if(status != OR_STATUS_ACK) return status;
  // Turn on reset vector + exception catch
  status = WriteMemory(0xE000EDFC, (1<<24) | (1<<10) | (1<<8) | (1<<4) | (1<<0));
  if(status != OR_STATUS_ACK) return status;

  // Reset the chip
  status = WriteMemory(0xE000ED0C, (0x5FA << 16) | 4);
  if(status != OR_STATUS_ACK) return status;

  // Enable Data Watchpoint & Trace module
  status = ReadMemory(0xE000EDFC, &data);
  if(status != OR_STATUS_ACK) return status;
  status = WriteMemory(0xE000EDFC, data | 1<<24);
  if(status != OR_STATUS_ACK) return status;
  status = ReadMemory(0xE000EDFC, &data);
  if(status != OR_STATUS_ACK) return status;
/*
  uint32_t wps, dps;
  // Read and figure out how many breakpoints are supported
  status = ReadMemory(0xE0002000, &dps);
  dps = (dps>>4) & 0xF;
  if(status != OR_STATUS_ACK) return status;
  // Read and figure out how many watchpoints are supported
  status = ReadMemory(0xE0001000, &wps);
  if(status != OR_STATUS_ACK) return status;
  wps = (wps>>28) & 0xF;
  printf ("dps = %d, wps = %d\n", dps, wps);
  printf ("wps = %d\n", wps);
*/
  // Flash Patch Control Register: set ENABLE
  status = WriteMemory(0xE0002000, (1<<1) | (1<<0));
  return status;
}

uint8_t ReadMemory (uint32_t address, uint32_t *data) {
  uint8_t status;

  status = WriteAP (4, address);
  if (status == OR_STATUS_ACK)
    status = ReadAP2 (0x0C, data);
  return status;
}
uint8_t ReadMemoryArray (uint32_t address, uint32_t *data, uint32_t count) {
  uint8_t status;
  int i;

  status = WriteAP (4, address);
  if (status != OR_STATUS_ACK) return status;
  status = ReadAP (0x0C, &data[0]); // dummy read
  i = 0;
  while (status == OR_STATUS_ACK && i < count) {
    status = ReadAP (0x0C, &data[i]);
    i++;
  }
  return status;
}

uint8_t WriteMemory(uint32_t address, uint32_t data) {
  uint8_t status;

  status = WriteAP( 4, address);
  if(status == OR_STATUS_ACK)
  {
    status = WriteAP( 0x0C, data);
    swd_flush();
  }
  return status;
}
uint8_t WriteMemoryArray(uint32_t address, const uint32_t *data, uint32_t count) {
  uint8_t status;
  int i;

  status = WriteAP( 4, address);
  i = 0;
  while(status == OR_STATUS_ACK && i < count)
  {
    status = WriteAP( 0x0C, data[i]);
    i++;
  }
  swd_flush();
  return status;
}
uint8_t Run() {
  uint8_t status = WriteAP(4, 0xE000EDF0);
  if(status == OR_STATUS_ACK) {
    uint32_t data;

    status = ReadAP2(0x10, &data);
    if(data & (1<<17) && status == OR_STATUS_ACK) {
      data &= 0xFFFF; data |= 0xA05F << 16;
      data &= ~7;
      data |= 1;
      status = WriteAP(0x10, data);
      swd_flush();
    }
  }
  return status;
}
uint8_t Step() {
  uint8_t status = WriteAP(4, 0xE000EDF0);
  if(status == OR_STATUS_ACK) {
    uint32_t data;

    status = ReadAP2(0x10, &data);
    if(data & (1<<17) && status == OR_STATUS_ACK) {
      data &= 0xFFFF; data |= 0xA05F << 16;
      data &= ~7;
      data |= 1 | 4;
      status = WriteAP(0x10, data);
      swd_flush();
    }
  }
  return status;
}
uint8_t Stop() {
  uint8_t status = WriteAP(4, 0xE000EDF0);
  if(status == OR_STATUS_ACK) {
    uint32_t data;

    status = ReadAP2(0x10, &data);
    if(!(data & (1<<17)) && status == OR_STATUS_ACK) {
      data &= 0xFFFF; data |= 0xA05F << 16;
      data &= ~7;
      data |= 3;
      status = WriteAP(0x10, data);
      swd_flush();
    }
  }
  return status;
}
uint8_t Reset() {
  uint8_t status = Stop();
  if(status != OR_STATUS_ACK) return status;
  /* Read DHCSR here to clear S_RESET_ST bit before reset */
  uint32_t data;
  status = ReadMemory (0xE000EDF0, &data);
  // Request system reset from NVIC: SRST doesn't work correctly 
  // This could be VECTRESET: 0x05FA0001 (reset only core)
  //          or SYSRESETREQ: 0x05FA0004 (system reset)
  status = WriteMemory (0xE000ED0C, (0x05FA<<16) | (1<<2));
  // Poll for release from reset
  while (1) {
    status = ReadMemory (0xE000EDF0, &data);
    if (status != OR_STATUS_ACK) return status;
    if (data & (1<<25)) break;
  }
  // Reset DFSR flags
  status = WriteMemory (0xE000ED30, 0x1F);
  return status;
}
uint8_t ReadCore(uint8_t regno, uint32_t *data) {
  uint8_t status = WriteAP( 0x4, 0xE000EDF0); // set up TAR
  if(status == OR_STATUS_ACK) {
    status = WriteAP( 0x14, regno);
    if(status == OR_STATUS_ACK)
      status = ReadAP2( 0x18, data);
  }
  return status;
}
uint8_t WriteCore(uint8_t regno, uint32_t data) {
  uint8_t status = WriteAP( 0x4, 0xE000EDF0); // set up TAR
  if(status == OR_STATUS_ACK) {
    status = WriteAP( 0x18, data);
    if(status == OR_STATUS_ACK)
      status = WriteAP( 0x14, ((uint32_t)regno) | 1<<16);
  }
  return status;
}
uint8_t WaitHalt (void) {
  uint8_t  status;
  uint32_t data;
  while (1) {
    status = ReadMemory (0xE000EDF0, &data);
    if (status != OR_STATUS_ACK) return status;
    if (data & (1<<17)) break;
  }
  // System halted
  uint32_t inst;
  status = ReadMemory (0xE000ED30, &data);
  if (status != OR_STATUS_ACK) return status;
  // printf ("System Halted - Flags = 0x%08X\n", data);
  if (data & (1<<1)) { // On breakpoints
    status = ReadCore (CORE_PC, &data);
    if (status != OR_STATUS_ACK) return status;
    status = ReadMemory ( (data & (~3)), &inst);
    if (status != OR_STATUS_ACK) return status;
    if (data & 2) inst >>= 16;
    else          inst  &= 0xFFFF;
    // printf ("Halt on PC=0x%08X [0x%04X]\n", data, inst);
  }
  return status;
}
