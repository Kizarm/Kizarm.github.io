#include "flash.h"
#include "swd.h"
#include "swd-api.h"
#include <LPC11Uxx.h>

#define printf(fmt,...)


#define IAP_PGM_CHUNKSIZE       256     /* should fit in RAM on any device */

struct flash_param {
  uint16_t        opcodes[2];     /* two opcodes to return to after calling the ROM */
  uint32_t        command[5];     /* command operands */
  uint32_t        result[4];      /* result data */
};

struct flash_program {
  struct flash_param      p;
  uint8_t                 data[IAP_PGM_CHUNKSIZE];
};
__attribute__((aligned(4)))
static struct flash_program flash_pgm;

#define MSP     17                      /* Main stack pointer register number */
#define MIN_RAM_SIZE_FOR_LPC1xxx        2048
#define RAM_USAGE_FOR_IAP_ROUTINES      32      /* IAP routines use 32 bytes at top of ram */

#define IAP_ENTRYPOINT  0x1fff1ff1
#define IAP_RAM_BASE    0x10000000

enum IAP_CMD {
  IAP_CMD_PREPARE       = 50,
  IAP_CMD_PROGRAM       = 51,
  IAP_CMD_ERASE         = 52,
  IAP_CMD_BLANKCHECK    = 53
};
enum IAP_STATUS {
  IAP_STATUS_CMD_SUCCESS         = 0,
  IAP_STATUS_INVALID_COMMAND     = 1,
  IAP_STATUS_SRC_ADDR_ERROR      = 2,
  IAP_STATUS_DST_ADDR_ERROR      = 3,
  IAP_STATUS_SRC_ADDR_NOT_MAPPED = 4,
  IAP_STATUS_DST_ADDR_NOT_MAPPED = 5,
  IAP_STATUS_COUNT_ERROR         = 6,
  IAP_STATUS_INVALID_SECTOR      = 7,
  IAP_STATUS_SECTOR_NOT_BLANK    = 8,
  IAP_STATUS_SECTOR_NOT_PREPARED = 9,
  IAP_STATUS_COMPARE_ERROR       = 10,
  IAP_STATUS_BUSY                = 11
};
static void lpc11x_iap_call (struct flash_param * param, unsigned param_len);
static int  lpc11xx_flash_prepare (uint32_t addr, int len);
static int  lpc11xx_flash_erase   (uint32_t addr, int len);
static int  lpc11xx_flash_write   (uint32_t dest, const uint8_t * src, int len);

static void *memcpy (void * dest, const void * src, unsigned n) {
  const char * s = (const char *) src;
  char * d = (char *) dest;
  unsigned i;
  for (i=0; i<n; i++) d[i] = s[i];
  return dest;
}
static void *memset (void * s, int c, unsigned n) {
  char * p = (char *) s;
  unsigned i;
  for (i=0; i<n; i++) p[i] = c;
  return s;
}

static void regs_read (uint32_t * regs) {
  ReadCore (0, regs);
  ReadCore (1, regs + 1);
}
static void regs_write (uint32_t * regs) {
  WriteCore (0,   regs[0]);
  WriteCore (1,   regs[1]);
  WriteCore (MSP, regs[2]);
  WriteCore (14,  regs[3]);
  WriteCore (15,  regs[4]);
}

static void lpc11x_iap_call (struct flash_param * param, unsigned param_len) {
  uint32_t regs[5];

  /* fill out the remainder of the parameters and copy the structure to RAM */
  param->opcodes[0] = 0xbe00;
  param->opcodes[1] = 0x0000;
  WriteMemoryArray (IAP_RAM_BASE, (void *) param, param_len >> 2);

  /* set up for the call to the IAP ROM */
  regs_read (regs);
  struct flash_param   * const fpp = (struct flash_param   * const) IAP_RAM_BASE;
  regs[0] = (uint32_t) & fpp->command;
  regs[1] = (uint32_t) & fpp->result;

  regs[2] = IAP_RAM_BASE + MIN_RAM_SIZE_FOR_LPC1xxx - RAM_USAGE_FOR_IAP_ROUTINES;
  regs[3] = IAP_RAM_BASE | 1;
  regs[4] = IAP_ENTRYPOINT;
  regs_write (regs);

  /* start the target and wait for it to halt again */
  Run();
  WaitHalt();

  /* copy back just the parameters structure */
  ReadMemoryArray (IAP_RAM_BASE, (void *) param, sizeof (struct flash_param) >> 2);
}
static inline int flash_page_size () {
  return 4096;
}
static int lpc11xx_flash_prepare (uint32_t addr, int len) {
  /* prepare the sector(s) to be erased */
  memset (&flash_pgm.p, 0, sizeof (flash_pgm.p));
  flash_pgm.p.command[0] = IAP_CMD_PREPARE;
  flash_pgm.p.command[1] = addr / flash_page_size ();
  flash_pgm.p.command[2] = (addr + len - 1) / flash_page_size ();

  lpc11x_iap_call (&flash_pgm.p, sizeof (flash_pgm.p));
  if (flash_pgm.p.result[0] != IAP_STATUS_CMD_SUCCESS) {
    return -1;
  }

  return 0;
}

static int lpc11xx_flash_erase (uint32_t addr, int len) {

  if (addr % flash_page_size ())
    return -1;

  /* prepare... */
  if (lpc11xx_flash_prepare (addr, len))
    return -1;

  /* and now erase them */
  flash_pgm.p.command[0] = IAP_CMD_ERASE;
  flash_pgm.p.command[1] = addr / flash_page_size ();
  flash_pgm.p.command[2] = (addr + len - 1) / flash_page_size ();
  flash_pgm.p.command[3] = 12000; /* XXX safe to assume this? */
  lpc11x_iap_call (&flash_pgm.p, sizeof (flash_pgm.p));
  if (flash_pgm.p.result[0] != IAP_STATUS_CMD_SUCCESS) {
    return -1;
  }
  flash_pgm.p.command[0] = IAP_CMD_BLANKCHECK;
  lpc11x_iap_call (&flash_pgm.p, sizeof (flash_pgm.p));
  if (flash_pgm.p.result[0] != IAP_STATUS_CMD_SUCCESS) {
    return -1;
  }

  return 0;
}

static int lpc11xx_flash_write (uint32_t dest, const uint8_t * src, int len) {
  unsigned first_chunk = dest / IAP_PGM_CHUNKSIZE;
  unsigned last_chunk = (dest + len - 1) / IAP_PGM_CHUNKSIZE;
  unsigned chunk_offset = dest % IAP_PGM_CHUNKSIZE;
  unsigned chunk;

  for (chunk = first_chunk; chunk <= last_chunk; chunk++) {

    printf ("chunk %u len %d\n", chunk, len);
    /* first and last chunk may require special handling */
    if ( (chunk == first_chunk) || (chunk == last_chunk)) {

      /* fill with all ff to avoid sector rewrite corrupting other writes */
      memset (flash_pgm.data, 0xff, sizeof (flash_pgm.data));

      /* copy as much as fits */
      int copylen = IAP_PGM_CHUNKSIZE - chunk_offset;
      if (copylen > len)
        copylen = len;
      memcpy (&flash_pgm.data[chunk_offset], src, copylen);

      /* if we are programming the vectors, calculate the magic number */
      if ( (chunk == 0) && (chunk_offset == 0)) {
        if (copylen < 32) {
          /* we have to be programming at least the first 8 vectors... */
          return -1;
        }

        uint32_t * w = (uint32_t *) (&flash_pgm.data[0]);
        uint32_t sum = 0;
        unsigned i;
        for (i = 0; i < 7; i++)
          sum += w[i];
        w[7] = ~sum + 1;
      }

      /* update to suit */
      len -= copylen;
      src += copylen;
      chunk_offset = 0;

    } else {

      /* interior chunk, must be aligned and full-sized */
      memcpy (flash_pgm.data, src, IAP_PGM_CHUNKSIZE);
      len -= IAP_PGM_CHUNKSIZE;
      src += IAP_PGM_CHUNKSIZE;
    }

    /* prepare... */
    if (lpc11xx_flash_prepare (chunk * IAP_PGM_CHUNKSIZE, IAP_PGM_CHUNKSIZE))
      return -1;

    struct flash_program * const fpg = (struct flash_program * const) IAP_RAM_BASE;
    /* set the destination address and program */
    flash_pgm.p.command[0] = IAP_CMD_PROGRAM;
    flash_pgm.p.command[1] = chunk * IAP_PGM_CHUNKSIZE;
    flash_pgm.p.command[2] = (uint32_t) & fpg->data;
    flash_pgm.p.command[3] = IAP_PGM_CHUNKSIZE;
    /* assuming we are running off IRC - safe lower bound */
    flash_pgm.p.command[4] = 12000; /* XXX safe to presume this? */
    lpc11x_iap_call (&flash_pgm.p, sizeof (flash_pgm));
    if (flash_pgm.p.result[0] != IAP_STATUS_CMD_SUCCESS) {
      return -1;
    }

  }

  return 0;
}

static const uint32_t RamBase   = IAP_RAM_BASE;
static const uint32_t FlashBase = 0x00000000;

static inline int cmd_erase_mass (void) {
  lpc11xx_flash_erase (FlashBase, flashDataLenght);
  return 0;
}
/*
 * Verifikace chodí, jen pokud je obraz firmware korektní,
 * t.j. součet prvních 8 vektorů je nulový.
 * */
static const uint32_t BlockLenMax = 0x80;
static uint32_t       gReadBuffer [0x80];
// Maximalni delka bloku dat je 0.5 Kb
static int memCompare (uint32_t base, const uint32_t * data, uint32_t len) {
  uint8_t  res;
  uint32_t i;
  int      k;

  res = ReadMemoryArray (base, gReadBuffer, len);
  k   = 0;
  if (res == OR_STATUS_ACK) {
    for (i=0; i<len; i++) {
      if (gReadBuffer[i] != data[i]) k++;
    }
  } else return -1;
  printf ("%s [l=0x%02X]: Error count = %d\n", __func__, len, k);
  return k;
}
static int verifyImage (void) {
  int result;
  uint32_t  block, wlen;
  uint32_t  waddr = FlashBase;
  uint32_t * rwptr = (uint32_t *) flashDataSource;
  wlen = flashDataLenght >> 2;
  if (flashDataLenght & 3) wlen++;

  Reset ();
  Stop  ();
  // Remap bootsect to flash SYSMEMREMAP = 2
  WriteMemory (LPC_SYSCON_BASE + 0, 2);
  
  while (wlen) {
    if (wlen > BlockLenMax) block = BlockLenMax;
    else                    block = wlen;
    result = memCompare (waddr, rwptr, block);
    if (result) return 1;
    waddr += 4 * block;
    rwptr += block;
    wlen  -= block;
  }
  return 0;
}

static int writeImage (void) {
  uint32_t  waddr = FlashBase;
  uint8_t * rwptr = (uint8_t *) flashDataSource;
  int result = lpc11xx_flash_write (waddr, rwptr, flashDataLenght);
  if (result) return 1;
  return 0;
}
static int chipInit (void) {
  uint8_t  res;
  uint32_t CoreID;
  res = Connect (&CoreID);
  printf ("CoreID=%08X, res=%d\n", CoreID, res);
  if (res != OR_STATUS_ACK) return 1;
  res = Attach ();
  printf ("Attach = %d\n", res);
  if (res != OR_STATUS_ACK) return 2;

  res = Reset();
  printf ("RESET = %d\n", res);
  if (res != OR_STATUS_ACK) return 3;
  return 0;
}
static int programStart (void) {
  uint8_t  res;

  res = Reset();
  printf ("RESET  = %d\n", res);
  if (res != OR_STATUS_ACK) return 1;
  res = Run();
  if (res != OR_STATUS_ACK) return 2;
  return 0;
}
int FlashProgram (void) {
  if (chipInit())       return 1;

  if (cmd_erase_mass()) return 2;
  if (writeImage())     return 3;
  if (verifyImage())    return 4;

  if (programStart())   return 5;
  return 0;
}
