#ifndef FLASH_H
#define FLASH_H
#include <stdint.h>

/// @file
/// Rutiny pro zápis do flash a option bytů cílové platformy

/**
 * @brief Zápis do flash cílového procesoru
 * 
 * Tohle je jediná věc, která musí být v main() vidět.
 *
 * @return int Chybový kód, 0 je správně
 **/
extern int FlashProgram (void);

/*  in user.S  */
extern const uint32_t * flashDataSource;
extern const uint32_t   flashDataLenght;

#endif // FLASH_H
