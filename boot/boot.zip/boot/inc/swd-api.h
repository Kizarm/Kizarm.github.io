#ifndef SWD_API_H
#define SWD_API_H
#include <stdint.h>

/**
 * @file
 * @brief API funkce SWD komunikace - mělo by chodit na Cortex-Mx
 */

#define SWDBUFLEN 0x100

enum CORE_REGS {
  CORE_R0  = 0,
  CORE_R1  = 1,
  CORE_R2  = 2,
  CORE_R3  = 3,
  CORE_R4  = 4,
  CORE_R5  = 5,
  CORE_R6  = 6,
  CORE_R7  = 7,
  CORE_R8  = 8,
  CORE_R9  = 9,
  CORE_R10 = 10,
  CORE_R11 = 11,
  CORE_R12 = 12,
  CORE_R13 = 13,
  CORE_SP  = 13,
  CORE_R14 = 14,
  CORE_R15 = 15,
  CORE_PC  = 15,
  CORE_XPSR= 16
};

// SWD status responses. SWD_ACK is good.
enum OR_STATUS_CODES {
  OR_STATUS_ACK     = 0b001,
  OR_STATUS_WAIT    = 0b010,
  OR_STATUS_FAULT   = 0b100,
  OR_STATUS_PARITY  = 0b1000,
  OR_STATUS_NOTHING = 0b11111111
};
/**
 * @brief Čtení DP
 *
 * @param address Adresa
 * @param data ukazatel na vrácená data
 * @return uint8_t Chybový kód
 **/
extern uint8_t ReadDP          (uint8_t address, uint32_t *data);
/**
 * @brief Zápis DP
 *
 * @param address Adresa
 * @param data zapisovaná data
 * @return uint8_t Chybový kód
 **/
extern uint8_t WriteDP         (uint8_t address, uint32_t  data);
/**
 * @brief Nastavení AP
 *
 * @param address Adresa
 * @return uint8_t Chybový kód
 **/
extern uint8_t SetAPSelect     (uint8_t address);
/**
 * @brief Čtení AP
 *
 * @param address Adresa
 * @param data ukazatel na vrácená data
 * @return uint8_t Chybový kód
 **/
extern uint8_t ReadAP          (uint8_t address, uint32_t *data);
/**
 * @brief Čtení AP dvakrát
 *
 * @param address Adresa
 * @param data ukazatel na vrácená data
 * @return uint8_t Chybový kód
 **/
extern uint8_t ReadAP2         (uint8_t address, uint32_t *data);
/**
 * @brief Zápis AP
 *
 * @param address Adresa
 * @param data zapisovaná data
 * @return uint8_t Chybový kód
 **/
extern uint8_t WriteAP         (uint8_t address, uint32_t  data);
/**
 * @brief Připojení k cíli
 *
 * @param CoreID ukazatel na identifikátor jádra
 * @return uint8_t chybový kód
 **/
extern uint8_t Connect         (uint32_t *CoreID);
/**
 * @brief Čtení slova paměti
 *
 * @param address Adresa
 * @param data ukazatel na vrácená data
 * @return uint8_t Chybový kód
 **/
extern uint8_t ReadMemory      (uint32_t address, uint32_t *data);
/**
 * @brief Čtení bloku paměti
 *
 * @param address Adresa
 * @param data ukazatel na vrácená data
 * @param count počet slov
 * @return uint8_t Chybový kód
 **/
extern uint8_t ReadMemoryArray (uint32_t address, uint32_t *data, uint32_t count);
/**
 * @brief Zápis slova do paměti
 *
 * @param address Adresa
 * @param data zapisovaná data
 * @return uint8_t Chybový kód
 **/
extern uint8_t WriteMemory     (uint32_t address, uint32_t  data);
/**
 * @brief Zápis bloku do paměti
 *
 * @param address Adresa
 * @param data zapisovaná data
 * @param count počet slov
 * @return uint8_t Chybový kód
 **/
extern uint8_t WriteMemoryArray(uint32_t address, const uint32_t *data, uint32_t count);
/// Počáteční připojení k SWD
/// @return uint8_t Chybový kód
extern uint8_t Attach          (void);
/// Spuštění programu
/// @return uint8_t Chybový kód
extern uint8_t Run             (void);
/// Krok
/// @return uint8_t Chybový kód
extern uint8_t Step            (void);
/// Zastavení
/// @return uint8_t Chybový kód
extern uint8_t Stop            (void);
/// Reset
extern uint8_t Reset           (void);
/// Čekání na zastavení (po breakpoint)
/// @return uint8_t Chybový kód
extern uint8_t WaitHalt        (void);

/**
 * @brief Čtení registru
 *
 * @param regno Jeho číslo
 * @param data  ukazatel na vrácená data
 * @return uint8_t Chybový kód
 **/
extern uint8_t ReadCore        (uint8_t regno, uint32_t *data);
/**
 * @brief Zápis do registru
 *
 * @param regno Jeho číslo
 * @param data zpisovaná hodnota
 * @return uint8_t Chybový kód
 **/
extern uint8_t WriteCore       (uint8_t regno, uint32_t  data);

#endif // SWD_API_H
