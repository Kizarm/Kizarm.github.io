/*
<Copyright 2011 mrd>

Usage of the works is permitted provided that this instrument is retained with the works, so that any entity that uses the works is notified of this instrument.

DISCLAIMER: THE WORKS ARE WITHOUT WARRANTY.
*/
/**
 * @file
 * @brief Základní SWD IO, na začátku funkce platformě závislé
 * */

// GPIO pins used for SWD
#define SWCLK_BIT 18
#define SWDIO_BIT 19

#define SWCLK_BIT_MSK (1<<SWCLK_BIT)
#define SWDIO_BIT_MSK (1<<SWDIO_BIT)

// Bit delay - pro 48MHz clock muze byt 0
#define BIT_DELAY 0

/**
 * @brief Přepnutí do SWD módu
 *
 Send magic number to switch to SWD mode. This function sends many
 zeros, 1s, then the magic number, then more 1s and zeros to try to
 get the SWD state machine's attention if it is connected in some
 unusual state.
 * @return void
 **/
void swd_enable(void);
/**
 * @brief Pomocná funkce
 **/
void swd_flush(void);

// SWD status responses. SWD_ACK is good.
enum SWD_RESPONSES {
  SWD_ACK    = 0b001,
  SWD_WAIT   = 0b010,
  SWD_FAULT  = 0b100,
  SWD_PARITY = 0b1000
};
/**
 * @brief Obecný zápis na SWD
 *
 This is one of the two core SWD functions. It can write to a debug port
 register or to an access port register. It implements the host->target
 write request, reading the 3-bit status, and then writing the 33 bits
 data+parity.
 * @param APnDP AP nebo DP
 * @param A ...
 * @param data data
 * @return int Status
 **/
enum SWD_RESPONSES swd_write(char APnDP, int A, unsigned long data);

/**
 * @brief Obecné čtení ze SWD
 *
 This is one of the two core SWD functions. It can read from a debug port
 register or an access port register. It implements the host->target
 read request, reading the 3-bit status, and then reading the 33 bits
 data+parity.
 * @param APnDP AP nebo DP
 * @param A ...
 * @param data data
 * @return int Status
 **/
enum SWD_RESPONSES swd_read(char APnDP, int A, volatile unsigned long *data);

