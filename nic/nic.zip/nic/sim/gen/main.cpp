#include <stdlib.h>
#include <stdio.h>

typedef double real;

static const real U0=2.0, G=2e-4;

static const real power (const real x, const unsigned n) {
  real result = x;
  for (unsigned i=0; i<n; i++) result *= result;
  return result;
}
/// negativní (nelineární) odpor je reprezentován polynomem
static const real neg_n (const real u) {
  const unsigned m = 1;   // polynom vyššího řádu je lineárnější v oblasti negativního odporu,
  // ale není nutné jej zvyšovat nad 3. Řád je 2^m + 1 (3,5,9...), musí se pak upravit i G !!!
  real res = power (u, m) - power (U0, m);
  res *= G * u;
  return res;
}
static void plot_va (const char * filename) {
  const real m = 2.5, d=0.01;
  FILE * out = fopen (filename, "w");
  for (real u=-m; u<+m; u+=d) {
    fprintf (out, "%10.6f %10.6f %10.6f %10.6f\n", u, neg_n(u), 1000.0 * neg_n(u), 0.001 * u);
  }
  fclose(out);
}


int main () {
  plot_va ("x.dat");
  return system("gnuplot eps.cmd");
}
