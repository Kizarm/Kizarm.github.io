#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include "solver.h"

using namespace std;
// Dva dost nečitelné výrazy pro zjednodušení dalšího zápisu
template<class T, size_t N> constexpr size_t SIZE (T (&)[N]) { return N; }
template<const  unsigned N> using PFUNC = void (*) (const Point<N> &, real &);

/** TEST - harmonický oscilátor se záporným nelineárním odporem, charakteristika N
 *  t, w[0] = u, w[1] = v (u je celkové napětí, v proud L)
 *  F1: du/dt = - (v/C + i(u)/C)
 *  F2: dv/dt = + u/L
 *  bc: t = 0: x0 = 0, p0 = 1
 * */

static const real U0=2.0, G=2e-4, L=1e-2, C=1e-6;

static const real power (const real x, const unsigned n) {
  real result = x;
  for (unsigned i=0; i<n; i++) result *= result;
  return result;
}
/// negativní (nelineární) odpor je reprezentován polynomem
static const real neg_n (const real u) {
  const unsigned m = 1;   // polynom vyššího řádu je lineárnější v oblasti negativního odporu,
  // ale není nutné jej zvyšovat nad 3. Řád je 2^m + 1 (3,5,9...), musí se pak upravit i G !!!
  real res = power (u, m) - power (U0, m);
  res *= G * u;
  return res;
}
static void compute (const char * filename, const real bu) {
  const unsigned steps = 5000;
  const real w0 [] = {bu, 0.0};        // Počet počátečních podmínek musí odpovídat počtu rovnic...
  const unsigned N = SIZE (w0);        // čili určuje celkový rozsah výpočtu.

  const Point<N> bc (0.0, w0);
  
  PFUNC<N> pf[N] = {                   // funkce lze předat jako lambdy...
    [=](const Point<N> & z, real & result) -> auto {      // F1
        real u = z.w[0], v = z.w[1];
        result = - (v + neg_n(u)) / C;
    },
    [=](const Point<N> & z, real & result) -> auto {      // F2
        real u = z.w[0];
        result = u / L;
    }
  };
  
  RungeKutta <N, PFUNC<N>> solver (pf, bc, 1e-5);
  
  vector<Point<N>> data;
  data.push_back (bc);
  for (unsigned i=0; i<steps; i++) {
    const Point<N> & s = solver.solve();
    data.push_back (s);
  }
  
  FILE * out = fopen (filename, "w");
  for (auto p: data) {
    fprintf (out, "%8.5f", p.t);
    for (auto k: p.w) fprintf (out, " %10.6f", k);
    fprintf (out, "\n");
  }
  fclose(out);
}
static void plot_va (const char * filename) {
  const real m = 2.5, d=0.01;
  FILE * out = fopen (filename, "w");
  for (real u=-m; u<+m; u+=d) {
    fprintf (out, "%10.6f %10.6f\n", u, neg_n(u));
  }
  fclose(out);
}

int main () {
  compute("x.dat", 0.1);
  compute("y.dat", 3.0);
  plot_va("z.dat");
  return system ("gnuplot osc.cmd");
}

