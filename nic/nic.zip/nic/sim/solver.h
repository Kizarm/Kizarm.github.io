#ifndef SOLVER_H
#define SOLVER_H

typedef double real;

template<const unsigned N> struct Point {
  Point () : t(0) {
    for (unsigned n=0; n<N; n++) w[n] = 0;    
  };
  Point (const real t0, const real w0 [N]) : t(t0) {
    for (unsigned n=0; n<N; n++) w[n] = w0[n];
  };
  Point (const Point<N> & other) : t(other.t) {
    for (unsigned n=0; n<N; n++) w[n] = other.w[n];
  }
  real t;
  real w[N];
};

/// Solver metodou Runge-Kutta
template<const unsigned N, typename FUNCTION> class RungeKutta {
  const real            h;            //!< krok metody
  const Point<N>        p0;           //!< holder pro počáteční podmínky
  FUNCTION              pf[N];        //!< počítané funkce typu real (*)(const Point<N> &)
  Point<N>              data;         //!< data
  public:
    /// konstruktor
    /// @param F Výpočetní objekt
    /// @param step krok metody
    /// @param pts  počet kroků
    RungeKutta(FUNCTION PF[N], const Point<N> & bc, const real step) :
      h(step), p0(bc) {
      data = p0;
      for (unsigned n=0; n<N; n++) pf[n] = PF[n];
    };
    void resetBC () { data = p0; };
    /// vlastní solver @param direction false pak běží pozpátku v čase
    const Point<N> & solve (const bool direction=true) {
      const real hh = direction ? +h : -h;
      
      Point<N> & p = data;
      
      const real hhh = 0.5 * hh;
      const real hhs = hh / 6.0;
      //Runge-Kutta method 4.order
      real     k1[N];
      for (unsigned k=0; k<N; k++) pf[k](p , k1[k]);
      Point<N> p2(p);              p2.   t += hhh;
      for (unsigned k=0; k<N; k++) p2.w[k] += hhh * k1[k];
      real     k2[N];
      for (unsigned k=0; k<N; k++) pf[k](p2, k2[k]);
      Point<N> p3(p);              p3.   t += hhh;
      for (unsigned k=0; k<N; k++) p3.w[k] += hhh * k2[k];
      real     k3[N];
      for (unsigned k=0; k<N; k++) pf[k](p3, k3[k]);
      Point<N> p4(p);              p4.   t += hh;
      for (unsigned k=0; k<N; k++) p4.w[k] += hh * k3[k];
      real     k4[N];
      for (unsigned k=0; k<N; k++) pf[k](p4, k4[k]);
      p.t += hh;
      for (unsigned k=0; k<N; k++)  p.w[k] += hhs * (k1[k] + 2.0 * k2[k] + 2.0 * k3[k] + k4[k]);

      return data;
    }
};

#endif // SOLVER_H
