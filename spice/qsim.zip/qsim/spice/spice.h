#ifndef SPICE_H
#define SPICE_H
#include <vector>
#include <string>
#include <atomic>

typedef void* funptr_t;
struct SpiceVector {
  std::string         name;
  std::vector<double> values;
};

class Spice {
  bool initialized;
  void * ngdllhandle;
  
  funptr_t ngSpice_Init_handle;
  funptr_t ngSpice_Command_handle;
  funptr_t ngSpice_Circ_handle;
  funptr_t ngSpice_CurPlot_handle;
  funptr_t ngSpice_AllVecs_handle;
  funptr_t ngSpice_GVI_handle;
  
  std::string       response;
  std::atomic<int>  timeout;
  std::atomic<bool> list_enabled;
  public:
    volatile bool no_bg;
    volatile bool will_unload;
  public:
    Spice();
    virtual ~Spice();
    
    bool Init (); //!< Nutné ! Pokud skončí false, nedá se už nic dalšího dělat !
    bool Circuit (const char * filename);
    bool Command (const char * cmd);
    bool CmdFmt  (const char * fmt, ...);
    void RunWait ();
    void Close   ();
    std::string  RespCmd (const char * cmd);
    std::vector<SpiceVector> Vectors (const std::vector<std::string> & names);
    std::vector<std::string> Labels  ();
    
    virtual void CatchCB (std::string row);
    virtual void SpiceProgress (char*);
    virtual void SpiceBgEnd    (bool);
};

#endif // SPICE_H
