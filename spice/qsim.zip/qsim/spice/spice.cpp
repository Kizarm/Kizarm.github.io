#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <signal.h>
#include <string.h>
#include <pthread.h>
#include <locale.h>
#include <dlfcn.h> /* to load libraries*/
#include <unistd.h>
#include <ctype.h>

#include "ngspice/sharedspice.h"
#include "spice.h"

#ifdef SPICE
static const char * loadstring = SPICE"/lib/libngspice.so";
#else
static const char * loadstring = "libngspice.so";
#endif // SPICE

static int ng_getchar (char* outputreturn, int ident, void* userdata);
static int ng_getstat (char* outputreturn, int ident, void* userdata);
static int ng_thread_runs (bool noruns,    int ident, void* userdata);
ControlledExit ng_exit;
SendData       ng_data;
SendInitData   ng_initdata;

using namespace std;

Spice::Spice() {
  initialized  = false;
  ngdllhandle  = nullptr;
  no_bg        = true;
  will_unload  = false;
  list_enabled = false;
  
  ngSpice_Init_handle    = nullptr;
  ngSpice_Command_handle = nullptr;
  ngSpice_CurPlot_handle = nullptr;
  ngSpice_AllVecs_handle = nullptr;
  ngSpice_GVI_handle     = nullptr;
  
}
void Spice::Close() {
  dlclose (ngdllhandle);
  initialized = false;
}

Spice::~Spice() {
  if (!initialized) return;
  Close();
}
bool Spice::Init() {
  if (initialized) return initialized;
  // nastavit v qt části nestačí, ostatně je to zbytečné, pokud se nenastaví
  // explicitně jiné (systémové), gcc automaticky použije LC_NUMERIC="C".
  setlocale (LC_NUMERIC, "C");
  char * errmsg = nullptr;
  ngdllhandle = dlopen (loadstring, RTLD_NOW);
  errmsg = dlerror();
  if (errmsg) printf ("%s\n", errmsg);
  if (ngdllhandle)
    printf ("ngspice.dll loaded\n");
  else {
    printf ("ngspice.dll not loaded !\n");
    return false;
  }
  ngSpice_Init_handle    = dlsym (ngdllhandle, "ngSpice_Init");
  errmsg = dlerror();
  if (errmsg)    printf ("%s", errmsg);
  ngSpice_Command_handle = dlsym (ngdllhandle, "ngSpice_Command");
  errmsg = dlerror();
  if (errmsg)    printf ("%s", errmsg);
  ngSpice_CurPlot_handle = dlsym (ngdllhandle, "ngSpice_CurPlot");
  errmsg = dlerror();
  if (errmsg)    printf ("%s", errmsg);
  ngSpice_AllVecs_handle = dlsym (ngdllhandle, "ngSpice_AllVecs");
  errmsg = dlerror();
  if (errmsg)    printf ("%s", errmsg);
  ngSpice_GVI_handle     = dlsym (ngdllhandle, "ngGet_Vec_Info");
  errmsg = dlerror();
  if (errmsg)    printf ("%s", errmsg);

  int ret = ((int (*) (SendChar*,  SendStat*,  ControlledExit*, SendData*, SendInitData*, BGThreadRunning*, void*)) ngSpice_Init_handle)
                      (ng_getchar, ng_getstat, ng_exit,         ng_data,   ng_initdata,  ng_thread_runs,    this);
  if (ret) return false;
  initialized = true;
  return initialized;
}
bool Spice::Circuit (const char * filename) {
  const int len = strlen (filename) + 16;
  char cmd [len];
  snprintf (cmd, len, "source %s", filename);
  return Command (cmd);
}
string Spice::RespCmd (const char * cmd) {
  string result;
  list_enabled = true;
  timeout      = 0;
  Command (cmd);
  for (;;) {
    usleep (1000);
    if (timeout++ > 10) break;
  }
  list_enabled = false;
  result = response;
  response.clear();
  return result;
}
void Spice::CatchCB (string row) {
  if (!list_enabled) return;
  string cmp ("stdout ");
  size_t pos = row.find (cmp);
  if (pos == string::npos) return;
  const size_t len = cmp.length();
  timeout = 0;
  response += row.substr(len+pos);
  response += '\n';
}


bool Spice::Command (const char * cmd) {
  // printf ("Command: \"%s\"\n", cmd);
  char * nc = strdup (cmd);
  int  ret = ((int (*) (char*)) ngSpice_Command_handle) (nc);
  return ret ? false : true;
}
void Spice::RunWait() {
  Command ("bg_run");
  /* wait until simulation finishes */
  /*
  for (;;) {
    usleep (100000);
    if (no_bg) break;
  }
  printf ("Simulation finished OK.\n");
  */
}
bool Spice::CmdFmt (const char * fmt, ...) {
  const size_t maxlen = 0x1000;
  char buffer [maxlen];
  va_list ap;
  va_start (ap, fmt);
  int rc = vsnprintf (buffer, maxlen, fmt, ap);
  va_end   (ap);
  buffer [rc] = '\0';
  return Command (buffer);
}
vector< SpiceVector > Spice::Vectors (const vector<string> & names) {
  const unsigned nl = names.size();
  vector<SpiceVector> result(nl);
  /* read current plot while simulation continues */
  char * curplot = ( (char * (*) ()) ngSpice_CurPlot_handle) ();
  // printf ("Current plot is %s\n", curplot);
  char ** vecarray = ( (char ** (*) (char*)) ngSpice_AllVecs_handle) (curplot);
  /* get length of first vector */
  int ord = 0;
  unsigned maxveclen = 0;
  while (vecarray) {
    const unsigned len = 100;
    char plotvec[len];
    pvector_info myvec;
    int veclength;
    char * vecname = vecarray[ord];
    if (!vecname) break;
    snprintf (plotvec, len, "%s.%s", curplot, vecname);
    myvec = ((pvector_info (*) (char*)) ngSpice_GVI_handle) (plotvec);
    veclength = myvec->v_length;
    maxveclen = veclength;
    unsigned m = 0;
    for (const string & name: names) {
      if (!name.compare(0, string::npos, vecname, name.length())) {
        SpiceVector sv;
        if (name[0] == '/') sv.name = name.substr(1, string::npos);
        else                sv.name = name;
        for (int n=0; n<veclength; n++) sv.values.push_back(myvec->v_realdata[n]);
        result[m] = sv;
      }
      m += 1;
    }
    ord += 1;
  }
  for (const SpiceVector & v: result) {
    if (v.values.size() != maxveclen) {
      printf ("Vector size ERROR %ld\n", v.values.size());
      break;
    }
  }
  return result;
}
vector< string > Spice::Labels() {
  vector<string> result;
  char * curplot = ( (char * (*) ()) ngSpice_CurPlot_handle) ();
  char ** vecarray = ( (char ** (*) (char*)) ngSpice_AllVecs_handle) (curplot);
  int ord = 0;
  while (vecarray) {
    char * vecname = vecarray[ord];
    if (!vecname) break;
    // printf("vector: \"%s\"\n", vecname); // listing
    result.push_back(string(vecname));
    ord += 1;
  }
  return result;
}
void Spice::SpiceProgress (char*) {

}
void Spice::SpiceBgEnd (bool) {

}


/* Callback function called from bg thread in ngspice to transfer
   any string created by printf or puts. Output to stdout in ngspice is
   preceded by token stdout, same with stderr.*/
static int ng_getchar (char * outputreturn, int ident, void * userdata) {
  Spice * model = reinterpret_cast<Spice*> (userdata);
  model->CatchCB (string(outputreturn));
  return 0;
}

/* Callback function called from bg thread in ngspice to transfer
   simulation status (type and progress in percent. */
static int ng_getstat (char * outputreturn, int ident, void * userdata) {
  Spice * model = reinterpret_cast<Spice*> (userdata);
  model->SpiceProgress (outputreturn);
  //printf ("%s\r", outputreturn);
  //fflush (stdout);
  return 0;
}

/* Callback function called from ngspice upon starting (returns true) or
  leaving (returns false) the bg thread. */
static int ng_thread_runs (bool noruns, int ident, void * userdata) {
  Spice * model = reinterpret_cast<Spice*> (userdata);
  model->no_bg = noruns;
  model->SpiceBgEnd (noruns);
  /*
  if (noruns) printf ("bg not running\n");
  else        printf ("bg running\n");
  */
  return 0;
}

/* Callback function called from bg thread in ngspice if fcn controlled_exit()
   is hit. Do not exit, but unload ngspice. */
int ng_exit (int exitstatus, bool immediate, bool quitexit, int ident, void * userdata) {
  Spice * model = reinterpret_cast<Spice*> (userdata);

  if (quitexit) {
    printf ("DNote: Returned form quit with exit status %d\n", exitstatus);
  }
  if (immediate) {
    printf ("DNote: Unload ngspice\n");
    model->Command ("bg_pstop");
    model->Close();
  }

  else {
    printf ("DNote: Prepare unloading ngspice\n");
    model->will_unload = true;
  }

  return exitstatus;

}

/* Callback function called from bg thread in ngspice once per accepted data point */
int ng_data (pvecvaluesall vdata, int numvecs, int ident, void * userdata) {
  // printf("ng_data: %d\n", numvecs);
#if 0
  int * ret;
  v2dat = vdata->vecsa[vecgetnumber]->creal;
  if (!has_break && (v2dat > 0.5)) {
    /* using signal SIGTERM by sending to main thread, alterp() then is run from the main thread,
      (not on Windows though!)  */
    if (testnumber == 4)
      pthread_kill (mainthread, SIGTERM);
    has_break = true;
    /* leave bg thread for a while to allow halting it from main */
    usleep (100000);
  }
#endif
  return 0;
}


/* Callback function called from bg thread in ngspice once upon intialization
   of the simulation vectors)*/
int ng_initdata (pvecinfoall intdata, int ident, void * userdata) {
  /*
  int i;
  int vn = intdata->veccount;
  for (i = 0; i < vn; i++) {
    printf ("Vector: %s\n", intdata->vecs[i]->vecname);
  }
  */
  return 0;
}
