#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "spice.h"

struct StepParams {
  double begin, step;
  int count;
  StepParams () {
    begin = 0; step = 0.1; count = 5;
  }
};
struct LineData {
  double gate;
  QVector<double> x;
  QVector<double> y;
  LineData (const double g = 0) {
    gate = g;
    x.clear();
    y.clear();
  }
};

class Ui_MainWindow;
class QTextEdit;

class MainWindow : public QMainWindow, public Spice {
    Q_OBJECT

  public:
    MainWindow  (QWidget *parent = 0);
    ~MainWindow ();
    bool setFile (const QString filename);
    void SpiceProgress (char*) override;   //!< reimplemented Spice method
    void SpiceBgEnd    (bool)  override;   //!< reimplemented Spice method
    void CatchCB (std::string row) override;
  protected:
    void ChangeColor (QCPAxis * axis, const QColor & color);
    void Simulation  ();
    void SetZoom (bool b);
  signals:
    void SigProgress (int);
    void SigEnd      ();
    void SigText     (QString);
  public slots:
    void startSim ();
    void SlotProgress (int);
    void SlotEnd      ();
    void SlotText     (QString);
    void exprt        (bool);
    void open         (bool);
    void PlotNow      (bool);
    void ColorScheme  (int);
    void PlotColor    ();
  private:
    Ui_MainWindow  * ui;
    QCustomPlot    * timePlot;
    QTextEdit      * textView;
    QColor           color;
    StepParams       params;
    QString          dut_name;
    bool             vbe, pnp;
    int progress, lineno;
    double begin_line;
    QVector<LineData> lines;
};

#endif // MAINWINDOW_H
