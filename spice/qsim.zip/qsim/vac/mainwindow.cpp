#include <QColorDialog>
#include <QDesktopWidget>
#include <QStackedWidget>
#include <QTextEdit>
#include <QFileDialog>
#include "mainwindow.h"
#include "ui_mainwindow.h"

//#undef  qDebug
//#define qDebug(p, ...)

MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent), Spice(), params() {
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  vbe = false; pnp = false;
  dut_name = QString ("unknown");
  color = QColor (Qt::green);
  QPixmap pixmap (16,16);
  pixmap.fill (color);
  QIcon   ico (pixmap);
  ui->Color->setIcon(pixmap);
  setWindowTitle ("Curve Tracer");
  setWindowIcon  (QIcon(":ico"));
  timePlot = new QCustomPlot  (this);
  textView = new QTextEdit    (this);
  textView->setReadOnly(true);
  QFont font ("Monospace", 14);
  textView->setFont (font);
  textView->setLineWrapMode(QTextEdit::NoWrap);
  ui->stackedWidget->insertWidget (0, timePlot);
  ui->stackedWidget->insertWidget (1, textView);
  ui->comboBox->addItem("Graph");
  ui->comboBox->addItem("Text");
  ui->stackedWidget->setCurrentIndex(0);
  ui->scheme->addItem("Black");
  ui->scheme->addItem("Print");
  ui->scheme->setCurrentIndex(0);
  
  const QBrush lb = QBrush (QColor (255,255,0, 64));
  timePlot->xAxis ->setLabel ("U[V]");
  timePlot->yAxis ->setLabel ("I[A]");
  timePlot->setInteractions  (QCP::iRangeDrag | QCP::iRangeZoom);
  //timePlot->legend->setBrush (lb);
  timePlot->legend->setVisible (false);
  if (true) {
    const QColor ax (Qt::yellow);
    const QBrush bg = QBrush (QColor (0,0,0, 255));
    ChangeColor (timePlot->xAxis, ax);
    ChangeColor (timePlot->yAxis, ax);
    timePlot->setBackground(bg);
    timePlot->legend->setTextColor(ax);
  }
  SetZoom(false);
  
  ui->startButton->setEnabled (false);
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
//connect (ui->,      SIGNAL (),       this, SLOT ());
  connect (ui->startButton, SIGNAL(pressed()), this, SLOT(startSim()));
  connect (ui->Color,       SIGNAL(pressed()), this, SLOT(PlotColor()));
  connect (this,  SIGNAL(SigProgress(int)),    this, SLOT(SlotProgress(int)));
  connect (this,  SIGNAL(SigEnd()),            this, SLOT(SlotEnd()));
  connect (this,  SIGNAL(SigText(QString)),    this, SLOT(SlotText(QString)));
  connect (ui->comboBox, SIGNAL(activated(int)), ui->stackedWidget, SLOT(setCurrentIndex(int)));
  connect (ui->scheme,   SIGNAL(activated(int)), this,              SLOT(ColorScheme(int)));
  
  connect (ui->actionClose,        SIGNAL(triggered(bool)), this, SLOT(close()));
  connect (ui->actionSave_Image,   SIGNAL(triggered(bool)), this, SLOT(exprt(bool)));
  connect (ui->actionOpen_Circuit, SIGNAL(triggered(bool)), this, SLOT(open (bool)));
  connect (ui->actionReplot,       SIGNAL(triggered(bool)), this, SLOT(PlotNow(bool)));
}

MainWindow::~MainWindow () {
  delete ui;
}
void MainWindow::PlotColor() {
  QColor newcolor = QColorDialog::getColor(color, this, "Select Color", QColorDialog::DontUseNativeDialog);
  if (newcolor.isValid()) color = newcolor;
  QPixmap pixmap (16,16);
  pixmap.fill (color);
  QIcon   ico (pixmap);
  ui->Color->setIcon (ico);
  PlotNow(true);
}

void MainWindow::ColorScheme (int n) {
  if (n) {
    const QColor ax (Qt::black);
    const QBrush bg = QBrush (QColor (255,255,255, 255));
    ChangeColor (timePlot->xAxis, ax);
    ChangeColor (timePlot->yAxis, ax);
    timePlot->setBackground(bg);
    timePlot->legend->setTextColor(ax);
  } else {
    const QColor ax (Qt::yellow);
    const QBrush bg = QBrush (QColor (0,0,0, 255));
    ChangeColor (timePlot->xAxis, ax);
    ChangeColor (timePlot->yAxis, ax);
    timePlot->setBackground(bg);
    timePlot->legend->setTextColor(ax);
  }
  PlotNow(true);
}
void MainWindow::ChangeColor (QCPAxis * axis, const QColor & color) {
  const QPen   pen   (color, 1);

  axis->setBasePen    (pen);
  axis->setTickPen    (pen);
  axis->setSubTickPen (pen);
  axis->setLabelColor     (color);
  axis->setTickLabelColor (color);
}

void MainWindow::CatchCB (std::__cxx11::string row) {
  Spice::CatchCB  (row);
  QString message (row.c_str());
  const QString out ("stdout ");
  const int n = message.indexOf(out);
  if (n>=0) {
    const int m = n + out.length();
    message.remove (n,m);
  }
  emit SigText (message);
}
void MainWindow::SpiceBgEnd (bool b) {
  if (b) emit SigEnd ();
  //Spice::SpiceBgEnd(b);
}
void MainWindow::SpiceProgress (char * resp) {
  QString msg (resp);
  QStringList l = msg.split(':');
  if (l.size() < 2)           return;
  if (!l[0].contains("tran")) return;
  QString res = l[1].remove('%');
  bool ok;
  double per = 0.01 * res.toDouble (&ok);
  double part = ((double) lineno + per) / (double) params.count;
  per = 100.0 * part;
  int n = (int) round (per);
  if (!ok)                    return;
  if (n != progress) {
    progress = n;
    // qDebug("%d", n);
    emit SigProgress (n);
  }
  //Spice::SpiceProgress(resp);
}
void MainWindow::SlotText (QString msg) {
  const QString out ("stderr");
  const int n = msg.indexOf(out);
  if (n>=0) {
    const int m = n + out.length();
    msg.remove (n,m);
    if (msg.contains("Warning")) ui->statusbar->setStyleSheet("background-color: rgb(0, 255, 0); color: black");
    else                         ui->statusbar->setStyleSheet("background-color: white; color: rgb(128, 0, 0)");
    ui->statusbar->showMessage (msg);
    // return;
  }
  textView->append(msg);
}
bool MainWindow::setFile (const QString filename) {
  ui->startButton->setEnabled (false);
  vbe = false;
  bool ibe = false;
  qDebug ("name = %s",  filename.toLatin1().data());
  if (!Init())                              return false;
  if (!Circuit(filename.toLatin1().data())) return false;
  ui->startButton->setEnabled (true);
  std::string l = RespCmd ("listing");
  QString list(l.c_str());
  QStringList rows = list.split('\n');
  const QString vn("vbe"), in("ibe"), dut("dut");
  for (const QString & row: rows) {
    if (row.contains(vn)) vbe = true;
    if (row.contains(in)) ibe = true;
    if (row.contains(dut)) {
      const QStringList dr = row.split(' ');
      const int md = dr.size() - 1;
      dut_name = dr[md].toUpper();
    }
    const QString p(".param ");
    const int n = row.indexOf(p);
    if (n <= 0) continue;
    QString copy (row);
    copy.remove (0, n + p.length());
    QStringList parms = copy.split('=');
    if (parms.size() != 2) continue;
    bool ok = false;
    if (parms[0].contains("begin")) {
      double par = parms[1].toDouble (&ok);
      if (ok) params.begin = par;
    } else if (parms[0].contains("step")) {
      double par = parms[1].toDouble (&ok);
      if (ok) params.step = par;
    } else if (parms[0].contains("count")) {
      int par = parms[1].toInt (&ok);
      if (ok) params.count = par;
    } else if (parms[0].contains("pnp")) {
      int par = parms[1].toInt (&ok);
      if (ok) pnp = par ? true : false;
    } else {
      qDebug("chyba radku:%s", row.toLatin1().data());
    }
  }
  qDebug("params [%s]: %f,%f,%d", dut_name.toLatin1().data(), params.begin, params.step, params.count);
  if (!vbe and !ibe) qDebug ("Not IBE or VBE source !");
  qDebug("VBE = %s, PNP = %s", vbe ? "TRUE" : "FALSE", pnp ? "TRUE" : "FALSE");
  return true;
}
void MainWindow::SlotProgress (int n) {
  // qDebug("%d", n);
  ui->progressBar->setValue(n);
}
void MainWindow::SlotEnd() {
  Command("linearize");
  std::vector<std::string> vlist = {"umc", "imc"};
  std::vector<SpiceVector> vects = Vectors (vlist);
  // qDebug ("%d.Finished OK (%ld)", lineno, vects.size());
  LineData ld (begin_line);
  ld.x = QVector<double>::fromStdVector (vects[0].values);
  ld.y = QVector<double>::fromStdVector (vects[1].values);
  if (pnp) {
    for (double & x: ld.x) x = -x;
    for (double & y: ld.y) y = -y;
  }
  lines.push_back(ld);
  lineno += 1;
  if (lineno >= params.count) {
    ui->progressBar->setValue(0);
    ui->startButton->setEnabled(true);
    PlotNow(true);
    return;
  }
  begin_line += params.step;
  Simulation();
}
void MainWindow::startSim() {
  progress = 0;
  lineno   = 0;
  begin_line = params.begin;
  textView->clear();
  lines.clear();
  ui->startButton->setEnabled(false);
  Simulation();
}
void MainWindow::Simulation() {
  if (vbe) CmdFmt ("alter @vbe[dc]=%g", begin_line);
  else     CmdFmt ("alter @ibe[dc]=%g", begin_line);
  RunWait();
}

void MainWindow::PlotNow (bool) {
  ui->comboBox->setCurrentIndex(0);
  ui->stackedWidget->setCurrentIndex(0);
  //...
  timePlot->clearGraphs();
  if (pnp) {
    timePlot->xAxis ->setLabel ("-U[V]");
    timePlot->yAxis ->setLabel ("-I[A]");
  }
  int gc = 0;
  double gmx=10.0,gpx=-gmx,gmy=gmx,gpy=gpx;
  const QPen pen (color, 2), lp (timePlot->xAxis->labelColor(), 1);
  for (const LineData & line: lines) {
    double mx=gmx,px=-mx,my=mx,py=px;
    timePlot->addGraph (timePlot->xAxis, timePlot->yAxis);
    QString name = IngFormat(line.gate, 2);
    for (const double x: line.x) {
      if (x > px) px = x;
      if (x < mx) mx = x;
    }
    for (const double y: line.y) {
      if (y > py) py = y;
      if (y < my) my = y;
    }
    //qDebug("data - %d: %d", n, data.size());
    timePlot->graph (gc)->setPen   (pen);
    timePlot->graph (gc)->setName  (name);
    timePlot->graph (gc)->setData  (line.x, line.y);
    QCPItemText * label = new QCPItemText (timePlot);
    label->setPositionAlignment(Qt::AlignBottom|Qt::AlignRight);
    label->setColor(pen.color());
    label->setPen(lp);
    label->setText(name);
    label->position->setCoords(px, py);
    if (px > gpx) gpx = px;
    if (mx < gmx) gmx = mx;
    if (py > gpy) gpy = py;
    if (my < gmy) gmy = my;
    gc += 1;
  }
  QCPItemText * label = new QCPItemText (timePlot);
  label->setPositionAlignment(Qt::AlignTop|Qt::AlignRight);
  label->setColor(pen.color());
  QFont font(label->font());
  font.setPointSize(16);
  label->setFont(font);
  label->setPen(lp);
  label->setText(dut_name);
  label->position->setCoords(gpx, gpy);
  timePlot->xAxis->setRange (gmx, gpx * 1.01);
  timePlot->yAxis->setRange (gmy, gpy * 1.05);
  timePlot->replot();
}
void MainWindow::exprt (bool) {
  QWidget * pw = timePlot;
  QString fileName = QFileDialog::getSaveFileName (this,
               tr ("Save File"), ".", "Images Files(*.png)");
  if (!fileName.isEmpty()) {
    if (!fileName.endsWith(".png")) fileName.append(".png");
    QImage    img (pw->width(), pw->height(), QImage::Format_ARGB32_Premultiplied);
    QPainter  painter(&img);
    pw->render (&painter);
    // save transparent white
    for (int i = 0; i < img.height(); i++) {
      for (int j = 0; j < img.width(); j++) {
         if(img.pixel(j, i) == qRgba(255,255,255,255)) img.setPixel(j, i, Qt::transparent);
      }
    }
    img.save   (fileName, "PNG", 0);
  }
}
void MainWindow::open (bool) {
  QString fileName = QFileDialog::getOpenFileName (this,
               tr ("Open File"), ".", "Spice Circuit Files(*.cir)");
  if (!fileName.isEmpty()) {
    setFile (fileName);
  }
}
void MainWindow::SetZoom (bool b) {
  // qDebug ("SetZoom %d", b);
  QCPAxisRect * ar = timePlot->axisRect(0);
  if (!ar) return;
  if (b) {
    ar->setRangeDrag (Qt::Horizontal | Qt::Vertical);
    ar->setRangeZoom (Qt::Horizontal | Qt::Vertical);
  } else {
    ar->setRangeDrag (Qt::Horizontal);
    ar->setRangeZoom (Qt::Horizontal);
  }
}
