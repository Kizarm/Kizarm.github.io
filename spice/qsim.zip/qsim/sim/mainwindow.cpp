#include <QDesktopWidget>
#include <QStackedWidget>
#include <QTextEdit>
#include <QFileDialog>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "vectors.h"

//#undef  qDebug
//#define qDebug(p, ...)
/*
static void test () {
  const double x = 1.5565;
  for (int n=-10; n<10; n++) {
    const double m = x * pow (10.0, (double) n);
    QString s = IngFormat (m, 3);
    qDebug ("m (%e) => %s", m, s.toAscii().data());
  }
}
*/
MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent), Spice() {
  // QLocale::setDefault(QLocale::C);
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  setWindowTitle ("Spice Simulation");
  setWindowIcon  (QIcon(":ico"));
  // test();
  method = METHOD_NONE;
  timePlot = new QCustomPlot  (this);
  textView = new QTextEdit    (this);
  vectSign = new SPlotVectors (this);
  textView->setReadOnly(true);
  QFont font ("Monospace", 14);
  textView->setFont (font);
  textView->setLineWrapMode(QTextEdit::NoWrap);
  ui->stackedWidget->insertWidget (0, timePlot);
  ui->stackedWidget->insertWidget (1, textView);
  ui->stackedWidget->insertWidget (2, vectSign);
  ui->comboBox->addItem("Graph");
  ui->comboBox->addItem("Text");
  ui->comboBox->addItem("Plots");
  ui->stackedWidget->setCurrentIndex(0);
  
  const QBrush lb = QBrush (QColor (255,255,0, 64));
  timePlot->xAxis ->setLabel ("t[s]");
  timePlot->yAxis ->setLabel ("U[V]");
  timePlot->setInteractions  (QCP::iRangeDrag | QCP::iRangeZoom);
  SetZoom (false);
  timePlot->legend->setBrush (lb);
  timePlot->legend->setVisible (true);

  ui->scheme->addItem("Black");
  ui->scheme->addItem("Print");
  ui->scheme->setCurrentIndex(0);
  
  if (true) {
    const QColor ax (Qt::yellow);
    const QBrush bg = QBrush (QColor (0,0,0, 255));
    ChangeColor (timePlot->xAxis, ax);
    ChangeColor (timePlot->yAxis, ax);
    timePlot->setBackground(bg);
    timePlot->legend->setTextColor(ax);
  }
  
  ui->startButton->setEnabled (false);
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
//connect (ui->,      SIGNAL (),       this, SLOT ());
  connect (ui->startButton, SIGNAL(pressed()), this, SLOT(startSim()));
  connect (this,  SIGNAL(SigProgress(int)),    this, SLOT(SlotProgress(int)));
  connect (this,  SIGNAL(SigEnd()),            this, SLOT(SlotEnd()));
  connect (this,  SIGNAL(SigText(QString)),    this, SLOT(SlotText(QString)));
  connect (ui->actionClose, SIGNAL(triggered(bool)), this, SLOT(close()));
  connect (ui->actionSave_Image,   SIGNAL(triggered(bool)), this, SLOT(exprt(bool)));
  connect (ui->actionOpen_Circuit, SIGNAL(triggered(bool)), this, SLOT(open (bool)));
  connect (ui->actionReplot,       SIGNAL(triggered(bool)), this, SLOT(PlotNow(bool)));
  connect (ui->actionZoom,         SIGNAL(triggered(bool)), this, SLOT(SetZoom(bool)));
  connect (ui->comboBox,           SIGNAL(activated(int)), ui->stackedWidget, SLOT(setCurrentIndex(int)));
  connect (ui->scheme, SIGNAL(activated(int)),  this, SLOT(ColorScheme(int)));
  connect (vectSign,   SIGNAL(SigReplot(bool)), this, SLOT(PlotNow(bool)));
  connect (vectSign,   SIGNAL(FFTMethod(int)),  this, SLOT(SlotMethod(int)));
}

MainWindow::~MainWindow () {
  delete vectSign;
  delete timePlot;
  delete textView;
  delete ui;
}
void MainWindow::ColorScheme (int n) {
  if (n) {
    const QColor ax (Qt::black);
    const QBrush bg = QBrush (QColor (255,255,255, 255));
    ChangeColor (timePlot->xAxis, ax);
    ChangeColor (timePlot->yAxis, ax);
    timePlot->setBackground(bg);
    timePlot->legend->setTextColor(ax);
  } else {
    const QColor ax (Qt::yellow);
    const QBrush bg = QBrush (QColor (0,0,0, 255));
    ChangeColor (timePlot->xAxis, ax);
    ChangeColor (timePlot->yAxis, ax);
    timePlot->setBackground(bg);
    timePlot->legend->setTextColor(ax);
  }
  PlotNow(true);
}
void MainWindow::SetZoom (bool b) {
  // qDebug ("SetZoom %d", b);
  QCPAxisRect * ar = timePlot->axisRect(0);
  if (!ar) return;
  if (b) {
    ar->setRangeDrag (Qt::Horizontal | Qt::Vertical);
    ar->setRangeZoom (Qt::Horizontal | Qt::Vertical);
  } else {
    ar->setRangeDrag (Qt::Horizontal | Qt::Vertical);
    ar->setRangeZoom (Qt::Horizontal);
  }
}

void MainWindow::CatchCB (std::__cxx11::string row) {
  QString message (row.c_str());
  const QString out ("stdout ");
  const int n = message.indexOf(out);
  if (n>=0) {
    const int m = n + out.length();
    message.remove (n,m);
  }
  emit SigText (message);
  //Spice::CatchCB (row);
}
void MainWindow::SlotText (QString msg) {
  const QString out ("stderr");
  const int n = msg.indexOf(out);
  if (n>=0) {
    const int m = n + out.length();
    msg.remove (n,m);
    if (msg.contains("Warning")) ui->statusbar->setStyleSheet("background-color: rgb(0, 255, 0); color: black");
    else                         ui->statusbar->setStyleSheet("background-color: white; color: rgb(128, 0, 0)");
    ui->statusbar->showMessage (msg);
    // return;
  }
  textView->append(msg);
}

void MainWindow::SpiceBgEnd (bool b) {
  if (b) emit SigEnd ();
  //Spice::SpiceBgEnd(b);
}
void MainWindow::SpiceProgress (char * resp) {
  QString msg (resp);
  QStringList l = msg.split(':');
  if (l.size() < 2)           return;
  if (!l[0].contains("tran")) return;
  QString res = l[1].remove('%');
  bool ok;
  int n = (int) round (res.toDouble(&ok));
  if (!ok)                    return;
  if (n != progress) {
    progress = n;
    emit SigProgress (n);
  }
  //Spice::SpiceProgress(resp);
}

void MainWindow::ChangeColor (QCPAxis * axis, const QColor & color) {
  const QPen   pen   (color, 1);

  axis->setBasePen    (pen);
  axis->setTickPen    (pen);
  axis->setSubTickPen (pen);
  axis->setLabelColor     (color);
  axis->setTickLabelColor (color);
}

bool MainWindow::setFile (const QString filename) {
  ui->startButton->setEnabled (false);
  qDebug ("name = %s",  filename.toLatin1().data());
  if (!Init())                              return false;
  if (!Circuit(filename.toLatin1().data())) return false;
  ui->startButton->setEnabled (true);
  Command("listing");
  return true;
}
void MainWindow::SlotProgress (int n) {
  ui->progressBar->setValue(n);
}
void MainWindow::SlotMethod (int n) {
  // qDebug("method = %d", n);
  method = (FFT_METHODS) n;
}

void MainWindow::SlotEnd() {
  qDebug ("Finished OK.");
  ui->startButton->setEnabled(true);
  ui->progressBar->setValue(0);
  Command("linearize");
  std::vector<std::string> vlist = Labels();
  vectSign->Create (vlist);
  vlist.insert (vlist.begin(), std::string("time"));
  std::vector<SpiceVector> tmp = Vectors (vlist);
  vects = PerformTransformation (tmp, method);
  PlotNow (true);
}
void MainWindow::PlotNow (bool) {
  ui->comboBox->setCurrentIndex(0);
  ui->stackedWidget->setCurrentIndex(0);
  
  QVector<qreal> atime = QVector<double>::fromStdVector (vects[0].values);
  const size_t tmax = atime.size() - 1u;
  qreal mx = atime.at(0), px = mx;
  for (const qreal x: atime) {
    if (x > px) px = x;
    if (x < mx) mx = x;
  }
  if (method != METHOD_NONE) {
    mx = atime[1];
    px = atime[tmax];
  }
  
  timePlot->clearGraphs();
  timePlot->xAxis->setRange (mx, px);
  QVector<VectorProperties*> props = vectSign->getProterties();
  const int mg = props.size();
  // qDebug("plots %d (%d)", mg, atime.size());
  qreal my = +1e9, py = -my;
  int gc = 0;
  for (int n=0; n<mg; n++) {
    VectorProperties * action = props.at(n);
    const int order = action->order;
    if (action->enabled) {
      timePlot->addGraph (timePlot->xAxis, timePlot->yAxis);
      QString name (action->text);
      QVector<qreal> data;
      data = QVector<double>::fromStdVector (vects[order+1].values);
      for (const qreal y: data) {
        if (y > py) py = y;
        if (y < my) my = y;
      }
      //qDebug("data - %d: %d", n, data.size());
      const QPen pen (action->color, action->width);
      timePlot->graph (gc)->setPen   (pen);
      timePlot->graph (gc)->setName  (name);
      timePlot->graph (gc)->setData  (atime, data);
      gc += 1;
    }
  }
  timePlot->yAxis->setRange (my, py);
  if (method != METHOD_NONE) {
    timePlot->xAxis->setLabel ("f[Hz]");
    timePlot->xAxis->setScaleType(QCPAxis::stLogarithmic);
    timePlot->yAxis->setLabel ("U[dB]");
  }
  timePlot->replot();
}

void MainWindow::startSim() {
  progress = 0;
  textView->clear();
  RunWait();
  ui->startButton->setEnabled(false);
}
void MainWindow::exprt (bool) {
  QWidget * pw = timePlot;
  QString fileName = QFileDialog::getSaveFileName (this,
               tr ("Save File"), ".", "Images Files(*.png)");
  if (!fileName.isEmpty()) {
    if (!fileName.endsWith(".png")) fileName.append(".png");
    QImage    img (pw->width(), pw->height(), QImage::Format_ARGB32_Premultiplied);
    QPainter  painter(&img);
    pw->render (&painter);
    // save transparent white
    for (int i = 0; i < img.height(); i++) {
      for (int j = 0; j < img.width(); j++) {
         if(img.pixel(j, i) == qRgba(255,255,255,255)) img.setPixel(j, i, Qt::transparent);
      }
    }
    img.save   (fileName, "PNG", 0);
  }
}
void MainWindow::open (bool) {
  QString fileName = QFileDialog::getOpenFileName (this,
               tr ("Open File"), ".", "Spice Circuit Files(*.cir)");
  if (!fileName.isEmpty()) {
    setFile (fileName);
  }
}

