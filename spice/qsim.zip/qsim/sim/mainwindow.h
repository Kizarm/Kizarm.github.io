#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "spice.h"
#include "fft.h"

class Ui_MainWindow;
class QTextEdit;
class SPlotVectors;

class MainWindow : public QMainWindow, public Spice {
    Q_OBJECT

  public:
    MainWindow  (QWidget *parent = 0);
    ~MainWindow ();
    bool setFile (const QString filename);
    void SpiceProgress (char*)     override;   //!< reimplemented Spice method
    void SpiceBgEnd    (bool)      override;   //!< reimplemented Spice method
    void CatchCB (std::string row) override;   //!< reimplemented Spice method
  protected:
    void ChangeColor (QCPAxis * axis, const QColor & color);
  signals:
    void SigProgress (int);
    void SigEnd      ();
    void SigText     (QString);
  public slots:
    void startSim ();
    void SlotProgress (int);
    void SlotEnd      ();
    void SlotText     (QString);
    void SlotMethod   (int);
    void exprt        (bool);
    void open         (bool);
    void PlotNow      (bool);
    void ColorScheme  (int);
    void SetZoom      (bool);
  private:
    Ui_MainWindow  * ui;
    QCustomPlot    * timePlot;
    QTextEdit      * textView;
    SPlotVectors   * vectSign;
    int              progress;
    std::vector<SpiceVector> vects;
    FFT_METHODS      method;
};

#endif // MAINWINDOW_H
