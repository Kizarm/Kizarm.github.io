#include <QScrollArea>
#include <QColorDialog>
#include <QComboBox>
#include "vectors.h"

VectorProperties::VectorProperties (const QString& name, const int n, QWidget* p) : QWidget (p),
  color (Qt::red), text (name) {
  ui = new Ui_VectorProps;
  ui->setupUi(this);
  
  width = 2;
  order = n;
  ui->spinBox->setValue (width);
  ui->label->setText    (text);
  QPixmap pixmap (16,16);
  pixmap.fill (color);
  QIcon   ico (pixmap);
  ui->pushButton->setIcon (ico);
  if (name[0] == '/') enabled = true;
  else                enabled = false;
  ui->checkEn->setChecked(enabled);
  
  connect (ui->checkEn, SIGNAL(stateChanged(int)), this, SLOT(SetEnable(int)));
  connect (ui->spinBox, SIGNAL(valueChanged(int)), this, SLOT(SetWidth(int)));
  connect (ui->pushButton, SIGNAL(pressed()),      this, SLOT(SetColor()));
}

VectorProperties::~VectorProperties() {
  delete ui;
}
void VectorProperties::SetColor (const QColor & col) {
  color = col;
  QPixmap pixmap (16,16);
  pixmap.fill (color);
  QIcon   ico (pixmap);
  ui->pushButton->setIcon (ico);
}

void VectorProperties::SetEnable (int n) {
  if (n) enabled = true;
  else   enabled = false;
}
void VectorProperties::SetWidth (int n) {
  width = n;
}
void VectorProperties::SetColor() {
  QColor newcolor = QColorDialog::getColor(color, this, "Select Color", QColorDialog::DontUseNativeDialog);
  if (newcolor.isValid()) color = newcolor;
  QPixmap pixmap (16,16);
  pixmap.fill (color);
  QIcon   ico (pixmap);
  ui->pushButton->setIcon (ico);
}

/********************************************************************/

PlotVectors::PlotVectors (QWidget * p) : QWidget(p) {
  layout = nullptr;
  properties.clear();

  const int m = 255;
  color_table.push_back(QColor (m,0,0));
  color_table.push_back(QColor (0,m,0));
  color_table.push_back(QColor (0,0,m));
  color_table.push_back(QColor (0,m,m));
  color_table.push_back(QColor (m,0,m));
  color_table.push_back(QColor (m,m,0));
  
  replot = new QPushButton (this);
  replot->setText("Replot");
  hbox   = new QHBoxLayout;
  vbox   = new QVBoxLayout;
  hspace = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
  vspace = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);
  fft_method = new QComboBox;
  fft_method->addItem ("FFT None");
  fft_method->addItem ("Rectangle");
  fft_method->addItem ("Cosinus");
  fft_method->setCurrentIndex(0);
  
  hbox->addItem  (hspace);
  hbox->addWidget(fft_method);
  hbox->addWidget(replot);
  vbox->addItem  (vspace);
  vbox->addLayout(hbox);
  setLayout(vbox);
  
  connect (replot,     SIGNAL(pressed()),      this, SLOT(SlotReplot()));
  connect (fft_method, SIGNAL(activated(int)), this, SLOT(SlotMethod(int)));
}

PlotVectors::~PlotVectors() {
  if (layout) delete layout;
}
void PlotVectors::SlotMethod (int n) {
  emit SigMethod(n);
}

bool PlotVectors::Create (std::vector< std::__cxx11::string > list) {
  if (layout) {
    for (VectorProperties * p: properties) delete p;
    properties.clear();
    vbox->removeItem(layout);
    delete layout;
    layout = nullptr;
  }
  layout = new QGridLayout;
  unsigned k = 0, n = 0, m = color_table.size(), row, col, mc = 10;
  for (const std::string & str: list) {
    QString desc (str.c_str());
    bool use = false;
    do {
      // nezobrazuj branche a spoje uvnitr subcircuit, je toho moc
      if (desc.contains("#branch"))                          break;
      if (desc.contains(QRegExp("^x[a-z0-9]+\\.[a-z0-9]+"))) break;
      use = true;
    } while (false);
    if (use) {
      VectorProperties * p = new VectorProperties (desc, k, this);
      properties.push_back (p);
    }
    k += 1;
  }
  k = (properties.size() + 1) / 2; // max 2 sloupce
  if (k > mc) mc = k;
  qSort(properties.begin(), properties.end(), [] (const VectorProperties * a, const VectorProperties * b) {
    return a->text < b->text;
  });
  n = 0;
  for (VectorProperties * p: properties) {
    row = n % mc;
    col = n / mc;
    p->SetColor (color_table.at(n%m));
    layout->addWidget (p, row, col, Qt::AlignLeft);
    n += 1;
  }
  vbox->insertLayout(0, layout);
  setLayout (vbox);
  return true;
}
void PlotVectors::SlotReplot() {
  emit SigReplot(true);
}

/********************************************************************/

SPlotVectors::SPlotVectors (QWidget * p) : QWidget(p) {
  hbox = new QHBoxLayout;
  ar = new QScrollArea;
  pv = new PlotVectors (this);
  //pv->setSizePolicy(QSizePolicy::Minimum);
  ar->setWidget   (pv);
  ar->setWidgetResizable(true);
  hbox->addWidget (ar);
  setLayout(hbox);
  connect (pv, SIGNAL(SigReplot(bool)), this, SLOT(SlotReplot(bool)));
  connect (pv, SIGNAL(SigMethod(int)),  this, SLOT(SlotMethod(int)));
}
SPlotVectors::~SPlotVectors () {
  delete hbox;
  //delete ar;
  //delete pv;
}
