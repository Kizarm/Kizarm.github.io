//   fft.cpp - impelementation of class
//   of fast Fourier transform - FFT
//

#include "fft.h"
#include <math.h>
CFFT::CFFT (const unsigned int order, FFT_METHODS m) : N(1<<order), method (m) {
  window = new double [N];
  const double step = 2.0 * M_PI / (double) N;
  switch (method) {
    case METHOD_COS:
      for (unsigned n=0; n<N; n++) {
        const double w = 1.0 - cos ((double) n * step);
        window[n] = w;
      }
      break;
    case METHOD_RECT:
    default:
      for (unsigned n=0; n<N; n++) window[n] = 1.0;
      break;
  };
}
CFFT::~CFFT() {
  delete [] window;
}

//   FORWARD FOURIER TRANSFORM, INPLACE VERSION
//     Data - both input data and output
//     N    - length of input data
bool CFFT::Forward (complex * const Data) const {
  //   Check input parameters
  if (!Data || N < 1 || N & (N - 1)) return false;
  for (unsigned n=0; n<N; n++) Data[n] *= window[n];
  //   Rearrange
  Rearrange (Data);
  //   Call FFT implementation
  Perform (Data);
  //   Succeeded
  return true;
}
//   INVERSE FOURIER TRANSFORM, INPLACE VERSION
//     Data  - both input data and output
//     N     - length of both input data and result
//     Scale - if to scale result
bool CFFT::Inverse (complex * const Data, const bool Sc /* = true */) const {
  //   Check input parameters
  if (!Data || N < 1 || N & (N - 1)) return false;
  //   Rearrange
  Rearrange (Data);
  //   Call FFT implementation
  Perform (Data, true);
  //   Scale if necessary
  if (Sc)  Scale (Data);
  //   Succeeded
  return true;
}
//   Inplace version of rearrange function
void CFFT::Rearrange (complex * const Data) const {
  //   Swap position
  unsigned int Target = 0;
  //   Process all positions of input signal
  for (unsigned int Position = 0; Position < N; ++Position) {
    //   Only for not yet swapped entries
    if (Target > Position) {
      //   Swap entries
      const complex Temp (Data[Target]);
      Data[Target]   = Data[Position];
      Data[Position] = Temp;
    }
    //   Výpočet Target (v podstatě reverzace pořadí bitů Position)
    unsigned int Mask = N;
    //   While bit is set
    while (Target & (Mask >>= 1))
      //   Drop bit
      Target &= ~Mask;
    //   The current bit is 0 - set it
    Target |= Mask;
  }
}

//   FFT implementation
void CFFT::Perform (complex * const Data, const bool Inverse /* = false */) const {
  complex Product;
  unsigned int Step;
  const real pi = Inverse ? 3.14159265358979323846 : -3.14159265358979323846;
  //   Iteration through dyads, quadruples, octads and so on...
  for (Step = 1; Step < N; Step <<= 1) {  // 1,2,...N/2
    //   Jump to the next entry of the same transform factor Jump = Step * 2
    const unsigned int Jump = Step << 1;            // 2,4,...N
    //   Angle increment
    const real delta = pi  / real (Step);
    const real incr  = 1.0 / real (Step);
    //   Multiplier for trigonometric recurrence
    const complex Multiplier (cos (delta), sin (delta));
    //   Start value for transform factor, fi = 0
    complex Factor (1.0);
    real    rot = 0.0;
    //   Iteration through groups of different transform factor
    for (unsigned int Group = 0; Group < Step; ++Group) {
      //   Iteration within group
      for (unsigned int Pair = Group; Pair < N; Pair += Jump) {
        //   Match position
        const unsigned int Match = Pair + Step;
        //   Second term of two-point transform
        Product = Factor * Data[Match];
        //   Transform for fi + pi
        Data[Match] = Data[Pair] - Product;
        //   Transform for fi
        Data[Pair]  = Data[Pair] + Product;
      }
      //   Successive transform factor via trigonometric recurrence
      //   Factor = Multiplier * Factor + Factor;
      Factor *= Multiplier;
      rot    += incr;
    }
  }
}

//   Scaling of inverse FFT result
void CFFT::Scale (complex *const Data) const {
  const real Factor = 1.0 / real (N);
  //   Scale all data entries
  for (unsigned int Position = 0; Position < N; ++Position)
    Data[Position] *= Factor;
}
/***************************************************************************/
using namespace std;
vector<SpiceVector> PerformTransformation (vector<SpiceVector> & input, FFT_METHODS meth) {
  vector<SpiceVector> output;
  if (meth == METHOD_NONE) {
    output = input;
    return output;
  }
  const SpiceVector & time = input[0];
  const size_t len = time.values.size();
  size_t max = 0, ord = 0;
  for(size_t n = 2; n < len; n <<= 1) {
    ord += 1;
    max  = n;
  }
  const double tend = time.values[len-1];
  const double fend = (double) (len-1) / tend;
  const double step = tend / (double) (max-1);
  const double otst = tend / (double) (len-1);
  const double ftst = 1.0 / otst;
  printf ("resize from %ld to %ld (%ld) end = %f, step = %e, old step = %e\n", len, max, ord, tend, step, otst);
  CFFT fft (ord, meth);
  complex * fft_data = new complex [max];
  size_t index = 0;
  for (const SpiceVector & spice: input) {
    for (size_t n=0; n<max-1; n++) {
      const double ct = (double) n * step;
      const size_t it = (size_t) trunc (ct * fend);
      const double mx = time.values[it];
      const double dx = fabs (ct - mx);
      const double my = spice.values[it];
      const double dy = spice.values[it + 1] - my;
      const double yy = my + dy * dx * ftst;
      fft_data[n] = yy;
    }
    fft_data[max-1] = spice.values[len-1];
    fft.Forward (fft_data);
    const size_t half = max >> 1;
    SpiceVector now;
    now.name = spice.name;
    const double xscale = 1.0 / tend;
    for (size_t n=0; n<half; n++) {
      if (index) {
        const double yy = 10.0 * log10 (fft_data[n].norm());
        now.values.push_back(yy);
      } else {
        now.values.push_back((double) n * xscale);
      }
    }
    output.push_back(now);
    index += 1;
  }
  delete [] fft_data;
  return output;
}
