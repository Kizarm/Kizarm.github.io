//   fft.h - declaration of class
//   of fast Fourier transform - FFT
//

#ifndef _FFT_H_
#define _FFT_H_

//   Include complex numbers header
#include "spice.h"
#include "complex.h"

enum FFT_METHODS {
  METHOD_NONE = 0, METHOD_RECT, METHOD_COS
};

std::vector<SpiceVector> PerformTransformation (std::vector<SpiceVector> & input, FFT_METHODS m = METHOD_NONE);

class CFFT {
  public:
    CFFT (const unsigned order, FFT_METHODS m = METHOD_NONE);
    ~CFFT();
    //   FORWARD FOURIER TRANSFORM, INPLACE VERSION
    //     Data - both input data and output
    //     N    - length of input data
    bool Forward (complex * const Data) const;
    //   INVERSE FOURIER TRANSFORM, INPLACE VERSION
    //     Data  - both input data and output
    //     N     - length of both input data and result
    //     Scale - if to scale result
    bool Inverse (complex * const Data, const bool Scale = true) const;
  protected:
    void Rearrange (complex * const Data) const;
    //   FFT implementation
    void Perform (complex * const Data, const bool Inverse = false) const;
    //   Scaling of inverse FFT result
    void Scale (complex * const Data) const;
  private:
    const unsigned N;
    double * window;
    FFT_METHODS method;
};

#endif
