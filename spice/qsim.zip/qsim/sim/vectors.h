#ifndef VECTORS_H
#define VECTORS_H

#include <QWidget>
#include "ui_vector_prop.h"

class VectorProperties : public QWidget {
  Q_OBJECT
  public:
    VectorProperties (const QString & name, const int n, QWidget * p = nullptr);
    virtual ~VectorProperties();  
    void SetColor (const QColor & col);
  public:
    QColor  color;
    QString text;
    int     width;
    int     order;
    bool    enabled;
  public slots:
    void SetEnable (int);
    void SetWidth  (int);
    void SetColor  ();
  private:
    Ui_VectorProps * ui;
};
class QComboBox;
class PlotVectors : public QWidget {
  Q_OBJECT
  public:
    PlotVectors (QWidget * p = nullptr);
    virtual ~PlotVectors();
    bool Create (std::vector<std::string> list);
    const QVector<VectorProperties *> & getProterties () const {
      return properties;
    }
  public slots:
    void SlotReplot ();
    void SlotMethod (int);
  signals:
    void SigReplot (bool);
    void SigMethod (int);
  private:
    QVBoxLayout              *  vbox;
    QHBoxLayout              *  hbox;
    QSpacerItem              *  vspace;
    QSpacerItem              *  hspace;
    QGridLayout              *  layout;
    QPushButton              *  replot;
    QComboBox                *  fft_method;
    QVector<VectorProperties *> properties;
    QVector<QColor> color_table;
};

class QScrollArea;
// obal pro scrooling kdyz je moc vektoru
class SPlotVectors : public QWidget {
  Q_OBJECT
  public:
    SPlotVectors (QWidget * p = nullptr);
    virtual ~SPlotVectors();
    bool Create (std::vector<std::string> list) {
      return pv->Create(list);
    }
    const QVector<VectorProperties *> & getProterties () const {
      return pv->getProterties();
    }
  signals:
    void SigReplot (bool);
    void FFTMethod (int);
  public slots:
    void SlotReplot (bool b) {
      emit SigReplot(b);
    }
    void SlotMethod (int n) {
      emit FFTMethod(n);
    }
  private:
    QHBoxLayout * hbox;
    PlotVectors * pv;
    QScrollArea * ar;
};

#endif // VECTORS_H
