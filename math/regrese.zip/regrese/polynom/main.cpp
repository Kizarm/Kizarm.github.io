#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_multifit.h>

/** Závislosti : gnuplot libgsl0-dev
 * fitting pomocí gnuplot také funguje :
    f(x) = a*x + b*x**2 + c*x**3 + d*x**4 + e*x**5 + f
    a=0.039; b=0.0001; c=0.000001; d=0.00001; e=0.0000001; f=0.000001
    fit f(x) 'copy.dat' using 1:2 via a, b, c, d, e, f
    plot     'copy.dat' using 1:($2-f($1)) t 'Error'
 * */

static const unsigned max = 1000;
static double table [max];
static const unsigned POL = 9;
static double polyc [POL];
extern "C" const char format[];

static void plot (void) {
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  const unsigned k = POL - 1;
  fprintf (cmd, format, k, k, k);
  fflush  (cmd);
  pclose  (cmd);
}

static void read (void) {
  FILE * in = fopen ("nist.dat", "r");
  long index = 0;
  const unsigned buflen = 256;
  char * buf = (char*) malloc (buflen);
  for (;;) {
    size_t l = buflen;
    long n = getline (&buf, &l, in);
    if (n < 0) break;
    if (n < 5) continue;
    char * end, * beg = buf;
    //printf ("%ld nacteno:%s\n", n, buf);
    long i = strtol (beg, &end, 10);
    if ( (i < 0) || (i > 500)) continue;
    //printf ("i=%ld\n", i);
    beg = end;
    for (unsigned m=0; m<10; m++) {
      double d = strtod (beg, &end);
      beg = end;
      //printf ("%ld, %g\n", index, d);
      table [index] = d * 0.001;
      index += 1;
    }
  }
  table [index] = 20.872e-3;
  free (buf);
  fclose (in);
}
/*
static double fittedpoly (const unsigned n) {
  double result = 0.0, x = (double) n;
  for (unsigned i=0; i<POL; i++) {
    result += polyc[i] * pow (x, (double) i);
  }
  return result;
}
*/
/// Optimalizovany vypocet polynomu
static double fittedpoly (const unsigned n) {
  double y = 0.0, x = (double) n;
  unsigned i = POL;
  while (i--) y = polyc[i] + y * x;
  return y;
}
static void write (void) {
  double sqer = 0.0;
  FILE * out = fopen ("copy.dat", "w");
  fprintf (out, "t[C]  U[V](nist) U[V](poly) Delta[V]\n");
  fprintf (out, "-------------------------------------\n");
  for (unsigned n=0; n<400; n++) {
    double t = table[n];
    double f = fittedpoly (n);
    double d = f - t;
    fprintf (out, "%3d %10.6f %10.6f %+12.6e\n", n, t, f, d);
    sqer += d*d;
  }
  fclose (out);
  printf ("total square error = %f\n", sqer);
}
// fitting using GNU Scientific Library
static bool polynomialfit (int obs, int degree,
                           double *dx, double *dy, double *store) { /* n, p */

  gsl_multifit_linear_workspace *ws;
  gsl_matrix *cov, *X;
  gsl_vector *y, *c;
  double chisq;

  int i, j;

  X = gsl_matrix_alloc (obs, degree);
  y = gsl_vector_alloc (obs);
  c = gsl_vector_alloc (degree);
  cov = gsl_matrix_alloc (degree, degree);

  for (i=0; i < obs; i++) {
    for (j=0; j < degree; j++) {
      gsl_matrix_set (X, i, j, pow (dx[i], j));
    }
    gsl_vector_set (y, i, dy[i]);
  }

  ws = gsl_multifit_linear_alloc (obs, degree);
  gsl_multifit_linear (X, y, c, cov, &chisq, ws);

  /* store result ... */
  for (i=0; i < degree; i++) {
    store[i] = gsl_vector_get (c, i);
  }

  gsl_multifit_linear_free (ws);
  gsl_matrix_free (X);
  gsl_matrix_free (cov);
  gsl_vector_free (y);
  gsl_vector_free (c);
  return true; /* we do not "analyse" the result (cov matrix mainly)
      to know if the fit is "good" */
}
static void compute (void) {
  const unsigned NP  = 400;
  double x[NP];
  for (unsigned n=0; n<NP; n++) x[n] = (double) n;
  polynomialfit (NP, POL, x, table, polyc);
  for (unsigned i=0; i<POL; i++) {
    printf ("a[%d]=%18.10e\n", i, polyc[i]);
  }
}

int main (void) {
  read();
  compute();
  write();
  plot();
  return 0;
}
