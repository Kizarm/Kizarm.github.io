#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Měření frekvence silové sítě předzpracováno v souboru a.dat
'''

import os
import csv
import numpy as np
from scipy.optimize import curve_fit


def readfile(name, x, y):
  with open(name, 'r') as f:
    reader = csv.reader(f, delimiter=' ')
    for row in reader:
      v = []
      for w in row:
        a = float(w)
        v.append(a)
      if len(v) == 2:
        x.append(v[0])
        y.append(v[1])
      else:
        print 'input error - ', v

def writefile (name, xa, ya, za):  
  file = open (name,'w')
  l = len(xa)
  for i in range(0,l):
    x = xa[i]
    y = ya[i]
    w = za[i]
    str = '{0} {1} {2}\n'.format(x, y, w)
    file.write (str)
  file.close()
  
def gauss (x, a0, x0, sg):
  return a0 * np.exp(-(x-x0)**2 / (sg**2))

if __name__ == '__main__':
  xa = []
  ya = []
  readfile('a.dat', xa, ya)

  popt,pcov = curve_fit (gauss, xa, ya, p0 = [500.0, 50000.0, 20.0])
  print "coefs:"
  print popt
  print "corel:"
  for n in pcov:
    print n
  za = []
  for x in xa:
    z = gauss (x, *popt)
    za.append (z)
  
  writefile ('b.dat', xa, ya, za)
  os.system ('gnuplot a.cmd')
