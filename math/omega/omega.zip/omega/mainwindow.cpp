#include <QDesktopWidget>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "riess.h"
/*
#undef  qDebug
#define qDebug(p, ...)
*/
//////////////////////// Konstanty ////////////////////////

static constexpr double STEP_Z = 0.02;
static constexpr double INVR_Z = 1.0 / STEP_Z;
static constexpr double STEP_A = 0.01;  // mld ly
static constexpr double UA     = 13.6;  // stáří vesmíru mld y

////////////////////////  Výpočty  ////////////////////////
/** @class Expansion
 * Tohle je poněkud abstraktní, ale je to vyzkoušená a poměrně
 * přesná metoda na numerické řešení nelineárních diferenciálních
 * rovnic, která se dá rozšířit i na jejich soustavy.
 * */
class Expansion : public BaseFunction {
  bool singularity;
  real sign;
  real omega_l, omega_m, omega_r;
public:
  explicit Expansion (const real t0, const real y0) : BaseFunction(t0, y0),
           singularity(false), sign(1.0), omega_l(0.68), omega_m(0.32), omega_r(0.0004) {};
    real operator()(const real t, const real a) override {
      constexpr double H0 = 1.0 / UA;  // zatím se nebudeme zabývat v čem je to měřeno
      (void) t;
      if (a <= 0.0) { singularity = true; return 0; }
      
      real result = omega_r * pow (a, -4) + omega_m * pow (a, -3) + omega_l;
      
      if (result <= 0.0) {
        sign *= -1.0;
        return sign * H0 * a * sqrt (-result);
      } else {
        return sign * H0 * a * sqrt (+result);
      }
    }
    void init (real & t0, real & y0)                  override {
      singularity = false; sign = +1.0;
      BaseFunction::init(t0, y0);
    };
    void setParams (const std::vector<real> & params) override {
      omega_l = params[0];
      omega_m = params[1];
      omega_r = params[2];
    }
    bool isDivergent () const                         override {
      return singularity;
    };
};
DataSet MainWindow::ComputeExpansion() {
  DataSet result;
  // spočteme expanzní funkci podle parametrů Omega.
  const std::vector<real> p = {omega_l, omega_m, omega_r};
  Expansion  e (0.0, 1.0);                // současná hodnota (čas nula) expanzní funkce je 1.0
  e.setParams (p);
  RungeKutta r (e, STEP_A, 3000);
  std::vector<Point> x = r.solve(false);  // s časem jdeme do mínusu (vyvíjíme pozpátku)
  const unsigned m = x.size();
  // expanzní funkce klesá k nule kde dochází k divergenci, takže 
  // skutečný počet bodů je menší než požadovaná hodnota
  QString s; s.sprintf ("Points = %d", m);
  ui->statusbar->showMessage (s);
  unsigned n = 0;
  result.x.resize(m);
  result.y.resize(m);
  for (Point & d : x) {
    if (d.t < result.lx) result.lx = d.t;
    result.x [n] = d.t;
    result.y [n] = d.y;
    n += 1;
  }
  return result;
}
DataSet MainWindow::ComputeMangitude() {
  DataSet result;
  // opět spočteme expanzní funkci
  const std::vector<real> p = {omega_l, omega_m, omega_r};
  Expansion  e (0.0, 1.0);
  e.setParams (p);
  RungeKutta r (e, STEP_A, 3000);
  std::vector<Point> x = r.solve(false);
  // a integrujeme její převrácenou hodnotu - zde nahrazeno prostým součtem
  for (double z = 0.2; z < 2.0; z += STEP_Z) {
    const double a = 1.0 / (z + 1.0);
    double dl = 0.0;       // luminosity distance
    for (const Point & e: x) {
      if (a > e.y) break;  // dorazili jsme na mez integrace
      dl += 1.0 / e.y;
    }
    dl *= STEP_A;          // mld ly
    dl *= (1.0e9 / 3.262); // mld ly -> ps
    dl *= z + 1.0;         // fakt není vůbec jasné proč, ale dělá se to tak - Riess 2007 (3)
    /* To ext se odečítá zřejmě jako extinkce, ale je to hodně citlivé na hodnotu, změna
     * o několik procent mění poměr temné energie a hmoty o desítky procent.
     * */
    constexpr double ext = 0.97;
    const double w = 5.0 * (log10 (dl) - ext);
    result.x.push_back (z);
    result.y.push_back (w);
  }
  SquareError (result);
  return result;
}
static int bisect (const QVector<double> & v, const double x) {
  int l = 0, r = v.size();
  while (l < r) {
    const int m = (l + r) / 2;
    if (v[m] > x) r = m;
    else          l = m + 1;
  }
#if 0
  if ((v [r - 1] <= x) and (v [r] >= x)) {  // Test - je v daném intervalu ?
    return r - 1;
  } else {
    qDebug ("Error find Z");
    return -1;
  }
#else
  return r - 1;   // funguje to - použijeme zkrácenou verzi
#endif
}
void MainWindow::SquareError (const DataSet & ds) {
  double delta_square = 0;
  for (const RiessData & e: RD) {
    const int n = bisect (ds.x, e.z);
    if (n < 0) continue;
    const double ew = 1.0 / e.error;      // váha je nepřímo úměrná chybě
    // lineární interpolace
    const double dz = (e.z - ds.x [n]) * INVR_Z;
    const double tm = ds.y [n] + (ds.y [n + 1] - ds.y [n]) * dz;
    const double delta = tm - e.luminosity;
    // je celkem jedno, zda se váha použije
    delta_square += delta * delta * ew;
  }
  QString s;
  s.sprintf("delta_square : %f", delta_square);
  ui->statusbar->showMessage(s);
}

//////////////////////// GUI - poměrně nepodstatné ////////////////////////

MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent) {
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  ui->comboBox->addItem ("Expansion");
  ui->comboBox->addItem ("Magnitude");
  setWindowTitle ("Test");
  setWindowIcon  (QIcon(":ico"));
  fix  = false;
  type = PLOT_EXPANSION;
  plot = new QCustomPlot (this);
  InitColors();
  ui->verticalLayout->addWidget(plot);
  
  omega_m = omega_r = 0.0;
  omega_l = 1.0;
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
//connect (ui->,      SIGNAL (),       this, SLOT ());
  connect (ui->Omega_l,      SIGNAL(valueChanged(int)),       this, SLOT(Change_l(int)));
  connect (ui->Omega_r,      SIGNAL(valueChanged(int)),       this, SLOT(Change_r(int)));
  connect (ui->Omega_m,      SIGNAL(valueChanged(int)),       this, SLOT(Change_m(int)));
  connect (ui->checkBox,     SIGNAL(stateChanged(int)),       this, SLOT(Change_fix(int)));
  connect (ui->comboBox,     SIGNAL(activated(int)),          this, SLOT(Change_plt(int)));
  
  tx.push_back(0.0);
  ty.push_back(1.0);
  tx.push_back(-UA);
  ty.push_back(0.0);
  
  zx.push_back(-20.0);
  zy.push_back(1.0);
  zx.push_back(0.0);
  zy.push_back(1.0);
  

  ui->Omega_r->setValue(4);
  Change_m (32);
  ui->checkBox->setCheckState (Qt::Checked);
}

MainWindow::~MainWindow () {
  delete plot;
  delete ui;
}
static const QString SOmega = QString::fromUtf8("Ω");

void MainWindow::Change_m (int n) {
  const double v = 0.01 * double (n);
  omega_m = v;
  omega_l = 1.0 - (omega_m + omega_r);
  if (omega_l < 1.0 and omega_l >= 0.0) {
    QString s;
    int k = lround (100.0 * omega_m);
    s = SOmega + s.sprintf ("m = %2d", k);
    ui->label_m->setText (s);
    
    k = lround (100.0 * omega_l);
    ui->Omega_l->setValue (k);
    s = SOmega + s.sprintf ("l = %2d", k);
    ui->label_l->setText (s);
    replot();
  } else {
    qDebug ("chybka m");
  }
}
void MainWindow::Change_r (int n) {
  const double v = 1.e-4 * double (n);
  omega_r = v;
  omega_l = 1.0 - (omega_m + omega_r);
  if (omega_l < 1.0) {
    QString s;
    int k = lround (1.e4 * omega_r);
    s = SOmega + s.sprintf ("r = %g", (double)k / 100.0);
    ui->label_r->setText (s);
    
    k = lround (100.0 * omega_l);
    s = SOmega + s.sprintf ("l = %2d", k);
    ui->label_l->setText (s);
    replot();
  } else {
    qDebug ("chybka r");
  }
}
void MainWindow::Change_l (int n) {
  const double v = 0.01 * double (n);
  omega_l = v;
  omega_m = 1.0 - (omega_l + omega_r);
  if (omega_m < 1.0 and omega_m >= 0.0) {
    QString s;
    int k = lround (100.0 * omega_l);
    s = SOmega + s.sprintf ("l = %2d", k);
    ui->label_l->setText (s);
    
    k = lround (100.0 * omega_m);
    ui->Omega_m->setValue (k);
    s = SOmega + s.sprintf ("m = %2d", k);
    ui->label_m->setText (s);
    replot();
  } else {
    qDebug ("chybka l");
  }
}
void MainWindow::Change_fix (int n) {
  //qDebug("%d", n);
  if (n) fix = true;
  else   fix = false;
  replot();
}

void MainWindow::PlotExpansion() {
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->graph(0)->setPen(QPen(Qt::magenta, 2));
  plot->graph(1)->setPen(QPen(Qt::green,   2));
  plot->graph(2)->setPen(QPen(Qt::red,     1));
  
  plot->legend->setBrush(QBrush(QColor(255,255,0,64)));
  plot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignLeft|Qt::AlignTop);
  plot->legend->removeItem(2);
  plot->legend->setVisible(true);
  plot->graph(0)->setName ("a (t)");
  plot->graph(1)->setName ("age");
  
  plot->xAxis->setLabel("t [mld ly]");
  plot->yAxis->setLabel("a(t) []");
  plot->setInteractions(QCP::iRangeZoom | QCP::iRangeDrag);

  DataSet ds = ComputeExpansion();
  plot->graph(0)->setData (ds.x, ds.y);
  plot->graph(1)->setData (tx, ty);
  plot->graph(2)->setData (zx, zy);
  
  if (fix) plot->xAxis->setRange (-20.0, 0);
  else     plot->xAxis->setRange (ds.lx, 0);
  plot->xAxis->setAutoTickStep (false);
  plot->xAxis->setTickStep (2.0);
  plot->yAxis->setRange (0.0, 1.0);
  plot->yAxis->setAutoTickStep (false);
  plot->yAxis->setTickStep (0.2);
}
void MainWindow::PlotMagnitude() {
  plot->xAxis->setAutoTickStep (true);
  plot->yAxis->setAutoTickStep (true);
  plot->xAxis->setLabel("Z []");
  plot->yAxis->setLabel("M(Z) []");

  QVector<double> Z, M, E;
  for (const RiessData e: RD) {
    Z.push_back (e.z);
    M.push_back (e.luminosity);
    E.push_back (e.error);
  }
  plot->addGraph();
  plot->graph(0)->setPen(QPen(Qt::blue, 2));
  plot->graph(0)->setLineStyle(QCPGraph::lsNone);
  plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCross, 4));
  plot->graph(0)->setName (QString::fromUtf8("Měření"));
  
  plot->xAxis->setRange (0.0, 2.0);
  plot->yAxis->setRange (40.0, 47.0);
  plot->graph(0)->setErrorPen(QPen(Qt::gray, 1));
  plot->graph(0)->setErrorBarSize (1);
  plot->graph(0)->setErrorType(QCPGraph::etValue);
  plot->graph(0)->setDataValueError (Z,M,E);
  
  DataSet ds = ComputeMangitude();
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->graph(1)->addData (ds.x, ds.y);
  plot->graph(1)->setName ("Teorie");
  plot->graph(1)->setPen(QPen(Qt::green,   2));
}

void MainWindow::replot() {
  plot->clearPlottables();
  
  switch (type) {
    case PLOT_EXPANSION: PlotExpansion(); break;
    case PLOT_MAGNITUDE: PlotMagnitude(); break;
    default : break;
  }
  
  plot->replot();
}
void MainWindow::Change_plt (int n) {
  type = PLOT_TYPE (n);
  replot();
}
void MainWindow::ChangeColor (QCPAxis * axis, const QColor & color) {
  const QPen   pen   (color, 1);
  axis->setBasePen    (pen);
  axis->setTickPen    (pen);
  axis->setSubTickPen (pen);
  axis->setLabelColor     (color);
  axis->setTickLabelColor (color);
}
void MainWindow::InitColors() {
  const QColor ax (Qt::yellow);
  const QBrush bg = QBrush (QColor (0,0,0, 255));
  ChangeColor (plot->xAxis, ax);
  ChangeColor (plot->yAxis, ax);
  plot->setBackground(bg);
  plot->legend->setTextColor(ax);
}

