#include <QDesktopWidget>
#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "union2.1.h"
#include "pantheon.h"   // větší soubor dat
/*
#undef  qDebug
#define qDebug(p, ...)
*/
static constexpr size_t BUFLEN = 256;
// Pomocná formátovací funkce
static QString msprintf (const char *fmt, ...) {
  char buf [BUFLEN];
  va_list    ap;
  signed int rc;
  va_start (ap, fmt);
  rc = vsnprintf (buf, BUFLEN, fmt, ap);
  (void) rc; 
  va_end (ap);
  return QString::fromUtf8 (buf);
}
//////////////////////// Konstanty ////////////////////////

static constexpr double STEP_T = 0.01;  // mld ly
static constexpr double UA     = 13.6;  // stáří vesmíru mld y
static constexpr double COEFF  = STEP_T * (1.0e9 / 3.262); // krok * (mld ly -> pc)

////////////////////////  Výpočty  ////////////////////////
static QVector<ObservedData> RDS;
/** @class Expansion
 * Tohle je poněkud abstraktní, ale je to vyzkoušená a poměrně
 * přesná metoda na numerické řešení nelineárních diferenciálních
 * rovnic, která se dá rozšířit i na jejich soustavy.
 * */
class Expansion : public BaseFunction {
  bool singularity;
  real sign;
  real omega_l, omega_m, omega_r, omega_c;
public:
  explicit Expansion (const real t0, const real y0) : BaseFunction(t0, y0),
           singularity(false), sign(1.0), omega_l(0.68), omega_m(0.32), omega_r(0.0004) {};
    real operator()(const real t, const real a)       override {
      constexpr double H0 = 1.0 / UA;  // zatím se nebudeme zabývat v čem je to měřeno
      (void) t;
      if (a <= 0.0) { singularity = true; return 0; }
      
      real result = omega_r * pow (a, -4) + omega_m * pow (a, -3) - omega_c * pow (a, -2) + omega_l;
      
      if (result <= 0.0) {
        sign *= -1.0;
        return sign * H0 * a * sqrt (-result);
      } else {
        return sign * H0 * a * sqrt (+result);
      }
    }
    void init (real & t0, real & y0)                  override {
      singularity = false; sign = +1.0;
      BaseFunction::init(t0, y0);
    };
    void setParams (const std::vector<real> & params) override {
      omega_l = params[0];
      omega_m = params[1];
      omega_r = params[2];
      omega_c = params[3];
    }
    bool isDivergent () const                         override {
      return singularity;
    };
};
// V uspořádaném vektoru v hledám hodnotu x, vracím index nejbližšího prvku.
static int bisect (const QVector<double> & v, const double x) {
  int l = 0, r = v.size();
  while (l < r) {
    const int m = (l + r) / 2;
    if (v[m] > x) r = m;
    else          l = m + 1;
  }
#if 0
  if ((v [r - 1] <= x) and (v [r] >= x)) {  // Test - je v daném intervalu ?
    return r - 1;
  } else {
    qDebug ("Error find Z");
    return -1;
  }
#else
  return r - 1;   // funguje to - použijeme zkrácenou verzi
#endif
}
DataSet MainWindow::ComputeExpansion() {
  DataSet result;
  // spočteme expanzní funkci podle parametrů Omega.
  const std::vector<real> p = {omega_l, omega_m, omega_r, omega_c};
  Expansion  e (0.0, 1.0);                // současná hodnota (čas nula) expanzní funkce je 1.0
  e.setParams (p);
  RungeKutta r (e, STEP_T, 3000);
  std::vector<Point> x = r.solve(false);  // s časem jdeme do mínusu (vyvíjíme pozpátku)
  const unsigned m = x.size();
  // expanzní funkce klesá k nule kde dochází k divergenci, takže 
  // skutečný počet bodů je menší než požadovaná hodnota
  ui->statusbar->showMessage (msprintf("Points = %d", m));
  unsigned n = 0;
  result.x.resize(m);
  result.y.resize(m);
  for (Point & d : x) {
    if (d.t < result.lx) result.lx = d.t; // hledání minima na ose x
    result.x [n] = d.t;
    result.y [n] = d.y;
    n += 1;
  }
  return result;
}
// Opravná funkce - něco jako sync (sin(x)/x), pro záporné x pak (sinh(x)/x)
static double sinc (double x) {
  static constexpr double eps = +1.0e-6;
  double sig = -1.0;
  if (x < 0.0) sig = +1.0;
  double arg = x*x, fac = 1.0, res = 0.0, ind = 1.0, mul = 1.0;
  for (;;) {
    const double e = mul / fac;
    ind += 1.0;
    fac *= ind;
    ind += 1.0;
    fac *= ind;
    mul *= arg * sig;
    res += e;
    if (abs (e) < eps) break;
  }
  return res;
}
// lineátní aproximace
static void approx (const QVector<ComputedData> & cd, const int index,
                    const ObservedData & rd, double & z, double & l) {
  const ComputedData & r = cd [index];
  const ComputedData & s = cd [index + 1];
  const double dz = s.z - r.z;
  const double dm = s.lum_dist - r.lum_dist;
  z = rd.z;
  if (dz == 0.0) {
    l = rd.luminosity;
  } else {
    l = (rd.z - r.z) * (dm / dz) + r.lum_dist;
  }
}
DataSet MainWindow::ComputeMangitude() {
  DataSet result;
  // opět spočteme expanzní funkci
  const std::vector<real> p = {omega_l, omega_m, omega_r};
  Expansion  e (0.0, 1.0);
  e.setParams (p);
  RungeKutta r (e, STEP_T, 3000);
  std::vector<Point> x = r.solve(false);
  QVector<ComputedData> cd;
  const ObservedData & rd = RDS [0];
  int index = -1, n = 0;
  double dl = 0.0;                // luminosity distance
  for (const Point & p: x) {      // vytvořím potřebná data a určím index tak, aby z v datech odpovídalo SN s nejmenším z
    ComputedData c;
    c.t = p.t; c.a = p.y;
    const double ia = 1.0 / c.a;
    c.z = ia - 1.0;
    if ((c.z > rd.z) and (index < 0)) index = n;
    /* Integrace prostým součtem - platí pouze, pokud omega_c == 0
     * jinak je potřeba upravit. Protože omega_c je malé, necháme zatím být.
     * Oprava by spočívala v tom, že pro kladnou křivost místo dl použijeme
     * něco jako sin(dl), ale argument v použitých jednotkách by byl malý,
     * menší než 0.4, oprava je pak v řádu setin. Oprava pomocí fce sinc
     * snad funguje správně, ale stejně není velká. Je to tak proto,
     * aby se nemuselo počítat sin(x)/x - jinak jsou tam velká čísla.
     * Nejde nastavit Ωc na víc jak 10% aby oprava nebyla moc velká,
     * není jistota, že je to správně.
     */
    dl += ia;
    c.lum_dist = dl;
    cd.push_back(c);
    n += 1;
  }
  double ext = 4.85;              // hausnumero, není důležité, výpočet ho změní
  /* To ext se odečítá aby to sedělo na počátku, kde je a ~ 1.0
    * Když se chytnu na první SN (má malou chybu), při nulové extikci
    * pak vyjde optimální omega_m asi 30%, celkem bez ohledu na DataSet.
  * */
  if (index >= 0) {               // nalezena oprava ext
    double z, l;
    approx (cd, index, rd, z, l);
    const double ll = 5.0 * log10 (COEFF * l * (z + 1.0));
    ext = ll - rd.luminosity;     // oprava ext zachycená pro 1. SN Ia
    // printf("%g %d\n", ext, index);
  }
  for (const ComputedData & c: cd) {
    if ((c.z >= z_min) and (c.z < z_max)) {               // jen tam, kde máme data
      const double ar = STEP_T * sqrt_c * c.lum_dist;
      // Riess 2007 (3) - úbytek energie fotonu vlivem expanze, sinc() je oprava na křivost
      const double ld = COEFF  * sinc(ar) * c.lum_dist * (c.z + 1.0);
      const double mw = 5.0 * log10 (ld) + decline * c.lum_dist - ext + offset;
      //printf ("a = %-10g z = %-10g ld = %-10g [mld ly] arg = %g\n", c.a, c.z, c.lum_dist * STEP_T, ar);
      
      result.x.push_back (c.z);
      result.y.push_back (mw);
    }
  }
  SquareError (result);
  return result;
}
void MainWindow::SquareError (const DataSet & ds) {
  double delta_square = 0;
  for (const ObservedData & e: RDS) {
    const int n = bisect (ds.x, e.z);
    if (n < 0) continue;
    const double ew = 1.0 / e.error;      // váha je nepřímo úměrná chybě
    const double delta = ds.y [n] - e.luminosity;
    // je celkem jedno, zda se váha použije
    delta_square += delta * delta * ew;
  }
  ui->statusbar->showMessage(msprintf("delta_square : %f", delta_square));
}

//////////////////////// GUI - poměrně nezajímavé ////////////////////////

static void print_data (const QVector<ObservedData> & data) {
  return;     // test dat: release -> nedělej nic, pokud tt. řádek zakomentujeme, vypíše data setříděná podle z
  FILE * f = fopen ("data.txt", "w");
  for (const ObservedData & e: data) {
    const int l = 12 - strlen (e.name);
    fprintf (f, "name = \"%s\"%*s, z = %-8g, m = %-10g, e = %g\n", e.name, l , " ", e.z, e.luminosity, e.error);
  }
  fclose(f);
}

MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent) {
  for (const ObservedData & e: RD) RDS.push_back(e);  // data zkopírujeme a setřídíme podle z
  std::sort (RDS.begin(), RDS.end(), [](const ObservedData & l, const ObservedData & r)->bool {
    return r.luminosity > l.luminosity;               // sekundárně podle luminosity
  });
  std::sort (RDS.begin(), RDS.end(), [](const ObservedData & l, const ObservedData & r)->bool {
    return r.z > l.z;                                 // primárně podle z
  });
  print_data (RDS);
  ObservedData & od_b = RDS.first();
  ObservedData & od_e = RDS.last();
  m_min = round (od_b.luminosity - 1.0);
  m_max = round (od_e.luminosity + 1.0);
  z_min = od_b.z;
  z_max = od_e.z + 0.1;
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  ui->comboBox->addItem ("Expansion");
  ui->comboBox->addItem ("Magnitude");
  setWindowTitle ("DataSet: Scolnic 2018");
  setWindowIcon  (QIcon(":ico"));
  fix  = false;
  type = PLOT_EXPANSION;
  plot = new QCustomPlot (this);
  InitColors();
  ui->verticalLayout->addWidget(plot);
  
  omega_m = 0.0;
  omega_c = 0.0;
  omega_l = 1.0;
  omega_r = 0.0005; // necháme konstantní
  decline = 0.0;
  offset  = 0.0;
  sqrt_c  = 0.0;
  rel_ml  = 32.0;
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
//connect (ui->,      SIGNAL (),       this, SLOT ());
  connect (ui->Omega_l,      SIGNAL(valueChanged(int)),       this, SLOT(Change_l(int)));
  connect (ui->Omega_r,      SIGNAL(valueChanged(int)),       this, SLOT(Change_r(int)));
  connect (ui->Omega_m,      SIGNAL(valueChanged(int)),       this, SLOT(Change_m(int)));
  connect (ui->Omega_c,      SIGNAL(valueChanged(int)),       this, SLOT(Change_c(int)));
  connect (ui->checkBox,     SIGNAL(stateChanged(int)),       this, SLOT(Change_fix(int)));
  connect (ui->comboBox,     SIGNAL(activated(int)),          this, SLOT(Change_plt(int)));
  connect (ui->actionQuit,   SIGNAL(triggered()),             this, SLOT(close()));
  connect (ui->actionExport, SIGNAL(triggered(bool)),         this, SLOT(exprt(bool)));
  
  tx.push_back(0.0);
  ty.push_back(1.0);
  tx.push_back(-UA);
  ty.push_back(0.0);
  
  zx.push_back(-20.0);
  zy.push_back(1.0);
  zx.push_back(0.0);
  zy.push_back(1.0);
  

  ui->Omega_m->setValue (32);
  ui->Omega_l->setValue (50);
  ui->Omega_c->setValue (50);
  ui->checkBox->setCheckState (Qt::Checked);
}

MainWindow::~MainWindow () {
  delete plot;
  delete ui;
}

void MainWindow::Change_m (int n) {
  rel_ml = 0.01 * double (n);
  const double ml = 1.0 - (omega_r + omega_c);
  omega_m = ml * rel_ml;
  omega_l = ml * (1.0 - rel_ml);
  ui->label_m->setText (msprintf("Ωm = %2d / Ωl = %2d [%%]", n, 100 - n));
  replot();
}
void MainWindow::Change_r (int n) {
  decline = 2.0e-5 * double (n);
  QString s;
  /* Zatím jen řádový odhad - za ~1.0e9 pc zeslabení na 1/e, což jsou řádově vzdálenosti na z = 2 .
   * Převod z mag na dB, asi to není úplně správně, ale z grafu to celkem sedí. Tohle stejně nebude
   * nikdy úplně košer, decline by se mělo se z zvětšovat (v malém vesmíru je větší hustota),
   * ale pak útlum se vzdáleností roste příliš. Asi by to šlo nějak okecat, možností je dost.
   */
  static constexpr double kd = 4.0 / STEP_T;
  ui->label_r->setText(msprintf("D = %g [dB / Gly]", kd * decline));
  replot();
}
void MainWindow::Change_c (int n) {
  omega_c = 0.002 * double (n - 50);
  if (omega_c < 0.0) sqrt_c  = +sqrt (-omega_c) / UA;
  else               sqrt_c  = -sqrt (+omega_c) / UA;
  const double ml = 1.0 - (omega_r + omega_c);
  omega_m = ml * rel_ml;
  omega_l = ml * (1.0 - rel_ml);
  ui->label_c->setText (msprintf("Ωc = %+g [%%]", 100.0 * omega_c));
  replot();
}

void MainWindow::Change_l (int n) {
  // případný ruční posuv o +/- 0.5 magnitudy
  offset = 0.01 * double (n - 50);
  ui->label_l->setText(msprintf("O = %g", offset));
  replot();
}
void MainWindow::Change_fix (int n) {
  //qDebug("%d", n);
  if (n) fix = true;
  else   fix = false;
  replot();
}

void MainWindow::PlotExpansion() {
  ui->checkBox->setText("Fix");
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->graph(0)->setPen(QPen(Qt::magenta, 2));
  plot->graph(1)->setPen(QPen(Qt::green,   2));
  plot->graph(2)->setPen(QPen(Qt::red,     1));
  
  plot->legend->setBrush(QBrush(QColor(255,255,0,64)));
  plot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignLeft|Qt::AlignTop);
  plot->legend->removeItem(2);
  plot->legend->setVisible(true);
  plot->graph(0)->setName ("a (t)");
  plot->graph(1)->setName ("age");
  
  plot->xAxis->setLabel(QString::fromUtf8("t [10⁹ year]"));
  plot->yAxis->setLabel("a(t) []");
  plot->setInteractions(QCP::iRangeZoom | QCP::iRangeDrag);

  DataSet ds = ComputeExpansion();
  plot->graph(0)->setData (ds.x, ds.y);
  plot->graph(1)->setData (tx, ty);
  plot->graph(2)->setData (zx, zy);
  
  plot->xAxis->setScaleType(QCPAxis::stLinear);
  if (fix) plot->xAxis->setRange (-20.0, 0);
  else     plot->xAxis->setRange (ds.lx, 0);
  plot->xAxis->setAutoTickStep (false);
  plot->xAxis->setTickStep (2.0);
  plot->yAxis->setRange (0.0, 1.0);
  plot->yAxis->setAutoTickStep (false);
  plot->yAxis->setTickStep (0.2);
}
void MainWindow::PlotMagnitude() {
  ui->checkBox->setText("log");
  plot->xAxis->setAutoTickStep (true);
  plot->yAxis->setAutoTickStep (true);
  plot->xAxis->setLabel("Z []");
  plot->yAxis->setLabel("M(Z) []");

  QVector<double> Z, M, E;
  for (const ObservedData e: RDS) {
    Z.push_back (e.z);
    M.push_back (e.luminosity);
    E.push_back (e.error);
  }
  plot->addGraph();
  plot->graph(0)->setPen(QPen(Qt::blue, 2));
  plot->graph(0)->setLineStyle(QCPGraph::lsNone);
  plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCross, 4));
  plot->graph(0)->setName (QString::fromUtf8("Měření"));
  if (fix) {
    plot->xAxis->setScaleType(QCPAxis::stLogarithmic);
    plot->xAxis->setScaleLogBase(2.0);
  } else {
    plot->xAxis->setScaleType(QCPAxis::stLinear);
  }
  plot->xAxis->setRange (z_min, z_max);
  
  plot->yAxis->setRange (m_min, m_max);
  plot->graph(0)->setErrorPen(QPen(Qt::gray, 1));
  plot->graph(0)->setErrorBarSize (1);
  plot->graph(0)->setErrorType(QCPGraph::etValue);
  plot->graph(0)->setDataValueError (Z,M,E);
  
  DataSet ds = ComputeMangitude();
  plot->addGraph (plot->xAxis, plot->yAxis);
  plot->graph(1)->addData (ds.x, ds.y);
  plot->graph(1)->setName ("Teorie");
  plot->graph(1)->setPen(QPen(Qt::green,   2));
}

void MainWindow::replot() {
  // printf("%g\n", omega_m + omega_l + omega_r + omega_c);
  plot->clearPlottables();
  
  switch (type) {
    case PLOT_EXPANSION: PlotExpansion(); break;
    case PLOT_MAGNITUDE: PlotMagnitude(); break;
    default : break;
  }
  
  plot->replot();
}
void MainWindow::Change_plt (int n) {
  type = PLOT_TYPE (n);
  replot();
}
void MainWindow::ChangeColor (QCPAxis * axis, const QColor & color) {
  const QPen   pen   (color, 1);
  axis->setBasePen    (pen);
  axis->setTickPen    (pen);
  axis->setSubTickPen (pen);
  axis->setLabelColor     (color);
  axis->setTickLabelColor (color);
}
void MainWindow::InitColors() {
  const QColor ax (Qt::yellow);
  const QBrush bg = QBrush (QColor (0,0,0, 255));
  ChangeColor (plot->xAxis, ax);
  ChangeColor (plot->yAxis, ax);
  plot->setBackground(bg);
  plot->legend->setTextColor(ax);
}
#ifndef EMSCRIPTEN
#include <QFileDialog>
#endif
void MainWindow::exprt (bool) {
#ifndef EMSCRIPTEN
  QWidget * pw = plot;
  QString fileName = QFileDialog::getSaveFileName (this,
               tr ("Save File"), ".", "Images Files(*.png)");
  if (!fileName.isEmpty()) {
    if (!fileName.endsWith(".png")) fileName.append(".png");
    QImage    img (pw->width(), pw->height(), QImage::Format_ARGB32_Premultiplied);
    QPainter  painter(&img);
    pw->render (&painter);
    img.save   (fileName, "PNG", 0);
  }
#endif
}

