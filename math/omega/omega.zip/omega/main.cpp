#include "main.h"

int main (int argc, char *argv[]) {
  QApplication a (argc, argv);
  MainWindow w;
/*
  QStyle *arthurStyle = new ArthurStyle();
  w.setStyle (arthurStyle);
  QList<QWidget *> widgets = w.findChildren<QWidget *>();
  for (QWidget * e: widgets) e->setStyle (arthurStyle);
*/
  w.show();
  return a.exec();
}
