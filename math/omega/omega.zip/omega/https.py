#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests

'''
Tento skript stáhne data z určené stránky, rozparsuje jí a zapíše data ve formě c-čkové hlavičky
do souboru pantheon.h. Je to jednoúčelové, takže kontrola chyb je nulová a parser je ukrutně zjednodušen.
'''

def getData ():
  response = requests.get('https://archive.stsci.edu/prepds/ps1cosmo/scolnic_datatable.html')
  data = response.text
  return data
'''
def getData ():
  f = open ('scolnic_datatable.html','r')
  res = f.read()
  f.close ();
  return res
'''
def find (html, tag):
  result = []
  body = html
  l = len (tag)
  while True:
    b = body.find ('<' + tag)
    e = body.find ('</' + tag + '>')
    if b < 0 or e < 0: break
    e+= l + 3
    result.append  (body[b:e])
    body = body[e:]
  return result
def extract (text):
  r = ''
  b = text.find ('>')
  if b < 0: return r
  e = text[b:].find ('<')
  if e < 0: return r
  e += b
  b += 1
  r = text[b:e]
  return r
preamble = '''/* GENERATED DATA - DO NOT EDIT ! */
#ifndef OBSERVED_DATA
#define OBSERVED_DATA
struct ObservedData {
  const char * name;
  double z, luminosity, error;
};
'''
def write_output (lines):
  f = open ('pantheon.h', 'w')
  f.write (preamble)
  f.write ('static const ObservedData RD [] = {\n')
  for line in lines:
    if len (line) == 0: continue
    f.write ('  {')
    n = 0
    for part in line:
      if n == 0:
        part_m = part
        f.write ('"{0:s}",'.format(part_m))
        m = 15 - len (part_m)
        for k in range (0,m): f.write(' ')
      else:
        f.write ('{0:16s},'.format(part))
      n += 1
    f.write(' },\n')
  f.write('};\n#endif\n')
  f.close

if __name__ == "__main__":
  html = getData();
  tab  = find (html, 'tbody')
  row  = find (tab [1], 'tr')
  out  = []
  for col in row:
    val = []
    dat = find (col, 'td')
    n = 0
    for e in dat:
      if n == 2 or n == 3:
        n += 1
        continue 
      p = extract (e)
      val.append  (p)
      n += 1
    out.append(val)
  write_output(out)
  
  