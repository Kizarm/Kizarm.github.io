#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "rungekutta.h"

class Ui_MainWindow;

enum PLOT_TYPE {
  PLOT_EXPANSION = 0, PLOT_MAGNITUDE
};
struct DataSet {
  explicit DataSet () {
    lx = 1000.0;
  }
  QVector<double> x,y;
  double          lx;     // minimum na ose x, nutno spočítat
};
struct ComputedData {
  double t,a;
  double z;
  double lum_dist;
};

class MainWindow : public QMainWindow {
    Q_OBJECT

  public:
    MainWindow (QWidget *parent = 0);
    ~MainWindow ();
  protected:
    void replot   ();
    void InitColors    ();
    void ChangeColor (QCPAxis * axis, const QColor & color);
    void PlotExpansion ();
    void PlotMagnitude ();
    
    DataSet ComputeExpansion ();
    DataSet ComputeMangitude ();
    void SquareError (const DataSet & ds);
  public slots:
    void Change_plt (int n);
    void Change_fix (int n);
    void Change_m   (int n);
    void Change_r   (int n);
    void Change_l   (int n);
    void Change_c   (int n);
    void exprt      (bool);
  private:
    Ui_MainWindow * ui;
    QCustomPlot   * plot;
    PLOT_TYPE       type;
    bool            fix;
    double          omega_m, omega_r, omega_l, omega_c;
    double          rel_ml;
    double          sqrt_c;
    double          decline, offset;
    double          m_min, m_max;
    double          z_min, z_max;
    QVector<double> tx, ty, zx, zy;
};

#endif // MAINWINDOW_H
