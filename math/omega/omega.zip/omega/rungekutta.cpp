#include <stdio.h>
#include "rungekutta.h"

const std::vector< Point >& RungeKutta::solve (const bool direction) {
  //clear();
  const real hh = direction ? +h : -h;
  real t, y;
  f.init (t, y);
  for (int n = 0; n < points; n++) {       //Runge-Kutta method
    const real k1 = hh * f(t,            y           );
    const real k2 = hh * f(t + 0.5 * hh, y + 0.5 * k1);
    const real k3 = hh * f(t + 0.5 * hh, y + 0.5 * k2);
    const real k4 = hh * f(t +       hh, y +       k3);
    y += k1/6.0 + k2/3.0 + k3/3.0 + k4/6.0;
    t += hh;
    if (f.isDivergent()) break;
    Point e;// = data[n];
    e.t = t;
    e.y = y;
    data.push_back(e);
  }
  return data;
}
