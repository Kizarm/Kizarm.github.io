#ifndef RUNGEKUTTA_H
#define RUNGEKUTTA_H

#include <vector>

typedef double real;

struct Point {
  Point () : t(0), y(0) {};
  Point (const real t0, const real y0) : t(t0), y(y0) {};
  real t,y;
};
/// Objekt, který bude interpretovat výpočet y' = f(t, y)
class BaseFunction {
  const Point p0;               //!< holder pro počáteční podmínky
  public:
    /// konstruktor
    explicit BaseFunction    (const real t0, const real y0) : p0(t0,y0) {};
    /// nutno přetížit - výpočet y' = f(t, y)
    virtual real  operator() (const real t , const real y ) = 0;
    /// přetížená funkce může inicializovat i jiné parametry
    virtual void  init       (real & t0, real & y0) {
      t0 = p0.t; y0 = p0.y;
    };
    /// přetížená funkce může mít divergence, solver pak přerušíme
    virtual bool isDivergent () const {return false;};
    /// přetížená funkce může mít parametry
    virtual void setParams   (const std::vector<real> & params) = 0;
};
/// Solver metodou Runge-Kutta
class RungeKutta {
  BaseFunction &      f;        //!< počítaná funkce
  const real          h;        //!< krok metody
  const int           points;   //!< pocet kroků
  std::vector<Point>  data;     //!< data
  public:
    /// konstruktor
    /// @param F Výpočetní objekt BaseFunction
    /// @param step krok metody
    /// @param pts  počet kroků
    RungeKutta(BaseFunction & F, const real step, const unsigned pts)
    : f(F), h(step), points(pts), data(0) {};
    /// vlastní solver @param direction false pak běží pozpátku v čase
    const std::vector<Point> & solve (const bool direction=true);
  protected:
};

#endif // RUNGEKUTTA_H
