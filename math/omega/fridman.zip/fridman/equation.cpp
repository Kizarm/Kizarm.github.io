#include "equation.h"

using namespace GiNaC;
using namespace std;

Equation::Equation(const ex & l, const ex & r) : left(l), right(r) {
  reduce();
}
static const char * flp = "<p class=\"formulaDsp\"> \\[ ";
static const char * fls = " \\]</p>";

void Equation::print (ostream & outs) {
  outs << flp << left << " = " << right << fls << endl;
}
void Equation::reduce() {
  left = left.normal();
  // substituce pro základní pravidlo sin^2 + cos^2 = 1
  left = left.subs(pow(cos(wild()), 2) == 1 - pow(sin(wild()), 2));
  left = left.normal();
  left = collect_common_factors(left);

  right = right.normal();
  right = collect_common_factors(right);
  if (!is_a<mul>(left )) return;
  if (!is_a<mul>(right)) return;
  size_t ml = left .nops();
  size_t mr = right.nops();
  lst cmn;    // Co všechno se dá vykrátit
  for (size_t nl=0; nl<ml; nl++) {
    ex el = left.op(nl);
    for (size_t nr=0; nr<mr; nr++) {
      ex er = right.op(nr);
      if (el == er) {         // stejné výrazy
        cmn.append (el);
      } else {
        if (is_a<power>(el) && is_a<power>(er)) {
          if (el.op(0) == er.op(0)) {
            ex te;
            if (abs(el.op(1)) > abs(er.op(1))) te = er;
            else                               te = el;
            //cout << el << " ~ " << er << " power -> " << te << endl;
            cmn.append(te);   // a mocniny se stejným základem, (absolutně) menší exponent
          }
        }
      }
    }
  }
  for (auto e: cmn) {         // vykrátit levou i pravou stranu
    left  /= e;
    right /= e;
  }
}
void Equation::move (const ex & e) {
  symbol GN("G"), pi("pi");
  ex Gk = 8*pi*GN;
  left  /= e;
  right /= e;
  left = left.expand();
}
