#ifndef EQUATION_H
#define EQUATION_H

#include <ostream>
#include <ginac/ginac.h>
namespace GiNaC {

  class Equation {
    public:
      Equation (const ex & l, const ex & r);
      void print (std::ostream & outs = std::cout);
      void move  (const ex & e);
    protected:
      void reduce ();
    private:
      ex left, right;
  };
  
};
#endif // EQUATION_H
