#ifndef MGINAC_SYMBOL_H
#define MGINAC_SYMBOL_H

#include "ginac/symbol.h"
#include "ginac/basic.h"
#include "ginac/ex.h"
#include "ginac/ptr.h"
#include "ginac/archive.h"

#include <string>
#include <typeinfo>

/** Pouze jednoduché funkce jediného parametru, kterým může být jen symbol.
 *  Umí derivace a výpis v latexu.
 * */

namespace GiNaC {

  class user_func : public basic {
      GINAC_DECLARE_REGISTERED_CLASS (user_func, basic)
      // other constructors
    public:
      explicit user_func (const std::string & initname, const symbol & d, const unsigned n=0, const bool dn = true);
               user_func (const std::string & initname, const std::string & texname, const symbol & d, const unsigned n=0, const bool dn = true);

      // functions overriding virtual functions from base classes
    public:
      bool info (unsigned inf) const override;
      ex eval() const  { return *this; } // for performance reasons
      ex evalf() const { return *this; } // overwrites basic::evalf() for performance reasons
      ex subs (const exmap & m, unsigned options = 0) const override { return subs_one_level (m, options); } // overwrites basic::subs() for performance reasons
      ex normal (exmap & repl, exmap & rev_lookup) const;
      /*
      ex conjugate() const override;
      ex real_part() const override;
      ex imag_part() const override;
      */
      bool is_polynomial (const ex & var) const override;
    protected:
      ex derivative (const symbol & s) const;
      bool is_equal_same_type (const basic & other) const override;
      unsigned calchash() const override;

    public:
      virtual unsigned get_domain() const { return domain::complex; }

    public:
      void set_name (const std::string & n) { name = n; }
      void set_TeX_name (const std::string & n) { TeX_name = n; }
      std::string get_name() const;
      std::string get_TeX_name() const;
    protected:
      void do_print (const print_context & c, unsigned level) const;
      void do_print_latex (const print_latex & c, unsigned level) const;

// member variables

    protected:
      unsigned serial;                 ///< unique serial number for comparison
      mutable std::string name;        ///< printname of this user_func
      std::string TeX_name;            ///< LaTeX name of this user_func
      symbol derivate;
      unsigned dlevel;
      bool     dotnotation;
  };
  GINAC_DECLARE_UNARCHIVER (user_func);

} // namespace GiNaC

#endif // ndef MGINAC_SYMBOL_H
