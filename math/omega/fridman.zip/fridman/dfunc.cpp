#include "ginac/ginac.h"
#include "ginac/lst.h"
#include "ginac/archive.h"
#include "ginac/inifcns.h"
#include "dfunc.h"

#include <stdio.h>
#include <stdint.h>
#include <map>
#include <stdexcept>
#include <string>

namespace GiNaC {
  inline unsigned golden_ratio_hash (uintptr_t n) {
    return n * UINT64_C (0x4f1bbcdd);
  }
  static inline unsigned make_hash_seed (const std::type_info& tinfo) {
    const void* mangled_name_ptr = (const void*) tinfo.name();
    unsigned v = golden_ratio_hash ( (uintptr_t) mangled_name_ptr);
    return v;
  }
  // Pro kontrolu jedinecnosti, pro derivace se musi kontrolovat podle jmena.
  struct NameList {
    struct element {
      std::string name;
      unsigned    order;
    };
    unsigned count;
    std::vector<element> list;
    NameList () {list.clear(); count = 10;};
    unsigned add (const std::string & s){
      element e = {s, count};
      unsigned result = count;
      list.push_back (e);
      count += 10;
      return result;
    };
    unsigned contains (const std::string & s) {
      for (auto i: list) {
        if (i.name == s) return i.order;
      }
      return 0;
    };
    
  };
  static NameList serialnumber;

  GINAC_IMPLEMENT_REGISTERED_CLASS_OPT (user_func, basic,
                                        print_func<print_context> (&user_func::do_print).
                                        print_func<print_latex> (&user_func::do_print_latex))

  user_func::user_func() : serial (0), name (""), TeX_name (""), derivate(), dlevel(0), dotnotation(false) {
    setflag (status_flags::evaluated | status_flags::expanded);
  }

  user_func::user_func (const std::string & initname, const symbol & d, const unsigned n, const bool dn) : 
    name (initname), TeX_name (initname), derivate(d), dlevel(n), dotnotation(dn) {
    unsigned k = serialnumber.contains (name);
    if (k) {
      serial = k + dlevel;
    } else {
      k = serialnumber.add(name);
      serial = k + dlevel;
    }
    // std::cout << "konstruktor " << name << ", dlevel = " << dlevel << ", serial = " << serial << std::endl;
    setflag (status_flags::evaluated | status_flags::expanded);
  }

  user_func::user_func (const std::string & initname, const std::string & texname, const symbol & d, const unsigned n, const bool dn) :
    name (initname), TeX_name (texname), derivate(d), dlevel(n), dotnotation(dn) {
    unsigned k = serialnumber.contains (name);
    if (k) {
      serial = k + dlevel;
    } else {
      k = serialnumber.add(name);
      serial = k + dlevel;
    }
    setflag (status_flags::evaluated | status_flags::expanded);
  }

  ex user_func::derivative (const symbol & s) const {
    // std::cout << __FUNCTION__ << " f = d" << get_name() << " / d" << s.get_name() << std::endl;
    if (s != derivate) return 0;
    const unsigned L = dlevel + 1;
    user_func r (name, TeX_name, derivate, L, dotnotation);
    return r;
  }

  std::string user_func::get_name() const {
    if (name.empty()) {
      name = "user_func" + std::to_string (serial);
    }
    const char * dtmp = derivate.get_name().c_str();
    const unsigned max = 256;
    char buf [max];
    if (dlevel) snprintf (buf, max, "D[%d]%s(%s)", dlevel, name.c_str(), dtmp);
    else        snprintf (buf, max, "%s(%s)",              name.c_str(), dtmp);
    return std::string(buf);
  }

  std::string user_func::get_TeX_name() const {
    if (TeX_name.empty()) {
      return std::string("none");
    }
    const char * dtmp = derivate.get_name().c_str();
    const unsigned max = 256;
    char buf [max];
    if (dotnotation) {
      if (dlevel) {
        snprintf (buf, max, "\\%.*sot{%s}(%s)", dlevel, "ddddddddddd", TeX_name.c_str(), dtmp);
      }
      else {
        snprintf (buf, max, "%s(%s)", TeX_name.c_str(), dtmp);
      }
    } else {
      switch (dlevel) {
        case 0:  snprintf (buf, max, "%s(%s)", TeX_name.c_str(), dtmp); break;
        case 1:  snprintf (buf, max, "\\frac{d%s(%s)}{d%s}", TeX_name.c_str(), dtmp, dtmp); break;
        default: snprintf (buf, max, "\\frac{d^{%d}%s(%s)}{d%s^{%d}}", dlevel, TeX_name.c_str(), dtmp, dtmp, dlevel); break;
      }
    }
  
    return std::string(buf);
  }

  void user_func::do_print (const print_context & c, unsigned level) const {
    c.s << get_name();
  }

  void user_func::do_print_latex (const print_latex & c, unsigned level) const {
    if (!TeX_name.empty())
      c.s << get_TeX_name();
    else if (!name.empty())
      c.s << "none";//get_default_TeX_name (name);
    else
      c.s << "user_func" << serial;
  }
  
  bool user_func::info (unsigned inf) const {
    switch (inf) {
    case info_flags::symbol:
    case info_flags::polynomial:
    case info_flags::integer_polynomial:
    case info_flags::cinteger_polynomial:
    case info_flags::rational_polynomial:
    case info_flags::crational_polynomial:
    case info_flags::rational_function:
    case info_flags::expanded:
      return true;
    case info_flags::real:
      return get_domain() == domain::real || get_domain() == domain::positive;
    case info_flags::positive:
    case info_flags::nonnegative:
      return get_domain() == domain::positive;
    case info_flags::has_indices:
      return false;
    }
    return inherited::info (inf);
  }
/*
  ex user_func::conjugate() const {
    return conjugate_function (*this).hold();
  }

  ex user_func::real_part() const {
    return real_part_function (*this).hold();
  }

  ex user_func::imag_part() const {
    return imag_part_function (*this).hold();
  }
*/
  bool user_func::is_polynomial (const ex & var) const {
    return true;
  }

  int user_func::compare_same_type (const basic & other) const {
    GINAC_ASSERT (is_a<user_func> (other));
    const user_func *o = static_cast<const user_func *> (&other);
    // std::cout << __FUNCTION__ << " f = " << get_name() << " == " << other << " serial: " << serial << " == " << o->serial << std::endl;
    if (serial==o->serial) return 0;
    return serial < o->serial ? -1 : 1;
  }

  bool user_func::is_equal_same_type (const basic & other) const {
    // std::cout << __FUNCTION__ << " f = " << get_name() << " == " << other << std::endl;
    GINAC_ASSERT (is_a<user_func> (other));
    const user_func *o = static_cast<const user_func *> (&other);
    return serial==o->serial;
  }

  unsigned user_func::calchash() const {
    unsigned seed = make_hash_seed (typeid (*this));
    hashvalue = golden_ratio_hash (seed ^ serial);
    setflag (status_flags::hash_calculated);
    return hashvalue;
  }

  GINAC_BIND_UNARCHIVER (user_func);

} // namespace GiNaC
