#include "otr.h"
#include "html.h"
#include "dfunc.h"
#include "equation.h"

static const char * flp = "<p class=\"formulaDsp\"> \\[ ";
static const char * fls = " \\]</p>";
/**********************************************************/
void MUD::print (ostream & outs) const {
  outs << flp << "g_{\\mu\\nu}  = " << DD << "\\quad ; \\quad g^{\\mu\\nu}  = " << UU << fls << endl;
}
void Ricci::print (ostream & outs) const {
  for (auto i : INDEXES) {
    for (auto j : INDEXES) {
      ex e = dd(i,j);
      if (e != 0) outs << flp << "R_{"<< i << j <<"} = " << e << fls << endl;
    }
  }
}
void Einstein::print (ostream & outs) const {
  g.print (outs);
  ex v = RS;
  v = v.subs(pow(cos(wild()), 2) == 1 - pow(sin(wild()), 2));
  v = v.normal();
  v = collect_common_factors(v);
  outs << flp << "R      = " << v << fls << endl;
  for (auto i : INDEXES) {
    ex e = dd(i,i);
    e = e.normal();
    e = e.subs(pow(cos(wild()), 2) == 1 - pow(sin(wild()), 2));
    e = e.simplify_indexed();
    if (i>0) {
      e = collect_common_factors(e.normal());
    }
    outs << flp << "G_{"<< i << i <<"} = " << e << fls << endl;
  }
}
/**********************************************************/
static const char * equations = " hustota: $ \\frac{\\dot{a}(t)^{2}}{a(t)^{2}} + \\frac{ c^{2} k}{a(t)^{2}} = \\frac{8 \\pi G}{3} \\rho $, "
"tlak: $ 2 \\frac{\\ddot{a}(t)}{a(t)} + \\frac {\\dot{a}(t)^{2}}{a(t)^{2}} + \\frac{c^{2} k}{a(t)^{2}} = - \\frac{8 \\pi G}{c^{2}}  p  $";

static const symbol c("c");

class TEM {
  const MUD g;
  // T je opravdu matice, tedy tenzor s jedním kovariantním a jedním kontravariantním indexem,
  matrix T;       // je to sice divné (ne moc), ale jinak to stejně nefunguje.
  ex     KA;
  public:
    TEM (matrix m) : g(m), T(4,4) {
      symbol  GE("G", "\\pi G");//, pi("pi");
      symbol  rho("rho"), p("p");
      KA = 8 * GE * pow(c,-4);
      ex E = -rho * pow(c,2);
      ex P = p;
      lst dg {E, P, P, P};
      init_diag (T, dg);
    }
    const ex dd (const unsigned mu, const unsigned nu) const {
      ex r = 0;
      for (auto alpha : INDEXES) {  // horní index přes metriku shodíme dolů
         r += g.dd(mu, alpha) * T(alpha, nu);
      }                             // to pak umožní vykrátit zbytečnosti
      r *= KA;
      r = r.simplify_indexed();     // a pro tlak dostaneme 3 stejné rovnice.
      return r;
    }
    void print (ostream & outs = cout) const {
      for (auto i : INDEXES) {
        ex e = dd(i,i);
        e = e.simplify_indexed();
        outs << flp << "T_{"<< i << i <<"} = " << e << fls << endl;
      }
    }
};
#define NOSUBS
//#undef  NOSUBS

int main() {
  ex T = -c*c;
#ifdef NOSUBS
  symbol K ("k");
  // obvykle používaná metrika na sféře S3
  symbol t ("t"), x ("r"), y ("Theta"), z ("Psi");
  user_func A("a", t);
  ex E = A*A;
  ex D = x*x*E;
  ex F = D * sin (y) * sin (y);
  E = E /  (1 - K*(x*x));
  // T = T * (A*A);      // konformní metrika
  lst dg {T, E, D, F};
#else
  symbol R ("R_0");
  // tato metrika pro kladné k je snad přirozenějsí, ale výsledek je stejný.
  symbol t ("t"), x ("chi"), y ("Theta"), z ("Psi");
  user_func A("a", t);
  ex E = A*A*R*R;
  ex D = E * sin(x) * sin(x);
  ex F = D * sin(y) * sin(y); 
  lst dg {T, E, D, F};
#endif
  vector<symbol> X  {t, x, y, z};
  matrix gdd (4,4);
  init_diag (gdd, dg);
  
  Einstein GG (gdd, X);
  // GG.print();
  cout << "count_dd = " << count_d << endl;
  cout << "count_uu = " << count_u << endl;
  
  TEM tem (gdd);
  // tem.print();
  
  filebuf file;
  file.open("fridman.html", ios::out);
  ostream os(&file);
  os << latex;
  os << prefix;
  os << "<p>Souřadnice : [$ ";
  for (auto n: X) os << n << " , ";
  os << "$]</p>" << endl;
  GG .print(os);
  tem.print(os);
  
  os << "<h2>Rovnice po automatické úpravě</h2>\n" << endl;
  for (auto i : INDEXES) {
    Equation eq (GG.dd(i,i), tem.dd(i,i));
#ifdef NOSUBS
    if (i != 0) eq.move (-(A*A));
#else
    if (i != 0) eq.move (-(A*A*R*R));
#endif
    else        eq.move (3);
    // eq.print();
    eq.print(os);
  }
  
  os << "<h2>" << equations << "</h2>\n" << endl;
  os << discus;
  os << suffix;
  file.close();
  
  return 0;
}
