#ifndef _HTML_H_
#define _HTML_H_

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern const char * const prefix;
extern const char * const suffix;
extern const char * const discus;

#ifdef __cplusplus
};
#endif // __cplusplus
#endif //  _HTML_H_