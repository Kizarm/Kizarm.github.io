#ifndef _OTR_H_
#define _OTR_H_

#include <vector>
#include <fstream>
#include <iostream>
#include <ginac/ginac.h>
#include <ginac/inifcns.h>

using namespace std;
using namespace GiNaC;

static const vector<unsigned> INDEXES = {0,1,2,3};

static matrix count_d (4,4), count_u (4,4);

static void init_diag (matrix & M, const lst & diag) {
  ex GD (diag_matrix(diag));
  unsigned i = 0;
  for (auto n : GD) {
    M(i/4,i%4) = n; i++;
  }
}
class MUD {
  matrix UU,DD;
  public:
    MUD (const matrix & M) {
      DD = M;
      UU = M.inverse();
    }
    MUD (const MUD & M) {
      DD = M.DD;
      UU = M.UU;
    }
    ex uu (const unsigned i, const unsigned j) const {
      if(UU(i,j) != 0) count_u (i,j) += 1;
      return UU(i,j);
    }
    ex dd (const unsigned i, const unsigned j) const {
      if(DD(i,j) != 0) count_d (i,j) += 1;
      return DD(i,j);
    }
    void print (ostream & outs = cout) const;
};
class GAMMA {
  const MUD g;
  const vector<symbol> x;
  public:
    GAMMA (const MUD & G, const vector<symbol> & X) : g(G), x(X) {};
    GAMMA (const GAMMA & G) : g(G.g), x(G.x) {}; 
    const ex udd(const unsigned gamma, const unsigned alpha, const unsigned beta) const {
      ex r = 0;
      for (auto ksi : INDEXES) {
        r += g.uu(gamma, ksi)/2 * (g.dd(ksi, alpha).diff(x[beta]) + g.dd(ksi, beta).diff(x[alpha]) - g.dd(alpha, beta).diff(x[ksi]));
      }
      return r;
    }
    const MUD & getG () const {return g;};
    void print (ostream & outs = cout) const {
      for (auto i : INDEXES) {
        for (auto j : INDEXES) {
          for (auto k : INDEXES) {
            ex e = udd(i,j,k);
            if (e != 0) outs << "Gamma["<< i << "," << j << "," << k <<"] = " << e << endl;
          }
        }
      }
    }
};
class Riemann {
  const GAMMA G;
  const vector<symbol> x;
  public:
    Riemann (const GAMMA & g, const vector<symbol> & X) : G(g), x(X) {};
    Riemann (const Riemann & R) : G(R.G), x(R.x) {};
    const ex uddd(const unsigned eta, const unsigned beta, const unsigned gamma, const unsigned delta) const {
      ex r = G.udd(eta, beta, delta).diff(x[gamma]) - G.udd(eta, beta, gamma).diff(x[delta]);
      for (auto xi : INDEXES)
          r += G.udd(xi, beta, delta) * G.udd(eta, xi, gamma) - G.udd(xi, beta, gamma) * G.udd(eta, xi, delta);
      return r;
    }
    const MUD & getG () const {return G.getG();};
    void print (ostream & outs = cout) const {
      for (auto i : INDEXES) {
        for (auto j : INDEXES) {
          for (auto k : INDEXES) {
            for (auto l : INDEXES) {
              ex e = uddd(i,j,k, l);
              if (e != 0) outs << "Riemann["<< i << "," << j << "," << k << "," << l <<"] = " << e << endl;
            }
          }
        }
      }
    }
};
class Ricci {
  const Riemann R;
  const vector<symbol> x;
  matrix RDD;   // optimalizace
  public:
    Ricci (const Riemann & r, const vector<symbol> & X) : R(r), x(X), RDD(4,4) {
      for (auto i: INDEXES) for (auto j: INDEXES) {
        RDD(i,j) = pdd (i,j);
      }
    };
    Ricci (const Ricci & r) : R(r.R), x(r.x), RDD(r.RDD) {};
    const ex dd(const unsigned mu, const unsigned nu) const {
      return RDD(mu,nu);
    }
    const ex ud(const unsigned mu, const unsigned nu) const {
      const MUD & g = R.getG();
      ex r = 0;
      for (auto lam : INDEXES) r += g.uu(mu, lam) * dd(lam, nu);
      return r;
    }
    const ex RS () const {
      ex r = 0;
      for (auto i : INDEXES) r += ud(i,i);
      r = r.simplify_indexed();
      /*
      ex nn = r.numer();
      ex dd = r.denom();
      nn = collect_common_factors(nn.normal());
      //nn = factor(expand(nn));
      dd = collect_common_factors(dd.normal());
      r = nn/dd;
      */
      r = collect_common_factors(r.normal());
      return r;
    }
    const MUD & getG () const {return R.getG();};
    void print (ostream & outs = cout) const;
  protected:
    const ex pdd(const unsigned mu, const unsigned nu) const {
      ex r = 0;
      for (auto lam : INDEXES) r += R.uddd(lam, mu, lam, nu);
      return r;
    }
};
class Einstein {
  const vector<symbol> X;
  const MUD            g;
  const Ricci          R;
  const ex             RS;
  public:
    Einstein (const matrix & m, const vector<symbol> & x) 
      : X(x), g(m), R(Ricci(Riemann(GAMMA(g,x),x),x)), RS(R.RS()) {};
    const ex dd (const unsigned mu, const unsigned nu) const {
      symbol lambda ("L", "\\Lambda");
      ex r = R.dd (mu, nu) - RS * g.dd(mu, nu) / 2;
      //r += lambda * g.dd (mu, nu);  // kosmologický člen
      return r;
    }
    void print (ostream & outs = cout) const;
};

#endif // _OTR_H_
