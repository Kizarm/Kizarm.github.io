#include <stdio.h>
#include <math.h>
#include "coeff.h"

/**
 * Příklad uvádí jak aproximovat funkci naměřenou v několika bodech (přesně).
 * 
 * Pokud máme velký počet měření s určitou nejistotou, pak je lépe použít
 * statistiku a nějakou metodu regrese. Zde je jiný přístup - měření je relativně
 * málo a považujeme je za přesná. Obvyklá metoda je dát tato měření do tabulky
 * a hodnoty mezi nimi, ty které v tabulce nejsou, se získají lineární interpolací.
 * 
 * To je zde ukázáno v části "Lineární aproximace". Protože v interpolaci je použito
 * dělení (nepředpokládají se ekvidistantní hodnoty v x), je lepší koeficienty
 * interpolace předpočítat - sice se zvětší tabulka, ale zase se zrychlí výpočet.
 * Zde je i tento předpočet.
 * 
 * V části "Kubická spline aproximace" je v podstatě to samé, ale místo prosté lineární
 * interpolace mezi měřeními je použita kubická spline interpolace. Protože výpočet
 * koeficientů zde již není triviální, je použita knihovna a výpočet je proveden
 * v jazyce python - cubic.py. Tento skript vygeneruje soubory coeff.c a coeff.h,
 * který obsahuje používané koeficienty - vlastní výpočet je pak už jednoduchý.
 * 
 * I když spočítat to bez knihovny není žádné drama - oproti lineární interpolaci (spojitost)
 * přibude jen podmínka hladkosti, tedy existence 2. derivace aproximující funkce
 * na celém definičním oboru. Prakticky to znamená, že 1. derivace musí navazovat,
 * takže ke dvěma podmínkám lineární aproximace v intervalu se přidají ještě dvě podmínky
 * pro 1. derivaci na začátku a konci intervalu - celkem 4 podmínky pak dají kubický
 * polynom. Takže pouhý požadavek hladkosti zvětší řád polynomu o dva.
 * 
 * Jako testovací funkce je použit prostý sinus. Na výsledných obrázcích je vidět
 * jak se zmenší chyba použitím lepší aproximace. Nárůst výpočetní složitosti
 * přitom není nijak dramatický.
 * 
 * Pozn.: Na konec měření je dobré přidat ještě jeden interval, třeba se stejnou hodnotou y,
 * protože se předpokládá nulová druhá derivace v koncových bodech a to není pravda. Takto
 * se to trochu srovná a výsledná chyba se zmenší.
 * 
 * */

/************************************* Plot ****************************************************/

static const char * plot_command =
  "set terminal postscript eps color size 8,10 font \",%d\"\n"
  "set output \'%s\'\n"
  "set grid\n"
  "set key box opaque left\n"
  "set xlabel \"x\"\n"
  "set ylabel \"y\"\n"
  "plot \'x.dat\' u 1:%d w l lw 2 t \'spline\',\\\n"
  "     \'x.dat\' u 1:%d w l lw 2 t \'linear\'\n";

static void plot (const unsigned a, const unsigned b, const char * name) {  
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  fprintf (cmd, plot_command, 24, name, a, b);
  fflush  (cmd);
  pclose  (cmd);
}

/*********************************** Lineární aproximace ***************************************/
static const unsigned range (const real x);
/// Koeficienty pro lineární aproximaci.
struct linear {
  real a,b;
};
//#define FINISHED
#ifndef FINISHED
/// budou dynamicky alokovány, je to jen ukázka
static linear * lin_coeff = nullptr;
/// Alokace a výpočet koeficientů.
static void compute_linear () {
  lin_coeff = new linear [intervals];
  for (unsigned n=0; n<intervals; n++) {
    linear & l = lin_coeff[n];
    // hodnota v počátečním bodě intervalu
    l.a = y_points[n];
    // derivace v tt. bodě - počítaná jako diference
    l.b = (y_points[n+1] - y_points[n]) / (x_points[n+1] - x_points[n]); 
  }
  // jen výpis, který je možno pak vyměnit za výpočet -> #define FINISHED
  fprintf(stdout, "static const linear lin_coeff[] = {\n");
  for (unsigned n=0; n<intervals; n++) {
    linear & l = lin_coeff[n];
    fprintf(stdout, "  {%+f,%+f},\n", l.a, l.b);
  }
  fprintf(stdout, "};\n");
}
static void destroy_linear () {
  delete [] lin_coeff;
}
#else
static const linear lin_coeff[] = {
  {+0.000000,+0.017255},
  {+0.258819,+0.016079},
  {+0.500000,+0.013807},
  {+0.707107,+0.010595},
  {+0.866025,+0.006660},
  {+0.965926,+0.002272},
  {+1.000000,-0.000500},
};
static void compute_linear () {};
static void destroy_linear () {};
#endif // FINISHED
/// Lineární funkce - polynom 1. řádu
static const real linear_poly (const linear & s, const real x) {
  return s.b * x  + s.a;
}
/// Interpolace v celém definičním oboru funkce
static const real interpolate_lin (const real x) {
  const unsigned n = range (x);                     // 1. určíme interval ve kterém budeme počítat
  const real     r = x - x_points [n];              // 2. souřadnice x v tomto intervalu
  const linear & s = lin_coeff    [n];              // 3. koeficienty polynomu v tomto intervalu
  //printf("%2d: %f, %f\n", n, x_points[n], r);
  return linear_poly (s, r);                        // 4. vlastní výpočet
}
/*********************************** Kubická spline aproximace *********************************/

/// Polynom 3. řádu
static const real cubic_poly (const spline & s, const real x) {
  return ((s.d * x + s.c) * x + s.b) * x  + s.a;
}
/// Interpolace v celém definičním oboru funkce
static const real interpolate_spline (const real x) {
  const unsigned n = range (x);                     // 1. určíme interval ve kterém budeme počítat
  const real     r = x - x_points [n];              // 2. souřadnice x v tomto intervalu
  const spline & s = cubic_coeff  [n];              // 3. koeficienty polynomu v tomto intervalu
  //printf("%2d: %f, %f\n", n, x_points[n], r);
  return cubic_poly (s, r);                         // 4. vlastní výpočet
}

/***********************************     Utility   *********************************************/

#if 0
static const unsigned range (const real x) {
  for (unsigned n=0; n<=intervals; n++) {
    if (x < x_points[n]) return n - 1;
  }
  return 0;
}
#else
/// Určení intervalu - pro větší tabulky je lepší bisekce.
static const unsigned range (const real x) {
  int l=0, r=intervals;
  while (l <= r) {
    const int s = (l + r) >> 1;
    //printf("find: %d\n", s);
    const real x0 = x_points[s];
    const real x1 = x_points[s + 1];
    if      (x <  x0) r = s - 1;
    else if (x >= x1) l = s + 1;
    else return s;
  }
  fprintf(stderr, "Value %f out of input interval [0,%d]\n", x, intervals);
  return 0;
}
#endif // 0
/// Originální funkce
static const real deg_sin (const real x) {
  const real arg = x * M_PI / 180.0;
  return sin (arg);
}

static void test () {
  compute_linear();
  FILE * out = fopen ("x.dat", "w");
  for (real x=0.0; x<=90.0; x += 1.0) {
    real y0 = interpolate_lin    (x);
    real y1 = interpolate_spline (x);
    real y2 = deg_sin            (x);
    fprintf(out, "%6.3f %f %f %f %+f %+f\n", x, y0, y1, y2, y2-y1, y2-y0);
  }
  fclose(out);
  destroy_linear();
}

int main (int argc, char * argv[]) {
  test();
  plot(3, 2, "img.eps");
  plot(5, 6, "err.eps");
  return 0;
}

