#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from scipy import interpolate

h_ctx = """#ifndef __COEFF_H
#define __COEFF_H

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
  
  typedef double real;
  struct spline {
    real a,b,c,d;
  };
  extern const struct spline cubic_coeff[];
  extern const real x_points[];
  extern const real y_points[];
  extern const unsigned intervals;

#ifdef __cplusplus
};
#endif //__cplusplus
#endif // __COEFF_H
"""

def gen_header (name):
  file = open (name + '.h', 'w')
  file.write(h_ctx)
  file.close()

def calculate (x, y, name):
  # calculate natural cubic spline polynomials
  cs = interpolate.CubicSpline(x,y,bc_type='natural')

  k = range (0, len(cs.c[0]))
  l = range (0, 4)

  mc = 'const struct spline cubic_coeff[] = {\n'

  for j in k:
    mc += '  {'
    for i in l: mc += '{0:+e}, '.format(cs.c.item(3-i,j))
    mc += '},\n'
  mc += '};\n'

  mx = 'const real x_points[] = {\n'
  for i in range (0, len(x)): mx += '{0:+f}, '.format(x[i])
  mx += '};\n'

  my = 'const real y_points[] = {\n'
  for i in range (0, len(y)): my += '{0:+f}, '.format(y[i])
  my += '};\n'

  print mx
  print my
  print mc
  file = open (name + '.c', 'w')
  file.write('#include "{0}"\n'.format(name + '.h'))
  file.write(mx)
  file.write(my)
  file.write(mc)
  file.write('const unsigned intervals = {0:d}u;\n'.format(len(cs.c[0])))
  file.close()

def m_sort (e):
  return e[0]
def array_meas (m):
  m.sort (key = m_sort)
  x = []
  y = []
  for n in m:
    x.append(n[0])
    y.append(n[1])
  x = np.array(x)
  y = np.array(y)
  return x,y

#####################################################################################################
# Naměřené hodnoty - x,y nemusí být seřazeny vzestupně, intervaly mezi měřeními mohou být různé.  ###
#####################################################################################################

meassure = [[30, 0.5],
            [45, 0.707106781],
            [60, 0.866025404],
            [75, 0.965925826],
            [15, 0.258819045],
            #[85, 0.996194698],
            [95, 0.9975], [90, 1], [0, 0]]   # Tady je to úmyslně přeházené

if  __name__ == '__main__':
  x, y = array_meas (meassure)
  name = 'coeff'
  calculate (x, y, name)
  gen_header(name)
