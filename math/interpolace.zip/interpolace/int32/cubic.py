#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from scipy import interpolate
import math

def gen_header (inter, name, lshf):
  h_ctx_b = """#ifndef __COEFF_H
#define __COEFF_H

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus  
  #include <stdint.h>
  
  struct spline {
    int32_t a,b,c,d;
  };
  extern const struct spline cubic_coeff[];
  extern const int32_t x_points[];
  extern const int32_t y_points[];
"""
  h_ctx_e = """#ifdef __cplusplus
};
#endif //__cplusplus
#endif // __COEFF_H
"""
  file = open (name + '.h', 'w')
  file.write(h_ctx_b)
  file.write('  static const unsigned intervals = {0:d}u;\n'.format(inter))
  file.write('  static const unsigned l_shift   = {0:d}u;\n'.format(lshf))
  file.write(h_ctx_e)
  file.close()

def calculate (x, y, name, lshf):
  # calculate natural cubic spline polynomials
  cs = interpolate.CubicSpline(x,y,bc_type='natural')

  k = range (0, len(cs.c[0]))
  l = range (0, 4)

  mc = 'const struct spline cubic_coeff[] = {\n'

  for j in k:
    mc += '  {'
    ec = 1.0
    for i in l:
      rk = cs.c.item(3-i,j)
      rk *= ec
      ec *= (1 << lshf)
      mc += '{0:+8d}, '.format(int(math.ceil(rk)))
    mc += '},\n'
  mc += '};\n'

  mx = 'const int32_t x_points[] = {\n'
  for i in range (0, len(x)): mx += '{0:+d}, '.format(x[i])
  mx += '};\n'

  my = 'const int32_t y_points[] = {\n'
  for i in range (0, len(y)): my += '{0:+d}, '.format(y[i])
  my += '};\n'

  print mx
  print my
  print mc
  file = open (name + '.c', 'w')
  file.write('#include "{0}"\n'.format(name + '.h'))
  file.write(mx)
  file.write(my)
  file.write(mc)
  file.close()
  return len(cs.c[0])

def m_sort (e):
  return e[0]
def array_meas (m):
  m.sort (key = m_sort)
  x = []
  y = []
  for n in m:
    x.append(n[0])
    y.append(n[1])
  x = np.array(x)
  y = np.array(y)
  return x,y

if  __name__ == '__main__':
  #####################################################################################################
  # Naměřené hodnoty - x,y nemusí být seřazeny vzestupně, intervaly mezi měřeními mohou být různé.  ###
  #####################################################################################################

  meassure = [[0,         0],
              [5000,   7765],
              [10000, 15000],
              [15000, 21214],
              [20000, 25981],
              [25000, 28978],
              [30000, 30000],
              [31666, 29920]]
  
  # Při celočíselném násobení imitujícím pevnou řádovou čárku je nutné upravit koeficienty posunem.
  # Tento parametr je společný pro skript i výpočet v C, hodnota může být
  # menší než 16, zmenší se tím přesnost ale zase se sníží riziko přetečení.
  # Větší než 16 může být jen pokud jsou násobená čísla dostatečně malá,
  # tedy výsledek násobení nesmí přesáhnout 2^31. V tt. případě je použitelný shift v intervalu <12,16>

  shift = 16

  x, y = array_meas (meassure)
  name = 'coeff'
  n = calculate (x, y, name, shift)
  gen_header    (n,    name, shift)
