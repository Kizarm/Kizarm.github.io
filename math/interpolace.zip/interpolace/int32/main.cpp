#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "coeff.h"

/**
 * Příklad uvádí jak aproximovat funkci naměřenou v několika bodech (přesně).
 * Zde je to počítáno v celých číslech (32-bit aritmetika), rozsah funkce
 * i argumentu však musí být menší než zhuba +/- 32000 (16. bit signed int).
 * Kubická interpolace je v tomto případě dost přesná - odchylky jsou +/- jednotky
 * i při malém počtu měření v tabulce (do 10).
 * 
 * Pokud máme velký počet měření s určitou nejistotou, pak je lépe použít
 * statistiku a nějakou metodu regrese. Zde je jiný přístup - měření je relativně
 * málo a považujeme je za přesná. Obvyklá metoda je dát tato měření do tabulky
 * a hodnoty mezi nimi, ty které v tabulce nejsou, se získají lineární interpolací.
 * 
 * To je zde ukázáno v části "Lineární aproximace". Protože v interpolaci je použito
 * dělení (nepředpokládají se ekvidistantní hodnoty v x), je lepší koeficienty
 * interpolace předpočítat - sice se zvětší tabulka, ale zase se zrychlí výpočet.
 * Zde je i tento předpočet.
 * 
 * V části "Kubická spline aproximace" je v podstatě to samé, ale místo prosté lineární
 * interpolace mezi měřeními je použita kubická spline interpolace. Protože výpočet
 * koeficientů zde již není triviální, je použita knihovna a výpočet je proveden
 * v jazyce python - cubic.py. Tento skript vygeneruje soubory coeff.c a coeff.h,
 * který obsahuje používané koeficienty - vlastní výpočet je pak už jednoduchý.
 * 
 * I když spočítat to bez knihovny není žádné drama - oproti lineární interpolaci (spojitost)
 * přibude jen podmínka hladkosti, tedy existence 2. derivace aproximující funkce
 * na celém definičním oboru. Prakticky to znamená, že 1. derivace musí navazovat,
 * takže ke dvěma podmínkám lineární aproximace v intervalu se přidají ještě dvě podmínky
 * pro 1. derivaci na začátku a konci intervalu - celkem 4 podmínky pak dají kubický
 * polynom. Takže pouhý požadavek hladkosti zvětší řád polynomu o dva.
 * 
 * Jako testovací funkce je použit prostý sinus. Na výsledných obrázcích je vidět
 * jak se zmenší chyba použitím lepší aproximace. Nárůst výpočetní složitosti
 * přitom není nijak dramatický.
 * 
 * Pozn.: Na konec měření je dobré přidat ještě jeden interval, třeba se stejnou hodnotou y,
 * protože se předpokládá nulová druhá derivace v koncových bodech a to není pravda. Takto
 * se to trochu srovná a výsledná chyba se zmenší.
 * 
 * */

static inline const int32_t imull (const int32_t a, const int32_t b) {
  return (a * b) >> l_shift;
}
/************************************* Plot ****************************************************/
static const char * plot_command =
  "set terminal postscript eps color size 8,10 font \",%d\"\n"
  "set output \'%s.eps\'\n"
  "set grid\n"
  "set key box opaque left\n"
  "set xlabel \"x\"\n"
  "set ylabel \"y\"\n"
  "plot \'x.dat\' u 1:%d w l lw 2 t \'spline\',\\\n"
  "     \'x.dat\' u 1:%d w l lw 2 t \'linear\'\n";

static void plot (const unsigned a, const unsigned b, const char * name) {  
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  fprintf (cmd, plot_command, 24, name, a, b);
  fflush  (cmd);
  pclose  (cmd);
}

/*********************************** Lineární aproximace ***************************************/
static const int range (const int32_t x);
/// Koeficienty pro lineární aproximaci.
struct linear {
  int32_t a,b;
};
static linear lin_coeff [intervals];
/// Výpočet koeficientů.
static void compute_linear () {
  for (unsigned n=0; n<intervals; n++) {
    linear & l = lin_coeff[n];
    // hodnota v počátečním bodě intervalu
    l.a = y_points[n];
    // derivace v tt. bodě - počítaná jako diference
    const double t = (double) (y_points[n+1] - y_points[n]) / (double) (x_points[n+1] - x_points[n]); 
    l.b = (int32_t) ceil (t * (double)(1 << l_shift)); 
  }
  // jen výpis, který je možno pak vyměnit za výpočet
  fprintf(stdout, "static const linear lin_coeff[] = {\n");
  for (unsigned n=0; n<intervals; n++) {
    linear & l = lin_coeff[n];
    fprintf(stdout, "  {%+d,%+d},\n", l.a, l.b);
  }
  fprintf(stdout, "};\n");
}
/// Lineární funkce - polynom 1. řádu
static inline const int32_t linear_poly (const linear & s, const int32_t x) {
  return imull (s.b, x) + s.a;
}
/// Interpolace v celém definičním oboru funkce
static const int32_t interpolate_linear (const int32_t x) {
  const unsigned n = range (x);                     // 1. určíme interval ve kterém budeme počítat
  const int32_t  r = x - x_points [n];              // 2. souřadnice x v tomto intervalu
  const linear & s = lin_coeff    [n];              // 3. koeficienty polynomu v tomto intervalu
  //printf("%2d: %d, %d\n", n, x_points[n], r);
  return linear_poly (s, r);                        // 4. vlastní výpočet
}
/*********************************** Kubická spline aproximace *********************************/

/// Polynom 3. řádu
static inline const int32_t cubics_poly (const spline & s, const int32_t x) {
  int32_t t = s.d;
  t = imull(t, x) + s.c;
  t = imull(t, x) + s.b;
  t = imull(t, x) + s.a;
  return t;
  
}
/// Interpolace v celém definičním oboru funkce
static const int32_t interpolate_cubics (const int32_t x) {
  const unsigned n = range (x);                     // 1. určíme interval ve kterém budeme počítat
  const int32_t  r = x - x_points [n];              // 2. souřadnice x v tomto intervalu
  const spline & s = cubic_coeff  [n];              // 3. koeficienty polynomu v tomto intervalu
  //printf("%2d: %d, %d\n", n, x_points[n], r);
  return cubics_poly (s, r);                        // 4. vlastní výpočet
}

/***********************************     Utility   *********************************************/

/// Určení intervalu - pro větší tabulky je lepší bisekce.
static const int range (const int32_t x) {
  int l=0, r=intervals;
  while (l <= r) {
    const int s = (l + r) >> 1;
    //printf("find: %d\n", s);
    const int32_t x0 = x_points[s];
    const int32_t x1 = x_points[s + 1];
    if      (x <  x0) r = s - 1;
    else if (x >= x1) l = s + 1;
    else return s;
  }
  fprintf(stderr, "Value %d out of input interval [0,%d]\n", x, intervals);
  return 0;
}
static const int coeff_max = 30000;
/// Originální funkce
static const int32_t deg_sin (const int32_t x) {
  const double arg = 0.5 * (double) x * M_PI / coeff_max;
  return (int) ceil (coeff_max * sin (arg));
}

static void test () {
  compute_linear();
  FILE * out = fopen ("x.dat", "w");
  for (int x=0; x<=coeff_max; x += 100) {
    int32_t y0 = interpolate_linear (x);
    int32_t y1 = interpolate_cubics (x);
    int32_t y2 = deg_sin            (x);
    fprintf(out, "%6d %5d %5d %5d %+5d %+5d\n", x, y0, y1, y2, y2-y1, y2-y0);
  }
  fclose(out);
}

int main (int argc, char * argv[]) {
  test();
  plot(3, 2, "img");
  plot(5, 6, "err");
  return 0;
}

