#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdint.h>
#include <termios.h>
#include "baselayer.h"
#include "calc.h"

class Console : public BaseLayer {
  int            fd;
  struct termios flags;
  public:
    Console();
    ~Console();
    uint32_t  Down   (const char * data, uint32_t len);
    bool loop ();
};

int main () {
  Console console;
  Calc    calc;
  calc += console;
  console.Up ("h", 1);
  while (console.loop());
  return 0;
}
/************************************************************************/
Console::Console() : BaseLayer() {
  fd = STDIN_FILENO;
  
  struct termios LineFlags;
  int attr = tcgetattr (fd, &LineFlags);
  if (attr) {
    return;
  }
  flags = LineFlags;
  // nastaveni komunikacnich parametru do struct termios
  LineFlags.c_iflag = IGNPAR;           // ignoruj chyby parity
  LineFlags.c_oflag = 0;                // normalni nastaveni
  LineFlags.c_cflag = CS8 | CREAD | CLOCAL; // 8-bit, povol prijem
  LineFlags.c_lflag = 0;                // Raw input bez echa
  LineFlags.c_cc [VMIN]  = 1;           // minimalni pocet znaku pro cteni
  LineFlags.c_cc [VTIME] = 0;           // timer nepouzit
  
  tcsetattr   (fd, TCSANOW, &LineFlags);
  fcntl       (fd, F_SETFL, 0);
  
}
Console::~Console() {
  tcsetattr   (fd, TCSANOW, &flags);
  fcntl       (fd, F_SETFL, 0);
}

uint32_t Console::Down (const char * data, uint32_t len) {
  uint32_t result = write (STDOUT_FILENO, data, len);
  return result;
}
bool Console::loop() {
  bool result = true;
  const int maxlen = 64;
  char buffer [maxlen];
  int readen = read (fd, buffer, maxlen);
  for (int n=0; n<readen; n++) {
    if (buffer[n] == '\x03') result = false;
    if (buffer[n] == '\r'  ) buffer[n] = '\n';
  }
  Up (buffer, readen);
  return result;
}
