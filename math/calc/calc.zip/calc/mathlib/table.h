#ifndef _TABLE_BIG_H_
#define _TABLE_BIG_H_
#include <stdint.h>
static const unsigned TabDimension = 16u;
static const unsigned TabDecZeros  = 20u;
extern const uint32_t table_high [TabDecZeros][TabDimension+1u];
extern const uint32_t table_low  [TabDecZeros][TabDimension+1u];
extern const uint32_t table_m_pi [TabDimension+1u];
extern const uint32_t table_r_pi [TabDimension+1u];
extern const uint32_t table_m_e  [TabDimension+1u];
extern const uint32_t table_r_e  [TabDimension+1u];

extern const uint32_t table_sq2  [TabDimension+1u];
extern const uint32_t table_ln2  [TabDimension+1u];
extern const uint32_t table_10i  [TabDimension+1u];
#endif //  _TABLE_BIG_H_
