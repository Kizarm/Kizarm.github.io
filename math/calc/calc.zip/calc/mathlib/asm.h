#ifndef ASMBIGNUM
#define ASMBIGNUM
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

  extern uint32_t AsmAdd (uint32_t * left, const uint32_t * right, uint32_t n, uint32_t carry);
  
#ifdef __cplusplus
};
#endif // __cplusplus

#endif // ASMBIGNUM
