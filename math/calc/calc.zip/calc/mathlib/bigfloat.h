#ifndef BIGFLOAT_H
#define BIGFLOAT_H
#ifdef HAVE_STDLIB
#include <stdio.h>
#endif
#include <stdint.h>
#ifdef __AVR__
#include <avr/pgmspace.h>
static const uint32_t ONE  = 1ul;
#else
static const uint32_t ONE  = 1u;
static inline uint32_t pgm_read_dword (const uint32_t * addr) {
  return * addr;
}
#endif // __AVR__
#ifdef PRECISION
static const unsigned BigDimension = PRECISION;
#else
static const unsigned BigDimension = 12u;
#endif // PRECISION
static const uint32_t BigOffsetExp = (ONE<<30);
static const unsigned MaxDecZeros  = 20u;      // maximalni dekadicky exponent je 2^MaxDecZeros

enum COMPARE {IS_LT=0, IS_EQ, IS_GT};

class BigFloat {
  union {
    struct {
      uint32_t e : 31;
      uint32_t s :  1;
    } s;
    uint32_t w;
  } u;
  uint32_t m [BigDimension];
  public:
    BigFloat () { clear (); u.s.e = BigOffsetExp; }
    BigFloat (const int32_t n)       {* this = n; }
#if __SIZEOF_DOUBLE__ == 8 && USE_DOUBLE
    BigFloat (const double n)        {* this = n; }
    BigFloat & operator = (const double n);
#endif
    BigFloat (const BigFloat & n)    {* this = n; }
    BigFloat (const uint32_t  *  array);
    BigFloat (const char * const array);
    BigFloat & operator = (const BigFloat & n);
    BigFloat & operator = (const int32_t n);
    BigFloat & operator+= (const BigFloat & n);
    BigFloat & operator+= (const int32_t n) {*this += BigFloat(n); return * this;}
    BigFloat & operator-= (const BigFloat & n);
    BigFloat & operator-= (const int32_t n) {*this -= BigFloat(n); return * this;}
    BigFloat & operator*= (const BigFloat & n);
    BigFloat & operator*= (const int32_t n) {*this *= BigFloat(n); return * this;}
    BigFloat & operator/= (const BigFloat & n);
    BigFloat & operator/= (const int32_t n) {*this /= BigFloat(n); return * this;}
    
    const BigFloat operator+ (const BigFloat & n) const {
      BigFloat t(*this); t += n; return t;
    }
    const BigFloat operator- (const BigFloat & n) const {
      BigFloat t(*this); t -= n; return t;
    }
    const BigFloat operator* (const BigFloat & n) const {
      BigFloat t(*this); t *= n; return t;
    }
    const BigFloat operator/ (const BigFloat & n) const {
      BigFloat t(*this); t /= n; return t;
    }
    // porovnávat float na rovnost je asi dost blbost
    const bool operator== (const BigFloat & n) const {
      return compare (n) == IS_EQ ? true : false;
    }
    const bool operator!= (const BigFloat & n) const {
      return compare (n) != IS_EQ ? true : false;
    }
    const bool operator<= (const BigFloat & n) const {
      return compare (n) <= IS_EQ ? true : false;
    }
    const bool operator>  (const BigFloat & n) const {
      return compare (n) >  IS_EQ ? true : false;
    }
    const bool operator>= (const BigFloat & n) const {
      return compare (n) >= IS_EQ ? true : false;
    }
    const bool operator<  (const BigFloat & n) const {
      return compare (n) <  IS_EQ ? true : false;
    }
    BigFloat         operator-   () const { BigFloat t(*this); t.u.s.s ^= 1u; return t; }
    const BigFloat & operator+   () const { return * this; }
    
    BigFloat mul_pow_two (const int no) const { BigFloat t(*this); t.u.s.e += no; return t;  }
    BigFloat abs         () const { BigFloat t(*this); t.u.s.s  = 0u; return t; }
    bool     signbit     () const { return u.s.s ? true : false; }
    int32_t  bin_exponent() const { return u.s.e - BigOffsetExp; }
    bool     separe      (BigFloat & c, BigFloat & d) const;    // c ~ trunc (), d je desetinna cast
    BigFloat round       (const unsigned num = 0)     const;
    bool     is_small    () const; // pouze pro testy v iteraci, kde se zacina cislem kolem 1.0
    uint32_t to_u32      () const; // pouze mala kladna cisla
    unsigned to_string   (char * const str, const unsigned max) const;
    
#ifdef HAVE_STDLIB
    void     tracen  (const char * dsc = nullptr) const;
    void     print   () const;
    void     row     (FILE * out) const;
#endif // HAVE_STDLIB
  protected:
    void     add (const BigFloat & right);
    void     sub (const BigFloat & right);
    void     mul (const BigFloat & right);
    void     div (const BigFloat & right);
    
    void     clear   (const bool mantisa_only = false);
    unsigned clz     () const;
    void     norm    (void);
    void     eque    (BigFloat & right);
    bool     bit_at  (const unsigned pos) const;
    void     set_at  (const unsigned pos, const bool b = true);
    bool     is_zero () const;
    int      decimals();
    COMPARE  compare (const BigFloat & n) const;
  //private:
};

#endif // BIGFLOAT_H
