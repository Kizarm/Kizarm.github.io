#include "asm.h"

uint32_t AsmAdd (uint32_t * left, const uint32_t * right, uint32_t n, uint32_t carry) {
  const uint32_t C = 1u << 29;
  if (carry) carry = C;
  else       carry = 0u;
  asm volatile (
  "lsl  %3,%3,#2\n\t"       // určení počtu cyklů
  "mov  r3,#0\n\t"          // počáteční ofset
  "mov  r6,%4\n"            // a příznaky
  "loop_0:\n\t"
  "ldr  r4,[%1,r3]\n\t"     // levý operand
  "ldr  r5,[%2,r3]\n\t"     // pravý operand
  "msr  APSR_nzcvq,r6\n\t"    // obnov příznaky
  "adcs r4,r4,r5\n\t"         // sečti spolu s přenosem C
  "mrs  r6,APSR\n\t"          // a schovej příznaky
  "str  r4,[%1,r3]\n\t"     // výsledek ulož zpět
  "add  r3,r3,#4\n\t"       // zvyš ofset
  "cmp  r3,%3\n\t"          // jsme na konci ?
  "bne  loop_0\n\t"         // ne, opakuj
  "mov  %0,r6\n\t"          // vrať flagy
  :"=&r"(carry) : "r"(left), "r"(right), "r"(n), "r" (carry) : "r3","r4","r5","r6");
  if (carry & C) return 1u; // pokud je C nastaven, vrať 1
  else           return 0u; //                  ne, vrať 0
}
#if __ARM_ARCH == 7
uint32_t AsmMul (uint32_t * left, const uint32_t right, const uint32_t dim) {
  uint32_t carry;
  asm volatile (
  "lsl  %3,%3,#2\n\t"       // určení počtu cyklů
  "mov  %0,#0\n\t"
  "mov  r5,#0\n\t"          // počáteční ofset
  "mov  r6,#0\n"            // a příznaky
  "loop_1:\n\t"
  "ldr  r4,[%1,r5]\n\t"     // levý operand
  "umull  r3,r4,r4,%2\n\t"
  "msr  APSR_nzcvq,r6\n\t"    // obnov příznaky
  "adcs r3,r3,%0\n\t"         // sečti spolu s přenosem C
  "mrs  r6,APSR\n\t"          // a schovej příznaky
  "mov  %0,r4\n\t"          // shovej novy  prenos do dalsiho kola
  "str  r3,[%1,r5]\n\t"     // výsledek ulož zpět
  "add  r5,r5,#4\n\t"       // zvyš ofset
  "cmp  r5,%3\n\t"          // jsme na konci ?
  "bne  loop_1\n\t"         // ne, opakuj
  "msr  APSR_nzcvq,r6\n\t"    // obnov příznaky
  "mov  r5,#0\n\t"
  "adcs %0,r5\n\t"
    :"=&r" (carry)
    :"r" (left), "r" (right), "r" (dim)
    : "r3","r4","r5","r6"
  );
  return carry;
}
#else
#if ASM_MUL
#error "NOT USE ASM_MUL"
#endif //ASM_MUL
#endif