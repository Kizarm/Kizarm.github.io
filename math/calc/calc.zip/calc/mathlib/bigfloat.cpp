#include "asm.h"
#include "bigfloat.h"

#ifdef HAVE_STDLIB
#include <assert.h>
#else
#define assert(p) (void)(p)
#endif
#ifdef GEN_TABLE
const uint32_t table_high [][1] = {};
const uint32_t table_low  [][1] = {};
#else
#include "table.h"
static_assert (BigDimension <= TabDimension, "generate large table (BigDimension)");
static_assert (MaxDecZeros  <= TabDecZeros , "generate large table (MaxDecZeros)");
#endif
#ifdef HAVE_STDLIB
#define debug(...)
//#define debug printf
#else
#define debug(...)
#endif
#ifdef __AVR__
static unsigned wrap_clz (const uint32_t a) {
  unsigned n = 0u, k=31u;
  do {
    if ((ONE << k) & a) break;
    k -= 1u;
    n += 1u;
  } while (k);
  return n;
}
#else
static inline unsigned wrap_clz (const uint32_t a) {
  return __builtin_clz (a);
}
#endif // __AVR__
static const char * decimal_string = "0123456789";
static unsigned exp_to_dec (char * const ptr, int num) {
  unsigned res = 0;
  ptr [res++] = 'E';
  if (num < 0) { ptr[res++] = '-'; num = - num; }
  else         { ptr[res++] = '+';              }
  int k = (res - 1) + 6;
  while (--k) {
    const int z = num % 10;
    ptr [k+1]   = decimal_string [z];
    res += 1;
    num /= 10;
  }
  return res;
}
static void negation  (uint32_t * const m, const unsigned len) {
  for (unsigned n=0; n<len; n++) m[n] = ~ m[n];
}
static void shift_left  (uint32_t * const m, const unsigned len, const unsigned bits) {
  const unsigned int c = bits >> 5;
  const unsigned int b = bits & 0x1F;
  const unsigned int d = 32 - b;
  unsigned int i = len;
  //printf("shl : %d, c=%d,b=%d,d=%d\n", bits, c, b, d);
  if (!b) {
    while (i--) {
      const int l = i - c;
      uint32_t  t;
      if (l>=0) t = m[l];
      else      t = 0u;
      m [i] = t;
    }
    return;
  }
  while (i--) {
    uint32_t r;
    const int l = i - c;
    const int k = l - 1;
    if (k>=0) r = m[k] >> (d);
    else      r = 0u;
    uint32_t t;
    if (l>=0) t = (m[l] << b);
    else      t = 0u;
    m [i] = t | r;
    //printf ("i=%d,l=%2d,k=%2d, r=0x%08X | 0x%08X\n", i,l,k,r,t);
  }
}
static void shift_right (uint32_t * const m, const unsigned len, const unsigned bits) {
  const unsigned int c = bits >> 5;
  const unsigned int b = bits & 0x1F;
  const unsigned int d = 32 - b;
  unsigned int i = 0;
  //printf("shr : %d, c=%d,b=%d,d=%d\n", bits, c, b, d);
  const int mm = (int) len;
  if (!b) {
    while (i < len) {
      const int l = i + c;
      uint32_t  t;
      if (l<mm) t = m[l];
      else      t = 0u;
      m [i] = t;
      i += 1;
    }
    return;
  }
  while (i < len) {
    uint32_t r;
    const int l = i + c;
    const int k = l + 1;
    if (k<mm) r = m[k] << d;
    else      r = 0u;
    uint32_t t;
    if (l<mm) t = (m[l] >> b);
    else    t = 0u;
    m [i] = t | r;
    //printf ("i=%d,l=%2d,k=%2d, r=0x%08X | 0x%08X\n", i,l,k,r,t);
    i += 1;
  }
}
static inline void shift (uint32_t * const m, const unsigned len, const int offset) {
  if (!offset) return;
  if (offset > 0) return shift_left  (m, len, +offset);
  if (offset < 0) return shift_right (m, len, -offset);
}
static inline void shift_div (uint32_t * const m, const unsigned len) {
  unsigned i = 0;
  while (i < len) {
    const unsigned k = i + 1;
    uint32_t r;
    if (k<len) r = m[k] << 31;
    else       r = 0x80000000u;
    uint32_t t = m[i] >> 1;
    m [i] = t | r;
    i += 1;
  }
}
/*
static void print_buf (uint32_t * const m, const unsigned len) {
  unsigned n = len;
  while (n--) printf ("%08lX ", m[n]);
  printf("\n");
}
void shift_test () {        // passed
  const unsigned max = 5;
  uint32_t buf [max];
  for (unsigned i=0; i<max; i++) {
    if (i<2) buf[i] = 0x55555555;
    else     buf[i] = 0;
  }
  const int n = 64;
  print_buf (buf, max);
  shift (buf, max, +n);
  print_buf (buf, max);
  shift (buf, max, -n);
  print_buf (buf, max);
}
*/
/********************************************************************/
BigFloat::BigFloat (const uint32_t * array) {
  unsigned k=0;
  u.w = pgm_read_dword(&array[k]);
  k = BigDimension;
  for (unsigned i=0; i<BigDimension; i++) m [i] = pgm_read_dword(&array[k--]);
}
BigFloat::BigFloat (const char * const array) {
  clear ();
  u.s.e = BigOffsetExp;
  unsigned n = 0;
  int  exp  = 0, pdp = 0;
  bool pdpc = false;
  bool mantisa = true, signm = false, signe = false;
  for (;;) {
    const char c = array [n++];
    if (c == '\0') break;
    if (c == '-') {
      if (mantisa) {
        signm = true;
      } else {
        signe = true;
      }
    } else if (c == '+') {
      // do nothing
    } else if (c == '.') {
      pdpc = true;
    } else if ((c == 'e') or (c == 'E')) {
      pdpc = false;
      mantisa = false;
    } else {
      const int res = c - '0';
      if (res < 0) continue;
      if (res > 9) continue;
      if (mantisa) {
        mul ((int32_t)10);
        add ((int32_t)res);
        if (pdpc) pdp += 1;
      } else {
        exp *= 10;
        exp += res;
      }
    }
  }
  if (signm) u.s.s = 1u;
  if (signe) exp = - exp;
  //printf ("(%d) exp = %d, pdp = %d\n", (int)signe, exp, pdp);
  exp -= pdp;
  if (exp > 0) {
    const uint32_t mask = + exp;
    for (unsigned k=0; k<MaxDecZeros; k++) {
      if (mask & (1u << k)) {
        BigFloat x (table_high [k]);
        mul (x);
      }
    }
  }
  if (exp < 0) {
    const uint32_t mask = - exp;
    for (unsigned k=0; k<MaxDecZeros; k++) {
      if (mask & (1u << k)) {
        BigFloat x (table_low [k]);
        mul (x);
      }
    }
  }
}

/********************************************************************/
BigFloat & BigFloat::operator= (const BigFloat & n) {
  u.w = n.u.w;
  for (unsigned i=0; i<BigDimension; i++) m [i] = n.m [i];
  return * this;
}
BigFloat & BigFloat::operator= (const int32_t n) {
  int32_t k = n;
  clear ();
  if (!k) {
    u.s.e = BigOffsetExp;
    return * this;
  }
  if (k < 0) {
    u.s.s = 1;
    k =-n;
  } 
  m[0] = static_cast<uint32_t> (k);
  u.s.e  = BigOffsetExp + (BigDimension << 5);
  norm ();
  return * this;
}
#if __SIZEOF_DOUBLE__ == 8 && USE_DOUBLE
union double_u32 {
  struct {
    uint32_t m0 : 32;
    uint32_t m1 : 20;
    uint32_t e  : 11;
    uint32_t s  :  1;
  } s;
  uint32_t u[2];
  double   d;
};
BigFloat & BigFloat::operator= (const double n) {
  debug("call: \"%s\"\n", __FUNCTION__);
  double_u32 du; du.d = n;
  //debug("(%zd) parameter = %f, %08X-%08X\n", sizeof(du), n, du.u[1], du.u[0]);
  //debug("s=%d, exp=%d, m=%05X-%08X\n", du.s.s, du.s.e - 1023, du.s.m1, du.s.m0);
  clear();
  m[0] = du.s.m0;
  m[1] = du.s.m1;
  m[1]|= (1u << 20);
  shift_left (m, BigDimension, (BigDimension << 5) - 53u);
  u.s.s = du.s.s;
  u.s.e = BigOffsetExp + du.s.e - 1022u;
  return * this;
}
#endif
/********************************************************************/
BigFloat& BigFloat::operator+= (const BigFloat& n) {
  debug("call: \"%s\"\n", __FUNCTION__);
  if (n.is_zero()) return * this;
  BigFloat t (n);     // local copy
  if (u.s.s) {
    u.s.s = 0u;
    if (t.u.s.s) {
      t.u.s.s = 0u;
      add (t);        // - -
      u.s.s ^= 1u;
    } else   {
      t.sub (*this);  // - +
      *this = t;
    }
  } else {
    if (t.u.s.s) {
      t.u.s.s = 0u;
      sub (t);        // + -
    } else   {
      add (t);        // + +
    }
  }
  return * this;
}
BigFloat& BigFloat::operator-= (const BigFloat& n) {
  debug("call: \"%s\"\n", __FUNCTION__);
  if (n.is_zero()) return * this;
  BigFloat t (n);     // local copy
  if (u.s.s) {
    u.s.s = 0u;
    if (t.u.s.s) {
      t.u.s.s = 0u;
      sub (t);        // - -
    } else   {
      t.add (*this);  // - +
      *this = t;
    }
    u.s.s ^= 1u;
  } else {
    if (t.u.s.s) {
      t.u.s.s = 0u;
      add (t);        // + -
    } else   {
      sub (t);        // + +
    }
  }
  return * this;
}
BigFloat& BigFloat::operator*= (const BigFloat& n) {
  mul (n);
  return * this;
}
BigFloat& BigFloat::operator/= (const BigFloat& n) {
  div (n);
  return * this;
}

/********************************************************************/
void BigFloat::clear (const bool mantisa_only) {
  if (!mantisa_only) u.w = 0u;
  for (unsigned i=0; i<BigDimension; i++) m [i] = 0u;
}
void BigFloat::norm (void) {
  if (is_zero()) {
    u.s.e = BigOffsetExp;
    u.s.s = 0u;
    return;
  }
  unsigned un = clz ();
  if (!un) return;
  shift_left (m, BigDimension, un);
  u.s.e -= un;
}
unsigned int BigFloat::clz (void) const {
  unsigned int res = 0;
  unsigned int i   = BigDimension;
  while (i--) {
    if (!m[i]) res += 32;
    else {
      res += wrap_clz (m[i]);
      break;
    }
  }
  return res;
}
void BigFloat::eque (BigFloat & right) {
  if (u.s.e > right.u.s.e) {
    const unsigned b = u.s.e - right.u.s.e;
    shift_right (right.m, BigDimension, b);
    right.u.s.e = u.s.e;
  }
  if (right.u.s.e > u.s.e) {
    const unsigned b = right.u.s.e - u.s.e;
    shift_right (m, BigDimension, b);
    u.s.e = right.u.s.e;
  }
}

void BigFloat::add (const BigFloat & right) {
  assert ((u.s.s == 0u) and (right.u.s.s == 0));
  debug("call: \"%s\"\n", __FUNCTION__);
  BigFloat cp (right);
  eque (cp);
  const unsigned b = AsmAdd (m, cp.m, BigDimension, 0u);
  if (b) {
    shift_right (m, BigDimension, 1);
    m[BigDimension-1] |= (ONE<<31);
    u.s.e += 1;
  }
  norm();
}
void BigFloat::sub (const BigFloat& right) {
  assert ((u.s.s == 0u) and (right.u.s.s == 0));
  debug("call: \"%s\"\n", __FUNCTION__);
  BigFloat cp (right);
  eque (cp);
  negation (cp.m, BigDimension);
  const uint32_t b = AsmAdd (m, cp.m, BigDimension, 1u);
  if (!b) { // vysledek je zaporny
    u.s.s = 1;
    BigFloat t0;
    negation (m, BigDimension);
    AsmAdd (m, t0.m, BigDimension, 1u);
  }
  norm();
}
bool BigFloat::bit_at (const unsigned int pos) const {
  const unsigned c = pos >> 5;
  const unsigned b = pos & 0x1F;
  const uint32_t r = m [c] & (1lu << b);
  return r ? true : false;
}
void BigFloat::set_at (const unsigned int pos, const bool value) {
  const unsigned c = pos >> 5;
  const unsigned b = pos & 0x1F;
  if (value) m[c] |=  (1lu << b);
  else       m[c] &= ~(1lu << b);
}
bool BigFloat::is_zero () const {
  for (unsigned n=0; n<BigDimension; n++) {
    if (m[n]) return false;
  }
  return true;
}
#if ASM_MUL
extern "C" uint32_t AsmMul (uint32_t * left, const uint32_t right, const uint32_t dim);
static void prepare_op (uint32_t * dst, const uint32_t * src, const unsigned offset) {
  const unsigned dm = BigDimension << 1;
  for (unsigned n=0; n<dm; n++) dst [n] = 0u;
  for (unsigned n=0; n<BigDimension; n++) {
    dst [n + offset] = src [n];
  }
}
/* Tohle je trochu rychlejší, ale nestojí to za tu práci */
void BigFloat::mul (const BigFloat & right) {
  if (is_zero()) return;
  u.s.e += right.u.s.e - BigOffsetExp;
  u.s.s ^= right.u.s.s;
  const unsigned dm = BigDimension << 1;
  uint32_t td[dm], ts[dm];
  for (unsigned n=0; n<dm; n++) {
    td[n] = 0u;
  }
  for (unsigned n=0; n<BigDimension; n++) {
    prepare_op (ts, right.m, n);
    const uint32_t o = AsmMul (ts + n, m[n], BigDimension);
    ts [BigDimension + n] = o;
    const uint32_t v = AsmAdd (td, ts, dm, 0u);
    assert (v == 0u);
  }
  
  for (unsigned n=0; n<BigDimension; n++) {
    m[n] = td [n + BigDimension];
  }
  norm();
}
/* timhle se nic neusetri 
void BigFloat::div (const BigFloat & right) {
  assert (!right.is_zero());
  if (is_zero()) return;
  debug("call: \"%s\"\n", __FUNCTION__);
  const unsigned rexp = right.u.s.e - BigOffsetExp;
  // Newtonova metoda
  const BigFloat one (1);
  BigFloat xn (one.mul_pow_two(-rexp));
  for (unsigned n=0; n<30; n++) {
    const BigFloat d = one - right * xn;
    if (d.is_small()) break;
    xn += xn * d;
    if (d.is_small()) break;
  }
  mul (xn);
}
*/
#else
void BigFloat::mul (const BigFloat & right) {
  if (is_zero()) return;
  u.s.e += right.u.s.e - BigOffsetExp;
  u.s.s ^= right.u.s.s;
  const unsigned dm = BigDimension << 1;
  uint32_t td[dm], ts[dm];
  for (unsigned n=0; n<dm; n++) {
    td[n] = 0u; ts[n] = 0u;
  }
  for (unsigned n=0; n<BigDimension; n++) {
    const uint32_t t = right.m[n];
    ts[n] = t;
  }
  const unsigned cycles = BigDimension << 5;
  for (unsigned n=0; n<cycles; n++) {
    if (bit_at(n)) {
      uint32_t r = AsmAdd (td, ts, dm, 0u);
      //print_buf (td, dm);
      assert (r == 0u);
    }
    shift_left (ts, dm, 1);
  }
  //print_buf (td, dm);
  for (unsigned n=0; n<BigDimension; n++) {
    m[n] = td [n + BigDimension];
  }
  norm();
}
#endif // ASM_MUL
void BigFloat::div (const BigFloat& right) {
  assert (!right.is_zero());
  if (is_zero()) return;
  debug("call: \"%s\"\n", __FUNCTION__);
  u.s.e -= right.u.s.e - BigOffsetExp;
  u.s.s ^= right.u.s.s;

  const unsigned dm = BigDimension << 1;
  uint32_t tt[dm], td[dm], ts[dm];
  for (unsigned n=0; n<dm; n++) {
    td[n] = 0u; ts[n] = ~0u;
  }
  for (unsigned n=0; n<BigDimension; n++) {
    ts[BigDimension + n] = ~right.m[n]; td[BigDimension + n] = m[n];
  }
  clear (true);
  const unsigned cycles = BigDimension << 5;
  for (unsigned n=0; n<cycles; n++) {
    for (unsigned k=0; k<dm; k++) tt [k] = td [k];    // local copy
    //print_buf (td, dm);
    //print_buf (ts, dm);
    uint32_t r = AsmAdd (td, ts, dm, 1u);
    //printf("%3d div : carry=%d\n", n, r);
    if (r == 0) {
      for (unsigned k=0; k<dm; k++) td [k] = tt [k];  // restore
    } else {
      set_at (cycles - (n + 1));
    }
    shift_div (ts, dm);
  }
  u.s.e += 1u; // ???
  norm();
  //print();
}
COMPARE BigFloat::compare (const BigFloat & n) const {
  BigFloat a (*this), b (n);
  a.norm(); b.norm();
  if (!a.u.s.s and  b.u.s.s) {return IS_GT;}  // +a -b
  if ( a.u.s.s and !b.u.s.s) {return IS_LT;}  // -a +b
  if (!a.u.s.s and !b.u.s.s) {                // +a +b
    int32_t k = a.u.s.e - b.u.s.e;
    const int32_t l = (BigDimension << 5) - 32u;
    if (k > +l) {return IS_GT;}
    if (k < -l) {return IS_LT;}
    a -= b;
    if (a.is_zero()) {return IS_EQ;}
    if (a.u.s.s)     {return IS_LT;}
    else             {return IS_GT;}
  }
  if ( a.u.s.s and  b.u.s.s) {                // -a -b
    int32_t k = a.u.s.e - b.u.s.e;
    const int32_t l = (BigDimension << 5) - 32u;
    if (k > +l) {return IS_LT;}
    if (k < -l) {return IS_GT;}
    a -= b;
    if (a.is_zero()) {return IS_EQ;}
    if (a.u.s.s)     {return IS_LT;}
    else             {return IS_GT;}
  }
  return IS_EQ;
}

bool BigFloat::is_small () const {
  int e = BigOffsetExp - u.s.e;
  if (e >= (int) (BigDimension << 5) - 2) return true;
  return false;
}
uint32_t BigFloat::to_u32() const {
  BigFloat t (*this);
  int texp = t.u.s.e - BigOffsetExp;
  if (texp <= 0)       return  0u;
  if (texp > (1 << 5)) return ~0u;
  shift_right (t.m, BigDimension, (BigDimension << 5) - texp);
  return t.m [0];
}
unsigned int BigFloat::to_string (char * const str, const unsigned int max) const {
  const unsigned mchars = ((BigDimension * 2466u) >> 8) - 1u;
  unsigned  res = 0u;
  if (max < mchars + 12u) {     // input is short
    str [res] = '\0';
    return res;
  }
  if (is_zero()) {
    str [res++] = '0';
    str [res]   = '\0';
    return res;
  }
  BigFloat cp (*this);
  do { // hack dame sem - kduz to vyjde vetsi, vadi to mene
    BigFloat z;
    z.m[0] = 0x60u;  // nejnizsi hexadecimalni cislice
    if  (AsmAdd (cp.m, z.m, BigDimension, 0u)) {
      shift_right (cp.m, BigDimension, 1);
      cp.m[BigDimension-1] |= (ONE<<31);
      cp.u.s.e += 1;
    }
    cp.norm();
  } while (false);
  if (cp.u.s.s) str [res++] = '-';
  else          str [res++] = '+';
  cp.u.s.s = 0;
  const int dec = cp.decimals();
  const bool format = ((dec > 0) and (dec < (int) mchars)) ? false : true;
  
  const uint32_t num = 10u;
  const unsigned dm  = BigDimension + 1u;
  const unsigned cycles = 32u - wrap_clz (num);
  uint32_t td[dm], ts[dm];
  for (unsigned n=0; n<dm; n++) {
    td[n] = 0u; ts[n] = 0u;
  }
  for (unsigned n=0; n<BigDimension; n++) td [n] = cp.m [n];
  /*
  if (cp.u.s.e > BigOffsetExp) {
    cp.print ();
  }
  */
  assert (cp.u.s.e <= BigOffsetExp);
  shift (td, dm, cp.u.s.e - BigOffsetExp);
  
  for (unsigned k=0; k<mchars; k++) {
    for (unsigned n=0; n<BigDimension; n++) ts [n] = td [n];
    ts [BigDimension] = 0u;
    for (unsigned n=0; n<dm;           n++) td [n] = 0u;
    
    for (unsigned n=0; n<cycles; n++) {
      if (1u & (num >> n)) {
        uint32_t r = AsmAdd (td, ts, dm, 0u);
        assert (r == 0u);
      }
      shift_left (ts, dm, 1u);
    }
    uint32_t top = td [BigDimension];
    //printf("top = %X\n", top);
    str [res++] = decimal_string [top];
    if (format) {
      if (res == 2) str [res++] = '.';
    } else {
      if ((int) res == dec + 1) str [res++] = '.';
    }
  }
  
  if (format) res += exp_to_dec (str + res, dec - 1);
  str [res] = '\0';
  return res;
}
int BigFloat::decimals() { // jen kladna cisla
  //print();
  assert (u.s.s == 0u);
  uint32_t exp = 0u;
  int k = MaxDecZeros, result;
  if        (u.s.e < BigOffsetExp) {  // low
    while (k--) {
      if (*this < BigFloat (table_low [k])) {
        mul (BigFloat (table_high [k]));
        exp |= (ONE << k);
      }
    }
    result = - exp;
  } else if (u.s.e > BigOffsetExp) {  // high
    while (k--) {
      if (*this >= BigFloat (table_high [k])) {
        mul (BigFloat (table_low [k]));
        exp |= (ONE << k);
      }
    }
    if (u.s.e > BigOffsetExp) {
      mul (BigFloat(table_low[0]));
      exp += 1;
    }
    result = + exp;
  } else {
    return 0u;
  }
  //print();
  //printf ("result = %d\r\n", result);
  return result;
}
bool BigFloat::separe (BigFloat & c, BigFloat & d) const {
  if (u.s.e > BigOffsetExp) {
    c = * this; d = * this;
    const unsigned shl = u.s.e - BigOffsetExp;
    shift_left  (d.m, BigDimension, shl);
    d.u.s.e -= shl;
    d.norm();
    const unsigned shr = (BigDimension << 5) - shl;
    shift_right (c.m, BigDimension, shr);
    c.u.s.e += shr;
    c.norm();
    return true;
  } else
    return false;
}
BigFloat BigFloat::round (const unsigned int num) const {
  BigFloat t (*this);
  for (unsigned n=0; n<MaxDecZeros; n++) {
    if ((num & (1u << n))) t.mul (table_high [n]);
  }
  if (t.u.s.e > BigOffsetExp) {
    BigFloat c(t), d(t);
    const unsigned shl = t.u.s.e - BigOffsetExp;
    shift_left  (d.m, BigDimension, shl);
    //d.u.s.e -= shl;
    const unsigned shr = (BigDimension << 5) - shl;
    shift_right (c.m, BigDimension, shr);
    c.u.s.e += shr;
    BigFloat zero;
    if (d.m[BigDimension-1] & (ONE << 31)) AsmAdd (c.m, zero.m, BigDimension, 1u);
    c.norm();
    for (unsigned n=0; n<MaxDecZeros; n++) {
      if ((num & (1u << n))) c.mul (table_low [n]);
    }
    // TODO : pro zaporna cisla to muze byt jinak (ceil(), floor() a trunc())
    return c;
  } else return * this;
}

#ifdef HAVE_STDLIB
void BigFloat::tracen(const char * dsc) const {
  const unsigned buflen = BigDimension * 10 + 12;
  char buffer [buflen];
  to_string (buffer, buflen);
  if (dsc and *dsc) printf("%s = %s\n", dsc, buffer);
  else              printf("\"%s\"\n",       buffer);
}
void BigFloat::print () const {
  printf ("<%08lX> s=%ld,e=%+4ld m=", (unsigned long) u.w, (unsigned long) u.s.s, (unsigned long) u.s.e - BigOffsetExp);
  for (unsigned i=0; i<BigDimension; i++)
    printf ("0x%08lX ", (unsigned long)  m[BigDimension - (i+1)]);
  putchar ('\r');
  putchar ('\n');
}
void BigFloat::row (FILE* out) const {
  fprintf (out, "  { 0x%08Xu,", u.w);
  for (unsigned i=0; i<BigDimension; i++) {
    fprintf (out, "0x%08Xu,", m[BigDimension - (i+1)]);
  }
  fprintf (out, " }");
}
#endif // HAVE_STDLIB
