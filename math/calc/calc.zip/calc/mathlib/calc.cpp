#include <stdio.h>
#include "calc.h"

static signed int PutChar (char * pStr, char c) {
  *pStr = c;
  return 1;
}
static signed int PutUnsignedInt (char * pStr, char fill, signed int width, unsigned int value) {
  signed int num = 0;
  // Take current digit into account when calculating width
  width--;
  // Recursively write upper digits
  if ( (value / 10) > 0) {
    num = PutUnsignedInt (pStr, fill, width, value / 10);
    pStr += num;
  }
  // Write filler characters
  else {
    while (width > 0) {
      PutChar (pStr, fill);
      pStr++;
      num++;
      width--;
    }
  }
  // Write lower digit
  num += PutChar (pStr, (value % 10) + '0');
  return num;
}
/************************************************************************************************/
static BigFloat add (const BigFloat & a, const BigFloat & b) {
  return a + b;
}
static BigFloat sub (const BigFloat & a, const BigFloat & b) {
  return a - b;
}
static BigFloat mul (const BigFloat & a, const BigFloat & b) {
  return a * b;
}
static BigFloat div (const BigFloat & a, const BigFloat & b) {
  return a / b;
}
/************************************************************************************************/
Calc::Calc() : BaseLayer(), stack() {
  running = true;
  index   = 0u;
  ty = TYPE_OPERATION;
}
uint32_t Calc::Up (const char * data, uint32_t len) {
  uint32_t k = 0;
  for (unsigned n=0; n<len; n++) {
    loop (data[n]);
    k += 1u;
  }
  return k;
}
uint32_t Calc::Down (const char * data, uint32_t len) {
  uint32_t offset = 0;
  uint32_t lenght = len;
  while (lenght) {
    const uint32_t result = BaseLayer::Down (data + offset, lenght);
    offset += result;
    lenght -= result;
  }
  return offset;
}

void Calc::show () {
  Down ("\r", 1);
  int m;
  const BigFloat b = stack.top (m);
  if (m < 0) {
    put_str ("Empty Stack !\r\n");
  } else {
    unsigned l = show_num (b, m);
    Down (buffer, l);
  }
  index = 0;
}
void Calc::show_all () {
  int m=0;
  put_str ("\rStack:\r\n");
  for (const BigFloat & b: stack) {
    unsigned l = show_num (b, m++);
    Down (buffer, l);
  }
  index = 0;
}
unsigned Calc::show_num (const BigFloat& b, const int order) {
  unsigned l = b.to_string(buffer, number_len);
  while (l < (number_len - 25)) buffer [l++] = ' ';
  l += PutChar (buffer + l, '(');
  l += PutUnsignedInt (buffer + l, '0', 2, order);
  l += PutChar (buffer + l, ')');
  l += PutChar (buffer + l, '\r');
  l += PutChar (buffer + l, '\n');
  return l;
}

void Calc::handle_enter() {
  if (index and (ty < TYPE_OPERATION)) {
    buffer [index] = '\0';
    BigFloat a (buffer);
    stack.push(a);
    show();
  }
  ty = TYPE_OPERATION;
  index = 0;
}
void Calc::handle_escape() {
  if (ty == TYPE_OPERATION) {
    BigFloat x, y;
    if (!stack.pop(x)) stack.push(y);
    show();
    return;
  }
  unsigned i = 0;
  buffer [i++] = '\r';
  for (unsigned n=0; n<index; n++) buffer [i++] = ' ';
  buffer [i++] = '\r';
  Down (buffer, i);
  ty = TYPE_OPERATION;
  index = 0;
}
void Calc::handle_backspace() {
  if (ty == TYPE_OPERATION) return;
  if (index > 0) {
    unsigned n = index - 1;
    if ((buffer[n] != '+') and (buffer[n] != '-')) {
      buffer [n] = '\0';
      index = n;
#ifdef EMSCRIPTEN
      Down("\x08", 1);
#else
      Down("\x1B[D \r", 5);
      Down(buffer, index);
#endif
    }
  }
}
void Calc::handle_number (const char c) {
  if (ty == TYPE_OPERATION) {
    ty = TYPE_MANTISA;
    buffer [index++] = '+';
    buffer [index++] = c;
    Down ("\r", 1);
    Down (buffer, index);
    return;
  }
  buffer [index++] = c;
  Down (&c, 1);
}
void Calc::handle_dot() {
  if (ty == TYPE_MANTISA) {
    buffer [index++] = '.';
    Down (".", 1);
  }
}
void Calc::handle_exp() {
  if (ty == TYPE_MANTISA) {
    ty = TYPE_EXPONENT;
    buffer [index++] = 'E';
    buffer [index++] = '+';
    Down ("\r", 1);
    Down (buffer, index);
    return;
  }
}
void Calc::handle_sign() {
  if (ty == TYPE_OPERATION) return;
  int k = index;
  if (k < 1) return;
  while (k--) {
    if (buffer[k] == '+') {
      buffer[k] = '-';
      break;
    }
    if (buffer[k] == '-') {
      buffer[k] = '+';
      break;
    }
  }
  Down ("\r", 1);
  Down (buffer, index);
}
void Calc::put_str (const char * str) {
  unsigned n = 0;
  for (n=0;;n++) {
    if (str [n] == '\0') break;
  }
  Down (str, n);
}
void Calc::handle_f1 (const char * dsc, f_1 f) {
  if (ty != TYPE_OPERATION) return;
  put_str (dsc);
  BigFloat a;
  stack.pop(a);
  //a = f (a);
  a = wrap_f1 (a, f);
  stack.push(a);
  show();
}
void Calc::handle_f2 (const char * dsc, f_2 f) {
  if (ty != TYPE_OPERATION) return;
  put_str (dsc);
  BigFloat a,b;
  stack.pop(a);
  stack.pop(b);
  b = wrap_f2 (b, a, f);
  stack.push(b);
  show();
}
const char * const help_str = "RPN kalkulátor se zvýšenou přesností\r\n"
"\tZadání čísla : dekadické číslice \'.\' \'E\'\r\n"
"\tklávesa TAB mění znaménko, po E u exponentu\r\n"
"\tBACKSPACE maže poslední zadaný znak, ESC celé číslo.\r\n"
"\tENTER uloží číslo na zásobník, ESC pak vyjme číslo ze zásobníku, \'r\' maže celý zásobník\r\n"
"\tZnaky \" + - * / \" - aritmetické operace, \'p\' - uloží na zásobník číslo PI\r\n"
"\t\'s\' - sin (x) \'c\' - cos (x) \'e\' - exp  (x) \'x\' - x^y\r\n"
"\t\'q\' - sqrt(x) \'l\' - log (x) \'L\' - log10(x) \'d\' - duplikuje vrchol zásobníku\r\n"
"\t\'w\' - prohodí 2 vrchní položky na zásobníku (pokud tam jsou)\r\n"
"\t\'h\' - vypíše tento text, SPACE celý zásobník\r\n"
;

void Calc::loop(const char c) {
  if (c == '\x7F') {        // backspace
    handle_backspace();
  } else if (c == ' ') {    // SPACE
    show_all();
  } else if (c == '\n') {   // ENTER
    handle_enter();
  } else if (c == '\x1B') { // ESCAPE
    handle_escape();
  } else if (c == '\x09') { // CHANGE SIGN MANTISA / EXPONENT
    handle_sign();
  } else if (c == '.') {
    handle_dot();
  } else if (c == 'E') {
    handle_exp();
  } else if (c == 'h') {
    put_str (help_str);
  } else if (c == 'd') {    // DUPLICATE STACK TOP
    BigFloat a;
    stack.pop (a);
    stack.push(a);
    stack.push(a);
    show();
  } else if (c == 'w') {    // SWAP STACK TOP <-> TOP-1
    stack.swap();
    show();
  } else if (c == 'r') {    // RESET
    stack.clear();
    show();
  } else if ((c >= '0') and (c <= '9')) {
    handle_number (c);
  } else if (c == '+') {    // Základní operace
    handle_f2 ("x+y\r\n", add);
  } else if (c == '-') {
    handle_f2 ("x-y\r\n", sub);
  } else if (c == '*') {
    handle_f2 ("x*y\r\n", mul);
  } else if (c == '/') {
    handle_f2 ("x/y\r\n", div);
  } else if (c == 'p') {  // PI
    const BigFloat pi (table_m_pi);
    stack.push (pi);
    show();
  } else if (c == 'q') {  // SQRT , funkce
    handle_f1 ("sqrt\r\n", sqrt);
  } else if (c == 'e') {  // EXP
    handle_f1 ("exp\r\n",  exp);
  } else if (c == 'l') {  // LN
    handle_f1 ("log\r\n",  log);
  } else if (c == 'L') {  // LOG
    handle_f1 ("log10\r\n",log10);
  } else if (c == 's') {  // SIN
    handle_f1 ("sin\r\n",  sin);
  } else if (c == 'c') {  // COS
    handle_f1 ("cos\r\n",  cos);
  } else if (c == 'x') {  // POW
    handle_f2 ("x^y\r\n",  pow);
  } else if (c == '\x03') {  // CTRL-C
    Down ("\x03\n", 2);
  } else {
    //printf ("unexpected %02X\n", c);
  }
}
