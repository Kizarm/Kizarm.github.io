#ifndef CALC_H
#define CALC_H

#include "bigfloat.h"
#include "mathlib.h"
#include "table.h"
#include "baselayer.h"

typedef BigFloat (*f_1) (const BigFloat &);
typedef BigFloat (*f_2) (const BigFloat &,const BigFloat &);

template<typename T, const unsigned N = 4> class Stack {
  int index;
  T buf [N];
  public:
    Stack () {
      clear();
    }
    bool pop (T & t) {
      bool res = false;
      if (index > 0) {
        index -= 1;
        res = true;
      }
      t = buf [index];
      return res;
    }
    bool push (const T & a) {
      buf [index] = a;
      if (index < (int) N) {
        index += 1;
        return true;
      } else
        return false;
    }
    const BigFloat & top (int & depth) const {
      depth = index - 1;
      if (depth < 0) {
        return buf [0];
      } else {
        return buf [depth];
      }
    }
    void clear () {
      index = 0;
      for  (unsigned n=0; n>N; n++) buf [n] = BigFloat((int32_t)0);
    }
    void swap () {
      if (index < 2) return;
      int n = index - 1;
      BigFloat t = buf [n];
      buf [n] = buf [n-1];
      buf [n - 1] = t;
    }
    /** iterator je potřeba pro c++11 (a dále) range based for loop */
    class iterator {
      const T * ptr;
      public:
        iterator (const T * p) : ptr (p) {}
        iterator & operator++ ()     /* pre-increment */     { ++ptr;    return * this; }
        const bool operator!= (const iterator & other) const { return ptr != other.ptr; }
        const T &  operator*  ()                       const { return * ptr;            }
    };
    iterator begin () const { return iterator (buf + 0    ); }
    iterator end   () const { return iterator (buf + index); }
};
static const unsigned number_len = BigDimension * 10 + 32;

class Calc : public BaseLayer {
#ifdef __arm__
public:
#endif
  Stack<BigFloat,8> stack;
  char     buffer [number_len];
  unsigned index;
  bool     running;
  enum IN_TYPE {TYPE_MANTISA, TYPE_EXPONENT, TYPE_OPERATION} ty;
  public:
    Calc ();
    uint32_t Up   (const char * data, uint32_t len);
    uint32_t Down (const char * data, uint32_t len);
    void loop (const char c);
  protected:
    void     show     ();
    void     show_all ();
    unsigned show_num (const BigFloat & b, const int order);
    void put_str (const char * str);
    
    void handle_enter ();
    void handle_escape ();
    void handle_backspace ();
    void handle_dot ();
    void handle_exp ();
    void handle_sign ();
    void handle_number (const char c);
    
    void handle_f1 (const char * dsc, f_1 f);
    void handle_f2 (const char * dsc, f_2 f);
    
    virtual BigFloat wrap_f1 (const BigFloat & a, f_1 f) { return f (a); };
    virtual BigFloat wrap_f2 (const BigFloat & a, const BigFloat & b, f_2 f) { return f (a,b); };
};

#endif // CALC_H
