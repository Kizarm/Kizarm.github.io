#include "asm.h"
extern uint8_t Add8 (uint8_t * dst, const uint8_t * src, const uint8_t cnt, const uint8_t cin);
uint32_t AsmAdd (uint32_t * left, const uint32_t * right, uint32_t n, uint32_t carry) {
  uint8_t * dst = (uint8_t*) left;
  const uint8_t * src = (const uint8_t*) right;
  const uint8_t cnt = n << 2;
  const uint8_t cin = carry;
  return (uint32_t) Add8 (dst, src, cnt, cin);
}
uint8_t Add8 (uint8_t * dst, const uint8_t * src, const uint8_t cnt, const uint8_t cin) {
  uint8_t cout, tmp = cin;
  for (uint8_t n=0; n<cnt; n++) {
    uint8_t       * dop = dst + n;
    const uint8_t * sop = src + n;
    __asm__ (
      "ld   r25,Z\n\t"
      "ld   r24,Y\n\t"
      "ror  %[t]\n\t"
      "adc  r25,r24\n\t"
      "rol  %[t]\n\t"
      "st   Z,r25\n\t"
      ::[dp]"z"(dop), [sp]"y"(sop), [t]"r"(tmp): "r24", "r25");
  }
  __asm__ (
    "eor %[co],%[co]\n\t"
    "ror %[t]\n\t"
    "rol %[co]\n\t"
    : [co]"=&r"(cout): [t]"r"(tmp));
  return cout;
}
