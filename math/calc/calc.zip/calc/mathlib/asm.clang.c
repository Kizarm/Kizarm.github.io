#include "asm.h"

uint32_t AsmAdd (uint32_t * left, const uint32_t * right, uint32_t n, uint32_t carry) {
  uint32_t carry_in = carry, carry_out;
  for (unsigned i=0; i<n; i++) {
    unsigned result = __builtin_addc (left[i], right[i], carry_in, &carry_out);
    carry_in = carry_out;
    left [i] = result;
  }
  
  return carry_out;
}
