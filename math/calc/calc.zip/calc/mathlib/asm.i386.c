#include <assert.h>
#include "asm.h"

#if __i386__
uint32_t AsmAdd (uint32_t * left, const uint32_t * right, uint32_t n, uint32_t carry) {
  uint32_t cout;
  asm volatile (
  "xorl   %%ebx,%%ebx\n\t"
  "decl   %%ebx\n\t"
  "addl   %1,%%ebx\n\t"
  "pushf\n\t"
  
"l1add:\n\t"
  "movl   (%4),%%ebx\n\t"   // argument do bx
  "popfl\n\t"
  "adcl   %%ebx,(%3)\n\t"   // součet včetně přenosu
  "pushfl\n\t"
  "addl   $4,%3\n\t"        // další "číslice"
  "addl   $4,%4\n\t"
  "loop   l1add\n\t" 

  "xorl   %%ebx,%%ebx\n\t"
  "popfl\n\t"
  "adcl   %%ebx,%%ebx\n\t"  // vracím přenos
  "movl   %%ebx,%0"

  :"=&r"(cout): "r"(carry), "c"(n), "D"(left), "S"(right):"%ebx");
  return cout;
}
#elif __x86_64__
static uint64_t Add64 (uint64_t * dst, const uint64_t * src, uint64_t cnt, uint64_t cin) {
  uint64_t cout;
  asm volatile (
  "xorq   %%rbx,%%rbx\n\t"
  "decq   %%rbx\n\t"
  "addq   %1,%%rbx\n\t"
  "pushf\n\t"
  
"l1add:\n\t"
  "movq   (%4),%%rbx\n\t"   // argument do bx
  "popf\n\t"
  "adcq   %%rbx,(%3)\n\t"   // součet včetně přenosu
  "pushf\n\t"
  "addq   $8,%3\n\t"        // další "číslice"
  "addq   $8,%4\n\t"
  "loop   l1add\n\t" 

  "xorq   %%rbx,%%rbx\n\t"
  "popf\n\t"
  "adcq   %%rbx,%%rbx\n\t"  // vracím přenos
  "movq   %%rbx,%0\n\t"

  :"=&r"(cout): "r"(cin), "c"(cnt), "D"(dst), "S"(src):"%rbx");
  return cout;
}
// tady je potřeba udělat trochu nešikovný obal aby to fungovalo stejně jako na 32-bit
uint32_t AsmAdd (uint32_t * left, const uint32_t * right, uint32_t n, uint32_t carry) {
  const uint64_t cin = carry;
  uint64_t cout=0, cnt;
  uint64_t * src, * dst;
  uint32_t cps [n+1], cpd [n+1];
  if (n & 1) {
    cnt = (n >> 1) + 1;
    for (unsigned i=0; i<n; i++) {
      cps [i] = right [i];  cpd [i] = left  [i];
    }
    cps [n] = 0u;           cpd [n] = 0u;
    dst = (uint64_t*) cpd;  src = (uint64_t*) cps;
  } else {
    cnt = n >> 1;
    dst = (uint64_t*) left; src = (uint64_t*) right;
  }
  cout = Add64 (dst, src, cnt, cin);  // v assembleru je vše 64-bit
  if (n & 1) {
    for (unsigned i=0; i<n; i++) left [i] = cpd [i];
    if (cpd[n] & 1u) carry = 1u;
    else             carry = 0u;
  } else {
    carry = cout ? 1u : 0u;
  }
  return carry;
}
uint32_t AsmMul (uint32_t * left, const uint32_t right, const uint32_t dim) {
  assert ((dim & 1) == 0);
  uint64_t carry;
  const uint64_t width = dim >> 1;
  const uint64_t par   = right;
  uint64_t * number = (uint64_t *) left;
  asm volatile (
    "pushq    %%rax\n\t"
    "pushq    %%rdx\n\t"
    "xorq     %%rbx,%%rbx\n\t"    // prenos v ebx je zacatku 0
    "clc\n\t"
    "pushf\n\t"
    "102:\n\t"
    "movq     (%%rsi),%%rax\n\t"  // operand number[i] do eax
    "mulq     %%rdi\n\t"          // v eax je vysledek, v edx je prenos
    "popf\n\t"
    "adcq     %%rbx,%%rax\n\t"    // pricti stary prenos
    "pushf\n\t"
    "movq     %%rdx,%%rbx\n\t"    // shovej novy  prenos do dalsiho kola
    "movq     %%rax,(%%rsi)\n\t"  // vysledek do pameti
    "addq     $8,%%rsi\n\t"
    "loop     102b\n\t"
    "popf\n\t"
    "adcq     $0,%%rbx\n\t"       // poslední přenos !
    "popq     %%rdx\n\t"
    "popq     %%rax\n\t"
    :"=b" (carry)
    :"S" (number), "D" (par), "c" (width)
    ://"%rax", "%rdx"
  );
  return (uint32_t) carry;
}
#else
#error arch
#endif