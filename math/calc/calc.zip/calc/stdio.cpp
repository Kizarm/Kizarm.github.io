#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <string>
#include "baselayer.h"
#include "calc.h"

static const char * description_string = R"---(
<h3>Kalkulačka - Popis.</h3>
<p>Původně to byl projekt knihovny, která umí základní aritmetické operace nad velkým číslem v pohyblivé řádové čárce.
I když nebyl kladen důraz na optimalizaci, šlo špíš o jednoduchost, ukázalo se, že to není až tak snadné. Aby se s tím
dalo vůbec něco dělat (třeba to jen odladit), je potřeba mít už hotové prakticky všechny vlastnosti algebraického tělesa - je totiž
potřeba převod na nějaký čitelný tvar a ten prostě aritmetické operace potřebuje. Je to problém vejce a slepice.
Aby nebylo potřeba psát spoustu kódu v assembleru je v něm jen jediná operace - sčítání dvou velkých nezáporných celých
čísel. Zde se volá v cyklu strojová instrukce sčítání s přenosem, kterou má většina procesorových architektur. Jsou
to všechny ty soubory asm*.c, hotové jsou pro AVR, ARM a x86 (i 64bit) a gcc. V clang je pro tuto operaci
vestavěná funkce, takže lze tento kód použít i pro všechny architektury, pro které existuje clang překladač.
Toho se nakonec využilo i zde, v emscripten konec konců neexistuje něco jako assembler, muselo by se to nějak obejít.
</p>
<p>Všechny ostatní operace jsou nad tím postaveny v C-čku. Násobení je tedy opakované sčítání spolu s posuvem, dělení podobně.
Není to nejefektivnější, ale v zásadě jednoduché a pro počítání to stačí. Nad algebraickým tělesem je pak postaveno několik nejpoužívanějších
matematických funkcí, většinou primitivně z jejich definic. No a to už stačí na opravdovou kalkulačku.
<a href="https://cs.wikipedia.org/wiki/Postfixov%C3%A1_notace" target="_blank">Reverzní polská notace</a>
byla použita pro její jednoduchost, používaly to např. kalkulačky HP a pro jednočip je to dobrá volba. 
Zásobník v této verzi může mít maximálně 8 položek. Přesnost výpočtu, resp. počet desetinných míst lze změnit při kompilaci,
největší a nejmenší použitelné číslo má dekadický řád zhruba milion.
Interně by to byla asi tak miliarda, ale tak velká (malá) čísla nejsou správně zobrazována (ale není problém to dodělat).
Stejně tak není ošetřeno přetečení číselného rozsahu. Pro běžné výpočty to není potřeba, pro výpočty v pravděpodobosti a statistice
není tohle vhodné, bylo by potřeba ještě větších čísel, která jsou ale stejně mimo lidskou představivost a tedy mimo veškerou realitu.
Chyby v tom asi jsou, ale v zásadě to počítá správně, poslední zobrazená 2 až 3 desetinná místa mohou být nesmyslná.
</p>
<p>I když je to jen taková hloupost, přikládám i <a href="calc.zip">zdrojáky</a>. To kdyby si chtěl někdo postavit přesnější kalkulačku třeba na Adruinu.
Je to ovšem bez jakékoli záruky.
</p>
<h3 align="center">© Kizarm 2020</h3>
)---";
/** @file
 * Volání z C++ do javascript a nazpátek.
 * Příklady na webu jsou příliš komplikované.
 * */
class Console : public BaseLayer {
  public:
    Console() : BaseLayer() {};
    uint32_t  Down   (const char * data, uint32_t len);
};


#include <emscripten/bind.h>
#include <emscripten/val.h>

using namespace emscripten;

static Console console;
static Calc    calc;

static void out_std (std::string text) {
  // musí se to udělat přes globální objekt window
  val win = val::global("window");
  win.call<void>("ConsoleOutput", text);
}

static void out_chr (const char out) {
  console.Up (&out, 1);
}
static void out_str (const std::string & str, bool ctrl) {
  const size_t len = str.length();
  if (len > 1) return;
  char c = str [0];
  if (ctrl) {
    if (!isalpha(c)) return;
    c = toupper (c);
    c -= '@';
    out_chr (c);
  } else {
    out_chr (c);
  }
}
static bool CtrlModifier = false;
void listenInput (std::string code, bool up) {
//printf("listenInput: %s, %d\n", code.c_str(), up);
  if (up) {
    if (code == "Enter") {
      out_chr('\n');
    } else if (code == "Control") {
      CtrlModifier = true;
    } else if (code == "Escape") {
      out_chr('\x1B');
    } else if (code == "Backspace") {
      out_chr('\x7F');
    } else if (code == "Delete") {
      out_chr('\x7F');
    } else if (code == "Tab") {
      out_chr('\x09');
    } else {
      out_str (code, CtrlModifier);
    }
  } else {
    if (code == "Control") {
      CtrlModifier = false;
    }
  }
}

std::string Init () {
  calc += console;
  console.Up ("h", 1);
  return std::string (description_string);
}
EMSCRIPTEN_BINDINGS (hello) {
  function ("Init", Init);
  function ("listenInput", listenInput);
}

uint32_t Console::Down (const char * data, uint32_t len) {
  char buffer [len+1];
  memcpy (buffer, data, len);
  buffer [len] = '\0';
  std::string result (buffer);
  out_std (result);
  return len;
}
