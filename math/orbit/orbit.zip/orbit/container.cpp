#include <exception>
#include "container.h"

using namespace std;

static const int FrameTime = 20; // ms
extern const char * description_string;

Container::Container() : canvas(this), sim_st (SS_DEFINE), sim_data(SimulationParameters), butDefin(nullptr), butStart(nullptr), butReset(nullptr) {
  order  = 0;
  root = new HtmlElement ("div");
  // create functional elements
  HtmlElement * cnv = new HtmlElement ("canvas");
  // and helpers
  HtmlElement * tab = new HtmlElement ("table");
  HtmlElement * row = new HtmlElement ("tr");
  // formatting
  tab->addTag (new HtmlTag ("style", "width:100%"));
  cnv->addTag (new HtmlTag ("id",    "canvas"));
  cnv->addTag (new HtmlTag ("class", "canvas"));
  viewParm = new Text ("td","R<sub>1</sub>, R<sub>2</sub>", this);
  viewParm->addTag (new HtmlTag ("width", "20%"));
  viewParm->addTag (new HtmlTag ("style", "color:#0000FF"));
  // build tree
  row->insert (button_type ());
  row->insert (button_anime());
  row->insert (button_start());
  row->insert (button_clear());
  row->insert (viewParm);
  tab->insert (row);
  // root element
  root->insert (cnv);
  root->insert (tab);
  root->insert (slider_table());
  
  HtmlElement * dsc = new Text ("div", description_string);
  dsc->addTag (new HtmlTag ("class", "frame1"));
  root->insert(dsc);
}
Container::~Container() {
  delete root;
}
static void set_internals (string & code, int timeout, bool clear) {
  const char * cs = clear ? "true" : "false";
  code += FmtString ("ClearFg = %s;\n", cs);
  code += FmtString ("TimeOut = %d;\n", timeout);
}
static void view_params (string & code, Container * p) {
  const SimData & sd = p->sim_data;
  code += FmtString ("document.getElementById(\'%s\').innerHTML = \'R<sub>1</sub>=%g<br> R<sub>2</sub>=%g\';\n", p->viewParm->getId().c_str(), sd.R1, sd.R2);
}
HtmlElement* Container::button_anime() {
  static const char  * types [] = {"Simulace", "Nastavení"};
  HtmlElement * but = new Button (types[0], this);
  
  HtmlElement * tde = new HtmlElement ("td");
  tde->addTag (new HtmlTag ("align", "center"));
  tde->addTag (new HtmlTag ("width", "20%"));
  // Function
  but->setCb([] (HtmlElement * e, const string & val, const bool init) -> Action {
    Container * p = e->getParent();
    SIMULATION_STATES & param = p->sim_st;
    string code;
    switch (param) {
      case SS_DEFINE: { e->setValue (types[1]); param = SS_STOP;   code += p->disableSettings (true);  code += p->butStart->disable(false);
             code += p->butReset->disable(false); set_internals (code, -1, true ); view_params(code, p); break; }
      case SS_STOP:   { e->setValue (types[0]); param = SS_DEFINE; code += p->disableSettings (false); code += p->butStart->disable(true);
             code += p->butReset->disable(true);  set_internals (code, -1, true ); break; }
      default: break;
    }
    code += FmtString ("document.getElementById(\'%s\').innerHTML = \'%s\';\n", e->getId().c_str(), e->getValue().c_str());
    code += FmtString ("drawStuff();\n");
    return Action (code);
  });
  tde->insert (but);
  butDefin = but;
  return tde;
}


HtmlElement * Container::button_type() {
  static const char * types [] = {"Schwarzschild", "Newton"};
  HtmlElement * but = new Button (types[0], this);  
  HtmlElement * tde = new HtmlElement ("td");
  tde->addTag (new HtmlTag ("align", "center"));
  tde->addTag (new HtmlTag ("width", "20%"));
  // Function
  but->setCb([] (HtmlElement * e, const string & val, const bool init) -> Action {
    Container * p = e->getParent();
    bool & param = p->sim_data.OTR_used;
    if (e->getValue() == types[0]) {
      e->setValue (types[1]);
      param = false;
    } else {
      param = true;
      e->setValue (types[0]);
    }
    string code = FmtString ("document.getElementById(\'%s\').innerHTML = \'%s\';\n", e->getId().c_str(), e->getValue().c_str());
    code += FmtString ("wChangeForeground();\n");
    return Action (code);
  });
  tde->insert (but);
  addSettings (but);
  return tde;
}
HtmlElement * Container::button_start() {
  static const char  * types [] = {"Start", "Stop"};
  HtmlElement * but = new Button (types[0], this);
  
  HtmlElement * tde = new HtmlElement ("td");
  but->addTag (new HtmlTag ("disabled", "true"));
  tde->addTag (new HtmlTag ("align", "center"));
  tde->addTag (new HtmlTag ("width", "20%"));
  // Function
  but->setCb([] (HtmlElement * e, const string & val, const bool init) -> Action {
    Container * p = e->getParent();
    SIMULATION_STATES & ss = p->sim_st;
    string code;
    switch (ss) {
      case SS_STOP: e->setValue (types[1]); ss = SS_RUN;  code += p->butDefin->disable(true);  set_internals (code, FrameTime, false); break;
      case SS_RUN:  e->setValue (types[0]); ss = SS_STOP; code += p->butDefin->disable(false); set_internals (code,        -1, false); break;
      default: break;
    }
    code += FmtString ("document.getElementById(\'%s\').innerHTML = \'%s\';\n", e->getId().c_str(), e->getValue().c_str());
    code += FmtString ("window.setTimeout (wChangeForeground, 1);\n");
    return Action (code);
  });
  tde->insert (but);
  butStart = but;
  return tde;
}
HtmlElement * Container::button_clear() {
  static const char * type = "Smazat";
  HtmlElement * but = new Button (type, this);
  
  HtmlElement * tde = new HtmlElement ("td");
  but->addTag (new HtmlTag ("disabled", "true"));
  tde->addTag (new HtmlTag ("align", "center"));
  tde->addTag (new HtmlTag ("width", "20%"));
  // Function
  but->setCb([] (HtmlElement * e, const string & val, const bool init) -> Action {
    string code;
    const SimData & sim = e->getParent()->sim_data;
    code += FmtString ("console.log(\'%s: J=%g, E=%g, R1=%g, R2=%g (E0=%g)\');\n", sim.OTR_used ? "OTR" : "NEW", sim.J, sim.E, sim.R1, sim.R2, sim.E0);
    code += FmtString ("clearForeground();\n");
    return Action (code);
  });
  tde->insert (but);
  butReset = but;
  return tde;
}

HtmlElement * Container::slider_table() {
  HtmlElement * tab = new HtmlElement ("table");
  HtmlElement * row = new HtmlElement ("tr");
  HtmlElement * ds1 = new Text ("td", "<b>Nastavení hodnot</b>");
  HtmlElement * ds2 = new Text ("td", "Hodnota");
  // Stacked elements
  SliderRow sr1 (this, "Orbitální moment J", 0, 333, 10), sr2 (this, "Energie E", 0, 1000, 350), sr3 (this, "Rychlost", 10, 200, 50);
  
  tab->addTag (new HtmlTag ("width", "100%"));
  tab->addTag (new HtmlTag ("bgcolor", "#FFFFC0"));
  ds2->addTag (new HtmlTag ("colspan", "2"));
  ds1->addTag (new HtmlTag ("align", "center"));
  ds2->addTag (new HtmlTag ("align", "center"));
  row->insert (ds1);
  row->insert (ds2);
  tab->insert (row);
  tab->insert (sr1.Init ());
  tab->insert (sr2.Init ());
  tab->insert (sr3.Init ());
  
  addSettings (sr1.getRoot());
  addSettings (sr2.getRoot());
  
  sr1.getRoot()->setCb  ([] (HtmlElement * e, const string & value, const bool init) -> Action {
    Container * p = e->getParent();
    double & param = p->sim_data.J;
    const int input = value.empty() ? -1 : std::stoi (value);
    const double dvalue = 1.809674836 * exp (0.01 * (double) input);
    param = dvalue;
    e->setValue (value);
    HtmlElement * f = e->getAttach();
    string result;
    if (init) {
      result += FmtString ("document.getElementById(\'%s\').value     =  %d;\n", e->getId().c_str(), input);
      result += FmtString ("document.getElementById(\'%s\').innerHTML = \'<i>%g</i>\';\n", f->getId().c_str(), dvalue);
    } else {
      result += FmtString ("document.getElementById(\'%s\').innerHTML = \'%6.3f\';\n",        f->getId().c_str(), dvalue);
      result += FmtString ("wChangeForeground();\n");
    }
    return Action (result);
  });
  sr2.getRoot()->setCb  ([] (HtmlElement * e, const string & value, const bool init) -> Action {
    Container * p = e->getParent();
    double & param = p->sim_data.E0;
    const int input = value.empty() ? -1 : std::stoi (value);
    const double dvalue = 0.1 * (double) input;
    param = 1.0 - 0.01 * dvalue;
    e->setValue (value);
    HtmlElement * f = e->getAttach();
    string result;
    if (init) {
      result += FmtString ("document.getElementById(\'%s\').value     =  %d;\n", e->getId().c_str(), input);
      result += FmtString ("document.getElementById(\'%s\').innerHTML = \'<i>%g%% Jm</i>\';\n", f->getId().c_str(), dvalue);
    } else {
      result += FmtString ("document.getElementById(\'%s\').innerHTML = \'%g%% Jm\';\n",        f->getId().c_str(), dvalue);
      result += FmtString ("wChangeForeground();\n");
    }
    return Action (result);
  });
  sr3.getRoot()->setCb  ([] (HtmlElement * e, const string & value, const bool init) -> Action {
    Container * p = e->getParent();
    const int input  = value.empty() ? -1 : std::stoi (value);
    int     & param  = p->sim_data.speed;
    param = input;
    ips_speed();
    const int ivalue = 10 * param;//p->sim_data.cycles * input;
    e->setValue (value);
    HtmlElement * f = e->getAttach();
    string result;
    if (init) {
      result += FmtString ("document.getElementById(\'%s\').value     =  %d;\n", e->getId().c_str(), input);
      result += FmtString ("document.getElementById(\'%s\').innerHTML = \'<i>%d ipf</i>\';\n", f->getId().c_str(), ivalue);
    } else {
      result += FmtString ("document.getElementById(\'%s\').innerHTML = \'%d ipf\';\n",    f->getId().c_str(), ivalue);
    }
    return Action (result);
  });
  return tab;
}

string  Container::InitAll() {
  string result;
  for (HtmlElement * s: initialized) {
    string value = s->getValue();
    Action act = s->action (value, true);
    if (act.length) result += act.code;
  }
  return result;
}
string Container::disableSettings (const bool yes) {
  const char * disable = yes ? "true" : "false";
  string result;
  for (HtmlElement * e: settings) {
    result += FmtString ("document.getElementById(\'%s\').disabled = %s;\n", e->getId().c_str(), disable);
  }
  return result;
}

string Container::to_string() {
  return root->to_string();
}

Action Container::back (const int index, const string & input) {
  // printf ("index = %d, input = %d\n", index, input);
  Action act;
  if (index >= 0 && index < ordered.size()) {
    HtmlElement * e = ordered [index];
    if (e) act = e->action (input);
  }
  return act;
}

