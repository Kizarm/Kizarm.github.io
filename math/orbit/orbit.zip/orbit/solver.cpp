#include "stdio.h"
#include "solver.h"
#include "solverpublic.h"

template<class T, size_t N> constexpr size_t SIZE (T (&)[N]) { return N; }
template<const  unsigned N> using PFUNC = bool (*) (const NPoint<N> &, real &);

/** Kepletova úloha s doplnění, o pohyb ve Schwarzschildově metrice.
 *  t, w : r, phi
 * 
 * I když je to každé trochu o něčem jiném, počítá se to celkem stejně.
 * */

SimData SimulationParameters;

static const real w0 [] = {1.0, 0.0};        // Počet počátečních podmínek musí odpovídat počtu rovnic...
static const unsigned M = SIZE (w0);         // čili určuje celkový rozsah výpočtu.
static const real C = 1.0;                   // rychlost svetla ve vakuu je všude počítána jako jednotka

static const NPoint<M> bc (0.0, w0);

static int  pass  = 0;
static bool F1 (const NPoint<M> & w, real & result) {
  const real r = w.w[0];
  if (r <= 0.0) return true;
  const real u   = SimulationParameters.E - ComputePotential (r, SimulationParameters.OTR_used);
  const real dir = SimulationParameters.dir ? +C : -C;
  if (u < 0.0) {
    result = dir * sqrt (-u);
    if (pass > 100) {    // algoritmus obracení znaménka odmocniny - je nutné počítat průchody, musí jich být docela dost
      // printf ("pass %d\n", pass);
      SimulationParameters.dir = ! SimulationParameters.dir;
      pass = 0;
    }
  } else {
    result = dir * sqrt (+u); // probíhá v zásadě tudy
  }
  pass += 1;
  return false;
}
static bool F2 (const NPoint<M> & w, real & result) {
  const real r = w.w[0];
  if (r <= 0.0) return true;
  result = C * SimulationParameters.J / (r*r);
  return false;
}

static PFUNC<M> pf[M] = {
  F1, F2
};

static RungeKutta <M, PFUNC<M>> solver (pf, bc, 0.003);

/***********************************************************************************/
const real ComputePotential (const real r, const bool OTR) {
  const real otr = OTR ? 1.0 : 0.0;
  const real j_r = SimulationParameters.J / r;
  const real s_r = SimulationParameters.S / r;
  const real u = (j_r) * (j_r) * (1.0 - otr * s_r) - s_r;
  return u;
}
FPoint DiffEqPass () {
  real rad, phi;
  const int m = 10;//SimulationParameters.cycles;
  for (int n=0; n<m; n++) {
    const NPoint<M> & p = solver.solve();
    rad = p.w[0];
    phi = p.w[1];
  }
  // printf ("result =(%+g | %+g)\n", rad, phi);
  FPoint result (rad * cos (phi), rad * sin (phi));
  return result;
}
void DiffEqBc () {
  SimulationParameters.dir = false;
  const real ww[] = {SimulationParameters.R2, 0.0};
  const NPoint<M> ic (0.0, ww);
  solver.setBC (ic, SimulationParameters.step);
}
