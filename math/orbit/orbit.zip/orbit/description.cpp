const char * description_string = R"---(<h3>Pohyb planety - popis.</h3>
  <p> I když eliptický pohyb planety řízený Newtonovým gravitačním zákonem za zjednodušujícího
  předpokladu, že centrální gravitující těleso je nehybné (tedy s hmotností daleko větší než těleso obíhající)
  a obě tělesa můžeme považovat za hmotné body, lze vyřešit analyticky, není od věci udělat si simulaci,
  která pohybové rovnice řeší numericky. Docela jednoduše lze pak přidat jediný člen do rovnic a ukázat
  i řešení pro světočáru částice ve Schwarzschildově metrice. I když jsou to úplně jiné problémy, rovnice
  jsou podobné, nicméně počítají trochu něco jiného. Zatímco Keplerův problém a tedy Newtonova klasická mechanika
  počítají ve standardních polárních (je to v pohyb v rovině) souřadnicích, Schwarzschildova metrika používá
  radiální souřadnici, která zachovává vzorec pro plochu koule a rovnice jsou integrovány ve vlastním čase hmotného
  bodu, jehož světočáru počítáme. A protože se tady pohybujeme dost blízko Schwarzschildova poloměru a tedy
  i rychlostmi blízkými rychlosti světla, reálné souřadnice v soustavě vzdáleného pozorovatele se budou
  od simulace dost lišit. Přepočet zde řešen není, nebylo celkem cílem ukázat co je vidět z dálky, jen jsem
  chtěl ukázat, že pohyb se od klasické Newtonovy mechaniky trochu liší. Konec konců reálně by se tam stejně
  asi ukázaly další efekty - zkreslení dané hlubokou potenciálovou jámou (gravitační čočka) a zřejmě by to
  také vyzařovalo gravitační vlny. A jakékoli reálné těleso by tak blízko Schwarzschildova poloměru hodně
  utrpělo slapovými silami. Vědu z toho tedy dělat nebudu, není to dizertace, je to spíš legrace, vzniklá
  za deštivých dnů letošního léta.
  </p>
  <p> Pohyb v blízkém okolí Schwarzschildova poloměru byl zvolen jen proto, aby bylo vůbec něco vidět.
  Vlastními rovnicemi použitými pro simulaci se zde nebudu zabývat, vyšel jsem z literatury [1] - kap. 1.4.3 a [2] - kap. 11,
  vyházel jsem z toho celkem nepotřebné konstanty a použité veličiny jsou v zásadě bezrozměrné. Základní
  rozměr v simulaci je Schwarzschildův poloměr R<sub>s</sub>, zde roven 1. Veličina J (úměrná orbitálnímu momentu hybnosti)
  by tady měla vlastně rozměr délky a v simulaci je udávána v násobcích R<sub>s</sub>. Protože se rovnice řídí
  fakticky efektivním potenciálem U, jehož průběh v závislosti na radiální vzdálenosti je závislý právě
  na J, byla pro stanovení počátečních podmínek zvolena tato závislost - počáteční graf. Zeleně je klasický, červeně
  relativistický, jaký bude použit se přepíná tlačítkem Schwarzschild/Newton.
  Efektivní potenciál určuje meze, v jakých se těleso může pohybovat v závislosti na energii
  (což je druhý parametr simulace). V grafu je to silnější vodorovná čára magentou, po přepnutí do režimu
  simulace se vpravo od tlačítek zobrazí parametry - R<sub>1</sub> je vzdálenost od pericentra a R<sub>2</sub> vzdálenost od apocentra v jednotkách R<sub>s</sub>.
  Měřítko na vodorovné ose (vzdálenost od centra) musí být logaritmické (zde v rozsahu 6 dekád, od 1 do 10<sup>6</sup>), rozsah je velký. Tak se dají ještě před spuštěním
  určit meze a nastavit měřítko zobrazení tak, aby to neuteklo z obrazovky. Ono to sice při energii blízké
  nule stejně uteče, ale to celkem není problém.<i> V simulaci je tedy měřítko na obou osách ve stejných násobcích R<sub>s</sub>, násobky
  jsou ale velmí proměnlivé v závislosti na R<sub>2</sub>. Pro lepší orientaci je na pozadí dekadický grid, jehož řád jde určit z velikosti R<sub>2</sub>.</i>
  </p>
  <p>Měřítko grafu na svislé ose (Energie) se mění tak, že je stálý rozdíl
  mezi minimem relativistického potenciálu <i>(musí existovat - J tedy musí být větší než odmocnina ze 3)</i> a nulou.
  Je to tak proto, že absolutní hodnota minima potenciálu s rostoucí hodnotou J rychle klesá a kdyby se měřítko neměnilo nebylo by nic moc vidět.
  </p>
  <p>Další problém je časové měřítko - pro elipsy s velkou excentricitou jsou časy oběhu příliš dlouhé,
  je tedy nutné upravit buď krok metody nebo počet kroků na jeden obrázek. Zde se zvyšuje krok metody, což
  má zase vliv na přesnost výpočtu, takže právě velmi excentrické dráhy (R<sub>2</sub>/R<sub>1</sub> ~ 1000) nejsou již počítány přesně,
  protože poměr rychlosti v pericentru a apocentru je velký a chtělo by to tedy zmenšit krok metody.
  Ona tato metoda výpočtu v reálném čase je sice vhodná pro zobrazení, ale ne pro přesný výpočet.
  Rychlostí simulace se dá trochu hýbat - jednotka <b>ipf</b> značí počet iterací
  na jeden obrázek. Obrázků za sekundu je zhruba 50. Takže počáteční podmínka v poloze je dána menším z kořenů
  rovnice E=U - R<sub>1</sub> a nulovým úhlem. V rychlosti je dána J. Veličiny J a E jsou tedy s počáteční podmínkou provázány.
  </p>
  <p> Simulace používá metodu Runge-Kutta 4.řádu, je celkem přesná. <i>Vlastně tohle celé vzniklo s cílem nějak
  využít webassembly, které je dobré pro náročnější výpočty (na rozdíl od čistého javascriptu běží fakticky jako nativní kód).
  Dalo by se to celé napsat jako webassembly aplikace třeba ve frameworku <a href="https://www.qt.io/" target="_blank">Qt</a>,
  bylo by to efektivnější z hlediska kódování ale vznikne tak docela moloch, takhle je to sice o něco víc práce, nicméně výsledek
  je zhruba 100× menší. A šlo o to naučit se něco nového, weby jinak dělat neumím a protože to dneska dělá každý, chtěl jsem si to vyzkoušet.</i>
  Bylo by lepší a jednodušší počítat radius v závislosti na úhlu, je to jedna rovice 2. řádu, ale bezproblémová.
  Jenže při zobrazení to vypadá hodně nepřirozeně - člověk tak nějak čeká, že se těleso blíže centra pohybuje rychleji,
  takhle by to bylo vlastně naopak. Pokud to řešíme v reálném čase, jsou potřeba 2 diferenciální rovnice 1. řádu, jenže
  derivace zde vystupuje v kvadrátu a tak je nutné zajistit správnou změnu znaménka výrazu po odmocnění, což může dělat problémy.
  Pokud by se zdálo divné, že je to celé nějak našišato i když počáteční podmínky by měly zajistit, že elipsa bude
  (alespoň klasicky) mít hlavní poloosu přesně vodorovně, je to tím, že se nezačíná úplně přesně R<sub>1</sub>, ale hodnotou
  o něco málo větší. Jinak vznikne právě tento problém změny znaménka - buď se to motá v kruhu nebo to uteče.
  </p>
  <p> Defaultní parametry simulace ukazují stáčení pericentra o 180° na otáčku. To je hodně blízko R<sub>s</sub> a tam se právě
  nejvíc projevují relativistické efekty. Pokud jdeme na vyšší hodnoty J, pak se klasická trajektorie od relativistické nebude moc
  lišit, to je vidět z průběhu efektivního potenciálu, ale stále bude vidět stáčení pericentra. Je dobré si uvědomit,
  že ani nejvyšší hodnoty J v této simulaci použité nejsou nějakými realistickými hodnotami, které by se vyskytovaly třeba
  ve Sluneční soustavě. Pokud by se použily realistické hodnoty, nebylo by na simulaci nic moc vidět.
  </p>
  <p><a href="orbit.zip">Zdrojový kód</a> je tak jak je. Komentáře to nemá, psal jsem to pro zábavu, takže je to celkem
  volně k použití. Za duševní újmu při jakémkoli použití však neodpovídám, tím méně pak za případné materiální nebo jiné ztráty.
  Tím je myslím licence dostatečně specifikována. Chyby v tom určitě jsou, ale doufám, že ne principiální.
  </p>
  <p> Závěrem pouze citát z filmu Pelíšky - To muselo dát příšernou práci ... Přitom taková blbost, co ?
  </p>
  <p><b>Použitá literatura.</b></p>
  <ul>
  <li>1. prof. Petr Kulhánek: Teoretická mechanika, dostupné <a href="https://www.aldebaran.cz/studium/mechanika.pdf" target="_blank">online</a>.
  <li>2. prof. Petr Kulhánek: TF4 Obecná relativita, verze 2017, dostupné <a href="https://www.aldebaran.cz/studium/otr.pdf" target="_blank">online</a>.
  </ul>
  <h3 align="center">© Kizarm 2020</h3>
)---";
const char * style_string = R"---(
html,
body {
    height:  100%;
    margin:  0;
    padding: 0;
}
.canvas {
    width:  98vw;
    height: 78vh;
}
.slider {
  -webkit-appearance: none;
  width: 98%;
  height: 30px;
  border-radius: 5px;  
  background: #00FF00;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}
.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider::-moz-range-thumb {
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider:disabled {background: #dddddd;}
.button {
  background-color: #00F0F0;
  border: none;
  color: black;
  padding: 10px 24px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 18px;
  border: 2px solid #4CAF50;
}
.button:disabled {background: #dddddd;}
.frame1 {
  width:  95%;
  margin: 0;
  padding: 10px;
  background-color: #FFFFC0;
  border: 10px solid #F0C0F0;
}
)---";
