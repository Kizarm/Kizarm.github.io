const char * description_string = R"---(<h3>Pohyb planety - popis.</h3>
  <p> I když eliptický pohyb planety řízený Newtonovým gravitačním zákonem za zjednodušujícího
  předpokladu, že centrální gravitující těleso je nehybné (tedy s hmotností daleko větší než těleso obíhající)
  a obě tělesa můžeme považovat za hmotné body, lze vyřešit analyticky, není od věci udělat si simulaci,
  která pohybové rovnice řeší numericky. Docela jednoduše lze pak přidat jediný člen do rovnic a ukázat
  i řešení pro světočáru částice ve Schwarzschildově metrice. I když jsou to úplně jiné problémy, rovnice
  jsou podobné, nicméně počítají trochu něco jiného. Zatímco Keplerův problém a tedy Newtonova mechanika
  počítají ve standardních polárních (je to v pohyb v rovině) souřadnicích, Schwarzschildova metrika používá
  radiální souřadnici, která zachovává plochu koule a rovnice jsou integrovány ve vlastním čase hmotného
  bodu, jehož světočáru počítáme. A protože se tady pohybujeme dost blízko Schwarzschildova poloměru a tedy
  i rychlostmi blízkými rychlosti světla, reálné souřadnice v soustavě vzdáleného pozorovatele se budou
  od simulace dost lišit. Přepočet zde řešen není, nebylo celkem cílem ukázat co je vidět z dálky, jen jsem
  chtěl ukázat, že pohyb se od klasické Newtonovy mechaniky trochu liší. Konec konců reálně by se tam stejně
  asi ukázaly další efekty - zkreslení dané hlubokou potenciálovou jámou (gravitační čočka) a zřejmě by to
  také vyzařovalo gravitační vlny. A jakékoli reálné těleso by tak blízko Schwarzschildova poloměru hodně
  utrpělo slapovými silami. Vědu z toho tedy dělat nebudu, není to dizertace, je to spíš zábava.
  </p>
  <p> Pohyb v blízkém okolí Schwarzschildova poloměru byl zvolen jen proto, aby bylo vůbec něco vidět.
  Vlastními rovnicemi použitými pro simulaci se zde nebudu zabývat, vyšel jsem z literatury [1] - kap. 1.4.3 a [2] - kap. 11,
  vyházel jsem z toho celkem nepotřebné konstanty a použité veličiny jsou v zásadě bezrozměrné. Základní
  rozměr v simulaci je Schwarzschildův poloměr Rs, zde roven 1. Veličina J (úměrná orbitálnímu momentu hybnosti)
  by tady měla vlastně rozměr délky a v simulaci je udávána v násobcích Rs. Protože se rovnice řídí
  fakticky efektivním potenciálem U, jehož průběh v závislosti na radiální vzdálenosti je závislý právě
  na J, byla pro stanovení počátečních podmínek zvolena tato závislost. Určuje meze, v jakých se těleso
  může pohybovat v závislosti na energii (což je druhý parametr simulace). V grafu je to silnější vodorovná čára magentou. 
  Měřítko na vodorovné ose (vzdálenost od centra) musí být logaritmické (v rozsahu 3 dekád), rozsah je velký. Tak se dají ještě před spuštěním
  určit meze a nastavit měřítko zobrazení tak, aby to neuteklo z obrazovky. Ono to sice při energii blízké
  nule stejně uteče, ale to celkem není problém. A protože se mění měřítko zobrazení, je potřeba ho nějak
  zobrazit - na Rs je (pokud není příliš malý) kroužek tmavě žluté barvy, na 10 Rs modrý a na 100 Rs fialový.
  Textové popisky grafu by sice šly udělat, ale nestálo by to za tu práci.
  Další problém je časové měřítko - pro elipsy s velkou excentricitou jsou časy oběhu příliš dlouhé,
  je tedy nutné upravit buď krok metody nebo počet kroků na jeden obrázek. Zde se zvyšuje počet kroků, což
  ovšem dost zvyšuje nároky na výpočet. Je to vidět z ukazatele rychlosti - jednotka <b>ips</b> značí počet iterací
  na jeden obrázek. Obrázků za sekundu je zhruba 50. Takže počáteční podmínka v poloze je dána menším z kořenů
  rovnice E=U a nulovým úhlem. V rychlosti je dána J. Veličiny J a E jsou s počáteční podmínkou provázány.
  </p>
  <p> Simulace používá metodu Runge-Kutta 4.řádu, je celkem přesná. <i>Vlastně tohle celé vzniklo s cílem nějak
  využít webassembly, které je dobré pro náročnější výpočty (na rozdíl od čistého javascriptu běží fakticky jako nativní kód).
  Dalo by se to celé napsat jako webassembly aplikace třeba ve frameworku <a href="https://www.qt.io/" target="_blank">Qt</a>,
  bylo by to efektivnější z hlediska kódování ale vznikne tak docela moloch, takhle je to sice o něco víc práce, nicméně výsledek
  je zhruba 100× menší. A šlo o to naučit se něco nového, weby jinak dělat neumím a protože to dneska dělá každý, chtěl jsem si to vyzkoušet.</i>
  Bylo by lepší a jednodušší počítat radius v závislosti na úhlu, je to jedna rovice 2. řádu, ale bezproblémová.
  Jenže při zobrazení to vypadá hodně nepřirozeně - člověk tak nějak čeká, že se těleso blíže centra pohybuje rychleji,
  takhle by to bylo vlastně naopak. Pokud to řešíme v reálném čase, jsou potřeba 2 diferenciální rovnice 1. řádu, jenže
  derivace zde vystupuje v kvadrátu a tak je nutné zajistit správnou změnu znaménka výrazu po odmocnění, což může dělat problémy.
  Pokud by se zdálo divné, že je to celé nějak našišato i když počáteční podmínky by měly zajistit, že elipsa bude
  (alespoň klasicky) mít hlavní poloosu přesně vodorovně, je to tím, že se nezačíná úplně přesně tím kořenem E=U, ale hodnotou
  o něco málo větší. Jinak vznikne právě tento problém změny znaménka - buď se to motá v kruhu nebo to uteče.
  </p>
  <p> Defaultní parametry simulace ukazují stáčení pericentra o 180° na otáčku, jiné pěkné nastavení je J=3, E=70%.
  Elipsy s velkou excentricitou nejsou vykreslovány úplně správně, rozdíl rychlostí je příliš velký. A žere to
  hodně procesorového času, hlavně pokud použijeme větší rychlost a celou obrazovku.
  </p>
  <p><a href="orbit.zip">Zdrojový kód</a> je tak jak je. Komentáře to nemá, psal jsem to pro zábavu, takže je to celkem
  volně k použití. Za duševní újmu při jakémkoli použití však neodpovídám, tím méně pak za případné materiální nebo jiné ztráty.
  Tím je myslím licence dostatečně specifikována. Chyby v tom určitě jsou, ale doufám, že ne principiální.
  </p>
  <p> Závěrem pouze parafráze z filmu Pelíšky - co to muselo dát práce a přitom je to taková blbost. Jo, fakt dalo.
  </p>
  <p><b>Použitá literatura.</b></p>
  <ul>
  <li>1. prof. Petr Kulhánek: Teoretická mechanika, dostupné <a href="https://www.aldebaran.cz/studium/mechanika.pdf" target="_blank">online</a>.
  <li>2. prof. Petr Kulhánek: TF4 Obecná relativita, verze 2017, dostupné <a href="https://www.aldebaran.cz/studium/otr.pdf" target="_blank">online</a>.
  </ul>
  <h3 align="center">© Kizarm 2020</h3>
)---";
const char * style_string = R"---(
html,
body {
    height:  100%;
    margin:  0;
    padding: 0;
}
.canvas {
    width:  98vw;
    height: 78vh;
}
.slider {
  -webkit-appearance: none;
  width: 98%;
  height: 30px;
  border-radius: 5px;  
  background: #00FF00;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}
.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider::-moz-range-thumb {
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider:disabled {background: #dddddd;}
.button {
  background-color: #00F0F0;
  border: none;
  color: black;
  padding: 10px 24px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 18px;
  border: 2px solid #4CAF50;
}
.button:disabled {background: #dddddd;}
.frame1 {
  width:  95%;
  margin: 0;
  padding: 10px;
  background-color: #FFFFC0;
  border: 10px solid #F0C0F0;
}
)---";
