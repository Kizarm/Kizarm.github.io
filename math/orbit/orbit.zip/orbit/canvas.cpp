#include <stdio.h>
#include <math.h>
#include <vector>
#include <string>
#include "canvas.h"
#include "container.h"

std::string Color::to_string() {
  const int buflen = 256;
  char buffer [buflen];
  snprintf(buffer, buflen, "#%02X%02X%02X", r, g, b);
  return std::string (buffer);
}


Canvas::Canvas(Container * p) : width(640), height(480),
  outpixel(0u), current(0xFF000000), matrix (1.0, 0.0, 0.0, -1.0, (real) (20.0), 0.5 * (real) (height)), parent(p) {
  data = new Color [width * height];
}
void Canvas::resize (int w, int h) {
  delete data;
  width = w; height = h;
  data = new Color [width * height];
  if (parent->sim_st == SS_DEFINE) matrix = parent->canvas.uni_matrix;
  else                             matrix = parent->canvas.sim_matrix;
}

Canvas::~Canvas() {
  delete [] data;
}
void Canvas::fill (const Color & c) {
  for (int y=0; y<height; y++) {
    for (int x=0; x<width; x++) {
      at (x, y) = c;
    }
  }
}
Color & Canvas::at (const int x, const int y) {
  if (!bound(x, y)) return outpixel;
  const int result = x + y * width;
  return data [result];
}
bool Canvas::bound (const int x, const int y) const {
  if (x < 0)       return false;
  if (y < 0)       return false;
  if (x >= width)  return false;
  if (y >= height) return false;
  return true;
}
void Canvas::line (const int xp, const int yp, const int xe, const int ye, const bool doted) {
  bool dot = true;
  int x1 = xp, y1 = yp;
  const int x2 = xe, y2 = ye;
  bool done = false;
  int mx = 0, my = 0;
  // Determine direction and distance
  const int xd = (x1 < x2) ? 1 : -1;
  const int yd = (y1 < y2) ? 1 : -1;
  const int xl = (x1 < x2) ? (x2 - x1) : (x1 - x2);
  const int yl = (y1 < y2) ? (y2 - y1) : (y1 - y2);
  while (!done) {
    if (x1 == x2 && y1 == y2) done = true;
    if (dot) at(x1,y1) = current;    // Plot pixel
    if (doted) dot = !dot;
    mx += xl;
    if (x1 != x2 && mx > yl) x1 += xd, mx -= yl;
    my += yl;
    if (y1 != y2 && my > xl) y1 += yd, my -= xl;
  }
}
void Canvas::rect (const int x0, const int y0, const int x1, const int y1) {
  for (int y=y0; y<y1; y++) {
    for (int x=x0; x<x1; x++) {
      at(x, y) = current;
    }
  }
}

void Canvas::line (const FPoint & begin, const FPoint & end, const bool doted) {
  const FPoint b (matrix * begin);
  const FPoint e (matrix * end  );
  const int x0 = (const int) round (b.x);
  const int y0 = (const int) round (b.y);
  const int x1 = (const int) round (e.x);
  const int y1 = (const int) round (e.y);
  // printf("%d:%d - %d:%d\n", x0, y0, x1, y1);
  line (x0, y0, x1, y1, doted);
}
void Canvas::circ (const FPoint & center, const real radius) {
  if (radius == 0) return;
  double x = radius, y = 0.0;
  const double dx = 1.0 / radius;
  const double ms = radius * 6.3;
  real count = 0.0;
  // kruh se da nakreslit i bez sin a cos, rychle ale trochu nepresne
  for (;;) {
    x += y * dx; y -= x * dx;
    const FPoint e (center.x + x, center.y + y);
    const FPoint t (matrix * e);
    at ((int) round (t.x), (int) round (t.y)) = current;
    count += 1.0;
    if (count > ms) break;
  }
}
/******************************************************************************************************/
/* linky v javascriptu - kooperace */
void BackGround::drawings() {
  if (parent->sim_st == SS_DEFINE) defines ();
  else                             simulation();
}
void BackGround::defines() {
  const real maxx = getMaxX() - 20.0,  maxy = 0.5 * getMaxY();
  const real /*mstx = 100.0,*/  msty = 50.0;
  fill (Color(0, 0, 0, 0xFF));
  const int outer = 3; // 3 rady
  const real step = maxx / (real) outer;
  setColor(Color(0x80, 0x80, 0x80));
  for (int n=0; n<outer; n++) {
    const real a = n;
    for (int i=0; i<10; i++) {
      const real arg = (real) (i + 1);
      const real x = step * (a + log10 (arg));
      line (FPoint(x,-maxy), FPoint(x,maxy), i ? true : false);
    }
  }
  for (real y=msty; y<maxy; y+=msty) { line (FPoint(0,y), FPoint(maxx,y), true); line (FPoint(0,-y), FPoint(maxx,-y), true); }
  setColor(Color(0xFF, 0xFF, 0));
  line (FPoint (0, -maxy), FPoint (0, maxy));
  line (FPoint (0, 0), FPoint (maxx, 0));
}
void BackGround::simulation() {
  const real maxx = 0.5 * getMaxX(),  maxy = 0.5 * getMaxY();
  fill (Color(0, 0, 0, 0xFF));
  const int w = getMaxX();
  const int h = getMaxY();
  const real m = 0.5 * (double) ((w < h) ? w : h) - 20.0;
  const real zoom = (parent->sim_data.R2 != 0.0) ? m / parent->sim_data.R2 : 1.0;
  real rad = zoom, mst = zoom;
  if (rad < m and rad > 20.0) {
    mst = rad;
    setColor(Color(0x7F, 0x7F, 0));
    circ (FPoint(0,0), rad);
  }
  rad *= 10;
  if (rad < m) {
    mst = rad;
    setColor(Color(0x00, 0x00, 0xFF));
    circ (FPoint(0,0), rad);
  }
  rad *= 10;
  if (rad < m) {
    mst = rad;
    setColor(Color(0xFF, 0x00, 0xFF));
    circ (FPoint(0,0), rad);
  }
  setColor(Color(0x40, 0x40, 0x40));
  const real mstx = mst,  msty = mst;
  for (real x=mstx; x<maxx; x+=mstx) { line (FPoint(x,-maxy), FPoint(x,+maxy), true); line (FPoint(-x,-maxy), FPoint(-x,+maxy), true); }
  for (real y=msty; y<maxy; y+=msty) { line (FPoint(-maxx,y), FPoint(+maxx,y), true); line (FPoint(-maxx,-y), FPoint(+maxx,-y), true); }
  setColor(Color(0x8F, 0x8F, 0));
  line (FPoint (0, -maxy), FPoint (0, maxy));
  line (FPoint (-maxx, 0), FPoint (maxx, 0));
}

/******************************************************************************************************/
inline void ForeGround::lineTo (const int x0, const int y0) {
  const IPoint ip (x0, y0);
  poly_tmp.points.push_back (ip);
}
void ForeGround::resize (int w, int h) {
  width  = w;
  height = h;
  zoom = (parent->sim_data.R2 != 0.0) ? (0.5 * (double) ((width < height) ? width : height - 20)) / parent->sim_data.R2 : 1.0;
  old_position = FPoint (parent->sim_data.R1, 0) * zoom;
  if (parent->sim_st == SS_DEFINE) {
    matrix = parent->canvas.def_matrix;
    data.planet = 0;
  }
  else {
    ips_speed();
    matrix = parent->canvas.sim_matrix;
    setColor(Color(0x00, 0xFF, 0));
    data.planet = 1;
    DiffEqBc();
  }
}
void ForeGround::lineTo (const FPoint & b) {
  const FPoint bp (matrix * b);
  const int x0 = (const int) round (bp.x);
  const int y0 = (const int) round (bp.y);
  lineTo (x0, y0);
}
static double r_12_otr (const SimData & sd, const bool high = true) {
  const double sign = high ? 1.0 : -1.0;
  const double S = sd.S;
  const double J = sd.J;
  const double D = 1.0 - (3.0 * (S/J) * (S/J));
  if (D < 0.0) return 1.0;
  const double result = (J*J/S)*(1.0 + sign * sqrt (D));
  return result;
}
static double r_12_newton (const SimData & sd) {
  return 2.0 * sd.J * sd.J / sd.S;
}
static const double resize_x (const double r, const double maxx) {
  return maxx * log(r) / log(1000.0);
}
void ForeGround::cross (const FPoint & p) {
  const double x = p.x;
  const double y = p.y;
  const double len = 10.0;
  do {
    begin (2);
    FPoint b(x, y - len * matrix.im22()), e(x, y + len * matrix.im22());
    lineTo(b);
    lineTo(e);
    end();
  } while (false);
  do {
    begin (2);
    FPoint b(x - len, y), e(x + len, y);
    lineTo(b);
    lineTo(e);
    end();
  } while (false);
}
static bool sign_changed (const real e, const SimData & sim_data, bool & os) {
  bool result = false;
  const bool sign = (e > sim_data.E) ? true : false;
  if (sign xor os) result = true;
  os = sign;
  return result;
}
void ForeGround::graph (const real step, const bool otr) {
  SimData & sim_data = parent->sim_data;
  const real maxx = getMaxX() - 20.0,  maxy = 0.5 * getMaxY();
  begin (3);
  real n = 0, r = 1.0, y = ComputePotential (r, otr);
  FPoint b (n, 0);
  lineTo (b);
  for (;;) {
    y = ComputePotential (r, otr);
    if (!(sim_data.OTR_used xor otr)) {
      if (sign_changed(y, sim_data, OS)) r_e.push_back (r);
    }
    if (y >= +maxy) y = +maxy;
    if (y <= -maxy) y = -maxy;
    const FPoint e (n, y);
    lineTo (e);
    r *= step;
    n += 1.0;
    if (n >= maxx) break;
  }
  //printf ("r=%e\n", r);
  end ();
}
void ForeGround::set_roots () {
  SimData & sim_data = parent->sim_data;
  const real r0 = r_12_newton (sim_data);
  const real p0 = ComputePotential (r0, false);
  const real r1 = r_12_otr (sim_data, false);
  const real r2 = r_12_otr (sim_data, true);
  const real p1 = ComputePotential (r1, true);
  const real p2 = ComputePotential (r2, true);
  roots.r0 = FPoint (r0, p0);
  roots.r1 = FPoint (r1, p1);
  roots.r2 = FPoint (r2, p2);
  // printf("extreme [%f:%f], [%f:%f]\n", r1, p1, r2, p2);
}
void ForeGround::eline (const FPoint & b, const FPoint & e) {
  const real len = 10 * matrix.im22();
  const int w = 4;
  FPoint tb(b.x, b.y+len), te(b.x, b.y-len);
  begin (w);
  lineTo(tb); lineTo(te);
  end();
  FPoint xb(e.x, e.y+len), xe(e.x, e.y-len);
  begin (w);
  lineTo(xb); lineTo(xe);
  end();
  begin (w);
  lineTo(b); lineTo(e);
  end();
}


void ForeGround::drawings () {
  if (parent->sim_st == SS_DEFINE) defines ();
  else {
    simulation();
  }
}
void ForeGround::defines() {
  data.lenght = 0; data.data.clear();
  
  const real maxx = getMaxX() - 20.0;
  const real step = exp ((log (1.0e3)) / maxx);   // 1 - 1000
  set_roots ();

  SimData & sim_data = parent->sim_data;
  // printf("OTR: %s\n", OTR_used ? "true": "false");
  OS = false;
  if (sim_data.OTR_used) {
    if (roots.r1.y < 0) sim_data.E = (sim_data.E0 * (roots.r2.y - roots.r1.y)) + roots.r1.y;
    else                sim_data.E = (sim_data.E0 * (roots.r2.y));
  } else {
    sim_data.E = (sim_data.E0 * (roots.r0.y));
  }
  r_e.clear();
  
  setColor(Color(0x00, 0xFF, 0));
  graph (step, false);
  setColor(Color(0xFF, 0x3F, 0));
  graph (step, true);
  
  setColor (Color (0xFF, 0xFF, 0));
  cross (FPoint (resize_x (roots.r0.x, maxx), roots.r0.y));
  cross (FPoint (resize_x (roots.r1.x, maxx), roots.r1.y));
  cross (FPoint (resize_x (roots.r2.x, maxx), roots.r2.y));
  
  setColor(Color(0xFF, 0x0, 0xFF));
  // printf("size = %ld\n", r_e.size());
  sim_data.R1 = 2.0    * sim_data.S;
  sim_data.R2 = 1000.0 * sim_data.S;
  FPoint b (0, sim_data.E), e(maxx, sim_data.E);
  if (sim_data.E0 == 1.0) {
    if (sim_data.OTR_used) {
      b.x = e.x = resize_x (roots.r2.x, maxx);
      sim_data.R1 = sim_data.R2 = roots.r2.x;
    } else {
      b.x = e.x = resize_x (roots.r0.x, maxx);
      sim_data.R1 = sim_data.R2 = roots.r0.x;
    }
  } else {
    switch (r_e.size()) {
      case 3: b.x = resize_x (r_e[1], maxx); e.x = resize_x (r_e[2], maxx); sim_data.R1 = r_e[1]; sim_data.R2 = r_e[2]; break;
      case 2: b.x = resize_x (r_e[1], maxx); sim_data.R1 = r_e[1]; break;
      case 1: if (sim_data.OTR_used) { b.x = resize_x (roots.r1.x, maxx); e.x = resize_x (r_e[0], maxx); sim_data.R1 = roots.r1.x; sim_data.R2 = r_e[0]; } break;
      case 0: if (sim_data.OTR_used) { b.x = resize_x (roots.r1.x, maxx); sim_data.R1 = roots.r1.x; } break;
      default: break;
    }
  }
  eline (b, e);
  
  data.lenght = data.data.size();
}
void ForeGround::simulation() {
  const int speed = parent->sim_data.speed;
  data.lenght = 0; data.data.clear();
  begin (1);
  FPoint pt = old_position;
  lineTo (pt);
  for (int i=0; i<speed; i++) {
    pt = DiffEqPass() * zoom;
    lineTo (pt);
  }
  old_position = pt;
  end ();
  
  data.lenght = data.data.size();
}
