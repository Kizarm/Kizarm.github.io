#ifndef ELEMENT_H
#define ELEMENT_H

#include <vector>
#include <string>
#include <functional>

extern std::string FmtString (const char * fmt, ...);

struct Action {
  int length;
  std::string code;
  Action () {
    length = 0; code = std::string ("console.log (\'callback error\');\n");
  }
  Action (const std::string cd) {
    code = cd, length = cd.length() ;
  }
  Action (const Action & o) {
    length = o.length; code = o.code;
  }
  Action & operator= (const Action & o) {
    length = o.length; code = o.code;
    return * this;
  }
};
class HtmlElement;
class Container;
typedef std::function<Action(HtmlElement * e, const std::string & val, const bool init)> ActionCallBack;

class HtmlTag {
    std::string name;
    std::string value;
    HtmlTag * next;
  public:
    HtmlTag (const char * n, const char * v) : name(n), value(v) { next = nullptr; }
    ~HtmlTag () { if (next) delete next; }
    std::string getName  () { return name;  }
    std::string getValue () { return value; }
    void add (HtmlTag * tag) {
      if (next) next->add (tag);
      else next = tag;
    };
    std::string to_string () {
      std::string result = ' ' + name + "=\"" + value + '\"';
      if (next) result += next->to_string();
      return result;
    }
};
class HtmlElement {
    Container   *   parent;
    std::string     name;
    std::string     value;
    std::string     Id;
    HtmlElement *   atte;
    ActionCallBack  atCb;
    HtmlTag     *   tags;
    HtmlElement *   next;
    HtmlElement *   down;
  public:
    HtmlElement (const char * n, const char * v = nullptr, Container * p = nullptr);
    virtual ~HtmlElement () { if (tags) delete tags; if (next) delete next; if (down) delete down; };
    virtual std::string end_string () {
      std::string result = "</" + name + '>';  return result;
    }
    void setCb (ActionCallBack cb) {
      atCb = cb;
    }
    virtual Action action (const std::string & val, const bool init = false) {
      if (atCb) return atCb (this, val, init);
      return Action();
    }
    virtual std::string disable (const bool yes = true);
    Container * getParent () { return parent; }
    std::string getValue () { return value; }
    void        setValue (const std::string n) { value = n; }
    std::string getId () { return Id; }
    HtmlElement * getAttach () { return atte; }
    void Attach (HtmlElement * other) { atte = other; };
    std::string to_string ();
    void addTag (HtmlTag * tag) {
      if (tag->getName() == std::string ("id")) Id = tag->getValue();
      if (tags) tags->add(tag);
      else      tags = tag;
    }
    void append (HtmlElement * e) {
      if (next) next->append(e);
      else next = e;
    }
    void insert (HtmlElement * e) {
      if (down) down->append(e);
      else down = e;
    }
};
class Text : public HtmlElement {
  public:
    Text (const char * n, const char * v, Container * p = nullptr);
    virtual ~Text () {}
    std::string end_string () override;
};
class Button : public HtmlElement {
  public:
    Button (const char * n, Container * p);
    virtual ~Button () {}
    std::string end_string () override;
};
class Slider : public HtmlElement {
  public:
    Slider (Container * p, const int min = 0, const int max = 100);
    virtual ~Slider () {}
    std::string end_string () override;
};
class SliderRow {
  HtmlElement   * root;
  Container     * parent;
  const char    * name;
  const int       min, max, begin;
  public:
    SliderRow (Container * p, const char * n, const int min = 0, const int max = 100, const int begin = 0);
    HtmlElement * Init ();
    HtmlElement * getRoot () { return root; }
  protected:
};
class InputFloat : public HtmlElement {
  public:
    InputFloat (Container * p, const double min = 0.0, const double max = 100.0, const double step = 1.0, const double value = 1.0);
    virtual ~InputFloat () {};
    std::string end_string () override;
};
class InputFloatSpan {
  HtmlElement   * root;
  Container     * parent;
  const char    * name;
  const double    min, max, step, begin;
  public:
    InputFloatSpan (Container * p, const char * n, const double min = 0.0, const double max = 100.0, const double step = 1.0, const double value = 1.0);
    HtmlElement * Init ();
    HtmlElement * getRoot () { return root; }
  protected:
};
#endif // ELEMENT_H
