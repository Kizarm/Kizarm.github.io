#ifndef SOLVERPUBLIC_H
#define SOLVERPUBLIC_H
#include "math.h"
typedef double real;

struct FPoint {
  real x,y;
  FPoint () : x(0), y(0) {};
  FPoint (const real x0, const real y0) : x(x0), y(y0) {};
  FPoint (const FPoint & other) : x(other.x), y(other.y) {};
  FPoint & operator= (const FPoint & other)  { x = other.x; y = other.y; return * this; };
  FPoint   operator* (const real par) const { FPoint res (x*par, y*par); return res; };
};
struct SimData {
  real S, J, E, E0;
  real R1, R2, step;
  int  speed;
  bool OTR_used, dir;
  SimData () {
    S=1.0; J=2.0; E=0.0;
    R1 = 2.0; R2 = 2.0; speed = 5; step = 0.001;
    E0 = 1.0; OTR_used = true; dir = true;
  }
};
extern SimData SimulationParameters;
extern const real ComputePotential (const real r, const bool otr);
extern FPoint DiffEqPass ();
extern void   DiffEqBc ();
static inline void ips_speed () {
  const real A0 = SimulationParameters.R1 + SimulationParameters.R2;
  const real A3 = A0 * A0 * A0;
  SimulationParameters.step = 1.0e-5 * sqrt (A3);
}

#endif // SOLVERPUBLIC_H
