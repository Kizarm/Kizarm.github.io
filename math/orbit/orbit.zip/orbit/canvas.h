#ifndef CANVAS_H
#define CANVAS_H
#include <stdint.h>
#include <stdlib.h>
#include "solverpublic.h"

class Container;
class Matrix {
  real m11, m12, m21, m22, ox, oy;
  public:
    Matrix (const real a11 = 1.0, const real a12 = 0.0, const real a21 = 0.0, const real a22 = -1.0, const real ax = 0, const real ay = 0) :
    m11(a11), m12(a12), m21(a21), m22(a22), ox(ax), oy(ay) {};
    const FPoint operator* (const FPoint & right) const {
      const real x = m11 * right.x + m12 * right.y + ox;
      const real y = m21 * right.x + m22 * right.y + oy;
      const FPoint result (x, y);
      return result;
    }
    real im22 () { return 1.0/m22; };
};

union Color {
  struct {
    uint8_t r,g,b,a;
  };
  uint32_t color;
  Color () {color = 0u; };
  Color (const uint8_t rr, const uint8_t gg, const uint8_t bb, const uint8_t aa = 0xFF) : r(rr), g(gg), b(bb), a(aa) {};
  Color (const uint32_t c) : color(c) {};
  Color (const Color & other) { color = other.color; };
  Color & operator= (const Color & other) { color = other.color; return * this; };
  const operator uint32_t () const { return color; };
  std::string to_string ();
};

class Canvas {
  int     width, height;
  Color   outpixel;
  Color   current;
  Matrix  matrix;
  Color * data;
  public:
    Container * parent;
  public:
    Canvas (Container * p);
    ~Canvas();
    void resize (const int w, const int h);
    uint8_t * getData () const { return reinterpret_cast<uint8_t*>(data); };
    size_t    getSize () const { return (width * height * sizeof(Color)); };
    int       getMaxX () const { return width;  };
    int       getMaxY () const { return height; };
    void fill (const Color & c);
    void setColor (const Color & c) { current = c; };
    void line (const int x0, const int y0, const int x1, const int y1, const bool doted = false);
    void line (const FPoint& begin, const FPoint& end, const bool doted = false);
    void rect (const int x0, const int y0, const int x1, const int y1);
    
    void circ (const FPoint & center, const real radius);
  protected:
    Color & at (const int x, const int y);
    bool bound (const int x, const int y) const;
};

struct IPoint {
  int x, y;
  IPoint (const int x0 = 0, const int y0 = 0) : x(x0), y(y0) {}
};
struct PolyLine {
  int lenght, width;
  std::string         style;
  std::vector<IPoint> points;
  PolyLine () : lenght(0), width(2), style(std::string("#FF00FF")) { points.clear(); }
};
struct ForeGroundData {
  int                   lenght, planet;
  std::vector<PolyLine> data;
  ForeGroundData () : lenght(0), planet(0) {data.clear();};
};
/***********************************/
class BackGround : public Canvas {
  public:
    BackGround (Container * p) : Canvas (p) {};
    virtual ~BackGround (){};
    void drawings   ();
    void defines    ();
    void simulation ();
};
struct SimRoots {
  FPoint r0;
  FPoint r1, r2;
};
class ForeGround {
  Container * parent;
  int         width, height;
  Color       current;
  Matrix      matrix;
  ForeGroundData data;
  PolyLine    poly_tmp;
  SimRoots    roots;
  std::vector<real> r_e;
  bool        OS;
  
  FPoint      old_position;
  double      zoom;
  public:
    ForeGround (Container * p) : width(640), height(480),
    current(0xFF000000), matrix (1.0, 0.0, 0.0, -1.0, (real) (20.0), 0.5 * (real) (height))  { parent = p; old_position = FPoint(0,0); zoom = 1.0; };
    ~ForeGround (){};
    void resize (int w, int h);
    int  getMaxX () const { return width;  };
    int  getMaxY () const { return height; };
    void setColor (const Color & c) { current = c; };
    void drawings   ();
    void defines    ();
    void simulation ();
    ForeGroundData & getData () { return data; };
    void lineTo (const FPoint & begin);
  protected:
    void lineTo (const int x0, const int y0);
    void begin (const int w = 1) {
      poly_tmp.lenght = 0;
      poly_tmp.style  = current.to_string();
      poly_tmp.width  = w;
      poly_tmp.points.clear();
    }
    void end () {
      poly_tmp.lenght = poly_tmp.points.size();
      data.data.push_back (poly_tmp);
    }
    void cross (const FPoint & p);
    void graph (const real step, const bool otr);
    void set_roots ();
    void eline (const FPoint & b, const FPoint & e);
};
/*******************************************************************/
struct Common {
  Container * parent;
  int maxx, maxy;
  BackGround * bg;
  ForeGround * fg;
  
  Matrix uni_matrix;
  Matrix def_matrix;
  Matrix sim_matrix;
  Common (Container * p) : def_matrix(), sim_matrix() {
    parent = p;  bg = new BackGround (p);  fg = new ForeGround (p);
  }
  void resize (int w, int h) {
    maxx = w; maxy = h;
    uni_matrix = Matrix (1.0, 0.0, 0.0, -1.0,                 (real) (20.0), 0.5 * (real) (maxy));
    def_matrix = Matrix (1.0, 0.0, 0.0, -5.0 * (real) (maxy), (real) (20.0), 0.5 * (real) (maxy));
    sim_matrix = Matrix (1.0, 0.0, 0.0, -1.0, 0.5 * (real) (maxx), 0.5 * (real) (maxy));
    fg->resize (w,h);
    bg->resize (w,h);
    bg->drawings();
    fg->drawings();
  }
  ~Common () {
    delete bg;
    delete bg;
  }
};


#endif // CANVAS_H
