#ifndef CONTAINER_H
#define CONTAINER_H
#include "element.h"
#include "canvas.h"

enum SIMULATION_STATES : int {
  SS_DEFINE = 0, SS_STOP, SS_RUN
};

class Container {
  HtmlElement * root;
  int  order;
  std::vector<HtmlElement*> ordered;
  std::vector<HtmlElement*> initialized;
  std::vector<HtmlElement*> settings;
  public:
    Common            canvas;
    SIMULATION_STATES sim_st;
    SimData         & sim_data;
    HtmlElement     * butDefin;
    HtmlElement     * butStart;
    HtmlElement     * butReset;
    HtmlElement     * viewParm;
  public:
    Container ();
    ~Container ();
    Action back (const int index, const std::string & input);
    std::string to_string ();
    std::string InitAll ();
    /////////////////////////// Helpers //////////////////////////////
    int getOrder () { return order; };
    HtmlElement * getOrdered (const int n) { return ordered [n]; };
    void addOrdered (HtmlElement * e) { ordered.push_back(e); order += 1; };
    void addInitialized (HtmlElement * e) { initialized.push_back(e); };
    void addSettings (HtmlElement * e) { settings.push_back(e); };
    std::string disableSettings (const bool yes = true);
  protected:
    HtmlElement * slider_table ();
    HtmlElement * button_anime ();
    HtmlElement * button_type  ();
    HtmlElement * button_start ();
    HtmlElement * button_clear ();
    
};

#endif // CONTAINER_H
