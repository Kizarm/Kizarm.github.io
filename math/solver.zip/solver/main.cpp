#include <stdio.h>
#include <math.h>
#include <string>
#include <string.h>
#include "solver.h"

using namespace std;
template<class T, size_t N> constexpr size_t SIZE (T (&)[N]) { return N; }


/** TEST - harmonický oscilátor - 2 výrazy z Hamiltonových rovnic.
 *  t, w[0] = x, w[1] = p
 *  F1: dx/dt = +p * omega
 *  F2: dp/dt = -x * omega
 *  bc: t = 0: x0 = 0, p0 = 1
 * */
const real omega = 2.0 * M_PI * 0.5;

static const char * plot_command =
"set terminal pdf size 15,4\n"
"set output \'%s.pdf\'\n"
"set grid\n"
"set key box opaque font \",16\"\n"
"set xlabel \"time\" font \",16\"\n"
"set ylabel \"a(t)\" font \",16\"\n"
"\n"
"plot \'x.dat\' u 1:2 w l lw 2 t \'x\',\\\n"
"     \'x.dat\' u 1:3 w l lw 2 t \'p\'\n";

static void plot (const char * name) {  
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  fprintf (cmd, plot_command, name);
  fflush  (cmd);
  pclose  (cmd);
}

int main () {
  const real w0 [] = {1.0, 0.0};        // Počet počátečních podmínek musí odpovídat počtu rovnic...
  const unsigned N = SIZE (w0);         // čili určuje celkový rozsah výpočtu.

  const Point<N> bc (0.0, w0);
  real (*pf[N])(const Point<N> & p) = { // funkce lze předat jako lambdy...
  [](const Point<N> & z) -> auto {      // F1
      real p = z.w[1];
      return +p * omega;
  },
  [](const Point<N> & z) -> auto {      // F2
      real x = z.w[0];
      return -x * omega;
  }};

  RungeKutta<N> solver (pf, bc, 0.01, 1000);
  // solver vyhodí celý vektor dat, tedy časový průběh
  const vector<Point<N>> & s = solver.solve();
  
  FILE * out = fopen ("x.dat", "w");
  for (auto p: s) {
    fprintf (out, "%6.2f", p.t);
    for (auto k: p.w) fprintf (out, " %10.6f", k);
    fprintf (out, "\n");
  }
  plot ("img");
  
  return 0;
}

