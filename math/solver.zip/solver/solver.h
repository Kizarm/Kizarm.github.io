#ifndef SOLVER_H
#define SOLVER_H

#include <vector>

typedef double real;

template<const unsigned N> struct Point {
  Point (const real t0, const real w0 [N]) : t(t0) {
    for (unsigned n=0; n<N; n++) w[n] = w0[n];
  };
  Point (const Point & other) : t(other.t) {
    for (unsigned n=0; n<N; n++) w[n] = other.w[n];
  }
  real t;
  real w[N];
};

/// Solver metodou Runge-Kutta
template<const unsigned N> class RungeKutta {
  const real            h;            //!< krok metody
  const int             points;       //!< pocet kroků
  const Point<N>        p0;           //!< holder pro počáteční podmínky
  real (*pf[N])(const Point<N> & p);  //!< počítané funkce
  std::vector<Point<N>> data;         //!< data
  public:
    /// konstruktor
    /// @param F Výpočetní objekt
    /// @param step krok metody
    /// @param pts  počet kroků
    RungeKutta(real (*F[N])(const Point<N> & p), const Point<N> & bc, const real step, const unsigned pts) :
      h(step), points(pts), p0(bc) {
      for (unsigned n=0; n<N; n++) pf[n] = F[n];
    };
    /// vlastní solver @param direction false pak běží pozpátku v čase
    const std::vector<Point<N>> & solve (const bool direction=true) {
      const real hh = direction ? +h : -h;
      data.clear();
      
      Point<N> p(p0);
      data.push_back(p);
      
      for (int n = 0; n < points; n++) {       //Runge-Kutta Nethod 4.order
        real     k1[N];
        for (unsigned k=0; k<N; k++) k1  [k]  = pf[k](p);
        Point<N> p2(p); p2.t += 0.5 * hh;
        for (unsigned k=0; k<N; k++) p2.w[k] += 0.5 * hh * k1[k];
        real     k2[N];
        for (unsigned k=0; k<N; k++) k2  [k]  = pf[k](p2);
        Point<N> p3(p); p3.t += 0.5 * hh;
        for (unsigned k=0; k<N; k++) p3.w[k] += 0.5 * hh * k2[k];
        real     k3[N];
        for (unsigned k=0; k<N; k++) k3  [k]  = pf[k](p3);
        Point<N> p4(p); p4.t += hh;
        for (unsigned k=0; k<N; k++) p4.w[k] += hh * k3[k];
        real     k4[N];
        for (unsigned k=0; k<N; k++) k4  [k]  = pf[k](p4);    
        p.t += hh;
        for (unsigned k=0; k<N; k++)  p.w[k] += (hh / 6.0) * (k1[k] + 2.0 * k2[k] + 2.0 * k3[k] + k4[k]);
        
        data.push_back(p);
      }
      return data;
    }
};

#endif // SOLVER_H
