#include "libwasm.h"
#include "Canvas.h"
////////////////////////////////////////////////////////////////////////////////////
extern "C" {
  extern void __wasm_call_ctors();
  extern char __data_end;
  extern char __heap_base;
  extern char __global_base;
  extern char __memory_base;
  extern char __table_base;
  extern void EXPORT(init) (const int memlen);
  extern void EXPORT(InitCanvas) (const int x, const int y);
  extern void EXPORT(WheelEvt)   (const int dir, const int px, const int py);
  extern void EXPORT(KeyAction)  (const int key);
  extern void IMPORT(PlotCanvas) (const uint8_t* ptr, int len);
};
void init (const int memlen) {
  _HEAP_MAX = reinterpret_cast<char*> (memlen);   // před prvním voláním malloc() - může být i v konstruktorech
  __wasm_call_ctors();                            // nutné volání statických konstruktorů pokud máme statické třídy
  puts ("*** Module initialized ***\n");
}
static Canvas * canvas = nullptr;

void InitCanvas (const int x, const int y) {
  printf("Image: x=%d, y=%d\n", x, y);
  if (canvas) { delete canvas; canvas = nullptr; }
  canvas = new Canvas (x, y);
  canvas->setPalette  (2);
  canvas->processImage();
  PlotCanvas (canvas->getData(), canvas->getSize());
}
void WheelEvt (const int dir, const int px, const int py) {
  if (!canvas) return;
  // printf("dir=%d, px=%d, py=%d\n", dir, px, py);
  const bool bd = dir > 0 ? true : false;
  canvas->setCoord (bd, px, py);
  canvas->processImage();
  PlotCanvas (canvas->getData(), canvas->getSize());
}
void KeyAction (const int key) {
  if (key < 0) return;
  if (!canvas) return;
  // printf("palette = %d\n", key);
  if (key < 10) canvas->setPalette (key);
  else          canvas->Reset();
  canvas->processImage();
  PlotCanvas (canvas->getData(), canvas->getSize());
}
