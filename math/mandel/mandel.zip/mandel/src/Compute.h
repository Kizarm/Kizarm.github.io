#ifndef COMPUTE_H
#define COMPUTE_H

#include <QThread>
#include <QImage>
#include <QMutex>
#include "Canvas.h"

class Compute : public QThread {
    Q_OBJECT
  public:
    explicit Compute();
    virtual ~Compute();
    void paint (Canvas * c) {
      canvas = c;
      if (isRunning()) return;
      start ();
    }
    void img_description (const MandelParam * data);
  signals:
    void img_finished ();
    void img_descr (QString);
  protected:
    void run () override;
  private:
    Canvas * canvas;
};

#endif // COMPUTE_H
