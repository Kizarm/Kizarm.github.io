#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class Ui_MainWindow;

class MainWindow : public QMainWindow {
    Q_OBJECT
  public:
    MainWindow  (QWidget *parent = 0);
    ~MainWindow ();
  protected:
  public slots:
  private:
    Ui_MainWindow * ui;
};

#endif // MAINWINDOW_H
