#ifdef __wasm__
#include "libwasm.h"
#else
#define IMPORT
#endif
#include "Canvas.h"
extern "C" void IMPORT(Description) (const void * ptr, int len);
static constexpr double dabs (const double a) { return a < 0.0 ? -a : +a; }
static constexpr double D_PI = 2.0 * 3.14159265358979323846;
static constexpr double sin (const double x) {
  if (x > D_PI) return sin (x - D_PI);
  double result (0.0), element(x), divider(1.0);
  constexpr double eps = 1.0e-9;      // maximální chyba výpočtu
  const double aa = - (x * x);
  for (;;) {
    result  += element;
    if (dabs  (element) < eps) break;
    divider += 1.0;
    double fact = divider;
    divider += 1.0;
    fact    *= divider;
    element *= aa / fact;
  }
  return result;
}
static constexpr double dZoom = 1.0905077326652577;
static constexpr double iZoom = 1.0 / dZoom;

void Canvas::setCoord(const bool zoom, const int px, const int py) {
  const double oldScale  = scaleFactor;
  if (zoom) scaleFactor *= dZoom;
  else      scaleFactor *= iZoom;
  const int hx = mx >> 1, hy = my >> 1;
  const int x = px - hx, y = py - hy;
  const double ds = oldScale - scaleFactor;
  const double cx = centerX + x * ds;
  const double cy = centerY + y * ds;
  centerX = cx;
  centerY = cy;
}

void Canvas::setPalette(const int palette) {
  for (int i = 0; i < ColormapSize; i++) {
    Color rgbn;
    switch (palette) {
    case 0:
      rgbn.r=i<<1;
      rgbn.g=i<<1;
      rgbn.b=i<<1;
      break;
    case 1:
      rgbn.r=i*10.0;
      rgbn.g=127+127.0*sin (i/30.0);
      rgbn.b=127+127.0*sin (i/10.0);
      break;
    case 2:
      rgbn.r=127+127.0*sin (i/30.0);
      rgbn.g=i*10;
      rgbn.b=127+127.0*sin (i/10.0);
      break;
    case 3:
      rgbn.r=127+127.0*sin (i/30.0);
      rgbn.g=127+127.0*sin (i/10.0);
      rgbn.b=i*10.0;
      break;
    case 4:
      rgbn.r=127+127.0*sin (i/30.0);
      rgbn.g=i*20;
      rgbn.b=127+127.0*sin (i/10.0);
      break;
    case 5:
      rgbn.r=i*5;
      rgbn.g=255-i*7;
      rgbn.b=i*9;
      break;
    case 6:
      rgbn.r=127+127.0*sin (i/30.0);
      rgbn.g=i*20;
      rgbn.b=127-127.0*sin (i/30.0);
      break;
    case 7:
      rgbn.r=127-127.0*sin (i/30.0);
      rgbn.g=i*10;
      rgbn.b=127+127.0*sin (i/10.0);
      break;
    case 8:
      rgbn.r=127+127.0*sin (i/30.0);
      rgbn.g=127-127.0*sin (i/10.0);
      rgbn.b=i*10;
      break;
    case 9:
      rgbn.r=127-127.0*sin (i/10.0);
      rgbn.g=i*20;
      rgbn.b=127+127.0*sin (i/20.0);
      break;
    default: break;
    }
    rgbn.a = 0xff;

    colormap [i] = rgbn.c;
  }
}
void Canvas::processImage () {
  const int halfHeight = my >> 1, halfWidth = mx >> 1;
  const int MaxIterations = 128;
  const int Limit = 4;
  for (int y = -halfHeight; y < halfHeight; ++y) {
    const double ay = centerY + (y * scaleFactor);
    for (int x = -halfWidth; x < halfWidth; ++x) {
      const double ax = centerX + (x * scaleFactor);
      int numIterations = 0;
      double zx=0,zy=0;
      do {
        ++numIterations;
        double a2 = zx * zx;
        double b2 = zy * zy;
        if ( (a2 + b2) > Limit) break;
        zy = 2.0 * zx * zy + ay;
        zx = a2 - b2 + ax;
      } while (numIterations < MaxIterations);
      const int xx = x + halfWidth, yy = y + halfHeight;
      if (numIterations < MaxIterations) {
        at (xx, yy).c = colormap[numIterations % ColormapSize];
      } else {
        at (xx, yy).c = 0xFF000000;
      }
    }
  }
  const MandelParam tmp = { scaleFactor, centerX, -centerY };
  Description (&tmp, 3);
}
