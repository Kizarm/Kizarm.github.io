#ifndef CANVAS_H
#define CANVAS_H
#include <stdint.h>
static constexpr int ColormapSize = 512;
union Color {
  struct {
   uint8_t r, g, b, a;
  };
  uint32_t c;
};
struct MandelParam {
  double z, x, y;
};
static constexpr MandelParam origParam = { 0.005, -0.5, 0.0 };
/**
 */
class Canvas {
  const int mx, my, wlen;
  Color   * color;
  uint32_t  colormap[ColormapSize];
  double    scaleFactor, centerX, centerY;
  public:
    explicit Canvas (const int x, const int y) noexcept : mx(x), my(y), wlen(x * y) {
      color = new Color [wlen];
      Reset();
    }
    ~Canvas () {
      delete [] color;
    }
    void Reset () {
      scaleFactor = origParam.z;
      centerX     = origParam.x;
      centerY     = origParam.y;
    }
    Color & at (const int x, const int y) {
      const int index = y * mx + x;
      return color [index < wlen ? index : 0];
    }
    uint8_t * getData () const {
      return reinterpret_cast<uint8_t*>(color);
    }
    int getSize () const {
      return mx * my * sizeof (Color);
    }
    int getX () { return mx; }
    int getY () { return my; }
    void setCoord     (const bool zoom, const int px, const int py);
    void setPalette   (const int palette);
    void processImage ();
};

#endif // CANVAS_H
