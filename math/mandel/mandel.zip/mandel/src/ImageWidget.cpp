#include <QPaintEvent>
#include <QResizeEvent>
#include <QKeyEvent>
#include <QWheelEvent>
#include <QPainter>
#include <QSize>
#include "ImageWidget.h"

ImageWidget::ImageWidget (QWidget * parent, Qt::WindowFlags f) : QWidget (parent, f), compute(), label(nullptr) {
  const QSize s = size();
  const int x = s.width(), y = s.height();
  canvas = new Canvas (x, y);
  connect (& compute, SIGNAL(img_finished()), this, SLOT(update()));
  connect (& compute, SIGNAL(img_descr(QString)), this, SLOT(Description(QString)));
  canvas->setPalette (2);
  compute.paint (canvas);
}
ImageWidget::~ImageWidget() {
}
void ImageWidget::Description (QString s) {
  if (label) label->setText (s);
}
void ImageWidget::paintEvent (QPaintEvent * event) {
  QRectF r = event->rect();
  QPainter p (this);
  p.fillRect(r, QBrush (Qt::black, Qt::SolidPattern));
  QImage img (canvas->getData(), canvas->getX(), canvas->getY(), QImage::Format_ARGB32);
  QRectF s = img.rect();
  p.drawImage (r, img, s);
}
void ImageWidget::resizeEvent (QResizeEvent * event) {
  const QSize s = event->size();
  const int x = s.width(), y = s.height();
  if (canvas) delete canvas;
  canvas = new Canvas (x, y);
  compute.paint (canvas);
}
void ImageWidget::wheelEvent  (QWheelEvent * event) {
  QPoint pos = event->pos ();
  QPoint num = event->angleDelta();
  const bool z = num.y() < 0 ? true : false;
  canvas->setCoord (z, pos.x(), pos.y());
  compute.paint (canvas);
}
static int KeyToInt (const int key) {
  int val = -1;
  switch (key) {
    case Qt::Key_0 : val = 0; break;
    case Qt::Key_1 : val = 1; break;
    case Qt::Key_2 : val = 2; break;
    case Qt::Key_3 : val = 3; break;
    case Qt::Key_4 : val = 4; break;
    case Qt::Key_5 : val = 5; break;
    case Qt::Key_6 : val = 6; break;
    case Qt::Key_7 : val = 7; break;
    case Qt::Key_8 : val = 8; break;
    case Qt::Key_9 : val = 9; break;
    case Qt::Key_Home  : val = 10; break;
    case Qt::Key_Return:
    case Qt::Key_Enter : val = 11; break;
    default  : break;
  }
  return val;
}
void ImageWidget::keyPressEvent (QKeyEvent * event) {
  const int n = KeyToInt (event->key());
  if (n <  0) return;
  if (n < 10) {
    canvas->setPalette (n);
    compute.paint (canvas);
  } else {
    canvas->Reset();
    compute.paint (canvas);
  }
}

