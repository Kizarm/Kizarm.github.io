#include <QDesktopWidget>
#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow (QWidget * parent)
  : QMainWindow (parent) {
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  ui->widget->setLabel (ui->label);
  setWindowTitle ("Lorenz");
  setWindowIcon  (QIcon(":ico"));
  connect (ui->actionExit, SIGNAL(triggered(bool)), this, SLOT(close()));
  ui->widget->setFocus();
}

MainWindow::~MainWindow () {
  delete ui;
}
/*********************************************/
#include <QApplication>

int main (int argc, char *argv[]) {
  QApplication a (argc, argv);
  MainWindow w;
  w.show();
  return a.exec();
}
