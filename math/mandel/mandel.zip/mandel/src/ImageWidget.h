#ifndef IMAGEWIDGET_H
#define IMAGEWIDGET_H

#include <QWidget>
#include <QLabel>
#include "Compute.h"
#include "Canvas.h"
class QPaintEvent;
class QResizeEvent;
class QKeyEvent;
class QWheelEvent;

class ImageWidget : public QWidget {
    Q_OBJECT
  public:
    explicit ImageWidget (QWidget* parent = 0, Qt::WindowFlags f = 0);
    virtual ~ImageWidget ();
    void setLabel (QLabel * l) { label = l; }
  public slots:
    void Description (QString s);
  protected:
    void paintEvent  (QPaintEvent  * event) override;
    void resizeEvent (QResizeEvent * event) override;
    void wheelEvent  (QWheelEvent  * event) override;
    void keyPressEvent (QKeyEvent  * event) override;
  private:
    Compute  compute;
    QLabel * label;
    Canvas * canvas;
};

#endif // IMAGEWIDGET_H
