#include <QPainter>
#include "Compute.h"

static Compute * ComputeInstance = nullptr;

extern "C" void Description (const void * ptr, int len);
void Description (const void * ptr, int len) {
  const MandelParam * data = reinterpret_cast<const MandelParam*>(ptr);
  (void) len;
  if (ComputeInstance) ComputeInstance->img_description (data);
}

Compute::Compute() : QThread() {
  ComputeInstance = this;
}

Compute::~Compute() {
}

void Compute::run() {
  if (!canvas) return;
  canvas->processImage ();
  emit img_finished();
}
void Compute::img_description (const MandelParam * data) {
  const int msize = 1024;
  char buffer [msize];
  snprintf  (buffer, msize, "Z=%g [X=%g : Y=%g]", data->z, data->x, data->y);
  QString s (buffer);
  emit img_descr (s);
}
