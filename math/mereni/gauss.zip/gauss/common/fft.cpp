/***************************************************************************
 *   Copyright (C) 2009 by Mrazik   *
 *   mraz@seznam.cz   *
 ***************************************************************************/
#include "fft.h"

FFT::FFT (const int len) {
  real ang = -M_PI;
  M = len;
  N = 1 << M;
  stab = new real  [M];
  ctab = new real  [M];
  for (int i=0; i<M; i++) {
    stab[i] = sin (ang);
    ctab[i] = cos (ang);
    ang *= 0.5;
  }
}

const int FFT::getN (void) const {
  return N;
}

// parametr order u tt. funkce je potreba pro rekursi
void FFT::FR (Complex * x, int order) const {
  int     k,l;                        // pomocne promenne
  Complex t;
  
  // zakladni pripad
  if (order == 0) {
    return;
  }
  order -= 1;
  const int Half = 1 << order;        // polovicni krok
  Complex even [Half];                // suda a
  Complex odd  [Half];                // licha cast
  for (k = 0; k < Half; k++) {        // vsechna vstupni data
    l  = 2*k;                         // suda
    even[k] = x[l];                   // dej do even
    l += 1;                           // licha
    odd [k] = x[l];                   // dej do odd
  }
  l = order;
  // rekurzivni volani teto funkce pro sudou a lichou cast
  FR (even, l);
  FR (odd,  l);

  Complex wk (1.0,0.0);                 // komplexni jednotka e^0i = 1 + 0i
  const Complex rej (ctab[l], stab[l]); // rej = e^i*ang
  for (k = 0; k < Half; k++) {
    t    = wk * odd[k];
    l    = k;
    x[l] = even[k] + t;               // y[dolni] = even + wk*odd
    l   += Half;
    x[l] = even[k] - t;               // y[horni] = even - wk*odd
    // "pootoceni" komplexni jednotky => wk *= rej (rychlejsi nez sin,cos)
    wk *= rej;
  }
}
void FFT::F (Complex * data) const {
  FR (data, M);
}
void FFT::T (Complex * data) const {
  int i;
  for (i = 0; i < N; i++)
    data[i].conj(); // komlexni sdruzeni
  FR(data, M);      // normalni FFT
  for (i = 0; i < N; i++) {
    data[i].conj(); // komlexni sdruzeni
    // normalizace se pri SFT nepouzije
    data[i].norm ((real) N);
  }
}

FFT::~FFT() {
  delete [] stab;
  delete [] ctab;
}


