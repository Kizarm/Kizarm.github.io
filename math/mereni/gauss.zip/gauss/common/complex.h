//
// C++ Interface: complex
//
// Description: 
//
//
// Author: Mrazik <mraz@seznam.cz>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef COMPLEX_H
#define COMPLEX_H

#include <math.h>
typedef double real;

/**
  \class Complex

  \author Mrazik <mraz@seznam.cz>

  \brief Komplexní číslo a práce s ním

  Všechny metody jsou jednoduché, takže
  je možné použít inline funkce.
 */
class Complex {
  private:
    real re;       //!< reálná část
    real im;       //!< imaginární část
  public:
    /**
     * Konstruktor
     * @param x reálná část
     * @param y imaginární část
     */
    Complex (real x, real y) {
      re = x;
      im = y;
    }
    /**
     * Default konstruktor (nastaví re=0.0,im=0.0)
     */
    Complex () {
      re = 0.0;
      im = 0.0;
    }
    /**
     * Kopírovací konstruktor
     * */
    Complex (const Complex & other) {
      re = other.re;
      im = other.im;
    }
    /**
     * Sčítání
     * @param x odkaz na sčítanec
     * @return součet
     */
    const Complex operator+ (const Complex & x) const {
      return (Complex (re+x.re,im+x.im));
    }
    /**
     * Odčítání
     * @param x odkaz na číslo, jež se odčítá
     * @return rozdíl
     */
    const Complex operator- (const Complex & x) const {
      return (Complex (re-x.re,im-x.im));
    }
    /**
     * Násobení
     * @param x odkaz na násobitel
     * @return součin
     */
    const Complex operator* (const Complex & x) const {
      return (Complex (re*x.re - im*x.im, re*x.im + im*x.re));
    }
    /**
     * Násobení reálným číslem
     * @param a odkaz na násobitel
     * @return součin
     */
    const Complex operator* (const real & a) const {
      return (Complex (a*re, a*im));
    }
    /**
     * Sumace
     * @param x přidávaná hodnota
     */
    Complex & operator+= (const Complex & x) {
      re += x.re;
      im += x.im;
      return * this;
    }
    /**
     * Odečítání
     * @param x odebíraná hodnota
     */
    Complex & operator-= (const Complex & x) {
      re -= x.re;
      im -= x.im;
      return * this;
    }
    Complex & operator*= (const Complex & x) {
      const real tre = re, tim = im;
      re = tre * x.re - tim * x.im;
      im = tre * x.im + tim * x.re;
      return * this;
    }
    /**
     * Návrat reálné části
     * @return reálná část
     */
    real getre (void) const {
      return re;
    }
    /**
     * Návrat imaginární části
     * @return imaginární část
     */
    real getim (void) const {
      return im;
    }
    /**
     * Konjunkce (komplexní sdružení)
     */
    void conj (void) {
      im = -im;
    }
    /**
     * Nastavení hodnoty na
     * @param x reálnou část
     * @param y imaginární část
     */
    void setc (const real x, const real y) {
      re = x;
      im = y;
    }
    /**
     * Podělí reálným číslem
     * @param n reálné číslo
     */
    void norm (const real n) {
      const real q = 1.0 / n;
      re *= q;
      im *= q;
    }
    /**
     * Kvadrát absolutní hodnoty
     * @return kvadrát absolutní hodnoty
     */
    const real squarabs (void) const {
      return (re*re + im*im);
    }
    /**
     * Absolutní hodnota
     * @return absolutní hodnota
     */
    const real abs (void) {
      return (sqrt (squarabs ()));
    }
};

#endif
