/***************************************************************************
 *   Copyright (C) 2009 by Mrazik   *
 *   mraz@seznam.cz   *
 ***************************************************************************/
#ifndef FFT_H
#define FFT_H

#include "complex.h"

/**
\class FFT

\author Mrazik <mraz@seznam.cz>

\brief Rychlá Fourierova transformace

Výpočet komplexní Fourierovy transformace pomocí algoritmu FFT.
Používá se rekurzívní volání #FR ()
*/
class FFT {
  private:
    real *    stab;           //!< tabulka goniometrické funkce sinus pro FFT
    real *    ctab;           //!< tabulky goniometrické funkce kosinus pro FFT
    int       N;              //!< N=2^m počet koeficientů
    int       M;              //!< m = řád transformace
  protected:
    // rekurzivni funkce
    /**
     * Rekurzívní funkce výpočtu FFT
     * @param x ukazatel na data
     * @param order řád transformace, musí být dělitelný 2^n
     */
    void        FR      (Complex * x, int order) const;
  public:
    /**
     * Konstruktor
     * @param  len Řád FFT, počet taps je pak 1^len
     */
    FFT                 (const int len);
    void        F       (Complex * data) const;       //!< transformace        T->F
    void        T       (Complex * data) const;       //!< zpetna transformace F->T
    const int   getN    (void) const;
    /**
     * Destruktor
     */
    ~FFT        ();

};

#endif
