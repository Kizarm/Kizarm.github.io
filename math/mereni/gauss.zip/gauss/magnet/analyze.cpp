#include "analyze.h"
#include <stdio.h>
#include <algorithm>

using namespace std;

static const char * suffixes[NC] = {"_x.dat", "_y.dat", "_z.dat"};

Histogram::Histogram (const char * name) : units (68.42), hist_base(name) {
  for (int n=0; n<NC; n++) {
    hist_name[n]  = name;
    hist_name[n] += suffixes[n];
    hist_file[n]  = hist_name[n].c_str();
  }
}
const std::vector<DataRow> & Histogram::analyze (const char * inputname) {
  if (!input (inputname)) return data;
  compute  ();
  output   ("output.dat");
  for (int n=0; n<NC; n++) {
    datagram        (n);
    write_histogram (n);
  }
  plot     ();
  return data;
}

bool Histogram::input (const char * name) {
  const int  buflen = 0x100;
  size_t     bl = buflen;
  const real factor = 1.0 / units;
  
  FILE * in = fopen (name, "r");
  if (!in) return false;
  char *   buf = new char [buflen];
  unsigned index = 0;
  for (;;) {
    int j  = getline (&buf, &bl, in);
    if (j < 0) {
      fprintf (stdout, "Konec souboru na %d\n", index);
      break;
    }
    DataRow dr;
    long order, l[NC];
    j = sscanf (buf, "%ld %ld %ld %ld", &order, l+0, l+1, l+2);
    if (j != 4) fprintf (stderr, "! %s", buf);
    else {
      dr.order = order;
      for (int n=0; n<NC; n++) {
        dr.v[n].value   = l[n];
        dr.v[n].value  *= factor;
        dr.v[n].delta   = 0.0;
        dr.v[n].delta_q = 0.0;
      }
      
      data.push_back(dr);
      index += 1;
    }
  }
  fclose(in);
  delete [] buf;
  sort (data.begin(), data.end(), [] (DataRow & a, DataRow & b) {
    return a.order < b.order;
  });
  return true;

}
void Histogram::output (const char * name) {
  FILE * out = fopen (name, "w");
  if (!out) return;
  for (const DataRow & d: data) {
    fprintf(out, "%5ld", d.order);
    for (int n=0; n<NC; n++) {
      fprintf(out, " %8.3f %+10.6f %10.6e", d.v[n].value, d.v[n].delta, d.v[n].delta_q);
    }
    fprintf(out, "\n");
  }
  fclose(out);
}

void Histogram::compute() {
  const int lenght = data.size();
  // printf("Celkem mame %ld radku dat\n", lenght);
  parm.count = lenght;
  printf ("Pocet mereni: %ld, prumerna namerena hodnota:\n", parm.count);
  for (int n=0; n<NC; n++) {
    real avg = 0.0;
    // 1. Spočítáme průměr
    for (DataRow & d: data) avg += d.v[n].value;
    avg /= (real) lenght;
    real sum_q = 0.0, sum_3 = 0.0, sum_4 = 0.0;
    // 2. Odchylky od průměru, jejich kvadráty a ty sečteme
    for (DataRow & d: data) {
      const real delta = avg - d.v[n].value;
      d.v[n].delta   = delta;
      real delta_q = delta * delta;
      d.v[n].delta_q = delta_q;
      sum_q += delta_q;
      
      delta_q *= delta;
      d.v[n].delta_3 = delta_q;
      sum_3 += delta_q;
      
      delta_q *= delta;
      d.v[n].delta_4 = delta_q;
      sum_4 += delta_q;
    }
    const real sigma = sqrt (sum_q / (real) (lenght - 1));
    parm.v[n].avg   = avg;
    parm.v[n].sum_q = sum_q;
    parm.v[n].sigma = sigma;
    const char * sf = "xyz";
    printf("\tB%c = %+f uT, sigma = %f uT\n", sf[n], parm.v[n].avg, parm.v[n].sigma);
    // nevychýlené odhady centrálních momentů
    const real g1 = sqrt(lenght) * sum_3 / pow (sum_q, 1.5);
    const real b1 = g1 * pow ((real)(lenght - 1) / (real) lenght, 2.0 / 3.0);
    const real g2 = (real) lenght * sum_4 / pow (sum_q, 2.0);
    const real b2 = g2 * pow ((real)(lenght - 1) / (real) lenght, 2.0) - 3.0;
    printf ("\t\tsikmost = %f, spicatost = %f\n", b1, b2);
  }
}
void Histogram::datagram (const int index) {
  vector<HistogramData> & hd = hist[index].h;
  // tak, aby byl celkový integrál HistogramData::prob jednotkový - což pak odpovídá Gaussově křivce
  const real factor = units / (real) parm.count;
  const real eps = 1e-6;
  for (const DataRow & d: data) {
    const real value = d.v[index].delta;
    //if (value != 0.0) printf("n=%d, val=%f\n", index, value);
    bool valid = false;
    for (HistogramData & h: hd) {
      if (abs(h.value - value) < eps) {
        h.prob += factor;
        valid = true;
        break;
      }
    }
    if (!valid) {
      HistogramData h = {.value = value, .prob = factor, .gauss = gauss (index, value)};
      hd.push_back (h);
    }
  }
  // Setřídit je nutné
  sort (hd.begin(), hd.end(), [] (HistogramData & a, HistogramData & b) {
    return a.value < b.value;
  });
}
const real Histogram::gauss (const int index, const real x) {
  const real x0 = 0, sigma = parm.v[index].sigma;
  const real k0 = +1.0 / (sigma * sqrt(2.0 * M_PI));
  const real k1 = -1.0 / (2.0 * sigma * sigma);
  const real x1 = (x - x0) * (x- x0);
  return k0 * exp (k1 * x1);
}
void Histogram::write_histogram (const int index) {
  FILE * out = fopen (hist_file[index], "w");
  if (!out) return;
  const vector<HistogramData> & hn = hist[index].h;
  for (const HistogramData h: hn) {
    fprintf(out, "%+f %+f %+f\n", h.value, h.prob, h.gauss);
  }
  fclose(out);
  
}

void Histogram::plot() {
  const char * plot_command =
    "set term postscript color eps \'Helvetica\' size 8,10\n"
    "set output \'%s.eps\'\n"
    "\n"
    "set multiplot layout 2,2 title \"Rozptyl B v osach x,y,z. Aproximace je normalni rozdeleni.\" font \"Helvetika-bold,16\"\n"
    "set bmargin 5\n"
    "set key box\n"
    "set xrange [-2:2]\n"
    "set xlabel \"delta B [uT]\"\n"
    "set ylabel \"hustota pravdepodobnosti\"\n"
    "\n"
    "set title \"Osa x\"\n"
    "plot \'%s\' using 1:2 t \'data\',\\\n"
    "     \'%s\' using 1:3 w l lw 2 t \'B(x)\'\n"
    "\n"
    "set title \"Osa y\"\n"
    "plot \'%s\' using 1:2 t \'data\',\\\n"
    "     \'%s\' using 1:3 w l lw 2 t \'B(y)\'\n"
    "\n"
    "set title \"Osa z\"\n"
    "plot \'%s\' using 1:2 t \'data\',\\\n"
    "     \'%s\' using 1:3 w l lw 2 t \'B(z)\'\n"
    "\n"
    "set grid\n"
    "set title \"Osy x,y,z\"\n"
    "plot \'%s\' using 1:3 w l lw 2 t \'B(x)\',\\\n"
    "     \'%s\' using 1:3 w l lw 2 t \'B(y)\',\\\n"
    "     \'%s\' using 1:3 w l lw 2 t \'B(z)\'\n"
    "\n"
    ;
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  fprintf (cmd, plot_command, hist_base, hist_file[0], hist_file[0], hist_file[1], hist_file[1], hist_file[2], hist_file[2],
    hist_file[0], hist_file[1], hist_file[2]);
  fflush  (cmd);
  pclose  (cmd);
}
/**************************************************************************************************************/

Spektrum::Spektrum (const vector<DataRow> & in) : data(in) {

}
void Spektrum::analyze (const char * name) {
  if (data.empty()) return;
  base_name  = name;
  data_name  = name;
  data_name += ".dat";
  data_file  = data_name.c_str();
  
  compute();
  output ();
  plot   ();
}
static const int determine_order (const size_t len) {
  int res = 20;   // použitelné maximum
  for (;;) {
    if ((1ul << res) < len) break;
    res -= 1;
    if (res <= 0) return 0;
  }
  return res;
}
void Spektrum::compute() {
  const size_t dlen = data.size();
  const int order   = determine_order (dlen);
  const int lenght  = (1 << order), half = lenght >> 1;
  sdata.resize (half);  // Vyhradíme kapacitu
  printf("Rad FFT = %d, pouzito %d radku dat, vystup bude mit %d taps\n", order, lenght, half);
  for (int n=0; n<NC; n++) {
    Complex * c = convert_to_complex (n, lenght);
    FFT fft (order);
    fft.F   (c);
    convert_to_sdata (n, c, half);
    delete [] c;
  }
}
void Spektrum::output () {
  FILE * out = fopen (data_file, "w");
  if (!out) return;
  const int len = sdata.size();
  printf("Hodnotu na pozici 0 (prumer) nepouzijeme - velikost je %.2f, %.2f, %.2f dB\n",
         sdata[0].A[0], sdata[0].A[1], sdata[0].A[2]);
  for (int n=1; n<len; n++) {
    const SpectrumData & d = sdata[n];
    fprintf (out, "%8.3f %10.6f %10.6f %10.6f %10.6f %+10.6f %+10.6f %+10.6f\n",
             d.t, d.f, d.A[0], d.A[1], d.A[2], d.B[0], d.B[1], d.B[2]);
  }
  fclose (out);
}

void Spektrum::plot() {
  const char * plot_command =
    "set term postscript color eps \'Helvetica\' size 8,10\n"
    "set output \'%s.eps\'\n"
    "\n"
    "set multiplot layout 2,2 title \"Frekvencni spektrum signalu\" font \"Helvetika-bold,16\"\n"
    "set bmargin 5\n"
    "set key box\n"
    "set logscale x\n"
    "set yrange [0:70]\n"
    "set grid\n"
    "set xlabel \"f [Hz]\"\n"
    "set ylabel \"A [dB]\"\n"
    "\n"
    "set title \"Osa x\"\n"
    "plot \'%s\' using 2:3 w l lw 2 t \'FFT\'\n"
    "\n"
    "set title \"Osa y\"\n"
    "plot \'%s\' using 2:4 w l lw 2 t \'FFT\'\n"
    "\n"
    "set title \"Osa z\"\n"
    "plot \'%s\' using 2:5 w l lw 2 t \'FFT\'\n"
    "unset logscale x \n"
    "unset yrange\n"
    "set title \"Osy x,y,z - casovy prubeh\"\n"
    "set xlabel \"t [s]\"\n"
    "set ylabel \"delta B [uT]\"\n"
    "plot \'%s\' using 1:6 w l lw 2 t \'B(x)\',\\\n"
    "     \'%s\' using 1:7 w l lw 2 t \'B(y)\',\\\n"
    "     \'%s\' using 1:8 w l lw 2 t \'B(z)\'\n"
    "\n";
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  fprintf (cmd, plot_command, base_name,
           data_file, data_file, data_file, data_file, data_file, data_file);
  fflush  (cmd);
  pclose  (cmd);
}

Complex * Spektrum::convert_to_complex (const int index, const int lenght) {
  Complex * result = new Complex [lenght];
  for (int n=0; n<lenght; n++) {
    const real x = data[n].v[index].value;
    result[n] = Complex (x, 0.0);
  }
  return result;
}
void Spektrum::convert_to_sdata (const int index, const Complex * in, const int len) {
  const real fs = 80.0;               // vzorkovací frekvencne
  const real f0 = 0.5 * fs / (real) len;
  const real t0 = 1.0 / fs;
  for (int n=0; n<len; n++) {
    Complex c (in[n]);
    const real t = (real) n * t0;
    const real f = (real) n * f0;
    const real A = 10.0 * log10 (c.squarabs());
    const real B = data[n].v[index].delta + 2.0 * (real) index;
    SpectrumData & sd = sdata[n];
    sd.A[index] = A; sd.B[index] = B; sd.f = f; sd.t = t;
  }
}


