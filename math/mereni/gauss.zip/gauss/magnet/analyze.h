#ifndef ANALYZE_H
#define ANALYZE_H
#include "fft.h"
#include <vector>
#include <string>

static const int NC = 3;

struct OneValue {
  real value, delta, delta_q, delta_3, delta_4;
};

struct DataRow {
  long order;
  OneValue v[NC];
};
struct Parameter {
   real avg, sum_q, sigma;
};
struct Parameters {
  long count; // počet měření
  Parameter v [NC];
};
struct HistogramData {
  real value, prob, gauss;
};
struct HistogramVector {
  std::vector<HistogramData> h;
};
class Histogram {
  const real   units;
  std::string  hist_name[NC];
  const char * hist_file[NC];
  const char * hist_base;
  std::vector<DataRow>       data;
  HistogramVector            hist [NC];
  Parameters                 parm;
  public:
    Histogram                             (const char * name);
    const std::vector<DataRow> & analyze  (const char * inputname);
  protected:
    void       plot     ();
    bool       input    (const char * name);
    void       output   (const char * name);
    void       compute  ();
    void       datagram (const int index);
    const real gauss    (const int index, const real x);
    void write_histogram(const int index);
};
/**********************************************************************/

struct SpectrumData {
  real t, f, A[NC], B[NC];
};
class Spektrum {
  std::string  data_name;
  const char * data_file;
  const char * base_name;
  const std::vector<DataRow> & data;
  std::vector<SpectrumData>    sdata;
  public:
    Spektrum     (const std::vector<DataRow> & in);
    void analyze (const char * name);
  protected:
    void       plot     ();
    void       output   ();
    void       compute  ();
    
    Complex * convert_to_complex (const int index, const int lenght);
    void convert_to_sdata (const int index, const Complex * in, const int len);
};

#endif // ANALYZE_H
