#ifndef ANALYZE_H
#define ANALYZE_H
#include "fft.h"
#include <vector>
#include <string>

struct DataRow {
  long order;
  real value, delta, delta_q, delta_3, delta_4;
};
struct Parameters {
  long count; // počet měření
  real avg, sum_q, sigma;
};
struct HistogramData {
  real value, prob, gauss;
};
class Histogram {
  std::string  hist_name;
  const char * hist_base;
  const char * hist_file;
  std::vector<DataRow>       data;
  std::vector<HistogramData> hist;
  Parameters                 parm;
  public:
    Histogram                             (const char * name);
    const std::vector<DataRow> & analyze  (const char * inputname);
  protected:
    void       plot     ();
    bool       input    (const char * name);
    void       output   (const char * name);
    void       compute  ();
    void       datagram ();
    const real gauss    (const real x);
};
/**********************************************************************/
struct SpectrumData {
  real f, A;
};
class Spektrum {
  std::string  data_name;
  const char * data_file;
  const char * base_name;
  const std::vector<DataRow> & data;
  std::vector<SpectrumData>    sdata;
  public:
    Spektrum     (const std::vector<DataRow> & in);
    void analyze (const char * name);
  protected:
    void       plot     ();
    void       output   ();
    void       compute  ();
    
    Complex * convert_to_complex (const int lenght);
    void convert_to_sdata (const Complex * in, const int len);
};
class HtmlOut {
  const std::vector<DataRow> & data;
  FILE * out;
  public:
    HtmlOut    (const std::vector<DataRow> & in);
    void print (const char * filename);
protected:
    void row   (const int n);
};

#endif // ANALYZE_H
