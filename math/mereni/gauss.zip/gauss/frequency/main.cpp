#include "analyze.h"
using namespace std;

#ifndef HISTG
#define HISTG "histg"
#endif // HISTG

int main (int argc, char *argv[]) {
  
  Histogram h (HISTG);  // defined by Makefile
  const vector<DataRow> & d = 
  h.analyze   ("input.txt");
  Spektrum  s (d);
  s.analyze   ("spectrum");
  /*
  HtmlOut   o (d);
  o.print     ("table.html");
  */
  return 0;
}
