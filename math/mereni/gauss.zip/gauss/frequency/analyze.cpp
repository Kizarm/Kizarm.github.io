#include "analyze.h"
#include <stdio.h>
#include <algorithm>

using namespace std;

Histogram::Histogram (const char * name) : hist_base(name) {
  hist_name  = name;
  hist_name += ".dat";
  hist_file  = hist_name.c_str();
}
const std::vector<DataRow> & Histogram::analyze (const char * inputname) {
  if (!input (inputname)) return data;
  compute  ();
  output   ("output.dat");
  datagram ();
  plot     ();
  return data;
}

bool Histogram::input (const char * name) {
  const int buflen = 0x100;
  size_t    bl = buflen;
  
  FILE * in = fopen (name, "r");
  if (!in) return false;
  char *   buf = new char [buflen];
  unsigned index = 0;
  for (;;) {
    int j  = getline (&buf, &bl, in);
    if (j < 0) {
      fprintf (stdout, "Konec souboru na %d\n", index);
      break;
    }
    DataRow dr;
    long adr, order, value;
    j = sscanf (buf, "%ld 0x%lX %ld", &order, &adr, &value);
    if (j != 3) fprintf (stderr, "! %s", buf);
    else {
      dr.order   = order;
      dr.value   = value;
      dr.value  *= 0.001;
      dr.delta   = 0.0;
      dr.delta_q = 0.0;
      data.push_back(dr);
      index += 1;
    }
  }
  fclose(in);
  delete [] buf;
  sort (data.begin(), data.end(), [] (DataRow & a, DataRow & b) {
    return a.order < b.order;
  });
  return true;

}
void Histogram::output (const char * name) {
  FILE * out = fopen (name, "w");
  if (!out) return;
  for (const DataRow & d: data) {
    fprintf(out, "%5ld %8.3f %+10.6f %10.6e\n", d.order, d.value, d.delta, d.delta_q);
  }
  fclose(out);
}

void Histogram::compute() {
  const int lenght = data.size();
  // printf("Celkem mame %ld radku dat\n", lenght);
  real avg = 0.0;
  // 1. Spočítáme průměr
  for (DataRow & d: data) avg += d.value;
  avg /= (real) lenght;
  real sum_q = 0.0, sum_3 = 0.0, sum_4 = 0.0;
  // 2. Odchylky od průměru, jejich kvadráty a ty sečteme
  for (DataRow & d: data) {
    const real delta = avg - d.value;
    d.delta   = delta;
    real delta_q = delta * delta;
    d.delta_q = delta_q;
    sum_q += delta_q;
    
    delta_q *= delta;
    d.delta_3 = delta_q;
    sum_3 += delta_q;
    
    delta_q *= delta;
    d.delta_4 = delta_q;
    sum_4 += delta_q;
  }
  const real sigma = sqrt (sum_q / (real) (lenght - 1));
  parm = {.count = lenght, .avg = avg, .sum_q = sum_q, .sigma = sigma};
  // Opakování N měření zmenší nejistotu v poměru 1/sqrt(N)
  real eps = sigma / sqrt ((real)lenght);
  printf("Pocet mereni: %ld, prumerna namerena hodnota = %f +/- %f Hz, sigma = %f Hz\n",
         parm.count, parm.avg, eps, parm.sigma);
  
  const real g1 = sqrt(lenght) * sum_3 / pow (sum_q, 1.5);
  const real b1 = g1 * pow ((real)(lenght - 1) / (real) lenght, 2.0 / 3.0);
  const real g2 = (real) lenght * sum_4 / pow (sum_q, 2.0);
  const real b2 = g2 * pow ((real)(lenght - 1) / (real) lenght, 2.0) - 3.0;
  printf ("sikmost = %f, spicatost = %f\n", b1, b2);
}
void Histogram::datagram() {
  // tak, aby byl celkový integrál HistogramData::prob jednotkový - což pak odpovídá Gaussově křivce
  const real factor = 1000.0 / (real) parm.count;  // suma bude tedy 1000, ale krok je 0.001, takže to sedí
  const real eps = 1e-4;
  for (const DataRow & d: data) {
    const real value = d.value;
    bool valid = false;
    for (HistogramData & h: hist) {
      if (abs(h.value - value) < eps) {
        h.prob += factor;
        valid = true;
        break;
      }
    }
    if (!valid) {
      HistogramData h = {.value = value, .prob = factor, .gauss = gauss (value)};
      hist.push_back (h);
    }
  }
  // Setřídit je nutné
  sort (hist.begin(), hist.end(), [] (HistogramData & a, HistogramData & b) {
    return a.value < b.value;
  });
  // A nakonec zapsat do souboru
  FILE * out = fopen (hist_file, "w");
  if (!out) return;
  for (const HistogramData & h: hist) {
    fprintf(out, "%8.3f %10.6f %10.6f\n", h.value, h.prob, h.gauss);
  }
  fclose(out);
}
const real Histogram::gauss (const real x) {
  const real x0 = parm.avg, sigma = parm.sigma;
  const real k0 = +1.0 / (sigma * sqrt(2.0 * M_PI));
  const real k1 = -1.0 / (2.0 * sigma * sigma);
  const real x1 = (x - x0) * (x- x0);
  return k0 * exp (k1 * x1);
}
void Histogram::plot() {
  const real x0 = parm.avg, sigma = parm.sigma;
  const real y0 = +1.0 / (sigma * sqrt(2.0 * M_PI));
  const real x1 = x0 - sigma, x2 = x0 + sigma;
  const char * plot_command =
    "set terminal postscript eps color size 8,8 font \"FreeSerif.ttf\" 24\n"
    "set grid\n"
    "set key box opaque\n"
    "set output \'%s.eps\'\n"
    "set xlabel \"f[Hz]\"\n"
    "set ylabel \"Probability(f)\"\n"
    "set style rect fc lt -1 fs solid 0.15 noborder\n"
    "set obj rect from %f,0 to %f,%f"
    "\n"
#ifdef FITTING
    /* Gnuplot umí gaussovu křivku nafitovat na reálná data, ale je to dost
     * nespolehlivá aproximace, je silně závislá na počátečních parametrech,
     * výsledek není normalizován, klasický výpočet je v tomto případě na místě.
     * V každém případě je dobré si z toho všeho udělat graf a podívat se,
     * jestli nejsou někde hrubé chyby. Obrázek je lepší než tabulka.
     * */
    "s=40; m=50; a=22;\n"
    "gauss(x) = a*exp(-((x-m)*s)**2)\n"
    "fit gauss(x) \"%s\" using 1:2 via s,m,a\n"
    "\n"
    "plot \'%s\' u 1:2 lc rgb \"red\" t \'Histogram\',\\\n"
    "     \'%s\' u 1:3 w l lt 1 lw 4 lc rgb \"blue\" t \'aprox Gauss\',\\\n"
    "     gauss(x) w l lt 1 lw 4 lc rgb \"green\" t \'gnuplot fitting\'\n";
#else
    "plot \'%s\' u 1:2 lc rgb \"red\" t \'Histogram\',\\\n"
    "     \'%s\' u 1:3 w l lt 1 lw 4 lc rgb \"blue\" t \'aprox Gauss\'\n";
#endif // FITTING
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
#ifdef FITTING
  fprintf (cmd, plot_command, hist_base, x1, x2, y0, hist_file, hist_file, hist_file);
#else
  fprintf (cmd, plot_command, hist_base, x1, x2, y0, hist_file, hist_file);
#endif // FITTING
  fflush  (cmd);
  pclose  (cmd);
}
/**************************************************************************************************************/
Spektrum::Spektrum (const vector<DataRow> & in) : data(in) {

}
void Spektrum::analyze (const char * name) {
  if (data.empty()) return;
  base_name  = name;
  data_name  = name;
  data_name += ".dat";
  data_file  = data_name.c_str();
  
  compute();
  output ();
  plot   ();
}
static const int determine_order (const size_t len) {
  int res = 20;   // použitelné maximum
  for (;;) {
    if ((1ul << res) < len) break;
    res -= 1;
    if (res <= 0) return 0;
  }
  return res;
}
void Spektrum::compute() {
  const size_t dlen = data.size();
  const int order   = determine_order (dlen);
  const int lenght  = (1 << order), half = lenght >> 1;
  printf("Rad FFT = %d, pouzito %d radku dat, vystup bude mit %d taps\n", order, lenght, half);
  Complex * c = convert_to_complex (lenght);
  
  FFT fft (order);
  fft.F   (c);
  convert_to_sdata (c, half);
  delete [] c;

}
void Spektrum::output () {
  FILE * out = fopen (data_file, "w");
  if (!out) return;
  const int len = sdata.size();
  printf("Hodnotu na pozici 0 (prumer) nepouzijeme - velikost je %.2f dB\n", sdata[0].A);
  for (int n=1; n<len; n++) {
    const SpectrumData & d = sdata[n];
    fprintf (out, "%10.6f, %10.6f\n", d.f, d.A);
  }
  fclose (out);
}
void Spektrum::plot() {
  const char * plot_command =
    "set terminal postscript eps color size 8,6 font \"FreeSerif.ttf\" 24\n"
    "set grid\n"
    "set key box opaque\n"
    "set output \'%s.eps\'\n"
    "set xlabel \"f[N/hod]\"\n"
    "set ylabel \"A[dB]\"\n"
    "set logscale x\n"
    "plot \'%s\' u 1:2 w l lt 1 lw 4 lc rgb \"blue\" t \'Spectrum\'\n";
  FILE * cmd = popen ("gnuplot","w");
  if (!cmd) return;
  fprintf (cmd, plot_command, base_name, data_file);
  fflush  (cmd);
  pclose  (cmd);
}
Complex * Spektrum::convert_to_complex (const int lenght) {
  Complex * result = new Complex [lenght];
  for (int n=0; n<lenght; n++) result[n] = Complex (data[n].value, 0.0);
  return result;
}
void Spektrum::convert_to_sdata (const Complex * in, const int len) {
  const real factor = 30.0 / (real) len;
  for (int n=0; n<len; n++) {
    Complex c (in[n]);
    const real f = (real) n * factor;
    const real A = 10.0 * log10 (c.squarabs());
    const SpectrumData sd = {.f = f, .A = A};
    sdata.push_back (sd);
  }
}
/**************************************************************************************************************/
static const char * t_prefix =
  "<!DOCTYPE html>\n"
  "<html lang=\"cs-cz\">\n"
  "  <head>\n"
  "    <meta charset=\"utf-8\" />\n"
  "    <title>Tabulka</title>\n"
  "    <script type=\"text/x-mathjax-config\">MathJax.Hub.Config({\n"
  "    extensions: [\"tex2jax.js\"],\n"
  "    jax: [\"input/TeX\",\"output/HTML-CSS\"],\n"
  "    tex2jax: {inlineMath: [[\'$\',\'$\']]},\n"
  "    displayAlign: \"left\"});\n"
  "    </script>\n"
  "    <script type=\"text/javascript\" src=\"https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js\">\n"
  "    </script>\n"
  "  </head>\n"
  "  <body>\n"
  "    <font size=\"4\" face=\"Courier New\">\n"
  "    <table border=\"2\" style=\"table-layout: fixed; border-collapse: collapse;\">\n"
  "      <tr><td>n</td><td align=\"center\">$x_n$</td><td>$\\Delta_n = \\bar x - x$</td><td>$\\Delta_n^2 = {(\\bar x - x)}^2$</td></tr>\n";
static const char * t_suffix =
  "      <tr><td>...</td><td></td><td></td><td></td></tr>\n"
  "    </table>\n"
  "    </font>\n"
  "  </body>\n"
  "</html>\n";
  
HtmlOut::HtmlOut (const vector< DataRow >& in) : data(in) {

}
void HtmlOut::print (const char * filename) {
  out = fopen (filename, "w");
  if (!out) return;
  const int max = 10;// data.size();
  fprintf (out, "%s", t_prefix);
  for (int n=0; n<max; n++) row (n);
  fprintf (out, "%s", t_suffix);
  fclose (out);
}
void HtmlOut::row (const int n) {
  const char * space = "      ";
  const DataRow & d = data[n];
  fprintf (out, "%s<tr><td>%5ld</td><td>%8.3f</td><td>%+10.4f</td><td>%.6f</td></tr>\n",
           space, d.order, d.value, d.delta, d.delta_q);
}


