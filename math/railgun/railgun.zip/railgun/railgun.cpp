#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "solver.h"

using namespace std;
template<class T, size_t N> constexpr size_t FSIZE (T (&)[N]) { return N; }
template<const  unsigned N> using PFUNC = bool (*) (const Point<N> &, real &);

/** TEST - Railgun
 * proměnné pro metodu Runge-Kutta z Hamiltonových rovnic  w[] = { x, p_x, Q, p_Q }
 * */
// vstup : m = hmotnost střely, mu = indukčnost vodiče na jednotku délky (odhad),
// C = kapacita kondenzátoru a U0 = počáteční napětí na něm
static const real m = 0.0007, mu = 1.2e-6, C = 0.020, U0 = 250.0;
// počáteční podmínky - začínáme v x0 = 20 cm (počáteční indukčnost), Q0 = C * U0
static const real w0 [] = {0.2, 0.0, C * U0, 0.0};
static const unsigned N = FSIZE (w0);
// základní krok simulate
static const real step = 1.0e-6;


static const vector<Point<N>> & railgun () {

  const Point<N> bc (0.0, w0);
  
  PFUNC<N> pf[N] = { // funkce lze předat jako lambdy...
    [=](const Point<N> & z, real & result) -> auto {      // F1
        const real p_x = z.w[1];
        result = p_x / m;
        return false;
    },
    [=](const Point<N> & z, real & result) -> auto {      // F2
        const real x   = z.w[0];
        if (x == 0.0) return true;
        const real p_Q = z.w[3];
        const real d   = p_Q / x;
        result = 0.5 * d * d / mu;
        return false;
    },
    [=](const Point<N> & z, real & result) -> auto {      // F3
        const real x   = z.w[0];
        if (x == 0.0) return true;
        const real p_Q = z.w[3];
        result = p_Q / (mu * x);
        return false;
    },
    [=](const Point<N> & z, real & result) -> auto {      // F4
        const real Q = z.w[2];
        result = - Q/C;
        return false;
    }
  };
  
  static RungeKutta <N, PFUNC<N>> solver (pf, bc, step, 1000.0);
  // solver vyhodí celý vektor dat, tedy časový průběh
  return solver.solve();
}
// Co nás konečně zajímá :
struct Output {
  real t, x, v, i, f; // čas, poloha, rychlost, proud, působící síla
};
static void simulate (const char * const filename) {
  const vector<Point<N>> s (railgun ());
  vector<Output> data;
  for (auto & p: s) {         // přepočet z Hamiltonových na nějaké "normální" veličiny
    Output pt;
    pt.t = p.t;               // čas máme
    pt.x = p.w[0];            // souřadnici také
    pt.v = p.w[1] / m;        // rychlost z hybnosti
    const real d = p.w[3] / p.w[0];
    pt.i = - d / mu;          // Q_dot,   viz F3 (znaménko kvůli grafice, směr proudu je konvence)
    pt.f = 0.5 * d * d / mu;  // p_x_dot, viz F2
    data.push_back(pt);
  }
  
  FILE * out = fopen(filename, "w");
  for (auto & p: data) {
    fprintf (out, "%12.6f %12.6f %12.6f %12.0f %12.3f\n", p.t, p.x, p.v, p.i, p.f);
  }
  fclose(out);
}
static const char * const plot_cmd = R"==(
#set terminal postscript eps color size 8,4
set terminal pngcairo transparent size 800,640
#set output 'img1.eps'
set output 'img1.png'
set format x  "%.0s%c"
set format y  "%.1s%c"
set format y2 "%.1s%c"
set grid
set key box opaque font ",16"

set y2tics
set tics out
set autoscale  y
set autoscale y2
set title "Proud a sila v zavislosti na case"
set xlabel  "t [s]" font ",16"
set ylabel  "I(t) [A]" font ",16"
set y2label "F(t) [N]" font ",16"

plot 'x.dat' u 1:4 w l lw 4 t 'I' axes x1y1 ,\
     'x.dat' u 1:5 w l lw 4 t 'F' axes x1y2

#set output 'img2.eps'
set output 'img2.png'
set title "Proud a sila v zavislosti na poloze (v nekonecne hlavni)"
set xlabel  "x [m]" font ",16"
set ylabel  "I(x) [A]" font ",16"
set y2label "F(x) [N]" font ",16"
plot 'x.dat' u 2:4 w l lw 4 t 'I' axes x1y1 ,\
     'x.dat' u 2:5 w l lw 4 t 'F' axes x1y2

#set output 'img3.eps'
set output 'img3.png'
set title "Rychlost a poloha v zavislosti na case"
set xlabel  "t [s]" font ",16"
set ylabel  "v(t) [m/s]" font ",16"
set y2label "x(t) [m]" font ",16"
plot 'x.dat' u 1:3 w l lw 4 t 'v' axes x1y1,\
     'x.dat' u 1:2 w l lw 4 t 'x' axes x1y2
)==";
static void plot (const char * const cmd) {
  FILE * out = popen ("gnuplot", "w");
  fprintf (out, "%s", cmd);
  pclose (out);
}

int main () {
  printf   ("Teoreticky: v_max = %f m/s\n", U0 * sqrt(m*C) / m);
  const char * const dat = "x.dat";
  simulate (dat);
  plot     (plot_cmd);
  remove   (dat);
  return 0;
}

