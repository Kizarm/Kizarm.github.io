#include <locale.h>
#include <QDesktopWidget>
#include <QPalette>
/** EMSCRIPTEN si zazatím neumí poradit s dialogy,
 * proto MENU bude nefukční.
 * */
#ifndef EMSCRIPTEN
  #include <QFileDialog>
  #include <QPrintDialog>
#endif // EMSCRIPTEN
#include <QPrinter>
#include <math.h>
#include "mainwindow.h"
#include "ui_mainwindow.h"
/*
#undef  qDebug
#define qDebug(p, ...)
*/
static const plot_strings description [PLOT_MAX] = {
  {"F(t) [N]", "I(t) [A]"},
  {"v(t) [m/s]", "x(t) [m]"}
};

MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent), mu0(1.257e-6) {
  setlocale (LC_NUMERIC, "POSIX");
  setWindowTitle ("Railgun - simulace");
  setWindowIcon(QIcon(":ico"));
  plots = PLOT_FI;
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  ui->pushButton->setToolTip(QString::fromUtf8("Přepínání režimu - dioda paralelně ke kondenzátoru zapnuta/vypnuta"));
  ui->SpinBoxgf ->setToolTip(QString::fromUtf8("Geometrický faktor - podle tvaru kolejnic (0.1 až 10),\nurčuje jejich indukčnost na jednotku délky"));
  ui->SpinBoxx0 ->setToolTip(QString::fromUtf8("Určuje počáteční indukčnost, zde v podstatě délka přívodů"));
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
  timePlot = new QCustomPlot (this);
  ui->verticalLayout->addWidget (timePlot);
  
  QBrush bg = QBrush (QColor (255,255,0, 64));
  timePlot->xAxis ->setLabel ("t[ms]");
  timePlot->yAxis2->setAutoTicks(true);
  timePlot->yAxis2->setVisible  (true);
  timePlot->addGraph(timePlot->xAxis, timePlot->yAxis );
  timePlot->addGraph(timePlot->xAxis, timePlot->yAxis2);
  timePlot->graph (0)->setPen  (QPen (Qt::red,  2));
  timePlot->graph (1)->setPen  (QPen (Qt::blue, 2));
  //timePlot->setInteractions (QCP::iRangeDrag | QCP::iRangeZoom);
  timePlot->legend->setBrush (bg);
  timePlot->legend->setVisible (true);

  QString sa;
  sa  = description[PLOT_FI].a;
  sa += " , ";
  sa += description[PLOT_FI].b;
  ui->typeCombo->addItem (sa);
  QString sb;
  sb  = description[PLOT_VX].a;
  sb += " , ";
  sb += description[PLOT_VX].b;
  ui->typeCombo->addItem (sb);
  
  connect (ui->typeCombo,   SIGNAL (activated (int)),       this, SLOT(setPlot(int)));
  connect (ui->SpinBoxPts,  SIGNAL (valueChanged(double)),  this, SLOT(setPts(double)));
  connect (ui->spinBoxStep, SIGNAL (valueChanged(int)),     this, SLOT(setStep(int)));
  connect (ui->SpinBoxm,    SIGNAL (valueChanged(double)),  this, SLOT(set_m(double)));
  connect (ui->SpinBoxgf,   SIGNAL (valueChanged(double)),  this, SLOT(set_mu(double)));
  connect (ui->SpinBoxx0,   SIGNAL (valueChanged(double)),  this, SLOT(set_x0(double)));
  connect (ui->SpinBoxC,    SIGNAL (valueChanged(double)),  this, SLOT(setC(double)));
  connect (ui->SpinBoxU0,   SIGNAL (valueChanged(double)),  this, SLOT(setU0(double)));
  connect (ui->SpinBoxR,    SIGNAL (valueChanged(double)),  this, SLOT(setR(double)));
  connect (ui->pushButton,  SIGNAL (pressed()),             this, SLOT(changeD()));
  connect (ui->actionDef,   SIGNAL (triggered(bool)),       this, SLOT(setDeflt(bool)));
  connect (ui->actionExit,  SIGNAL (triggered(bool)),       this, SLOT(close()));
#ifndef EMSCRIPTEN
  connect (ui->actionPrt,   SIGNAL (triggered(bool)),       this, SLOT (printDoc(bool)));
  connect (ui->actionExprt, SIGNAL (triggered(bool)),       this, SLOT (exprt(bool)));
#endif // EMSCRIPTEN
#ifdef EMSCRIPTEN
  setWindowState(Qt::WindowMaximized);
#endif // EMSCRIPTEN
  
  setDeflt (true);
}

MainWindow::~MainWindow () {
  delete timePlot;
  delete ui;
}
void MainWindow::printDoc (bool) {
#ifndef EMSCRIPTEN
  QWidget  * pw = timePlot;
  QPrinter * printer = new QPrinter (QPrinter::HighResolution);
  printer->setOutputFileName ("print.pdf");
  printer->setOrientation    (QPrinter::Landscape);
  QPrintDialog printDialog   (printer, this);
  if (printDialog.exec() == QDialog::Accepted) {
    QPainter painter;
    painter.begin  (printer);
    double xscale = printer->pageRect().width()  / double (pw->width ());
    double yscale = printer->pageRect().height() / double (pw->height());
    //double scale = qMin (xscale, yscale);
    painter.translate (printer->paperRect().x() + printer->pageRect().width()  / 2,
                       printer->paperRect().y() + printer->pageRect().height() / 2);
    painter.scale (xscale, yscale);
    painter.translate (-pw->width() / 2, -pw->height() / 2);

    pw->render (&painter);
  }
  delete printer;
#endif // EMSCRIPTEN
}
void MainWindow::exprt (bool) {
#ifndef EMSCRIPTEN
  QWidget * pw = timePlot;
  QString fileName = QFileDialog::getSaveFileName (this,
               tr ("Save File"), ".", "Images Files(*.png)");
  if (!fileName.isEmpty()) {
    QImage    img (pw->width(), pw->height(), QImage::Format_ARGB32_Premultiplied);
    QPainter  painter(&img);
    pw->render (&painter);
    img.save   (fileName, "PNG", 0);
  }
#endif // EMSCRIPTEN
}
void MainWindow::setDeflt (bool) {
  params.m  = 0.0007, params.mu = 0.5 * mu0, params.C    = 0.02,   params.U0     = 250.0;
  params.x0 = 0.2,    params.R  = 0.004,     params.step = 1.0e-6, params.points = 1000;
  params.diode = true;

  // synchronizace
  if (params.diode) ui->pushButton->setIcon(QIcon(":dio"));
  else              ui->pushButton->setIcon(QIcon(":din"));
  ui->SpinBoxPts ->setValue(params.points);
  ui->spinBoxStep->setValue(-(int)round(log10(params.step)));
  
  ui->SpinBoxm  ->setValue(params.m * 1000.0);
  ui->SpinBoxgf ->setValue(params.mu / mu0);
  ui->SpinBoxx0 ->setValue(params.x0);
  ui->SpinBoxC  ->setValue(params.C  * 1000.0);
  ui->SpinBoxU0 ->setValue(params.U0);
  ui->SpinBoxR  ->setValue(params.R  * 1000.0);
  replot();
}
void MainWindow::changeD() {
  params.diode = ! params.diode;
  if (params.diode) ui->pushButton->setIcon(QIcon(":dio"));
  else              ui->pushButton->setIcon(QIcon(":din"));
  replot();
}

void MainWindow::setPlot (int n) {
  switch (n) {
    default:
    case 0: plots = PLOT_FI; break;
    case 1: plots = PLOT_VX; break;
  }
  replot();
}
void MainWindow::setPts (double x) {
  unsigned n = (unsigned) x;
  params.points = n;
  replot();
}
void MainWindow::setStep (int v) {
  params.step = pow(10, -(double)v);
  replot();
}
void MainWindow::set_m (double v) {
  params.m = 0.001 * v;
  replot();
}
void MainWindow::set_mu (double v) {
  params.mu = mu0 * v;
  replot();
}
void MainWindow::set_x0 (double v) {
  params.x0 = v;
  replot();
}
void MainWindow::setC (double v) {
  params.C = 0.001 * v;
  replot();
}
void MainWindow::setU0 (double v) {
  params.U0 = v;
  replot();
}
void MainWindow::setR (double v) {
  params.R = 0.001 * v;
  replot();
}


void MainWindow::replot (void) {
  QString fmt, str(QString::fromUtf8("Energie kondenzátoru je "));
  const real WC = 0.5 * params.C * params.U0 * params.U0;
  const real v0 = sqrt (2.0 * WC / params.m);
  str += fmt.sprintf ("%.1f", WC);
  str += QString::fromUtf8(" J -> maximální rychlost náboje je ");
  str += fmt.sprintf("%.1f m/s", v0);
  statusBar()->showMessage(str);
  
  std::vector<Output> data = simulate (params);
  const unsigned m = data.size();
  xt.resize(m);
  at.resize(m);
  bt.resize(m);
  unsigned n = 0;
  real maxy1 = 0.0, maxy2 = 0.0;
  real miny1 = 0.0, miny2 = 0.0;
  for (const Output & e : data) {
    xt[n] = 1000.0 * e.t; // v ms
    switch (plots) {
      default:
      case PLOT_FI: at[n] = e.f; bt[n] = e.i; break;
      case PLOT_VX: at[n] = e.v; bt[n] = e.x; break;
    }
    if (at[n] < miny1) miny1 = at[n];
    if (at[n] > maxy1) maxy1 = at[n];
    if (bt[n] < miny2) miny2 = bt[n];
    if (bt[n] > maxy2) maxy2 = bt[n];
    n += 1;
  }
  // qDebug("%d: Y1:%f-%f, Y2:%f-%f", m, miny1, maxy1, miny2, maxy2);
  switch (plots) {
    default:
    case PLOT_FI:
      timePlot->graph(0)->setName (QString::fromUtf8(description[PLOT_FI].a));
      timePlot->graph(1)->setName (QString::fromUtf8(description[PLOT_FI].b));
      timePlot->yAxis   ->setLabel(QString::fromUtf8(description[PLOT_FI].a));
      timePlot->yAxis2  ->setLabel(QString::fromUtf8(description[PLOT_FI].b));
      break;
    case PLOT_VX:
      timePlot->graph(0)->setName (QString::fromUtf8(description[PLOT_VX].a));
      timePlot->graph(1)->setName (QString::fromUtf8(description[PLOT_VX].b));
      timePlot->yAxis   ->setLabel(QString::fromUtf8(description[PLOT_VX].a));
      timePlot->yAxis2  ->setLabel(QString::fromUtf8(description[PLOT_VX].b));
      break;
  }
  timePlot->xAxis ->setRange(0, 1000.0 * (real) params.points * params.step);
  timePlot->yAxis ->setRange(miny1, maxy1);
  timePlot->yAxis2->setRange(miny2, maxy2);
  timePlot->graph (0)->setData (xt, at);
  timePlot->graph (1)->setData (xt, bt);
  timePlot->replot();
}
