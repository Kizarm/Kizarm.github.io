#ifndef RAILGUN_H
#define RAILGUN_H
#include <vector>
#include "solver.h"

// Co nás konečně zajímá :
struct Output {
  real t, x, v, i, f; // čas, poloha, rychlost, proud, působící síla
};
struct Parameters {
  real m, mu, C, U0, x0, R, step;
  unsigned points;
  bool diode;
};
const std::vector<Output> simulate (const Parameters & prms);
#endif // RAILGUN_H
