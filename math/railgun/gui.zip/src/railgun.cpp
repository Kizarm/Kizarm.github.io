#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include "railgun.h"

using namespace std;
template<const unsigned N> using PFUNC = function<real(const Point<N> &, bool &)>;

/** TEST - Railgun
 * proměnné pro metodu Runge-Kutta z Hamiltonových rovnic  w[] = { x, p_x, Q, p_Q }
 * */
// vstup : m = hmotnost střely, mu = indukčnost vodiče na jednotku délky (odhad),
// C = kapacita kondenzátoru a U0 = počáteční napětí na něm, R = statický odpor obvodu,
// modely pro mu se rozcházejí, použijeme např. nějakou rozumnou hodnotu
// z http://access.feld.cvut.cz/view.php?cisloclanku=2006042301 (3 až 8 *10^-7 H/m)
/*
*/
static const unsigned N = 4;

static bool  diode  = false;

static const vector<Point<N>> railgun (const Parameters & prms) {
  const real w0 [] = {prms.x0, 0, prms.C * prms.U0, 0};
  const Point<N> bc (0.0, w0);
  
  PFUNC<N> pf[N] = { // funkce lze předat jako lambdy...
    [&](const Point<N> & z, bool & ) -> real {      // F1
        const real p_x = z.w[1];
        return p_x / prms.m;
    },
    [&](const Point<N> & z, bool & divergence) -> real {      // F2
        const real x   = z.w[0];
        if (x == 0.0) { divergence = true; return 0; }
        const real p_Q = z.w[3];
        const real d   = p_Q / x;
        return 0.5 * d * d / prms.mu;
    },
    [&](const Point<N> & z, bool & divergence) -> real {      // F3
        const real x   = z.w[0];
        if (x == 0.0) { divergence = true; return 0; }
        const real p_Q = z.w[3];
        return p_Q / (prms.mu * x);
    },
    [&](const Point<N> & z, bool & divergence) -> real {      // F4
        const real x   = z.w[0];
        if (x == 0.0) { divergence = true; return 0; }
        const real Q   = z.w[2];
        const real p_Q = z.w[3];
        const real Rp  = - (prms.R * p_Q) / (prms.mu * x);
        if (prms.diode) {
          if (Q < 0.0) diode  = true;
          if (diode)   return Rp;
          else         return Rp - Q / prms.C;
        } else {
          return Rp - Q/prms.C;
        }
    }
  };
  
  RungeKutta <N, PFUNC<N>> solver (pf, bc, prms.step, prms.points);
  // solver vyhodí celý vektor dat, tedy časový průběh
  return solver.solve();
}
const vector<Output> simulate (const Parameters & prms) {
  diode = false;
  const vector<Point<N>> rg (railgun (prms));
  vector<Output> data;
  for (auto & p: rg) {        // přepočet z Hamiltonových na nějaké "normální" veličiny
    Output pt;
    pt.t = p.t;               // čas máme
    pt.x = p.w[0] - prms.x0;       // souřadnici také
    pt.v = p.w[1] / prms.m;        // rychlost z hybnosti
    const real d = p.w[3] / p.w[0];
    pt.i = - d / prms.mu;          // Q_dot,   viz F3 (znaménko kvůli grafice, směr proudu je konvence)
    pt.f = 0.5 * d * d / prms.mu;  // p_x_dot, viz F2
    data.push_back(pt);
  }
  return data;
}
