#ifndef SOLVER_H
#define SOLVER_H

#include <vector>
#include <functional>

typedef double real;

template<const unsigned N> struct Point {
  Point (const real t0, const real w0 [N]) : t(t0) {
    for (unsigned n=0; n<N; n++) w[n] = w0[n];
  };
  Point (const Point<N> & other) : t(other.t) {
    for (unsigned n=0; n<N; n++) w[n] = other.w[n];
  }
  real t;
  real w[N];
};

/// Solver metodou Runge-Kutta
template<const unsigned N, typename FUNCTION> class RungeKutta {
  const real            h;            //!< krok metody
  const int             points;       //!< pocet kroků
  const Point<N>        p0;           //!< holder pro počáteční podmínky
  const FUNCTION  *     pf;           //!< počítané funkce typu real (*)(const Point<N> &)
  public:
    /// konstruktor
    /// @param PF Výpočetní objekt
    /// @param step krok metody
    /// @param pts  počet kroků
    RungeKutta(FUNCTION * PF, const Point<N> & bc, const real step, const unsigned pts) :
      h(step), points(pts), p0(bc), pf(PF) {};
    /// vlastní solver @param direction false pak běží pozpátku v čase
    const std::vector<Point<N>> solve (const bool direction=true) const {
      std::vector<Point<N>> data;         //!< data
      const real hh = direction ? +h : -h;
      
      Point<N> p(p0);
      data.push_back(p);
      
      const real hhh = 0.5 * hh;
      const real hhs = hh / 6.0;
      bool divergence = false;
      for (int n = 0; n < points; n++) {       // Runge-Kutta Method 4.order
        real     k1[N];
        for (unsigned k=0; k<N; k++) k1[k] = pf[k](p , divergence);
        Point<N> p2(p);              p2.   t += hhh;
        for (unsigned k=0; k<N; k++) p2.w[k] += hhh * k1[k];
        real     k2[N];
        for (unsigned k=0; k<N; k++) k2[k] = pf[k](p2, divergence);
        Point<N> p3(p);              p3.   t += hhh;
        for (unsigned k=0; k<N; k++) p3.w[k] += hhh * k2[k];
        real     k3[N];
        for (unsigned k=0; k<N; k++) k3[k] = pf[k](p3, divergence);
        Point<N> p4(p);              p4.   t += hh;
        for (unsigned k=0; k<N; k++) p4.w[k] += hh * k3[k];
        real     k4[N];
        for (unsigned k=0; k<N; k++) k4[k] = pf[k](p4, divergence);
        if  (divergence) break;
        p.t += hh;
        for (unsigned k=0; k<N; k++) p.w[k] += hhs * (k1[k] + 2.0 * k2[k] + 2.0 * k3[k] + k4[k]);
        
        data.push_back(p);
      }
      return data;
    }
};

#endif // SOLVER_H
