#ifndef _MAIN_H_
#define _MAIN_H_
#include <QApplication>
#include "mainwindow.h"
#include <qstyle.h>

/**
 * RAILGUN
 * */

#endif // _MAIN_H_
