#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "railgun.h"

class Ui_MainWindow;

enum plot_graphs {
  PLOT_FI = 0, PLOT_VX, PLOT_MAX
};
struct plot_strings {
  const char * a;
  const char * b;
};

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow  (QWidget *parent = 0);
    ~MainWindow ();
protected:
    void replot   (void);
public slots:
    void setPlot  (int);
    void setPts   (double);
    void setStep  (int);
    void set_m    (double);
    void set_mu   (double);
    void set_x0   (double);
    void setC     (double);
    void setU0    (double);
    void setR     (double);
    void changeD  ();
    
    void printDoc (bool);
    void exprt    (bool);
    void setDeflt (bool);
private:
    const double    mu0;
    plot_graphs     plots;
    Parameters      params;
    Ui_MainWindow * ui;
    QCustomPlot   * timePlot;
    QVector<qreal>  xt, at, bt;
};

#endif // MAINWINDOW_H
