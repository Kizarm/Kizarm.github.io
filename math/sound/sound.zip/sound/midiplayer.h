#ifndef DACPLAYER_H
#define DACPLAYER_H

bool PlatformMainLoop (void);
/// Prototyp pro funkci ukončení melodie.
typedef void (*callBackFunc) (void);
/// Třída, která hraje čistě na pozadí.
class MidiPlayer {
  // Veřejné metody
  public:
    /// Konstruktor
    MidiPlayer ();
    /// Start melodie v poli score
    void start  ();
    void stop   ();
    
    float * chunk (const int len);
    void adjustSampleRate (const int sample_rate);
  protected:
  // Chráněné metody
    /// Obsluha softwarového přerušení
    void ToneChange    (void);
    /// Obsluha vzorku
    float nextSample (void);
  private:
    int     dlen;
    float * data;
    unsigned char const * melody;
    unsigned              index;
    volatile int          pause;

};
extern "C" const unsigned char * scores[];

#endif // DACPLAYER_H
