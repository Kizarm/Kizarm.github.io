#include "./lib/libwasm.h"
#include "midiplayer.h"
#include "tone.h"
#include "audio.h"

/**
 * @file
 * @brief Jednoduchý přehrávač midi souborů.
 * 
 * Kompletní midi obsahuje zvukové fonty, které jsou obrovské. Tohle je velice zjednodušené,
 * takže docela dobře přehrává skladby typu ragtime, orchestrální midi jsou skoro nepoužitelné.
 * Přesto se to pro jednoduché zvuky může hodit, protože je to poměrně nenáročné na systémové
 * prostředky. Může to fungovat dokonce i na 8-bitovém uP.
 * */
/// Generátory tónů
static Tone  gens[maxGens];
/// Generuj vzorek pro všechny tóny  @return Vzorek
static inline float genSample (void) {
  int res = 0;
  for (unsigned int i=0; i<maxGens; i++) res += gens[i].step();
  // Pro jistotu omezíme - předejdeme chrastění
  if (res > maxValue) res = maxValue;
  if (res < minValue) res = minValue;
  return float (res) * MultFactor;
}
/// Počítá další vzorek
float MidiPlayer::nextSample (void) {
  if (pause) pause -= 1;  // Časování tónu
  else ToneChange();      // Nový tón - vyvolá přerušení, obsloužené MidiPlayer::ToneChange
  return genSample ();
}
float * MidiPlayer::chunk(const int len) {
  if (len > dlen) {
    dlen = len;
    delete [] data;   // ! na začátku musí být něco málo alokováno, nullptr zde nefunguje
    data = new float [dlen];
    printf("now alocate %d floats (~%zd MiB), data = %p\n", dlen, (dlen * sizeof (float)) >> 20, data);
  }
  for (int n=0; n<dlen; n++) {
    data [n] = nextSample();
  }
  return data;
}
static constexpr int maxTone = (1L<<15) - 1;
static int limit (double tone) {
  int k = (int) (tone + 0.5);
  if (k > maxTone) k = 0;
  return k;
}
static constexpr unsigned MIDILENT = 128u;
unsigned short midiTones [MIDILENT];
unsigned AudioMidiDelay = 44;
void MidiPlayer::adjustSampleRate(const int samle_rate) {
  printf("Adjust  table to %d Hz\n", samle_rate);
  const double srat = double (samle_rate);
  const double dint = 1.0594630943592953; // 12. odmocnina ze 2.0
  double base = 8.1757989156;             // C5 v Hz (http://www.tonalsoft.com/pub/news/pitch-bend.aspx)
  base *= (double)(1UL << 16) / srat;
  for (unsigned n=0; n<MIDILENT; n++) {
    midiTones [n] = limit(base);
    base *= dint;
  }
  AudioMidiDelay = samle_rate / 1000;
}
/// Konstruktor
MidiPlayer::MidiPlayer() {
  index = 0;
  pause = 0;
  dlen  = 0x100;
  data  = new float (dlen);
  melody = scores[index++];
}
/// Spušťění přehrávání
void MidiPlayer::start () {
  for (unsigned i=0; i<maxGens; i++) gens[i].setMidiOff();
  ToneChange(); // Spustíme první.
}
void MidiPlayer::stop (void) {
  melody = scores[index++];
  if (!melody) {
    index  = 0;
    melody = scores[index++];
  }
}
void MidiPlayer::ToneChange (void) {
  unsigned char cmd, midt;
  unsigned int  geno;
  
  for (;;) {              // Pro všechny tóny před pauzou
    cmd = * melody++;
    if (cmd & 0x80) {     // event
      geno  = cmd & 0x0F;
      cmd >>= 4;
      switch (cmd) {
        case 0x8:         // off
          gens[geno].setMidiOff();
          break;
        case 0x9:         // on
          midt = * melody++;
          gens[geno].setMidiOn (midt); 
          break;
        default:
          stop();
          return;         // melodie končí eventem 0xf0
      }
    } else {              // pause
      midt = * melody++;
      // Když to trochu uteče, zase se z toho nestřílí, tak to nechme být.
      pause  = ((unsigned int) cmd << 8) + midt;  // v ms
      pause *= AudioMidiDelay;                    // ale máme vzorkování cca 44 kHz 
      return;
    }
  }
}
