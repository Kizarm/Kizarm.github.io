#ifndef AUDIO_H
#define AUDIO_H

#include <stdint.h>

extern double   AudioSampleRate;
extern unsigned AudioMidiDelay;
/// Počet generátorů.
static constexpr unsigned int  maxGens  = 16;
/// Kladné maximum vzorku.
static constexpr int           maxValue =  30000;
/// Záporné maximum vzorku.
static constexpr int           minValue = -maxValue;
///
static constexpr unsigned int  maxAmplt = (1U<<27);
static constexpr float       MultFactor = 1.0f / float (maxValue);

#endif // AUDIO_H
