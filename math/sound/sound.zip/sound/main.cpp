#include "./lib/libwasm.h"
#include "midiplayer.h"
extern "C" {
  void    EXPORT(init) (const int memlen);
  void    EXPORT(initGenerator) (const int sampleRate);
  float * EXPORT(getChunk) (const int len);
};
////////////////////////////////////////////////////////////////////////////////////
static MidiPlayer player;
////////////////////////////////////////////////////////////////////////////////////
extern "C" {
  extern void __wasm_call_ctors();
  extern char __data_end;
  extern char __heap_base;
  extern char __global_base;
  extern char __memory_base;
  extern char __table_base;
};
void init (const int memlen) {
  _HEAP_MAX = reinterpret_cast<char*> (memlen);   // před prvním voláním malloc() - může být i v konstruktorech
  __wasm_call_ctors();                            // nutné volání statických konstruktorů pokud máme statické třídy
  puts("Interní symboly (ano, umí to i česky):\n");
  printf("\t__data_end    = %p\n", &__data_end);
  printf("\t__heap_base   = %p\n", &__heap_base);
  printf("\t__global_base = %p\n", &__global_base);
  printf("\t__memory_base = %p\n", &__memory_base);
  printf("\t__table_base  = %p\n", &__table_base);
  printf("Memory end = 0x%08X\n", memlen);        // konec paměti, předpokládá že __memory_base = 0
}
double AudioSampleRate = 0.0;
void initGenerator (const int sampleRate) {
  if (AudioSampleRate == double (sampleRate)) return;
  AudioSampleRate = double (sampleRate);
  printf ("Now sampleRate = %d Hz\n", sampleRate);
  player.adjustSampleRate (sampleRate);
  player.start();
}
float * getChunk (const int len) {
  return player.chunk (len);
}
