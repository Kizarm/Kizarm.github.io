#ifndef _HEAP_H
#define _HEAP_H
#define EXPORT(name) __attribute__((used, export_name(#name))) name
// "imports" odpovídá importObject.imports v JS, default je to importObject.env
#define IMPORT(name) __attribute__((import_module("imports"),import_name(#name))) name
#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
  extern int printf (const char *__restrict fmt, ...)__attribute__((__format__(__printf__, 1, 2)));;
  extern void IMPORT(printout) (const char * ptr, const int len);  // external javascript function
  
  extern void * sbrk (unsigned long size);
  extern char * _HEAP_MAX;
#ifdef __cplusplus
};
#endif //__cplusplus
#endif // _HEAP_H
