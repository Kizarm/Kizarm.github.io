#include <stdio.h>
#include <string.h>
#include <mzint.h>
/*
static inline void render_pixel (const int y, const int x, const int r, const int g, const int b) {
  printf("%2dx%2d:%d,%d,%d\n", y, x, r, g, b);
}
*/
int main () {
  struct zint_symbol * qrcode;
  qrcode = ZBarcode_Create();
  if (qrcode != NULL) {
      printf("Symbol successfully created!\n");
  } else return -1;
  qrcode->symbology = BARCODE_QRCODE;
  qrcode->scale     = 1;
  strcpy (qrcode->outfile, "qrcode.svg");
  const char * name = "1234567890";
  ZBarcode_Encode (qrcode, (const unsigned char *) name  , 0);
  /*
  ZBarcode_Buffer (qrcode, 0);
  printf("%dx%d\n",qrcode->bitmap_width, qrcode->bitmap_width);
  int row, col, i = 0;
  for (row = 0; row < qrcode->bitmap_height; row++) {
    for (col = 0; col < qrcode->bitmap_width; col++) {
      const int red   = qrcode->bitmap[i++];
      const int green = qrcode->bitmap[i++];
      const int blue  = qrcode->bitmap[i++];
      render_pixel(row, col, red, green, blue);
    }
  }
  */
  ZBarcode_Print  (qrcode, 0);
  ZBarcode_Delete (qrcode);
  return 0;
}
