# QR Code generator for web.

Je to v zásadě vypůjčený kód ze https://github.com/zint/zint.git,
resp. jen backend. I když je kód velmi dobře strukturovaný, pracuje se soubory
a jsou v něm použita i jiná systémová volání, která web posléze nepoužívá.
Je jednodušší je ignorovat než zkoušet je odstraňovat ze zdrojáků. Bylo by
možné použít emscripten, ale to generuje příliš zbytečného lepidla.
Zvolená metoda používá newlib, známou z embedded zařízení, kompilace ze zdrojáků
pomocí clang je možná, ale chce to trochu invence. Jak na to viz lib/newlib-wasm.zip.
Jsem zvyklý dělat spíš bare-bone moduly bez komplikovaného lepidla.

API zint je jednoduché, umožňuje spoustu voleb, zde se vykreslují jednotlivé pixely
do canvasu webové stránky. Je to spíš příklad než užitečná aplikace.
