#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <mzint.h>
#include "heap.h"

extern "C" void EXPORT(test)   (char * ptr, const int len);
extern "C" void EXPORT(init)   (const int memlen);
extern "C" int  EXPORT(cAlloc) (int len);
extern "C" void IMPORT(exit)   (const int code);
////////////////////////////////////////////////////////////////////////////////////
extern "C" {
  extern void __wasm_call_ctors();
  extern char __data_end;
  extern char __heap_base;
  extern char __global_base;
  extern char __memory_base;
  extern char __table_base;
  extern void _exit (int code) {
    exit (code);
  }
  extern void IMPORT(ReplotPass)(const uint8_t * ptr, const int len, const int w, const int h);
};
void init (const int memlen) {
  _HEAP_MAX = reinterpret_cast<char*> (memlen);   // před prvním voláním malloc() - může být i v konstruktorech
  __wasm_call_ctors();                            // nutné volání statických konstruktorů pokud máme statické třídy
}
int cAlloc (int len) {
  return reinterpret_cast<long>(malloc(len+1));
}
/*************************************************/
class Drawing {
  const int widht, height;
  uint32_t * canvas;
public:
  explicit Drawing (const int w, const int h) : widht(w), height(h) {
    canvas = new uint32_t [widht * height];
  }
  uint8_t * Data () { return reinterpret_cast<uint8_t*> (canvas); }
  int       Size () { return widht * height * sizeof  (uint32_t); }
  int H () { return height; }
  int W () { return widht;  }
  void pixel (const int y, const int x, const uint8_t r, const uint8_t g, const uint8_t b) {
    uint32_t color = 0xFF00'0000u;
    color |= uint32_t (r) << 16;
    color |= uint32_t (g) << 8;
    color |= uint32_t (b) << 0;
    uint32_t & px = canvas [ y * widht + x ];
    px = color;
  }
  ~Drawing () { delete [] canvas; }
};
void test (char * ptr, const int len) {
  ptr [len] = '\0';
  printf("QR Code:\"%s\"\n", ptr);
  struct zint_symbol * qrcode;
  qrcode = ZBarcode_Create();
  if (qrcode != NULL) {
    printf("Symbol successfully created!\n");
  } else {
    printf("ERROR Barcode library\n");
    return;
  }
  qrcode->symbology = BARCODE_QRCODE;
  qrcode->scale     = 8;
  
  ZBarcode_Encode (qrcode, reinterpret_cast<const unsigned char *> (ptr), len);
  
  ZBarcode_Buffer (qrcode, 0);
  printf("Geometry: %dx%d px\n",qrcode->bitmap_width, qrcode->bitmap_height);
  Drawing plot (qrcode->bitmap_width, qrcode->bitmap_height);
  int row, col, i = 0;
  for (row = 0; row < qrcode->bitmap_height; row++) {
    for (col = 0; col < qrcode->bitmap_width; col++) {
      const uint8_t red   = qrcode->bitmap[i++];
      const uint8_t green = qrcode->bitmap[i++];
      const uint8_t blue  = qrcode->bitmap[i++];
      plot.pixel(row, col, red, green, blue);
    }
  }
  ReplotPass (plot.Data(), plot.Size(), plot.W(), plot.H());  
  ZBarcode_Delete (qrcode);  
}
