#include "heap.h"
extern void IMPORT(memoryGrow) (const int block);
extern char __heap_base;

static const char * _HEAP_START = &__heap_base;
char *              _HEAP_MAX   = &__heap_base;

void * sbrk (unsigned long size) {
  static const char * heap_ptr;
  const char *        old_heap_ptr;
  static unsigned int init_sbrk = 0;
  /* heap_ptr is initialized to HEAP_START */
  if (init_sbrk == 0) {
    heap_ptr = _HEAP_START;
    init_sbrk = 1;
  }
  old_heap_ptr = heap_ptr;
  /* Tohle je jen zkusmo, uvidíme, zatím se zdá, že to chodí. 
   * Těžko říct, co to udělá, když dojde paměť, ale pár MiB to zvládne.
   */
  if ((heap_ptr + size) > _HEAP_MAX) {
    const int blocks = (((heap_ptr + size) - _HEAP_MAX) >> 16) + 1;
    memoryGrow (blocks);
    _HEAP_MAX += blocks << 16;
  }  
  heap_ptr += size;
  return (void *)old_heap_ptr;
}
typedef __SIZE_TYPE__ size_t;
/* Zbytečnosti, které jsou v kódu zint použity, ale jsou v zásadě mimo,
 * protože web to nepoužívá. Je to jednodušší než to měnit ve zdrojácích.
 * */
int open  (const char * p, int f, int m) { return 1; }
int close (int fd) { return 0; }
int read (int fd, void * b, size_t l) { return l; }
int write(int fd, const void * b, size_t l) {
  if ((fd == 1) || (fd == 2)) printout(b, l);
  return l;
}
size_t lseek(int fd, size_t offset, int whence) { return 0; }
int fstat(int fd, void * statbuf) { return 0; }
// formátování pro long double asi nebudu používat
double __trunctfdf2(long double a) { return (double)(a); }
#include <sys/types.h>
pid_t getpid(void) { return 0; }
int kill(pid_t pid, int sig) { return 0; }
int isatty(int fd) { return 0; }

int mkdir(const char *pathname, mode_t mode) { return 0; }
int stat(const char *pathname, void *statbuf) { return 0; }
