#include <stdint.h>
#include "libwasm.h"
#include "chaosgame.h"

////////////////////////////////////////////////////////////////////////////////////
extern "C" {
  extern void __wasm_call_ctors();
  extern char __data_end;
  extern char __heap_base;
  extern char __global_base;
  extern char __memory_base;
  extern char __table_base;
  extern void IMPORT(ReplotPass)(const uint8_t * ptr, const int len);
  extern void EXPORT(init)      (const int memlen);
  extern void EXPORT(InitImage) (const int n);
  extern void EXPORT(Change)    ();
  extern void EXPORT(Escape)    ();
  extern void EXPORT(PassAll)   ();
  extern void EXPORT(Number)    (const int);
};
void init (const int memlen) {
  _HEAP_MAX = reinterpret_cast<char*> (memlen);   // před prvním voláním malloc() - může být i v konstruktorech
  __wasm_call_ctors();                            // nutné volání statických konstruktorů pokud máme statické třídy
}

static ChaosGame game;

void Escape () {
  game.Clear();
  ReplotPass(game.getData(), game.getSize());
}
void InitImage (const int n) {
  srand(n);
  Escape();
}
void Change () {
  game.Clear();
  game.Init ();
}
void Number (const int n) {
  game.Number(n);
}
void PassAll () {
  game.PassAll();
  ReplotPass(game.getData(), game.getSize());
}
