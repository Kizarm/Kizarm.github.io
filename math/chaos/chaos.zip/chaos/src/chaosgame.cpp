#include "libwasm.h"
#include "chaosgame.h"

static const Fractal<4u> Barnsley = {
  {
    [] (const FPoint & p) -> const FPoint {
      const Matrix m (0.0f, 0.0f, 0.0f, 0.16f);
      return m * p;
    },
    [] (const FPoint & p) -> const FPoint {
      const Matrix m (0.85f, 0.04f, -0.04f, 0.85f);
      const FPoint q (0.0f, 1.6f);
      return m * p + q;
    },
    [] (const FPoint & p) -> const FPoint {
      const Matrix m (0.20f, -0.26f, 0.23f, 0.22f);
      const FPoint q (0.0f, 1.6f);
      return m * p + q;
    },
    [] (const FPoint & p) -> const FPoint {
      const Matrix m (-0.15f, 0.28f, 0.26f, 0.24f);
      const FPoint q (0.0f, 0.44f);
      return m * p + q;
    }
  },
  {
    0.01f, 0.85f, 0.07f, 0.07f
  }
};
static const Fractal<3u> Sierpinski = {
  {
    [] (const FPoint & p) -> const FPoint {
      const FPoint v (0.0f, 10.0f);
      return (p + v) * 0.5f;
    },
    [] (const FPoint & p) -> const FPoint {
      const FPoint v (-5.77f, 0.0f);
      return (p + v) * 0.5f;
    },
    [] (const FPoint & p) -> const FPoint {
      const FPoint v (+5.77f, 0.0f);
      return (p + v) * 0.5f;
    }
  },
  {
    0.3333f, 0.3333f, 0.3334f
  }
};
static const real normalize (const uint32_t p) {
  constexpr uint32_t m = 0xFFFF'FFFFu;
  const real r = (real) p / (real) m;
  return r;
}
static const char * DescTable [] = {
  "Sierpińského trojúhelník",
  "Barnsleyho kapradí",
};

ChaosGame::ChaosGame() noexcept :  pVideoBit (new uint32_t [x_max * y_max]),
  count (50u), next (), pict (BARNSLEY) {
  printf("%s", DescTable [pict]);
}
void ChaosGame::Init() {
  if (pict == BARNSLEY) { pict = SIERPINSKI; }
  else                  { pict = BARNSLEY;   }
  printf("%s", DescTable [pict]);  
}
void ChaosGame::PassOne() {
  const real np = normalize (random());
  FPoint pt;
  switch (pict) {
    case SIERPINSKI: pt = Sierpinski.transformation(next, np); break;
    case BARNSLEY  : pt = Barnsley  .transformation(next, np); break;
  }
  const real     z = 60.0f;
  const unsigned x = (unsigned) (z * pt.x + 400.5f);
  const unsigned y = (unsigned) (600.5f - z * pt.y);
  at (x, y) = 0xFF00'FF00u;
  
  next = pt;
}
void ChaosGame::PassAll() {
  for (unsigned k = 0; k<count; k++) PassOne();
}

void ChaosGame::Clear() {
  for (unsigned y=0; y<y_max; y++) {
    for (unsigned x=0; x<x_max; x++) {
      at (x,y) = 0xFF00'0000u;
    }
  }
}
static const unsigned pass_table [] = {
  1, 2, 5, 10, 20, 50, 100, 200, 500, 1000,
};
void ChaosGame::Number(const int n) {
  count = pass_table [n];
}
