#include "mmath.h"
#include "libwasm.h"
#include "canvas.h"

Canvas::Canvas(const int w, const int h) : width(w), height(h),
  outpixel(0u), current(0xFF000000), matrix (1.0, 0.0, 0.0, -1.0, 0.5 * (real) w, 0.5 * (real) (h)) {
  data = new Color [w * h];
}

Canvas::~Canvas() {
  delete [] data;
}
void Canvas::fill (const Color & c) {
  for (int y=0; y<height; y++) {
    for (int x=0; x<width; x++) {
      at (x, y) = c;
    }
  }
}
Color & Canvas::at (const int x, const int y) {
  if (!bound(x, y)) return outpixel;
  const int result = x + y * width;
  return data [result];
}
bool Canvas::bound (const int x, const int y) const {
  if (x < 0)       return false;
  if (y < 0)       return false;
  if (x >= width)  return false;
  if (y >= height) return false;
  return true;
}
void Canvas::line (const real xp, const real yp, const real xe, const real ye, const unsigned w) {
  real dx = xe - xp;
  real dy = yp - ye;
  real dl = dx * dx + dy * dy;
  if (dl == 0.0) return;
  dl = __builtin_sqrt (dl); // TODO: sqrt
  dx = dx / dl;
  dy = dy / dl;
  const Matrix m (dx, dy, -dy, dx, xp, yp);
  
  const unsigned nl = w / 2;
  const unsigned wl = w % 2;
  const real hl = 0.5 * (real) w;
  if (wl) {
    for (real n=-hl; n<dl+hl; n+=1.0) {
      const FPoint p = m * FPoint (n, 0.0);
      at (iround (p.x), iround (p.y)) = current;
    }
  }
  for (unsigned k=0; k<nl; k++) {
    const real dw = hl - (real) k;
    const real dz = wl ? 1.0 : 0.5;
    const real dh = (real) k + dz;
    for (real n=-dw; n<dl+dw; n+=1.0) {
      const FPoint p = m * FPoint (n, +dh);
      at (iround (p.x), iround (p.y)) = current;
      const FPoint q = m * FPoint (n, -dh);
      at (iround (q.x), iround (q.y)) = current;
    }
  }  
}
void Canvas::line (const FPoint & begin, const FPoint & end, const unsigned w) {
  const FPoint b (matrix * begin);
  const FPoint e (matrix * end  );
  // printf("%d:%d - %d:%d\n", x0, y0, x1, y1);
  line (b.x, b.y, e.x, e.y, w);
}
void Canvas::circ (const FPoint & center, const real radius) {
  if (radius == 0) return;
  double x = radius, y = 0.0;
  const double dx = 1.0 / radius;
  const double ms = radius * 6.3;
  real count = 0.0;
  // kruh se da nakreslit i bez sin a cos, rychle ale trochu nepresne
  for (;;) {
    x += y * dx; y -= x * dx;
    const FPoint e (center.x + x, center.y + y);
    const FPoint t (matrix * e);
    at (iround (t.x), iround (t.y)) = current;
    count += 1.0;
    if (count > ms) break;
  }
}
void Canvas::setMatrix (const Matrix& m) {
  matrix = m;
}
