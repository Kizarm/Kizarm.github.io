#include "solver.h"
#include "solverpublic.h"

template<class T, size_t N> constexpr size_t SIZE (T (&)[N]) { return N; }
template<const  unsigned N> using PFUNC = bool (*) (const NPoint<N> &, real &);

/** TEST
 *  t, w : x, y, z
 * Lorenzovy rovnice
 * */

static real omega = 27.0;
static const real sigma = 10.0, beta = 8.0 / 3.0;

static const real w0 [] = {0.0, 1.0, 10.0};  // Počet počátečních podmínek musí odpovídat počtu rovnic...
static const unsigned M = SIZE (w0);         // čili určuje celkový rozsah výpočtu.

static const NPoint<M> bc (0.0, w0);

static bool F1 (const NPoint<M> & w, real & result) {
    const real x = w.w[0];
    const real y = w.w[1];
    result  = sigma * (y - x);
    return false;
}
static bool F2 (const NPoint<M> & w, real & result) {
    const real x = w.w[0];
    const real y = w.w[1];
    const real z = w.w[2];
    result  = x * (omega - z) - y;
    return false;
}
static bool F3 (const NPoint<M> & w, real & result) {
    const real x = w.w[0];
    const real y = w.w[1];
    const real z = w.w[2];
    result  = x * y - beta * z;
    return false;
}

static PFUNC<M> pf[M] = {
  F1, F2, F3
};

static RungeKutta <M, PFUNC<M>> solver (pf, bc, 0.001);

/***********************************************************************************/
void OmegaChange (const real prm) {
  omega = prm;
}

FPoint DiffEqPass () {
  const NPoint<M> & p = solver.solve();
  FPoint result (p.w[0], p.w[1]);
  return result;
}
FPoint DiffEqBc () {
  const NPoint<M> & p (bc);
  FPoint result (p.w[0], p.w[1]);
  return result;
}
