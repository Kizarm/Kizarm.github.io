#ifndef ELEMENT_H
#define ELEMENT_H

#include <vector>
#include <string>
#include <functional>
#include "solverpublic.h"

class BackGround : public Canvas {
  public:
    BackGround (const int w, const int h) : Canvas (w, h) {};
    virtual ~BackGround (){};
    void drawings ();
};
class ForeGround : public Canvas {
  FPoint begin;
  int index, speed;
  public:
    ForeGround (const int w, const int h) : Canvas (w, h) { begin = DiffEqBc(); index = 0; speed = 10; };
    virtual ~ForeGround (){};
    void drawings ();
    void step ();
    void changeColor();
    void changeSpeed (int s) { speed = s; };
};
struct CommonPlots {
  int maxx, maxy;
  BackGround * bg;
  ForeGround * fg;
  CommonPlots (const int w, const int h) : maxx (w), maxy(h) {
    bg = new BackGround (w,h);
    fg = new ForeGround (w,h);
    bg->drawings();
    fg->drawings();
  }
  ~CommonPlots () {
    delete bg;
    delete fg;
  }
};
/*************************** Kooperace s javascriptem ***********************************/
enum ACTION_TYPE {
  ACTION_NONE = 0, ACTION_INT, ACTION_STRING
};

struct Action {
  int type;
  std::string src_id;
  std::string dst_id;
  std::string ivalue;   // integer, přečtená hodnota
  std::string dvalue;   // integer nebo double, přepočítaná hodnota
  Action () {
    type = 0; src_id = std::string ("none"); dst_id = std::string ("none"); ivalue = std::string ("none"); dvalue = std::string ("none");
  }
  Action (const ACTION_TYPE t, const std::string id, const std::string ival, const std::string dval) {
    type = (int) t, src_id = id, dst_id = id, ivalue = ival, dvalue = dval;
  }
  Action (const Action & o) {
    type = o.type; src_id = o.src_id; dst_id = o.dst_id; ivalue = o.ivalue; dvalue = o.dvalue;
  }
  Action & operator= (const Action & o) {
    type = o.type; src_id = o.src_id; dst_id = o.dst_id; ivalue = o.ivalue; dvalue = o.dvalue;
    return * this;
  }
};
struct InitValues {
  int                 max;
  std::vector<Action> values;
};
/**************************** HTML prvky a vlastnosti ***********************************/
class HtmlElement;
class HtmlContainer;
/// Přepočet hodnoty, formátování na výstup a nastavení parametru ,lze nastavit jako lambda výraz
typedef std::function<Action(HtmlElement * e, const int val, HtmlContainer * c)> ActionCallBack;

class HtmlTag {
    std::string name;
    std::string value;
    HtmlTag * next;     // Linked List
  public:
    HtmlTag (const char * n, const char * v) : name(n), value(v) { next = nullptr; }
    ~HtmlTag () { if (next) delete next; }
    std::string getName  () { return name;  }
    std::string getValue () { return value; }
    void add (HtmlTag * tag) {
      if (next) next->add (tag);
      else next = tag;
    };
    std::string to_string () {
      std::string result = ' ' + name + "=\"" + value + '\"';
      if (next) result += next->to_string();
      return result;
    }
};
class HtmlElement {
    std::string    name;
    std::string    Id;
    HtmlElement *  atte;    // attached element může být použit pro výstup
    ActionCallBack atCb;    // pomocí toho callbacku
    HtmlTag     *  tags;    // linked list
    /* Binary Tree */
    HtmlElement *  next;
    HtmlElement *  down;
    int hold;               // drží hodnotu, pokud nějaká je
  public:
    HtmlContainer * parent;
    HtmlElement (const char * n, HtmlContainer * p = nullptr): name(n), Id("none"), atte (this), atCb(nullptr) {
      tags = nullptr; next = nullptr; down = nullptr; hold = 0; parent = p;
    }
    virtual ~HtmlElement () { if (tags) delete tags; if (next) delete next; if (down) delete down; };
    virtual std::string end_string () {
      std::string result = "</" + name + '>';  return result;
    }
    void setCb (ActionCallBack cb) { atCb = cb; }
    virtual Action action (const int val) {
      Action act;
      if (atCb) act = atCb (this, val, parent);
      return act;
    }
    int  getHold () { return hold; }
    void setHold (const int n) { hold = n; }
    std::string getId () { return Id; }
    HtmlElement * getAttach () { return atte; }
    void Attach (HtmlElement * other) { atte = other; };
    std::string to_string ();
    void addTag (HtmlTag * tag) {
      if (tag->getName() == std::string ("id")) Id = tag->getValue();
      if (tags) tags->add(tag);
      else      tags = tag;
    }
    void append (HtmlElement * e) {
      if (next) next->append(e);
      else next = e;
    }
    void insert (HtmlElement * e) {
      if (down) down->append(e);
      else down = e;
    }
};
/******************************* Odvozené prvky *****************************************/
class IndexedElement : public HtmlElement {
    std::string value;
  public:
    IndexedElement (const char * n, const char * v, HtmlContainer * p, const char * func = nullptr);
    virtual ~IndexedElement() {};
    std::string getValue () { return value; }
};
class Text : public IndexedElement {
  public:
    Text (const char * n, const char * v, HtmlContainer * p = nullptr, const char * func = nullptr);
    virtual ~Text () {}
    std::string end_string () override;
};
class Button : public IndexedElement {
  public:
    Button (const char * n, HtmlContainer * p, const char * func = nullptr);
    virtual ~Button () {}
    std::string end_string () override;
};
class Slider : public IndexedElement {
  public:
    Slider (HtmlContainer * p, const char * func = nullptr);
    virtual ~Slider () {}
    std::string end_string () override;
};
class SliderRow {
  HtmlContainer * parent;
  const char    * name;
  const int begin;
  public:
    HtmlElement * slider;
    SliderRow (HtmlContainer * p, const char * n, const int begin = 0);
    HtmlElement * Init ();
  protected:
};
/******************* Použito spíš jako struktura - hlavní kontejner *********************/
class HtmlContainer {
  HtmlElement * root;   // Kořenový prvek je jediný privátní
  public:
  int           order;                // číslování prvků
  bool          StartStop;
  CommonPlots * plots;                // vše, co se týká vykreslování do canvasu
  std::vector<HtmlElement*> ordered;  // pro použití javascriptem - číslované prvky zajišťují určitou funkci
  std::vector<HtmlElement*> sliders;  // pro použití javascriptem, jen počet sliderů
  HtmlElement * canvas; // možná ani nemusí být přístupný, ale je to jedno
  public:
    HtmlContainer ();
    ~HtmlContainer ();
    // Vše je pak obaleno globální metodou a voláno javascriptem.
    Action back (const int index, const int input);
    void ChangeOmega (const double w);
    std::string to_string ();
    InitValues  InitSliders ();
  protected:
};

#endif // ELEMENT_H
