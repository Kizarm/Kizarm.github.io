#include "libwasm.h"
#include "solverpublic.h"
#include "mmath.h"

extern "C" {
  extern void __wasm_call_ctors();
  extern char __data_end;
  extern char __heap_base;
  extern char __global_base;
  extern char __memory_base;
  extern char __table_base;
  extern void EXPORT(init)     (const int memlen);
  extern void EXPORT(graph)    (int w, int h);
  extern void EXPORT(wChanged) (int w);
  extern void EXPORT(gReset)   ();
  extern void EXPORT(wChangedSpeed) (int w);
  extern void * EXPORT(bg_data)();
  extern void * EXPORT(fg_data)();
  extern void * EXPORT(gStep)  ();
  extern void * EXPORT(getdesc)();
};
void init (const int memlen) {
  _HEAP_MAX = reinterpret_cast<char*> (memlen);   // před prvním voláním malloc() - může být i v konstruktorech
  __wasm_call_ctors();                            // nutné volání statických konstruktorů pokud máme statické třídy
  puts ("*** Module initialized ***\n");
}

class BackGround : public Canvas {
  public:
    BackGround (const int w, const int h) : Canvas (w, h) {};
    virtual ~BackGround (){};
    void drawings ();
};
class ForeGround : public Canvas {
  FPoint begin;
  int index, speed;
  public:
    ForeGround (const int w, const int h) : Canvas (w, h) { begin = DiffEqBc(); index = 0; speed = 10; };
    virtual ~ForeGround (){};
    void drawings ();
    void step ();
    void changeColor();
    void changeSpeed (int s) { speed = s; };
};
struct Common {
  int maxx, maxy;
  BackGround * bg;
  ForeGround * fg;
  Common (const int w, const int h) : maxx (w), maxy(h) {
    bg = new BackGround (w,h);
    fg = new ForeGround (w,h);
    bg->drawings();
    fg->drawings();
  }
  ~Common () {
    delete bg;
    delete fg;
  }
};
void BackGround::drawings() {
  const real maxx = getMaxX(),  maxy = getMaxY();
  fill (Color(0, 0, 0, 0xFF));
  const real hx = 0.5 * maxx, hy = 0.5 * maxy;
  setColor (Color (0x80, 0x80, 0));
  line (FPoint(-hx, 0), FPoint(hx, 0));
  line (FPoint(0, -hy), FPoint(0, hy));
  const real st = 50.0, mt = 25.0, dw = 2.0;
  for (real x=mt; x<hx; x+=mt) {
    line (FPoint(+x, dw), FPoint(+x, -dw));
    line (FPoint(-x, dw), FPoint(-x, -dw));
  }
  for (real y=mt; y<hy; y+=mt) {
    line (FPoint(dw, +y), FPoint(-dw, +y));
    line (FPoint(dw, -y), FPoint(-dw, -y));
  }
  setColor (Color (0x40, 0x40, 0x40));
  for (real x=st; x<hx; x+=st) {
    line (FPoint(+x,-hy), FPoint(+x,hy));
    line (FPoint(-x,-hy), FPoint(-x,hy));
  }
  for (real y=st; y<hy; y+=st) {
    line (FPoint(-hx,+y), FPoint(hx,+y));
    line (FPoint(-hx,-y), FPoint(hx,-y));
  }
}
void ForeGround::drawings() {
  index = 0;
  fill     (Color(0xFF, 0xFF, 0xFF, 0));
  setColor (Color(0xFF, 0, 0xFF, 0xFF));
  const double maxx = getMaxX(), maxy = getMaxY();
  const Matrix m (0.025 * maxx, 0.0, 0.0, -0.02 * maxy, 0.5 * maxx, 0.5 * maxy);
  setMatrix (m);
}
void ForeGround::step() {
  // postupné stmívání
  const int mxy  = getMaxX() * getMaxY();
  Color * pixels = reinterpret_cast<Color*> (getData());
  for (int i=0; i<mxy; i++) {
    Color & px = pixels [i];
    if (px.a != 0u) px.a -= 1u;
  }
  // vlastní vykreslení
  for (int i=0; i<speed; i++) {
    FPoint end = DiffEqPass();
    line (begin, end, 3);
    begin = end;
  }
  changeColor();
}
void ForeGround::changeColor() {
  const double fi = D_PI / 3.0;       // úhel posunu argumentu barvy
  double a1, a2, a3;
  int   r,g,b;                        // proměnné barvy
  // výpočet barvy - duha
  a1 = (double) index / 33.0;         // argument pro r
  a2 = a1 + fi;                       // argument pro g
  a3 = a2 + fi;                       // argument pro b
  r = (int)(127.0 + 127.0*sin(a1));
  g = (int)(127.0 + 127.0*sin(a2));
  b = (int)(127.0 + 127.0*sin(a3));
  Color color(r, g, b, 255);
  setColor(color);
  index += 1;
}


static Common  * canvas      = nullptr;
static uint8_t * description = nullptr;

void graph (int w, int h) {
  if (canvas) {
    delete canvas;
    canvas = nullptr;
  }
  canvas = new Common (w, h);
}
void wChanged (int w) {
  const double omega = 0.1 * (double) w;
  OmegaChange (omega);
};
void gReset () {
  canvas->fg->drawings();
}
void wChangedSpeed (int w) {
  canvas->fg->changeSpeed (w);
}
/* Asi by bylo obtížné vrátit 2 čísla (i když by to už mělo jít),
 * takže se vrací ukazatel na statickou strukturu, která je obsahuje.
 * Je to sice divné, ale funguje to a ani není potřeba moc lepidla navíc.
 * */
struct PtrLen {
  void * ptr;
  int    len;
};
void * getdesc () {
  static PtrLen pl;
  if (description) {
    free (description);
    description = nullptr;
  }
  const unsigned max = 256;
  char str [max];
  const size_t n = snprintf(str, max, "Lorenzův atraktor %d x %d", canvas->maxx, canvas->maxy);
  description = reinterpret_cast<uint8_t*> (malloc (n));
  if (description == nullptr) return & pl;
  memcpy (description, str, n);
  
  pl.ptr = description;
  pl.len = n;
  return & pl;
};
void * bg_data () {
  static PtrLen pl;
  pl.ptr = canvas->bg->getData();
  pl.len = canvas->bg->getSize();
  return & pl;
}
void * fg_data () {
  static PtrLen pl;
  pl.ptr = canvas->fg->getData();
  pl.len = canvas->fg->getSize();
  return & pl;
}
void * gStep () {
  canvas->fg->step();
  static PtrLen pl;
  pl.ptr = canvas->fg->getData();
  pl.len = canvas->fg->getSize();
  return & pl;
};
