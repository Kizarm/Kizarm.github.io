#include <emscripten/bind.h>
#include <emscripten.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <string>
#include "element.h"

/** Je to napsáno dost chaoticky, protože u docela dost postupů jsem musel dost pracně hledat jak dál.
 * Refaktorizace na základě znalosti jak to funguje by byla dobrá, ale není potřeba.
 * 27.07.2020 Vyházeny některé redundantní struktury.
 * */
static const char * style_string = R"---(
html,
body {
    height:  100%;
    margin:  0;
    padding: 0;
}
.canvas {
    width:  98vw;
    height: 75vh;
}
.slider {
  -webkit-appearance: none;
  width: 100%;
  height: 30px;
  border-radius: 5px;  
  background: #00FF00;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}
.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider::-moz-range-thumb {
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.button {
  background-color: #00F0F0;
  border: none;
  color: black;
  padding: 10px 64px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 24px;
  border: 2px solid #4CAF50;
}
.frame1 {
  width:  90%;
  margin: auto;
  background-color: #FFFFC0;
  border: 10px solid #F0C0F0;
}
)---";

static HtmlContainer * pContainer = nullptr;

std::string getStyle () {
  return std::string (style_string);
}

std::string Init () {
  if (pContainer) {
    delete pContainer;
    pContainer = nullptr;
  }
  pContainer = new HtmlContainer ();
  return pContainer->to_string();
};
Action BackAction (const int index, const int input) {
  return pContainer->back(index, input);
}
InitValues ZeroSliders () {
  return pContainer->InitSliders();
}
std::string WasmElementId (int index) {
  HtmlElement * e = pContainer->ordered [index];
  if (e) return e->getId();
  return std::string ("none");
}
void graph (int w, int h) {
  if (pContainer->plots) {
    delete pContainer->plots;
    pContainer->plots = nullptr;
  }
  pContainer->plots = new CommonPlots (w, h);
}
int gEnabled () {
  return pContainer->StartStop ? 1 : 0;
}
emscripten::val bg_data () {
  return emscripten::val (emscripten::typed_memory_view (pContainer->plots->bg->getSize(), pContainer->plots->bg->getData()));
}
emscripten::val fg_data () {
  return emscripten::val (emscripten::typed_memory_view (pContainer->plots->fg->getSize(), pContainer->plots->fg->getData()));
}
emscripten::val gStep () {
  pContainer->plots->fg->step();
  return emscripten::val (emscripten::typed_memory_view (pContainer->plots->fg->getSize(), pContainer->plots->fg->getData()));
};

/* V následujících funkcích běží i javascript. Globální proměnné document a Module
 zde zřejmě existují, takže to fungovat může, přístup na DOM je zajištěn. (index -> $0) */
void WasmDriver (int index) {
  EM_ASM ({
    const id = Module.WasmElementId ($0);
    // Pokud má element nějakou hodnotu má, zpracuj ji Module.BackAction().
    const val = document.getElementById (id).value;
    const res = (!val || 0 === val.length) ? -1 : parseInt (val, 10);
    const act = Module.BackAction ($0, res);
    // console.log (act);
    switch (act.type) {
      case 1: document.getElementById(act.dst_id).value = parseInt (act.ivalue, 10); break;
      case 2: document.getElementById(act.dst_id).innerHTML = act.dvalue; break;
      default : break;
    };
  }, index);
}
/* Možná by bylo lépe přesunout do index.html, jen zkouška */

void WasmInitAll () {
  EM_ASM (
    var sheet = document.createElement('style');
    sheet.innerHTML = Module.getStyle();
    document.body.appendChild (sheet);
    
    const origWidth = document.getElementById('canvas').style.width;
    var bgImage = new Image();
    var fgImage = new Image();
    var init = Module.ZeroSliders();
    for (var n=0; n<init.max; n++) {
      var one = init.values.get (n);
      // console.log (one);
      document.getElementById(one.src_id).value     = one.ivalue;
      document.getElementById(one.dst_id).innerHTML = one.dvalue;
    }
    window.addEventListener('resize', resizeCanvas, false);
    resizeCanvas();
    function resizeCanvas() {
      var canvas    = document.getElementById('canvas');
      // nechci moc velky obrazek - problem je dnes spis sirka
      if (innerWidth > 1100) canvas.style.width = '1024px';
      else                   canvas.style.width = origWidth;
      const width   = canvas.clientWidth;
      const height  = canvas.clientHeight;
      canvas.width  = width;
      canvas.height = height;
      drawStuff ();
      window.setTimeout (ReplotPass, 50);
    }
    function backup (m_Data) {
      var canvas   = document.getElementById('canvas');
      const width  = canvas.width;
      const height = canvas.height;
      var backupCanvas  = document.createElement('canvas');
      backupCanvas.width  = width;
      backupCanvas.height = height;
      const backupContext = backupCanvas.getContext('2d');
      const bData = new ImageData (new Uint8ClampedArray (m_Data), width, height);
      backupContext.putImageData (bData, 0, 0);
      return backupCanvas;
    }
    function drawStuff() {
      var canvas   = document.getElementById('canvas');
      var context  = canvas.getContext('2d');
      const width  = canvas.width;
      const height = canvas.height;
      Module.graph (width, height);
      context.clearRect(0, 0, width, height); // clear canvas
      delete bgImage;
      bgImage = backup (Module.bg_data());
      delete fgImage;
      fgImage = backup (Module.fg_data());
      context.drawImage (bgImage, 0, 0);
      context.drawImage (fgImage, 0, 0);
    }
    function ReplotPass () {
      if (Module.gEnabled()) {
        var canvas  = document.getElementById('canvas');
        var context = canvas.getContext('2d');
        delete fgImage;
        fgImage = backup (Module.gStep());
        context.clearRect(0, 0, canvas.widht, canvas.height); // clear canvas
        context.drawImage (bgImage, 0, 0);
        context.drawImage (fgImage, 0, 0);
      }
      window.setTimeout (ReplotPass, 20);
    }
  );
}

EMSCRIPTEN_BINDINGS (my_bind) {
  emscripten::function ("Init",  &Init);
  emscripten::value_object<Action>("Action")
    .field ("type",    &Action::type)
    .field ("src_id",  &Action::src_id)
    .field ("dst_id",  &Action::dst_id)
    .field ("ivalue",  &Action::ivalue)
    .field ("dvalue",  &Action::dvalue)
    ;
  emscripten::function ("BackAction", &BackAction);
  emscripten::register_vector<Action>("vector<Action>");
  emscripten::value_object<InitValues>("InitValues")
    .field ("max",    &InitValues::max)
    .field ("values", &InitValues::values)
  ;
  emscripten::function ("WasmInitAll",   &WasmInitAll);
  emscripten::function ("ZeroSliders",   &ZeroSliders);
  emscripten::function ("WasmDriver",    &WasmDriver);
  emscripten::function ("WasmElementId", &WasmElementId);
  
  emscripten::function ("bg_data",  &bg_data);
  emscripten::function ("fg_data",  &fg_data);
  emscripten::function ("graph",    &graph);
  emscripten::function ("gStep",    &gStep);
  emscripten::function ("gEnabled", &gEnabled);
  emscripten::function ("getStyle", &getStyle);
}
