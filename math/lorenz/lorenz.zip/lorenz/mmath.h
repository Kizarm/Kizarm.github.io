#ifndef MMATH_HH
#define MMATH_HH
static constexpr double dabs (const double a) { return a < 0.0 ? -a : +a; }
static constexpr int  iround (const double a) { return a > 0.0 ? int(a + 0.5) : int(a - 0.5); }
static constexpr double D_PI = 2.0 * 3.14159265358979323846;
static constexpr double sin (const double x) {
  if (x <    0) return -sin (-x);
  if (x > D_PI) return +sin (x - D_PI);
  double result (0.0), element(x), divider(1.0);
  constexpr double eps = 1.0e-9;      // maximální chyba výpočtu
  const double aa = - (x * x);
  for (;;) {
    result  += element;
    if (dabs  (element) < eps) break;
    divider += 1.0;
    double fact = divider;
    divider += 1.0;
    fact    *= divider;
    element *= aa / fact;
  }
  return result;
}
#endif // MMATH_HH
