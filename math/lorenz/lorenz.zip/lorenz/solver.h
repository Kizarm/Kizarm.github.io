#ifndef SOLVER_H
#define SOLVER_H

typedef double real;

template<const unsigned N> struct NPoint {
  NPoint () : t(0) {
    for (unsigned n=0; n<N; n++) w[n] = 0;    
  };
  NPoint (const real t0, const real w0 [N]) : t(t0) {
    for (unsigned n=0; n<N; n++) w[n] = w0[n];
  };
  NPoint (const NPoint<N> & other) : t(other.t) {
    for (unsigned n=0; n<N; n++) w[n] = other.w[n];
  }
  real t;
  real w[N];
};

/// Solver metodou Runge-Kutta
template<const unsigned N, typename FUNCTION> class RungeKutta {
  const real            h;            //!< krok metody
  const NPoint<N>       p0;           //!< placeholder pro počáteční podmínky
  FUNCTION              pf[N];        //!< počítané funkce typu real (*)(const NPoint<N> &, real &)
  NPoint<N>             data;         //!< data
  public:
    /// konstruktor
    /// @param PF Výpočetní objekt
    /// @param bc počáteční podmínky
    /// @param pts  počet kroků
    RungeKutta(FUNCTION PF[N], const NPoint<N> & bc, const real step) :
      h(step), p0(bc) {
      data = p0;
      for (unsigned n=0; n<N; n++) pf[n] = PF[n];
    };
    /// vlastní solver @param direction false pak běží pozpátku v čase, zde jeden krok
    const NPoint<N> & solve (const bool direction=true) {
      const real hh = direction ? +h : -h;

      NPoint<N> & p = data;

      const real hhh = 0.5 * hh;
      const real hhs = hh / 6.0;
      real     k1[N];

      for (unsigned k=0; k<N; k++) pf[k](p , k1[k]);
      NPoint<N> p2(p);              p2.   t += hhh;
      for (unsigned k=0; k<N; k++) p2.w[k] += hhh * k1[k];
      real     k2[N];
      for (unsigned k=0; k<N; k++) pf[k](p2, k2[k]);
      NPoint<N> p3(p);              p3.   t += hhh;
      for (unsigned k=0; k<N; k++) p3.w[k] += hhh * k2[k];
      real     k3[N];
      for (unsigned k=0; k<N; k++) pf[k](p3, k3[k]);
      NPoint<N> p4(p);              p4.   t += hh;
      for (unsigned k=0; k<N; k++) p4.w[k] += hh * k3[k];
      real     k4[N];
      for (unsigned k=0; k<N; k++) pf[k](p4, k4[k]);
      p.t += hh;
      for (unsigned k=0; k<N; k++)  p.w[k] += hhs * (k1[k] + 2.0 * k2[k] + 2.0 * k3[k] + k4[k]);

      return data;
    }
};

#endif // SOLVER_H
