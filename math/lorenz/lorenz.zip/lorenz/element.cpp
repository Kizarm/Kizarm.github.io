#include <math.h>
#include "element.h"

using namespace std;

static const char * description_string = R"---(<h3>Chaotický atraktor (Lorenzův) - popis.</h3>
  <p>Tento skript sice také není k ničemu, ale ukazuje, že lze použít Webassembly i bez jakýchkoli grafických knihoven, pokud jde jen
  o vykreslování čar (ale třeba i kroužků - nakreslit kruh jde i bez trigonometrických funkcí, jen pomocí násobení a sčítání, je ale potřeba trochu
  znát vlastnosti unitárních matic). Sice to není hezké, ale zato je to hodně malé. Možná i rychlé, ale o to zde moc nešlo.
  Spíš šlo o to použít něco, co by bylo v samotném javascriptu pomalé nebo neohrabané. Zde je to <b>řešení soustavy nelineárních
  diferenciálních rovnic metodou Runge-Kutta 4.řádu</b>. To je v C++ prosté, rychlé a poměrně přesné. Wasm část trajektorie vyklesluje
  do paměti, problém je to zpátky zobrazit. Je potřeba z toho udělat obrázek a k tomu je nutný pomocný canvas, což docela zdržuje.
  Je tu ukázána (celkem zbytečně) i metoda jak vytvořit obrázek pozadí a přes to překreslit samotné trajektorie - vrchní obrázek
  musí být průhledný. I když ty transformace dat asi nejsou udělány nejlépe, funguje to celkem svižně, lze udělat 60fps při zatížení
  procesoru 80%. Přitom v každém kroku je možné udělat až 200 iterací rovnic a na zatížení se to moc neprojeví. Zřejmě to nejvíc zabíjí
  to zobrazování. Je to jedna z mála možností, kde by wasm kód mohl mít alespoň trochu smysl. Měl jsem to samé uděláno v Qt (tedy i pro Webassembly),
  ale celé to zabralo 13MiB, tohle má celkem jen asi 130 KiB (t.j. 100x méně). A to je docela znát.
  </p>
  <p>I když jsou v tom chyby (např. Clear funguje jen když běží vykreslování) a zřejmě to není optimálně napsáno, přibalím i <a href="lorenz.zip">zdrojáky</a>.
  </p>
  <h3 align="center">© Kizarm 2020</h3>
)---";

/*********************************************************************************/
static uint8_t c_color (const real c, const real tau) {
  const double arg = 3.14159 / 50.0;
  const real d = 96.0 * exp (- c * tau) * (1 - cos (c * arg));
  return (uint8_t) d;
}
void BackGround::drawings() {
  const real maxx = getMaxX(),  maxy = getMaxY();
  fill (Color(0, 0, 0, 0xFF));
  
  const real hx = 0.5 * maxx, hy = 0.5 * maxy;
  const FPoint center (0, 0);
  const real maxr = hx, minr = 0.0;
  const real tau = 1.5 / (maxr - minr);
  for (real r=minr; r<maxr; r+=0.5) {
    const uint8_t b = c_color(r - minr, tau);
    setColor (Color(0, 0, b));
    circ (center, r);
  }
  setColor (Color (0x80, 0x80, 0));
  line (FPoint(-hx, 0), FPoint(hx, 0));
  line (FPoint(0, -hy), FPoint(0, hy));
  const real st = 50.0, mt = 25.0, dw = 2.0;
  for (real x=mt; x<hx; x+=mt) {
    line (FPoint(+x, dw), FPoint(+x, -dw));
    line (FPoint(-x, dw), FPoint(-x, -dw));
  }
  for (real y=mt; y<hy; y+=mt) {
    line (FPoint(dw, +y), FPoint(-dw, +y));
    line (FPoint(dw, -y), FPoint(-dw, -y));
  }
  setColor (Color (0x60, 0x60, 0x60));
  for (real x=st; x<hx; x+=st) {
    line (FPoint(+x,-hy), FPoint(+x,hy), true);
    line (FPoint(-x,-hy), FPoint(-x,hy), true);
  }
  for (real y=st; y<hy; y+=st) {
    line (FPoint(-hx,+y), FPoint(hx,+y), true);
    line (FPoint(-hx,-y), FPoint(hx,-y), true);
  }
}
void ForeGround::drawings() {
  index = 0;
  fill (Color(0xFF, 0xFF, 0xFF, 0));
  setColor (Color(0xFF, 0, 0xFF, 0xFF));
  const double maxx = getMaxX(), maxy = getMaxY();
  const Matrix m (0.025 * maxx, 0.0, 0.0, -0.02 * maxy, 0.5 * maxx, 0.5 * maxy);
  setMatrix (m);
}
void ForeGround::step() {
  for (int i=0; i<speed; i++) {
    FPoint end = DiffEqPass();
    line (begin, end);
    begin = end;
    changeColor();
  }
}
void ForeGround::changeColor() {
  const float fi = 2.0 * M_PI / 3.0;  // úhel posunu argumentu barvy
  float a1, a2, a3;
  int   r,g,b;                        // proměnné barvy
  // výpočet barvy - duha
  a1 = (float) index / 330.0f;        // argument pro r
  a2 = a1 + fi;                       // argument pro g
  a3 = a2 + fi;                       // argument pro b
  r = (int)(127.0f + 127.0f*sinf(a1));
  g = (int)(127.0f + 127.0f*sinf(a2));
  b = (int)(127.0f + 127.0f*sinf(a3));
  Color color(r, g, b, 255);
  setColor(color);
  index += 1;
}
/*********************************************************************************/
string HtmlElement::to_string() {
  string result;
  result += '<' + name;
  if (tags) result += tags->to_string();
  result += '>';
  if (down) result += down->to_string();
  result += end_string();
  if (next) result += next->to_string();
  return result;
}
IndexedElement::IndexedElement (const char * n, const char * v, HtmlContainer * p, const char * func) : HtmlElement (n, p), value(v)  {
  if (!p) return;
  const int buflen = 256;
  char buffer [buflen];
  snprintf(buffer, buflen, "Element_%d", p->order);
  addTag (new HtmlTag ("id", buffer));
  if (func) {
    snprintf(buffer, buflen, "UniversalDriver(%d);", p->order);
    addTag (new HtmlTag (func, buffer));
  }
  p->ordered.push_back (this);
  p->order += 1;
}

Text::Text (const char * n, const char * v, HtmlContainer * p, const char * func) : IndexedElement (n, v, p, func) {

}
string Text::end_string() {
  string result = getValue();
  result += HtmlElement::end_string();
  return result;
}


Button::Button (const char * v, HtmlContainer * p, const char * func) : IndexedElement ("button", v, p, func) {
  addTag(new HtmlTag ("class", "button"));
}
string Button::end_string() {
  string result = getValue();
  result += HtmlElement::end_string();
  return result;
}
string Slider::end_string() {
  string result("");
  return result;
}

/***************************************************************************************/
HtmlContainer::~HtmlContainer() {
  if (plots) {
    delete plots;
    plots = nullptr;
  }
  delete root;
}
InitValues HtmlContainer::InitSliders() {
  const int nslider = sliders.size();
  struct InitValues iv;
  iv.max = nslider;
  for (int n=0; n<nslider; n++) {
    HtmlElement * e = sliders[n];
    Action act = e->action (e->getHold());
    act.src_id = e->getId();
    iv.values.push_back (act);
  }
  return iv;
}
void HtmlContainer::ChangeOmega (const double w) {
  OmegaChange (w);
}

string HtmlContainer::to_string() {
  return root->to_string();
}

Action HtmlContainer::back (const int index, const int input) {
  // printf ("index = %d, input = %d\n", index, input);
  Action act;
  if (index >= 0 && index < ordered.size()) {
    HtmlElement * e = ordered [index];
    if (e) act = e->action (input);
  }
  return act;
}
/*********************************** CONTEXT *******************************************/
Slider::Slider (HtmlContainer * p, const char * func) : IndexedElement ("input", "", p, func) {
  addTag(new HtmlTag ("class", "slider"));
  addTag(new HtmlTag ("type", "range"));
  addTag(new HtmlTag ("min", "0"));
  addTag(new HtmlTag ("max", "1000"));
}
SliderRow::SliderRow (HtmlContainer * p, const char * n , const int b) : parent(p), name(n), begin(b) {};
HtmlElement * SliderRow::Init () {
  HtmlElement * bd  = new Text ("b", name);
  HtmlElement * tr  = new HtmlElement ("tr");
  HtmlElement * td1 = new HtmlElement ("td");
  HtmlElement * td2 = new HtmlElement ("td");
  slider = new Slider (parent, "oninput");
  HtmlElement * td3 = new Text ("td", "???", parent);
  td1->addTag (new HtmlTag ("width", "80%"));
  td2->addTag (new HtmlTag ("align", "center"));
  td3->addTag (new HtmlTag ("align", "center"));
  td3->addTag (new HtmlTag ("width", "10%"));
  td3->addTag (new HtmlTag ("bgcolor", "#FFA0FF"));
  
  slider->setHold(begin);
  slider->Attach (td3);
  
  td1->insert (slider);
  tr ->insert (td1);
  td2->insert (bd);
  tr ->insert (td2);
  tr ->insert (td3);
  parent->sliders.push_back (slider);
  return tr;
}
HtmlContainer::HtmlContainer() {
  StartStop = false;
  plots  = nullptr;
  order  = 0;
  root = new HtmlElement ("div");
  // create functional elements
  HtmlElement * b1  = new Button ("Clear", this, "onClick");
  HtmlElement * b2  = new Button ("Start", this, "onClick");
  // and helpers
  HtmlElement * tab = new HtmlElement ("table");
  HtmlElement * par = new HtmlElement ("p");
  HtmlElement * row = new HtmlElement ("tr");
  HtmlElement * ds1 = new Text ("td", "<b>Nastavení</b>");
  HtmlElement * ds2 = new Text ("td", "Hodnota");
  // formatting
  tab->addTag (new HtmlTag ("width", "100%"));
  tab->addTag (new HtmlTag ("bgcolor", "#FFFFC0"));
  ds2->addTag (new HtmlTag ("colspan", "2"));
  ds1->addTag (new HtmlTag ("align", "center"));
  ds2->addTag (new HtmlTag ("align", "center"));
  par->addTag (new HtmlTag ("align", "center"));
  // Function
  b1->setCb  ([] (HtmlElement * e, const int val, HtmlContainer * p) -> Action {
    HtmlElement * f = e->getAttach();
    string value ("none");
    if (p) p->plots->fg->drawings();
    //printf("action_b2 %s, value = %d\n", f->getId().c_str(), val);
    return Action (ACTION_NONE, f->getId(), value, value);
  });
  b2->setCb  ([] (HtmlElement * e, const int val, HtmlContainer * p) -> Action {
    HtmlElement * f = e->getAttach();
    string value;
    if (f->getHold()) {
      f->setHold (0); value = string ("Start");
      if (p) p->StartStop = false;
    } else {
      f->setHold (1); value = string ("Stop");
      if (p) p->StartStop = true;
    }
    //printf("action_b2 %s, value = %d\n", f->getId().c_str(), val);
    return Action (ACTION_STRING, f->getId(), value, value);
  });
  HtmlElement * cwr = new HtmlElement ("div");
  cwr->addTag(new HtmlTag ("align", "center"));
  const char * cname = "canvas";
  canvas = new HtmlElement (cname);
  canvas->addTag (new HtmlTag ("id",    cname));
  canvas->addTag (new HtmlTag ("class", cname));
  cwr->insert (canvas);
  HtmlElement * dsc = new Text ("div", description_string);
  dsc->addTag (new HtmlTag ("class", "frame1"));
  // Stacked elements
  SliderRow omega (this, "omega", 700), speed (this, "speed", 0);
  // build tree
  row->insert (ds1);
  row->insert (ds2);
  tab->insert (row);
  tab->insert (omega.Init ());
  tab->insert (speed.Init ());
  omega.slider->setCb([] (HtmlElement * e, const int val, HtmlContainer * p) -> Action {
    HtmlElement * f = e->getAttach();
    const double result = 20.0 + 0.01 * (double) val;
    const int buflen = 256; char buffer [buflen];
    snprintf (buffer, buflen, "%.3f", result);
    if (p) p->ChangeOmega (result);
    return Action (ACTION_STRING, f->getId(), ::to_string (val), string(buffer));
  }) ;
  speed.slider->setCb([] (HtmlElement * e, const int val, HtmlContainer * p) -> Action {
    HtmlElement * f = e->getAttach();
    const int result = (int) round (5.0 + 0.2 * (double) val);
    const int buflen = 256; char buffer [buflen];
    snprintf (buffer, buflen, "%d", result);
    if (p) p->plots->fg->changeSpeed (result);
    return Action (ACTION_STRING, f->getId(), ::to_string(val), string(buffer));
  }) ;
  
  par->insert (b1);
  par->insert (b2);
  // root element
  root->insert (cwr);
  root->insert (par);
  root->insert (tab);
  root->insert (dsc);
  
}
