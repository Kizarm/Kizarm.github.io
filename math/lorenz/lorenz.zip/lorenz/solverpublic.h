#ifndef SOLVERPUBLIC_H
#define SOLVERPUBLIC_H
#include "canvas.h"
extern void OmegaChange (const real prm);
extern FPoint DiffEqPass ();
extern FPoint DiffEqBc ();
#endif // SOLVERPUBLIC_H
