#ifndef CANVAS_H
#define CANVAS_H
#include <stdint.h>
#include <stdlib.h>

typedef double real;
/**
 * Velmi jednoduché kreslení úseček a kruhů.
 */
struct FPoint {
  real x,y;
  FPoint () : x(0), y(0) {};
  FPoint (const real x0, const real y0) : x(x0), y(y0) {};
  FPoint (const FPoint & other) : x(other.x), y(other.y) {};
  FPoint & operator= (const FPoint & other)  { x = other.x; y = other.y; return * this; };
};
class Matrix {
  real m11, m12, m21, m22, ox, oy;
  public:
    Matrix (const real a11 = 1.0, const real a12 = 0.0, const real a21 = 0.0, const real a22 = -1.0, const real ax = 0, const real ay = 0) :
    m11(a11), m12(a12), m21(a21), m22(a22), ox(ax), oy(ay) {};
    const FPoint operator* (const FPoint & right) const {
      const real x = m11 * right.x + m12 * right.y + ox;
      const real y = m21 * right.x + m22 * right.y + oy;
      const FPoint result (x, y);
      return result;
    }
};

union Color {
  struct {
    uint8_t r,g,b,a;
  };
  uint32_t color;
  Color () {color = 0u; };
  Color (const uint8_t rr, const uint8_t gg, const uint8_t bb, const uint8_t aa = 0xFF) : r(rr), g(gg), b(bb), a(aa) {};
  Color (const uint32_t c) : color(c) {};
  Color (const Color & other) { color = other.color; };
  Color & operator= (const Color & other) { color = other.color; return * this; };
  const operator uint32_t () const { return color; };
};

class Canvas {
  const int width, height;
  Color   outpixel;
  Color   current;
  Matrix  matrix;
  Color * data;
  public:
    Canvas (const int w, const int h);
    ~Canvas();
    uint8_t * getData () const { return reinterpret_cast<uint8_t*>(data); };
    size_t    getSize () const { return (width * height * sizeof(Color)); };
    int       getMaxX () const { return width;  };
    int       getMaxY () const { return height; };
    void      setMatrix (const Matrix & m);
    void fill (const Color & c);
    void setColor (const Color & c) { current = c; };
    void line (const FPoint & begin, const FPoint & end, const bool doted = false);
    
    void circ (const FPoint & center, const real radius);
    
    // void drawings ();
  protected:
    Color & at (const int x, const int y);
    bool bound (const int x, const int y) const;
    void line (const int x0, const int y0, const int x1, const int y1, const bool doted = false);
    void rect (const int x0, const int y0, const int x1, const int y1);
};

#endif // CANVAS_H
