#include "tea.h"

typedef __SIZE_TYPE__ size_t;
static const uint32_t delta = 0x9e3779b9;              /* a key schedule constant */
static const uint32_t ckey [4] = {0x205F9241, 0x11CBC3D1, 0x6EB84070, 0x747C3107};
extern size_t strlen (const char * s);

void encrypt (uint32_t* v, uint32_t const* const k) {
  uint32_t v0=v[0], v1=v[1], sum=0, i;                 /* set up */
  const uint32_t k0=k[0], k1=k[1], k2=k[2], k3=k[3];   /* cache key */
  for (i=0; i < 32; i++) {                             /* basic cycle start */
    sum += delta;
    v0 += ( (v1<<4) + k0) ^ (v1 + sum) ^ ( (v1>>5) + k1);
    v1 += ( (v0<<4) + k2) ^ (v0 + sum) ^ ( (v0>>5) + k3);
  }                                                    /* end cycle */
  v[0]=v0; v[1]=v1;
}

void decrypt (uint32_t* v, uint32_t const* const k) {
  uint32_t v0=v[0], v1=v[1], sum=0xC6EF3720, i;        /* set up */
  const uint32_t k0=k[0], k1=k[1], k2=k[2], k3=k[3];   /* cache key */
  for (i=0; i<32; i++) {                               /* basic cycle start */
    v1 -= ( (v0<<4) + k2) ^ (v0 + sum) ^ ( (v0>>5) + k3);
    v0 -= ( (v1<<4) + k0) ^ (v1 + sum) ^ ( (v1>>5) + k1);
    sum -= delta;
  }                                                    /* end cycle */
  v[0]=v0; v[1]=v1;
}

/** Use - prevent garbage collection */
const tea_t tea = { /* Start section */
  .e = encrypt,
  .d = decrypt
};
static const uint32_t adler32 (const char * str, const size_t len)  {
  const unsigned char * data = (const unsigned char*)(str);
  static const uint32_t MOD_ADLER = 65521;
  uint32_t a = 1, b = 0;
  for (size_t index = 0; index < len; ++index) {
    a = (a + data[index]) % MOD_ADLER;
    b = (b + a)           % MOD_ADLER;
  }
  return (b << 16) | a;
}
void gen_key (const char * passwd, uint32_t * key) {
  const size_t   len  = strlen  (passwd);
  const uint32_t hash = adler32 (passwd, len);
  for (unsigned n=0; n<4; n++) {
    key [n] = ckey [n] ^ hash;
  }
}
