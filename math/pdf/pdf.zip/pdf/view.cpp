#include <stdint.h>
#include "tea.h"
extern "C" {
  extern block_t Context [];
  extern const int ContextLen;
  extern const int ContextChunks;
};
const char * htm_str = R"---(
<div id="form">
  <label for="pwd">Password:</label>
  <input type="password" id="pwd" name="pwd">
  <button onclick="passwd(document.getElementById('pwd').value)" id="sbut">Submit</button>
</div>
)---";
#ifdef __wasm__
#define IMPORT(name) __attribute__((import_module("imports"),import_name(#name))) name
#define EXPORT(name) __attribute__((used, export_name(#name))) name
typedef __SIZE_TYPE__ size_t;
extern "C" size_t strlen (const char *s) {
  size_t l = 0;
  while (*s++) l++;
  return l;
}

/* Demontruje předávání javascript String a C-čkového stringu
 * pomocí pohledu do paměti. Zobrazení pdf z jednotlivých bytů.
 */

extern "C" void EXPORT(init) ();
extern "C" void EXPORT(passString)(char * ptr, int len);
extern "C" int  EXPORT(cAlloc) (int len);
extern "C" void IMPORT(writePdf)  (const char * ptr, const int len);
extern "C" void IMPORT(writeHtml) (const char * ptr, const int len);
////////////////////////////////////////////////////////////////////////////////////
extern "C" void __wasm_call_ctors();
void init () {
  __wasm_call_ctors();
  writeHtml (htm_str, strlen(htm_str));
}
static constexpr int maxPassword = 0x100;
static char PasswordBuffer [maxPassword];
int cAlloc (int len) {
  if (len < maxPassword) {
    return reinterpret_cast<int> (PasswordBuffer);
  } else {
    return 0;
  }
}
#else
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

// Přepsáno to, co ve webassembly řeší javascript
extern "C" void writePdf (const char * ptr, const int len) {
  FILE * out = fopen ("refman.pdf","w");
  size_t res = fwrite(ptr, 1, len, out);
  fclose(out);
  (void) res;
}
extern "C" void writeHtml (const char * ptr, const int len) {
  fwrite(ptr, 1, len, stdout);
}
#endif
static const char * err_str = R"---(
<h2 style="color:#ff5733;">BAD PASSWORD</h2>
<p>Heslo lze zjistit jen ze zdrojáků, tj. jak byl soubor vytvořen. Soubor je obsažen
v module.wasm, je zašifrován pomocí jednoduché symetrické šifry TEA. Klíč k této šifře
je odvozen právě z hesla, takže ve wasm modulu není. Šifrování je dost slabé, ale pro ukázku postačí.
</p>
)---";
static const char * ok_str  = R"---(
<h2 style="color:#008033;">PASSWORD OK</h2>
<p><a href="pdf.zip">Zdrojáky</a> bez blobu.
</p>
)---";
static uint32_t key [4];
void passString (char * str, int len) {
  str[len] = '\0';
  // nechávat tu heslo jako string není dobrý nápad, takhle ví každý prd co tam opravdu je
  gen_key (str, key);
  
  for (int n=0; n<ContextChunks; n++) {
    tea.d (Context[n].data, key);
  }
  const uint32_t check = * reinterpret_cast<const uint32_t*>("%PDF");
  if (Context[0].data[0] == check) {
    char * context = reinterpret_cast<char*>(Context);
    writePdf  (context, ContextLen);
    writeHtml (ok_str,  strlen(ok_str));
  } else {
    writeHtml (err_str, strlen(err_str));
  }
}
#ifndef __wasm__
int main (int argc, char *argv[]) {
  if (argc < 2) {
    printf("Usage:\n\t%s PASSWORD\n", argv[0]);
    return 0;
  }
  // test pro linux - zpětně vytvoří kopii originálu, projde i valgrind
  char * passwd = argv[1];
  passString (passwd, strlen(passwd));
  return 0;
}
#endif


