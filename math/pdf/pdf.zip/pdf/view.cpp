#include <stdint.h>
#include "deflate.h"
#include "tea.h"
#ifdef __wasm__
#include "lib/libwasm.h"

/* Demontruje předávání javascript String a C-čkového stringu
 * pomocí pohledu do paměti. Zobrazení pdf z jednotlivých bytů.
 */

extern "C" {
  extern int xwrite (int fd, char * buf, int len);
};
extern "C" void EXPORT(init) (const int memlen);
extern "C" void EXPORT(passString)(char * ptr, int len);
extern "C" int  EXPORT(cAlloc) (int len);
extern "C" void EXPORT(Decode) (char * ptr, const int len);
extern "C" void IMPORT(writePdf)  (const char * ptr, const int len);
extern "C" void IMPORT(writeHtml) (const char * ptr, const int len);
extern "C" void IMPORT(fileRead) ();
////////////////////////////////////////////////////////////////////////////////////
extern "C" void __wasm_call_ctors();
void init (const int memlen) {
  _HEAP_MAX = reinterpret_cast<char*>(memlen);
  __wasm_call_ctors();
}
int cAlloc (int len) {
  return reinterpret_cast<int> (malloc(len + 1));
}
#else
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

extern "C" int  xwrite (int fd, char * buf, int len);
extern "C" void Decode (char * str, const int len);
// Přepsáno to, co ve webassembly řeší javascript
extern "C" void fileRead () {
  const char * name = "./bin/text.blob";
  struct stat stat_buf;
  stat(name, &stat_buf);
  char * buffer = new char [stat_buf.st_size];
  FILE * in = fopen (name, "r");
  if (!in) return;
  size_t res = fread (buffer, 1, stat_buf.st_size, in);
  if (res != stat_buf.st_size) return;
  fclose(in);
  Decode(buffer, res);
}
extern "C" void writePdf (const char * ptr, const int len) {
  FILE * out = fopen("copy.pdf","w");
  size_t res = fwrite(ptr, 1, len, out);
  fclose(out);
  (void) res;
}
extern "C" void writeHtml (const char * ptr, const int len) {}
#endif
static const char * err_str = R"---(
<h2 style="color:#ff5733;">BAD PASSWORD</h2>
<p>Heslo lze zjistit jen ze zdrojáků, tj. jak byl soubor vytvořen. Soubor je zabalen
pomocí libz (best compression) a následně zašifrován pomocí jednoduché symetrické
šifry TEA. Klíč k této šifře je odvozen právě z hesla, takže ve wasm modulu není.
Šifrování je dost slabé, ale pro ukázku postačí.
</p>
<p><a href="pdf.zip">Zdrojáky</a> bez blobu.
</p>
)---";
static const char * ok_str  = R"---(
<h2 style="color:#008033;">PASSWORD OK</h2>
)---";
static const size_t maxlen  = 1u << 24;  // ~16MiB by mělo stačit, na začátku je to přesně
static       size_t count   = 0u;
static char       * context = nullptr;   // kvůli kódování (utf-8) je lépe zobrazit to najednou
static uint32_t key [4];
void passString (char * str, int len) {
  str[len] = '\0';
  // nechávat tu heslo jako string není dobrý nápad, takhle ví každý prd co tam opravdu je
  gen_key (str, key);
  fileRead();
  free(str);
}
int xwrite (int fd, char * buf, int len) {
  if (!context) context = new char [maxlen];
  (void) fd;
  if (count + len > maxlen) return 0;
  memcpy (context + count, buf, len);
  count += len;
  return len;
}
void Decode (char * str, const int len) {
  block_s * buffer =   reinterpret_cast<block_s*>(str);
  const int chunks = len >> 3;
  for (int n=0; n<chunks; n++) tea.d (buffer[n].data, key);
  const int bytes  = * reinterpret_cast<int*>(str);
  const int zblen  = * reinterpret_cast<int*>(str + 4);
  
  const uint16_t magic = * reinterpret_cast<uint16_t*>(str + sizeof(block_s));
  const int delta  = len - zblen;
//printf("delta=%d, zblen=%d, bytes=%d, chunks=%d, magic=%04X\n", delta, zblen, bytes, chunks, magic);
  bool ok = magic == 0xDA78;
  if ((delta < 8) or (delta > 15)) ok = false;
  if ((len & 0x7) != 0)            ok = false;
  if (ok) {
    context = new char [bytes];
    const cFile ptr  = {
      .clen  = zblen,
      .data  = str + sizeof(block_s) + 2, // vynech 1. blok + magic
    };
    restore_file (&ptr);
    printf("%d == %zd\n", bytes, count);
    if (bytes == count) writePdf (context, count);
    if (context) delete [] context;
    context = nullptr;
    writeHtml (ok_str,  strlen(ok_str));
  } else {
    writeHtml (err_str, strlen(err_str));
  }
  delete [] str;
}
#ifndef __wasm__
int main (int argc, char *argv[]) {
  if (argc < 2) {
    printf("Usage:\n\t%s PASSWORD\n", argv[0]);
    return 0;
  }
  // test pro linux - zpětně vytvoří kopii originálu, projde i valgrind
  char * passwd = strdup(argv[1]);
  passString (passwd, strlen(passwd));
  return 0;
}
#endif


