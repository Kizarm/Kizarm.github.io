#ifndef _TEA_H_
#define _TEA_H_
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
typedef void (*fnc) (uint32_t*, uint32_t const* const k);
typedef struct tea_s {
  fnc e;
  fnc d;
} tea_t;
extern const tea_t tea;
typedef struct block_s {
  uint32_t data [2];
} block_t;
extern void gen_key (const char * passwd, uint32_t * key);
#ifdef __cplusplus
};

#endif //__cplusplus
#endif // _TEA_H_
