#include <stdint.h>
#include <zlib.h>
#include "../tea.h"

#define ERR {printf ("Chyba \"%s\", na radku %d\n",__FILE__,__LINE__); return -1;}

#ifdef __cplusplus
extern "C" {
#endif
int mycompress (const char* in, const char* out, int level, block_t * prefix);
#ifdef __cplusplus
};
#endif
