#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include "compress.h"
#include "../tea.h"

static uint32_t key [4];
/* To heslo je zde úmyslně explicitně uvedeno, kdybych ho zapomněl. */
static const char * passwd = "CubicSplines";

static void tea_encode (const char * inname, const char * outname, block_t * prefix) {
  gen_key (passwd, key);
  struct stat stat_buf;
  int rc = stat(inname, &stat_buf);
  if (rc) return;
  const uint32_t flen = stat_buf.st_size;
  const uint32_t tlen = (((flen - 1) >> 3) + 1) << 3;
  const unsigned chunks = tlen >> 3;
  printf("flen = %d, tlen = %d, chunks = %d\n", flen, tlen, chunks);
  block_s * buffer = new block_s [chunks];
  memset (buffer, 0, chunks * sizeof(block_s));
  
  FILE * in, * out;
  in = fopen (inname, "r");
  if (!in) return;
  out = fopen (outname, "w");
  if (!out) {
    fclose(in);
    return;
  }
  prefix[0].data[1] = flen;
  tea.e (prefix[0].data, key);
  size_t r = fwrite(prefix, sizeof(block_t), 1, out);
  
  r = fread (buffer, 1, tlen, in);
  if (r != flen) return;
  
  for (unsigned n=0; n<chunks; n++) {
    tea.e (buffer[n].data, key);
  }
  r = fwrite(buffer, sizeof(block_s), chunks, out);
  fclose(in);
  fclose(out);
  delete [] buffer;
  return;
}

int main () {
  block_s prefix;
  const char * tmpname = "xxx.tmp";
  mycompress ("refman.pdf", tmpname, Z_BEST_COMPRESSION, &prefix);
  tea_encode (tmpname, "../bin/text.blob", &prefix);
  remove(tmpname);
  return 0;
}
