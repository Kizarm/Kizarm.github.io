#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include "config.h"
#include "mime.h"
#include "../tea.h"

static uint32_t key [4];
static uint32_t ContextSignature = 0u;
static uint32_t MemoryBlocks     = 0u;
static void tea_encode (const char * inname, const char * outname) {
  gen_key (passwdForFile, key);
  struct stat stat_buf;
  int rc = stat(inname, &stat_buf);
  if (rc) {
    fprintf(stderr, "Soubor %s (max. ~10MiB) není součástí zdrojových textů,\n"
                    "lze si zvolit vlastní, ale je nutno upravit config.h\n", inname);
    return;
  }
  const uint32_t flen = stat_buf.st_size;
  const uint32_t tlen = (((flen - 1) >> 3) + 1) << 3;
  const uint32_t blck = (flen >> 16) + 2;
  MemoryBlocks = blck < 16u ? 16u : blck;
  const unsigned chunks = tlen >> 3;
  printf("flen = %d, tlen = %d, chunks = %d\n", flen, tlen, chunks);
  block_s * buffer = new block_s [chunks];
  memset (buffer, 0, chunks * sizeof(block_s));
  
  FILE * in, * out;
  in = fopen (inname, "r");
  if (!in) return;
  const int r = fread (buffer, 1, flen, in);
  if (r != flen) return;
  fclose(in);
  
  ContextSignature = buffer[0].data[0];
  for (unsigned n=0; n<chunks; n++) {
    tea.e (buffer[n].data, key);
  }
  
  out = fopen (outname, "w");
  if (!out) {
    fclose(in);
    return;
  }
  fprintf(out, "#include \"tea.h\"\nblock_t Context [] = {\n");
  for (unsigned n=0; n<chunks; n++) {
    fprintf(out, "  {0x%08X, 0x%08X},\n", buffer[n].data[0], buffer[n].data[1]);
  }
  fprintf(out, "};\nconst int ContextLen = %d;\n", flen);
  fprintf(out, "const int ContextChunks = %d;\n", chunks);
  fprintf(out, "const unsigned ContextSignature = 0x%08X;\n", ContextSignature);
  fclose(out);
  delete [] buffer;
  return;
}

int main () {
  tea_encode (inputFileName, "../data.c");
  generate_script ("../bin/index.js", MemoryBlocks);
  generate_page   ("../bin/index.html");
  return 0;
}
