#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include "compress.h"
#include "../tea.h"

static uint32_t key [4];
/* To heslo je zde úmyslně explicitně uvedeno, kdybych ho zapomněl. */
static const char * passwd = "CubicSplines";

static void tea_encode (const char * inname, const char * outname) {
  gen_key (passwd, key);
  struct stat stat_buf;
  int rc = stat(inname, &stat_buf);
  if (rc) {
    fprintf(stderr, "Soubor %s (max. ~16MiB) není součástí zdrojových textů,\n"
                    "lze si zvolit vlastní, ale je nutno upravit main.cpp\n", inname);
    return;
  }
  const uint32_t flen = stat_buf.st_size;
  const uint32_t tlen = (((flen - 1) >> 3) + 1) << 3;
  const unsigned chunks = tlen >> 3;
  printf("flen = %d, tlen = %d, chunks = %d\n", flen, tlen, chunks);
  block_s * buffer = new block_s [chunks];
  memset (buffer, 0, chunks * sizeof(block_s));
  
  FILE * in, * out;
  in = fopen (inname, "r");
  if (!in) return;
  const int r = fread (buffer, 1, flen, in);
  if (r != flen) return;
  fclose(in);
  
  for (unsigned n=0; n<chunks; n++) {
    tea.e (buffer[n].data, key);
  }
  
  out = fopen (outname, "w");
  if (!out) {
    fclose(in);
    return;
  }
  fprintf(out, "#include \"tea.h\"\nblock_t Context [] = {\n");
  for (unsigned n=0; n<chunks; n++) {
    fprintf(out, "  {0x%08X, 0x%08X},\n", buffer[n].data[0], buffer[n].data[1]);
  }
  fprintf(out, "};\nconst int ContextLen = %d;\n", flen);
  fprintf(out, "const int ContextChunks = %d;\n", chunks);
  fclose(out);
  delete [] buffer;
  return;
}

int main () {
  tea_encode ("refman.pdf", "../data.c");
  return 0;
}
