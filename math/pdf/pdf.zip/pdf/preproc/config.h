#ifndef _CONFIG_H
#define _CONFIG_H
//////////////////////////////////////////////////////////////////////
/* To heslo je zde úmyslně explicitně uvedeno, kdybych ho zapomněl. */
static const char * passwdForFile = "CubicSplines";
static const char * inputFileName = "refman.pdf";
// pageTitle je zde zároveň passwdForFile, ale nemusí tomu tak být
static const char * pageTitle     = passwdForFile;
//////////////////////////////////////////////////////////////////////
#endif //  _CONFIG_H
