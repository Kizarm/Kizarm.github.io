#include <cstdio>
#include <string>
#include <map>
#include "config.h"
#include "mime.h"
static const char * script_template = R"---(var gWASM = null; // WASM -> global object
(async () => {
  const Outs   = document.getElementById("context");
  const memory = new WebAssembly.Memory({ initial: %d });
  if  (!memory) {
    console.log ('!!! WebAssembly not supported');  return;
  }
  Outs.innerHTML = '<p>Compile module ...</p>';
  const importObject = {
    env: { memory },
    imports: {            // importované funkce do wasm
      writeHtml : (ptr, len) => {
        const view = new Uint8Array (memory.buffer, ptr, len);
        const utf8decoder = new TextDecoder();
        Outs.innerHTML = utf8decoder.decode(view);
      },
      writePdf : (ptr, len) => {
        const view = new Uint8Array (memory.buffer, ptr, len);
        var blob = new Blob([view], {type: "%s"});
        var link = window.URL.createObjectURL(blob);
        window.open(link,'_blank');
      },
    },
  };
  const response = await fetch('./module.wasm');
  const bytes    = await response.arrayBuffer();
  const module   = await WebAssembly.instantiate(bytes, importObject);
  gWASM = {
    asm : module.instance.exports,
    mem : memory,
  };
  gWASM.asm.init();
})();

function passwd (str) {
  if (!str.length) return;
  console.log(str);
  const utf8EncodeText = new TextEncoder();
  const bytes = utf8EncodeText.encode(str);
  // alokovat pamet v modulu je nutne, aby bylo kam kopirovat
  const cArrayPointer = gWASM.asm.cAlloc(bytes.length);
  if (!cArrayPointer) return;
  const cArray = new Uint8Array(gWASM.mem.buffer, cArrayPointer, bytes.length);
  cArray.set(bytes);              // naplnit dekodovanym stringem
  gWASM.asm.passString(cArrayPointer, cArray.length);
};
)---";
static const char * page_template = R"---(<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>WASM</title>
    <style>body {background-color: rgb(192,255,255);} p {white-space: pre-wrap;} i {color: rgb(64,0,192);}</style>
</head>
<body>
    <h1>%s</h1>
    <div id="context" style="font-family:bookman;font-size:100%" align="left">
    </div>
    <script src="index.js"></script>
</body>
</html>
)---";

static std::string name_to_mime (const char * name) {
  std::string result("application/octet-stream");
  std::string input (name);
  size_t r = input.rfind (".");
  if (r != std::string::npos) {
    std::string type = input.substr(r+1);
    printf("type:%s\n", type.c_str());
    std::map<std::string, std::string> types = {
      {"html", "text/html"},
      {"pdf" , "application/pdf"},
      {"ps"  , "application/postscript"},
      {"png" , "image/png"},
      // ...
    };
    std::string id = types[type];
    if (!id.empty()) result = id;
  }
  return result;
}
void generate_script (const char * name, const uint32_t memblk) {
  FILE * out = fopen (name, "w");
  if (!out) return;
  std::string mime = name_to_mime(inputFileName).c_str();
  printf("mime:%s\n", mime.c_str());
  fprintf(out, script_template, memblk, mime.c_str());
  fclose(out);
  printf("Generate %s\n", name);
}
void generate_page   (const char * name) {
  FILE * out = fopen (name, "w");
  if (!out) return;
  fprintf(out, page_template, pageTitle);
  fclose(out);
  printf("Generate %s\n", name);
}
