#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "compress.h"

#define CHUNK 16384
/* komprese souboru in probiha do souboru out a to tak, ze se
   vytvori .c kod, ktery se pak pouzije v metode decompress */
int mycompress (const char* in, const char* out, int level, block_t * prefix) {
  int ret, flush;
  unsigned have;
  z_stream strm;
  unsigned char inb [CHUNK];
  unsigned char outb[CHUNK];

  FILE *source,*dest;
  source  = fopen (in, "r");
  dest    = fopen (out,"w");
  if (source == NULL) {
    fprintf(stderr, "Soubor %s (max. ~16MiB) není součástí zdrojových textů,\n"
                    "lze si zvolit vlastní, ale je nutno upravit main.cpp\n", in);
    ERR;
  }
  if (dest   == NULL) ERR;
  // allocate deflate state
  strm.zalloc = Z_NULL;
  strm.zfree  = Z_NULL;
  strm.opaque = Z_NULL;
  ret = deflateInit (&strm, level);
  if (ret != Z_OK) ERR;
  // compress until end of file
  int bytes_count = 0;
  do {
    strm.avail_in = fread(inb, 1, CHUNK, source);
    if (ferror (source)) {
      (void) deflateEnd (&strm);
      ERR;
    }
    bytes_count += strm.avail_in;
    flush = feof (source) ? Z_FINISH : Z_NO_FLUSH;
    strm.next_in = inb;

    /* run deflate() on input until output buffer not full, finish
    compression if all of source has been read in */
    do {
      strm.avail_out = CHUNK;
      strm.next_out = outb;
      ret = deflate(&strm, flush);    // no bad return value
      assert (ret != Z_STREAM_ERROR); // state not clobbered
      have = CHUNK - strm.avail_out;
      if (fwrite(outb, 1, have, dest) != have || ferror(dest)) {
          (void)deflateEnd(&strm);
          return Z_ERRNO;
      }
    } while (strm.avail_out == 0);
    assert (strm.avail_in == 0);      // all input will be used

  // done when last data in file processed
  } while (flush != Z_FINISH);
  assert (ret == Z_STREAM_END);       // stream will be complete
  printf("total bytes = %d\n", bytes_count);
  prefix[0].data[0] = bytes_count;

  // clean up and return
  (void) deflateEnd (&strm);
  fclose (source);
  fclose (dest);
  return Z_OK;
}

