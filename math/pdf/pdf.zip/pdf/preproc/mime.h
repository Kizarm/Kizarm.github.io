#ifndef MIME_H
#define MIME_H
#include <stdint.h>
void generate_script (const char * name, const uint32_t memblk);
void generate_page   (const char * name);
#endif // MIME_H
