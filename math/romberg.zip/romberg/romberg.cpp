#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "romberg.h"

/** **************************************************/
/**
 * @brief Pomocný objekt pro alokaci dvourozmerného pole na hromadě.
 * 
 * Je to jen pro to, aby se nemuselo kouzlit s indexy přímo ve funkci Romberg.
 */
template <typename T> class Schema {
  public:
    /**
     * @brief Konstruktor
     * @param n rozměr (n x n)
     */
    Schema (unsigned n) : order (n) {
      data = new T [order * order];
    }
    /**
     * @brief Destruktor
     */
    ~Schema () {
      delete [] data;
    }
    /**
     * @brief Jen pro tohle je to uděláno.
     * @param x to co bylo v 1.[]
     * @param y to co bylo v 2.[]
     * @return T& reference na prvek[x][y]
     */
    T & M (unsigned x, unsigned y) const {
      return (data [order * x + y]);
    }
    /**
     * @brief Getter pro velikost
     * @return const unsigned int velikost v jednom rozměru
     */
    const unsigned O (void) const {
      return order;
    };
    /**
    * @brief Debug funkce pro výpis schematu.
    */
    void print (void) {
      unsigned n = order;
      for (unsigned i=0; i<n; i++) {
        for (unsigned j=0; j<=i; j++) {
          printf ("%.14Lg ", M (i,j));
        }
        printf ("\n");
      }
    }
  private:
    const unsigned order;       //!< velikost v jednom rozměru
    T * data;                   //!< vlastní data
};
/**
 * @brief Omezení Rombergova schematu od .. do.
 * 
 * @param n nezáporné celé číslo
 * @return const unsigned int ve zvolených mezích
 */
static inline const unsigned limiting (const unsigned n) {
  const unsigned min = 5, max = 10;
  if (n < min) return min;
  if (n > max) return max;
  return n;
}
/** **************************************************/
/* Vlastní integrační funkce */
real Romberg (const real a, const real b, const unsigned n, ifunc f) {
  unsigned i, j, k;
  real  h, sum, minerr = 1.0;
  const unsigned m = limiting (n);
  Schema<real> R (m+1);

  h = b - a;
  R.M (0,0) = (h/2) * (f (a) + f (b));
  for (i=1; i<=m; i++) {
    h   = 0.5 * h;
    sum = 0.0;
    for (k=1; k<(1UL<<i); k+=2) sum += f (a + k*h);
    R.M (i,0) = 0.5 * R.M (i-1,0) + sum * h;
    for (j=1; j<=i; j++) {
      real delta = (R.M (i,j-1) - R.M (i-1,j-1)) / (powl (4.0,j)-1);
      R.M (i,j) = R.M (i,j-1) + delta;
      real err = fabsl (delta);
      if (err < minerr) minerr = err;
      //printf ("[%2d,%2d]delta = %Lg\n", i, j, delta); // debug
    }
  }
  // R.print(); // debug
  printf ("error ~= %Le\n", minerr);    // přibližná chyba
  real result = R.M (m,m);              // výsledek vrátí v registru (schema je pak destruováno)
  return result;
}
/** **************************************************/

