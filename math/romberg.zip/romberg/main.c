#include <stdio.h>
#include <math.h>
#include "romberg.h"

/** **************************************************/
// the test function
real fce (real x) {
  real f;
  f = 8.0 * (sqrtl (1.0 - x*x) - x);
  return f;
}
void test (void) {
  const unsigned n = 10;
  real res;
  
  real a = 0, b = 1.0 / sqrtl (2.0);
  res = Romberg (a, b, n, fce);
  printf ("result = %.18Lf\n", res - M_PI);
}
/** **************************************************/
real mexp (real x) {
  return expl (-x*x);
}
real iexp (real u) {
  real y = 0.0;
  if (u == 0.0) return y;       // limita v 0 musi byt 0, prevence dělení 0
  real x = 1.0 /  u;            // substituce 1/u
  real d = 1.0 / (u*u);         // derivace d(1/u)/du s opačným znaménkem (meze jsou obráceně!)
  y  = d * mexp (x);
  return y;
}
/** Integrace rychle klesající (exponenciální) funkce v celém oboru od nuly do nekonečna
 *  vyžaduje rozdělit obor integrace na dvě části:
 * - V první integrujeme od nuly do nějakého čísla b přímo tuto funkci.
 * - V druhé části provedeme substituci x=1/u, změníme meze (0,1/b) a za dx dáme zřejmě -(-1/(u*u))du
 *   a provedeme tuto integraci
 * - Obě části sečteme a je hotovo.
 * */
void infinite (void) {
  const unsigned n = 10;
  real res;
  
  real a = 0.0, b = 5.0;
  res  = Romberg (a, b, n, mexp);
  b = 1.0 / b;
  res += Romberg (a, b, n, iexp);
  printf ("result = %.18Lf\n", res);
  res = 0.5 * sqrtl (M_PI);
  printf ("refval = %.18Lf\n", res);
}
/** **************************************************/

int main (int argc, char * argv[]) {
//test     ();
  infinite ();
  return 0;

}

