#ifndef ROMBERG_H
#define ROMBERG_H
#ifdef __cplusplus
extern "C" {
#endif // __cplusplus
  
typedef long double real;
typedef real (*ifunc) (real x);

/**
 * @brief Vlastní integrace pomocí Rombergova schematu.
 * 
 * Funkce tvoří rozhraní jazyka C, velikost schematu je omezena,
 * protože při větším řádu převažují zaokrouhlovací chyby
 * výpočtu funkčních hodnot. Lze dosáhnout přesnosti na víc než
 * 12 platných dekadických cifer. To zřejmě postačí.
 * 
 * @param a dolní mez integrace
 * @param b horní mez integrace
 * @param n řád integrace, interně omezeno 5..10
 * @param f ukazatal na integrovanou funkci y=f(x)
 * @return real nejlepší hodnota numerické integrace - poslední hodnota schematu R[n][n].
 */
real Romberg (const real a, const real b, const unsigned n, ifunc f);

#ifdef __cplusplus
};
#endif // __cplusplus

#endif // ROMBERG_H
