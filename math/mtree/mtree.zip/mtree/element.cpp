#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "container.h"

using namespace std;

string FmtString (const char * fmt, ...) {
  string result;
  int size = 0;
  char * p = nullptr;
  va_list ap;
  /* Determine required size */
  va_start(ap, fmt);
  size = vsnprintf(p, size, fmt, ap);
  va_end(ap);
  if (size < 0)     return result;
  size++;             /* For '\0' */
  p = new char [size];
  if (p == nullptr) return result;
  va_start(ap, fmt);
  size = vsnprintf(p, size, fmt, ap);
  if (size < 0) {
      delete [] p;
      return result;
  }
  va_end(ap);
  result = p;
  delete [] p;
  return result;
  
}
/*********************************************************************************/
HtmlElement::HtmlElement (const char * n, const char * v, Container * p) : parent(p), name(n), Id("none"), atte (this), atCb(nullptr) {
  if (v) value = string (v);
  else   value = string ("");
  tags = nullptr; next = nullptr; down = nullptr;
}
std::string HtmlElement::to_string () {
  std::string result;
  result += '<' + name;
  if (tags) result += tags->to_string();
  result += '>';
  if (down) result += down->to_string();
  result += end_string();
  if (next) result += next->to_string();
  return result;
}
string HtmlElement::disable (const bool yes) {
  const char * disabled = yes ? "true" : "false";
  return FmtString ("document.getElementById(\'%s\').disabled = %s;\n", getId().c_str(), disabled);
}

/*********************************************************************************/
Text::Text (const char * n, const char * v, Container * p) : HtmlElement (n, v, p)  {
  if (!p) return;
  const int buflen = 256; char buffer [buflen];
  snprintf(buffer, buflen, "Element_%d", p->getOrder());
  addTag (new HtmlTag ("id", buffer));
  p->addOrdered(this);
}
string Text::end_string() {
  string result = getValue();
  result += HtmlElement::end_string();
  return result;
}


Button::Button (const char * n, Container * p) : HtmlElement ("button", n, p) {
  const char * func = "onClick";
  const int buflen = 256; char buffer [buflen];
  snprintf(buffer, buflen, "Element_%d", p->getOrder());
  addTag (new HtmlTag ("id", buffer));
  if (func) {
    snprintf(buffer, buflen, "UniversalDriver(%d);", p->getOrder());
    addTag (new HtmlTag (func, buffer));
  }
  p->addOrdered(this);
  addTag(new HtmlTag ("class", "button"));
}
string Button::end_string() {
  string result = getValue();
  result += HtmlElement::end_string();
  return result;
}
 Slider::Slider (Container * p, const int min, const int max) : HtmlElement ("input", "", p) {
  const char * func = "oninput";
  const int buflen = 256; char buffer [buflen];
  snprintf(buffer, buflen, "Element_%d", p->getOrder());
  addTag (new HtmlTag ("id", buffer));
  if (func) {
    snprintf(buffer, buflen, "UniversalDriver(%d);", p->getOrder());
    addTag (new HtmlTag (func, buffer));
  }
  p->addOrdered(this);
  addTag(new HtmlTag ("class", "slider"));
  addTag(new HtmlTag ("type", "range"));
  snprintf(buffer, buflen, "%d", min);
  addTag(new HtmlTag ("min", buffer));
  snprintf(buffer, buflen, "%d", max);
  addTag(new HtmlTag ("max", buffer));
}
string Slider::end_string() {
  string result("");
  return result;
}
SliderRow::SliderRow (Container * p, const char * n, const int min, const int max, const int b) : parent(p), name(n), min(min), max(max), begin(b) {
  
}
HtmlElement * SliderRow::Init () {
  root = new Slider (parent, min, max);
  HtmlElement * bd  = new Text ("b", name);
  HtmlElement * tr  = new HtmlElement ("tr");
  HtmlElement * td1 = new HtmlElement ("td");
  HtmlElement * td2 = new HtmlElement ("td");
  HtmlElement * td3 = new Text ("td", "???", parent);
  td1->addTag (new HtmlTag ("width", "80%"));
  td2->addTag (new HtmlTag ("align", "center"));
  td3->addTag (new HtmlTag ("align", "center"));
  td3->addTag (new HtmlTag ("width", "10%"));
  td3->addTag (new HtmlTag ("bgcolor", "#FFA0FF"));
  
  root->setValue(::to_string (begin));
  root->Attach (td3);
  td1->insert (root);
  tr ->insert (td1);
  td2->insert (bd);
  tr ->insert (td2);
  tr ->insert (td3);
  parent->addInitialized (root);
  return tr;
}
InputFloat::InputFloat (Container * p, const double min, const double max, const double step, const double value) : HtmlElement ("input", "", p) {
  const char * func = "onchange";
  const int buflen = 256; char buffer [buflen];
  snprintf(buffer, buflen, "Element_%d", p->getOrder());
  addTag (new HtmlTag ("id", buffer));
  snprintf(buffer, buflen, "UniversalDriver(%d);", p->getOrder());
  addTag (new HtmlTag (func, buffer));
  p->addOrdered(this);
  addTag(new HtmlTag ("type", "number"));
  snprintf(buffer, buflen, "%e", min);
  addTag(new HtmlTag ("min",   buffer));
  snprintf(buffer, buflen, "%e", max);
  addTag(new HtmlTag ("max",   buffer));
  snprintf(buffer, buflen, "%e", step);
  addTag(new HtmlTag ("step",  buffer));
  snprintf(buffer, buflen, "%g", value);
  addTag(new HtmlTag ("value", buffer));
  setValue (FmtString("%g", value));
}
string InputFloat::end_string() {
  string result("");
  return result;
}
InputFloatSpan::InputFloatSpan (Container * p, const char * n, const double min, const double max, const double step, const double value)
  : parent(p), name(n), min(min), max(max), step(step), begin(value) {
}
HtmlElement * InputFloatSpan::Init() {
  root = new InputFloat (parent, min, max, step, begin);
  HtmlElement * tab = new HtmlElement ("table");
  HtmlElement * row = new HtmlElement ("tr");
  HtmlElement * td1 = new HtmlElement ("td");
  HtmlElement * td2 = new HtmlElement ("td");
  HtmlElement * dsc = new Text ("b", name);
  td1->addTag (new HtmlTag ("width","40%"));
  td2->addTag (new HtmlTag ("width","60%"));
  td1->insert (dsc);
  td2->insert (root);
  row->insert (td1);
  row->insert (td2);
  tab->insert (row);
  parent->addInitialized (root);
  return tab;
}
