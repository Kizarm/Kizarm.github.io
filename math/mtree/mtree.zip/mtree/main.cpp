#include <emscripten/bind.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <string>
#include "canvas.h"
#include "container.h"

static Container * pContainer = nullptr;

extern const char * style_string;

std::string getStyle () {
  return std::string (style_string);
}
static std::string Init () {
  if (pContainer) {
    delete pContainer;
    pContainer = nullptr;
  }
  pContainer = new Container ();
  return pContainer->to_string();
};
static Action BackAction (const int index, const std::string value) {
  //printf ("value = %s\n", value.c_str());
  return pContainer->back(index, value);
}
static std::string WasmElementId (int index) {
  HtmlElement * e = pContainer->getOrdered(index);
  if (e) return e->getId();
  return std::string ("none");
}
static std::string WasmInitAll () {
  return pContainer->InitAll();
}

void resize (int w, int h) {
  pContainer->canvas.resize (w,h);
}
std::string progress () {
  return pContainer->getProgress();
}
emscripten::val bg_data () {
  return emscripten::val (emscripten::typed_memory_view (pContainer->canvas.getSize(), pContainer->canvas.getData()));
}
emscripten::val wChanged () {
  if (pContainer->canvas.newconn ()) {
    return emscripten::val (emscripten::typed_memory_view (pContainer->canvas.getSize(), pContainer->canvas.getData()));
  } else {
    return emscripten::val::undefined();
  }
};

EMSCRIPTEN_BINDINGS (anime) {
  emscripten::function ("Init",  &Init);
  emscripten::value_object<Action>("Action")
    .field ("length", &Action::length)
    .field ("code",   &Action::code)
    ;
  emscripten::function ("BackAction",    &BackAction);
  emscripten::function ("WasmInitAll",   &WasmInitAll);
  emscripten::function ("WasmElementId", &WasmElementId);
  
  emscripten::function ("bg_data",  &bg_data);
  emscripten::function ("wChanged", &wChanged);
  emscripten::function ("resize",   &resize);
  emscripten::function ("getStyle", &getStyle);
  emscripten::function ("progress", &progress);
}
