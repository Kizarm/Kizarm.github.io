#include <math.h>
//#include <exception>
#include "container.h"

using namespace std;

// static const int FrameTime = 20; // ms
extern const char * description_string;

Container::Container() : canvas(this) {
  ordered.clear();
  order  = 0;
  root = new HtmlElement ("div");
  // create functional elements
  HtmlElement * cnv = new HtmlElement ("canvas");
  // and helpers
  HtmlElement * tab = new HtmlElement ("table");
  HtmlElement * row = new HtmlElement ("tr");
  HtmlElement * div = new Text ("div", "100%");
  HtmlElement * prg = new HtmlElement ("td");
  // formatting
  tab->addTag (new HtmlTag ("style", "width:100%"));
  cnv->addTag (new HtmlTag ("id",    "canvas"));
  cnv->addTag (new HtmlTag ("class", "canvas"));
  div->addTag (new HtmlTag ("class", "progress"));
  div->addTag (new HtmlTag ("id", "progressBar"));
  progress = div;
  prg->insert (div);
  // build tree
  row->insert (prg);
  row->insert (button_start ());
  tab->insert (row);
  // root element
  root->insert (cnv);
  root->insert (tab);
  
  HtmlElement * dsc = new Text ("div", description_string);
  dsc->addTag (new HtmlTag ("class", "frame1"));
  root->insert(dsc);
}
Container::~Container() {
  delete root;
}
HtmlElement* Container::button_start() {
  static const char * type = "Start";
  HtmlElement * but = new Button (type, this);
  
  HtmlElement * tde = new HtmlElement ("td");
  tde->addTag (new HtmlTag ("align", "center"));
  tde->addTag (new HtmlTag ("width", "20%"));
  // Function
  but->setCb([] (HtmlElement * e, const string & val, const bool init) -> Action {
    string code;
    code += FmtString ("wChangeBackground();\n");
    code += FmtString ("document.getElementById(\'%s\').disabled = %s;\n", e->getId().c_str(), "true");
    return Action (code);
  });
  tde->insert (but);
  b_start = but;
  return tde;
}

string Container::getProgress() {
  const string percent = FmtString("%d%%", canvas.progress());
  /*
  string result;
  result += FmtString ("document.getElementById(\'%s\').style.width = %s;\n", progress->getId().c_str(), percent.c_str());
  result += FmtString ("document.getElementById(\'%s\').innerHTML   = %s;\n", progress->getId().c_str(), percent.c_str());
  return result;
  */
  return percent;
}


string  Container::InitAll() {
  string result;
  result += FmtString ("document.getElementById(\'%s\').disabled = %s;\n", b_start->getId().c_str(), "false");
  return result;
}

string Container::to_string() {
  return root->to_string();
}

Action Container::back (const int index, const string & input) {
  // printf ("index = %d, input = %d\n", index, input);
  Action act;
  if (index >= 0 && index < ordered.size()) {
    HtmlElement * e = ordered [index];
    if (e) act = e->action (input);
  }
  return act;
}

