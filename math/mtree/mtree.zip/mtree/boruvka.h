#ifndef BORUVKA_H
#define BORUVKA_H

#include <vector>

typedef void (*edge_cb) (const int a, const int b);

struct Edge {
  int x, y;       // vertices
  double metrics;
};
struct Connection {
  int a, b;
};
enum MathEdge {
  E_MATH = 0, E_NO_MATH, E_END
};
class Canvas;

class Boruvka {
  Canvas * parent;
  const int         vertices;
  std::vector<Edge> edges;
  int               color_index;
  public:
    Boruvka (const int v, Canvas * p = nullptr, edge_cb = nullptr, const bool fast = false);
    ~Boruvka();
    void addEdge (const Edge & e);
    void MST ();
    int  getTrees () {return m_numTrees;}
    
    void     init ();
    bool     edge (int & a, int & b);
  protected:
    int      find   (const std::vector< int >& parent, int i) const;
    void     Union (std::vector<int> & parent, std::vector<int> & rank, int x, int y) const;
    MathEdge pass (int & a, int & b);
  private:
    edge_cb callback;
    bool    fastmode;
    std::vector<Connection> connections;
  private:
    std::vector<int>  m_parent, m_rank;
    std::vector<Edge> m_cheapest;
    int    m_numTrees;
    double m_MSTweight;
    // state variables
    int  m_node;
    bool m_inner, m_clear;
};

#endif // BORUVKA_H
