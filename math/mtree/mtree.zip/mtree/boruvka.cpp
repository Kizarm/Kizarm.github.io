#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <algorithm>
#include "boruvka.h"
#include "canvas.h"

using namespace std;

static const Color palette [] = {
  Color (0x00,0xFF,0x00),Color (0x00,0x00,0xFF),Color (0xFF,0x00,0x00),
  Color (0xFF,0xFF,0x00),Color (0x00,0xFF,0xFF),Color (0xFF,0x00,0xFF)
};

Boruvka::Boruvka (const int v, Canvas * p, edge_cb cb, const bool fast) : parent(p), vertices(v) {
  callback = cb;
  fastmode = fast;
  color_index = 0;
}

Boruvka::~Boruvka() {

}

void Boruvka::addEdge (const Edge & e) {
  edges.push_back (e);
}
int Boruvka::find (const vector< int > & parent, int i) const {
  if (parent[i] == i) return i ;
  return find (parent, parent[i]) ;
}
void Boruvka::Union (vector< int >& parent, vector< int >& rank, int x, int y) const {
  int xroot = find (parent, x);
  int yroot = find (parent, y);
  if (rank[xroot] < rank[yroot]) {
    parent[xroot] = yroot;
  } else if (rank[xroot] > rank[yroot]) {
    parent[yroot] = xroot;
  } else {
    parent[yroot] = xroot;
    rank[xroot] += 1;
  }
}


void Boruvka::MST () {
  connections.clear();
  vector<int>  parent, rank;
  vector<Edge> cheapest (vertices);
  int    numTrees  = vertices;
  double MSTweight = 0;
  for (int node=0; node<vertices; node++) {
    parent.push_back (node);
    rank  .push_back (0);
    cheapest[node].metrics = -1.0;
  }
  while (numTrees > 1) {
    printf ("trees=%d\n", numTrees);
    int m = edges.size();
    for (int i=0; i<m; i++) {
      const Edge & e = edges[i];
      const int set1 = find (parent, e.x);
      const int set2 = find (parent, e.y);
      const double m1 = cheapest[set1].metrics;
      const double m2 = cheapest[set2].metrics;
      if (set1 != set2) {
        if ((m1 == -1.0) or (m1 > e.metrics)) cheapest[set1] = e;
        if ((m2 == -1.0) or (m2 > e.metrics)) cheapest[set2] = e;
      }
    }
    for (int node=0; node<vertices; node++) {
      if (cheapest[node].metrics != -1.0) {
        const Edge & e = cheapest[node];
        const int set1 = find (parent, e.x);
        const int set2 = find (parent, e.y);
        if (set1 != set2) {
          MSTweight += e.metrics;
          Union (parent, rank, set1, set2);
          const Connection c = {e.x, e.y};
          connections.push_back (c);
          if (callback) {
            callback (e.x, e.y);
            if (!fastmode) usleep (10000);
          }
          numTrees -= 1;
        }
      }
    }
    for (int node=0; node<vertices; node++) cheapest[node].metrics = -1.0;
  }
  printf ("Weight of MST is %8g, connections = %ld\n", round(MSTweight), connections.size());
}
void Boruvka::init() {
  connections.clear();
  m_parent.clear(); m_rank.clear(); m_cheapest.clear();
  m_cheapest.resize(vertices);
  m_numTrees  = vertices;
  m_MSTweight = 0.0;
  for (int node=0; node<vertices; node++) {
    m_parent.push_back (node);
    m_rank  .push_back (0);
    m_cheapest[node].metrics = -1.0;
  }
  m_node  = 0;
  m_inner = true;
  m_clear = false;
}
MathEdge Boruvka::pass (int & a, int & b) {
  if (m_numTrees > 1) {
    if (m_clear) {
      m_clear = false;
      for (int node=0; node<vertices; node++) m_cheapest[node].metrics = -1.0;
    }
    if (m_inner) {
      m_inner = false;
      printf ("trees=%d, color_index = %d\n", m_numTrees, color_index);
      parent->setColor (palette [color_index % 6]);
      color_index += 1;
      int m = edges.size();
      for (int i=0; i<m; i++) {
        const Edge & e = edges[i];
        const int set1 = find (m_parent, e.x);
        const int set2 = find (m_parent, e.y);
        const double m1 = m_cheapest[set1].metrics;
        const double m2 = m_cheapest[set2].metrics;
        if (set1 != set2) {
          if ((m1 == -1.0) or (m1 > e.metrics)) m_cheapest[set1] = e;
          if ((m2 == -1.0) or (m2 > e.metrics)) m_cheapest[set2] = e;
        }
      }
    }
    for (int node=m_node; node<vertices; node++) {
      if (m_cheapest[node].metrics != -1.0) {
        const Edge & e = m_cheapest[node];
        const int set1 = find (m_parent, e.x);
        const int set2 = find (m_parent, e.y);
        if (set1 != set2) {
          m_MSTweight += e.metrics;
          Union (m_parent, m_rank, set1, set2);
          const Connection c = {e.x, e.y};
          connections.push_back (c);
          a = e.x; b = e.y;
          m_numTrees -= 1;
          m_node = node + 1;
          return E_MATH;
        }
      }
    }
    m_node  = 0;
    m_clear = true;
    m_inner = true;
    return E_NO_MATH;
  } else {
    return E_END;
  }
}
bool Boruvka::edge (int & a, int & b) {
  for (;;) {
    const MathEdge me = pass (a, b);
    if (me == E_MATH) return true;
    if (me == E_END ) return false;
  }
}
