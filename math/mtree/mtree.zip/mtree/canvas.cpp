#include <math.h>
#include <time.h>
#include <vector>
#include <string>
#include "canvas.h"
#include "container.h"
#include "boruvka.h"

static double pDistance (const SPoint & p1, const SPoint & p2) {
  const double dx = p1.p.x - p2.p.x;
  const double dy = p1.p.y - p2.p.y;
  double d  = sqrt (dx*dx + dy*dy);
  double n = ((double)rand ()) / ((double)(RAND_MAX));
  n = 2.0 * n - 1.0;
  if (p1.e and p2.e) d = 0.7 * d;
  return d - 0.01 * n;
}

Canvas::Canvas (Container * p) : padding(10), grid(40), parent(p), width(640), height(480),
  outpixel(0u), current(0xFF000000), matrix (1.0, 0.0, 0.0, -1.0, real (0), (real) (height)) {
  data = new Color [width * height];
  pBor = new Boruvka (1, this);
  (void) parent;
}
void Canvas::resize (const int w, const int h) {
  time_t t = time (nullptr);
  srand (t);
  repeat = false;
  printf("resize %dx%d\n", w, h);
  width  = w;
  height = h;
  delete [] data;
  data = new Color [width * height];
  maxx = (width  - 2 * padding) / grid;
  maxy = (height - 2 * padding) / grid;
  matrix = Matrix ((real) grid, 0.0, 0.0, -(real) grid, (real) padding, (real) (height - padding));
  drawings();
}
Canvas::~Canvas() {
  delete [] data;
  delete pBor;
}
void Canvas::Init () {
  int vertices = points.size();
  delete pBor;
  pBor = new Boruvka (vertices, this);
  for (int i=0; i<vertices; i++) {
    for (int j=i; j<vertices; j++) {
      if (i == j) continue;
      const SPoint & pi = points[i];
      const SPoint & pj = points[j];
      const double ds = pDistance (pi, pj);
      const Edge e = {i, j, ds};
      pBor->addEdge (e);
    }
  }
}
void Canvas::fill (const Color & c) {
  for (int y=0; y<height; y++) {
    for (int x=0; x<width; x++) {
      at (x, y) = c;
    }
  }
}
Color & Canvas::at (const int x, const int y) {
  if (!bound(x, y)) return outpixel;
  const int result = x + y * width;
  return data [result];
}
bool Canvas::bound (const int x, const int y) const {
  if (x < 0)       return false;
  if (y < 0)       return false;
  if (x >= width)  return false;
  if (y >= height) return false;
  return true;
}
void Canvas::line (const real xp, const real yp, const real xe, const real ye, const unsigned w) {
  real dx = xe - xp;
  real dy = yp - ye;
  real dl = dx * dx + dy * dy;
  if (dl == 0.0) return;
  dl = sqrt (dl);
  dx = dx / dl;
  dy = dy / dl;
  const Matrix m (dx, dy, -dy, dx, xp, yp);
  
  const unsigned nl = w / 2;
  const unsigned wl = w % 2;
  //const real hl = 0.5 * (real) w;
  if (wl) {
    for (real n=0; n<dl; n+=1.0) {
      const FPoint p = m * FPoint (n, 0.0);
      at ((int) round (p.x), (int) round (p.y)) = current;
    }
  }
  for (unsigned k=0; k<nl; k++) {
    //const real dw = hl - (real) k;
    const real dz = wl ? 1.0 : 0.5;
    const real dh = (real) k + dz;
    for (real n=0; n<dl; n+=1.0) {
      const FPoint p = m * FPoint (n, +dh);
      at ((int) round (p.x), (int) round (p.y)) = current;
      const FPoint q = m * FPoint (n, -dh);
      at ((int) round (q.x), (int) round (q.y)) = current;
    }
  }
  
}
void Canvas::line (const FPoint & begin, const FPoint & end, const unsigned w) {
  const FPoint b (matrix * begin);
  const FPoint e (matrix * end  );
  // printf("%d:%d - %d:%d\n", x0, y0, x1, y1);
  line (b.x, b.y, e.x, e.y, w);
}
void Canvas::circ (const FPoint & center, const real radius) {
  if (radius == 0) return;
  double x = radius, y = 0.0;
  const double dx = 1.0 / radius;
  const double ms = radius * 6.3;
  real count = 0.0;
  // kruh se da nakreslit i bez sin a cos, rychle ale trochu nepresne
  for (;;) {
    x += y * dx; y -= x * dx;
    const FPoint e (center.x + x, center.y + y);
    const FPoint t (matrix * e);
    at ((int) round (t.x), (int) round (t.y)) = current;
    count += 1.0;
    if (count > ms) break;
  }
}

void Canvas::drawings() {
  points.clear();
  fill(Color (0,0,0, 0xFF));
  setColor(Color (0xFF, 0xFF, 0));
  for (int x=0; x<=maxx; x++) {
    for (int y=0; y<=maxy; y++) {
      const FPoint q = FPoint ((real)x, (real)y);
      const FPoint p = matrix * q;
      at(p.x, p.y) = current;
      SPoint s (q);
      if (x == 0)    s.e = true;
      if (y == 0)    s.e = true;
      if (x == maxx) s.e = true;
      if (y == maxy) s.e = true;
      points.push_back (s);
    }
  }
  points[0].e = false;
  Init ();
  pBor->init();
  setColor (Color(0x00,0xFF,0x00));
}
bool Canvas::newconn() {
  if (repeat) {
    resize (width, height);
  }
  int a, b;
  const bool res = pBor->edge (a, b);
  const FPoint beg = points[a].p;
  const FPoint end = points[b].p;
  line (beg, end, 4);
  if (!res) repeat = true;
  return res;
}

int Canvas::progress() {
  const int max = points.size();
  if (max == 0) return 0;
  const int trees = pBor->getTrees();
  const double result = 100.0 * (double) (max - trees) / (double) max;
  // printf("result = %g\n", result);
  return (int) round (result);
}
