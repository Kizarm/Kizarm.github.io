const char * description_string = R"---(<h3>Hledání minimální kostry grafu - popis.</h3>
  <p>Jako první našel tento algoritmus prof. Borůvka už před sto léty. Ačkoli se o tom
  traduje, že to byl nějaký bezvýznamý inženýr, který na to přišel náhodou při hledání nejkratších tras
  elektrického vedení kdesi na Moravě, pravdou je na tom jen ta definice problému. Otakar Borůvka byl
  poměrně významný matematik, tento algoritmus publikoval v r. 1926 v článku "O jistém problému minimálním",
  ale nějak to zapadlo a tak byl tento algoritmus znovu objeven dalšími vědci. Zde je použita modifikace
  se kterou přišel později Joseph Kruskal.
  </p>
  <p>O co jde. Vstupem algoritmu je souvislý ohodnocený graf, výstupem minimální kostra (minimum spanning tree).
  Ano, tato minimální kostra má strukturu stromu, nenajdete tedy nějaké uzavřené smyčky. Kdysi jsem to použil
  pro propojení děr na plošném spoji a zaujalo že optimalizace proběhne způsobem, který není na první pohled
  patrný. Tento prográmek sice není celkem k ničemu, ale generuje pěkné bludiště. Je to dáno tím, že ohodnocení
  hran není dáno jen vzdáleností uzlů ale je tam přidána malá náhodná odchylka. Ve <a href="./mtree.zip">zdrojácích</a>
  je nepoužitá metoda Boruvka::MST () což je kompletní výpočet kostry, zde je to rozsekáno do dost nepřehledných
  kousků kódu tak aby se to dalo použít ve smyčce událostí. Pak to jde průběžně zobrazovat a je vidět jak algoritmus
  pracuje - spojuje hrany postupně do větších celků.
  </p>
  <h3 align="center">© Kizarm 2020</h3>
)---";
const char * style_string = R"---(
html,
body {
    height:  100%;
    margin:  0;
    padding: 0;
}
.canvas {
    width:  98vw;
    height: 90vh;
}
.slider {
  -webkit-appearance: none;
  width: 98%;
  height: 30px;
  border-radius: 5px;  
  background: #00FF00;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}
.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider::-moz-range-thumb {
  width: 25px;
  height: 30px;
  background: #A000A0;
  cursor: pointer;
}
.slider:disabled {background: #dddddd;}
.button {
  background-color: #00F0F0;
  border: none;
  color: black;
  padding: 10px 24px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 18px;
  border: 2px solid #4CAF50;
}
.button:disabled {background: #dddddd;}
.frame1 {
  width:  95%;
  margin: 0;
  padding: 10px;
  background-color: #FFFFC0;
  border: 10px solid #F0C0F0;
}
.progress {
  width: 100%;
  height: 30px;
  background-color: #FF0000;
  text-align: center;
  line-height: 30px;
  color: white;
}
)---";
