#ifndef CONTAINER_H
#define CONTAINER_H
#include "element.h"
#include "canvas.h"

class Container {
  HtmlElement * root;
  int  order;
  std::vector<HtmlElement*> ordered;
  HtmlElement            *  b_start;
  HtmlElement            *  progress;
  public:
    Canvas                  canvas;
  public:
    Container ();
    ~Container ();
    Action back (const int index, const std::string & input);
    std::string to_string ();
    std::string InitAll ();
    std::string getProgress ();
    /////////////////////////// Helpers //////////////////////////////
    int getOrder () { return order; };
    HtmlElement * getOrdered (const int n) { return ordered [n]; };
    void addOrdered (HtmlElement * e) { ordered.push_back(e); order += 1; };
    void addInitialized (HtmlElement *) {};
  protected:
    HtmlElement* button_start();
    
};

#endif // CONTAINER_H
