#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include "formica.h"
#include "pcb.h"

//#define DEBUG 1
#ifdef DEBUG
  #define dbg {printf("%s,\tthis=%p\n",__FUNCTION__,this);}
  #define debug printf
#else
  #define dbg
  #define debug(...)
#endif

FILE * output = NULL;
// Pro kontrolu počtu objektů a uvolnění paměti.
static int cntitems=0, maxitems=0;
// static int depth = 0;

/** *******************************************************************/
static inline void incItems (void) {
  cntitems += 1;	// V konstruktoru přidáme
  maxitems += 1;
}
static inline void decItems (void) {
  cntitems -= 1;	// a v destruktoru ubereme
}
/** *******************************************************************/

Element::Element () {
  incItems();
  // debug ("Konstruktor %p Element\n", this);
  // printf ("Konstruktor %p Element\n", this);
  next  = NULL;
  back  = NULL;
  
  //up = NULL;
};
Element::~Element () {
  decItems();
  // debug ("Destruktor %p Element\n", this);
  if (next ) delete next;
}

Element * Element::addItem (Element * e) {
  debug ("%s:\tthis %p -> (%p)", __FUNCTION__, this, e);
  if (next) {		// Kontrola pro případ, že parser nefunguje, jinak zbytečné
    debug (" error next");
    fprintf (stderr, "Error next %s at this=%p\n", __FUNCTION__, this);
  } else {
    next = e;
  }
  
  if (e->back) {	// Kontrola pro případ, že parser nefunguje, jinak zbytečné
    debug (" error back");
    fprintf (stderr, "Error back %s at this=%p\n", __FUNCTION__, this);
  }
  else {
    e->back = this;
  }
  debug ("\n");
  return this;
}

Element* Element::bracket ( void ) {
  Nested * e = new Nested ();
  debug ("%s:\tthis %p <\\\\ new (%p)\n", __FUNCTION__, this, e);
  back = e;
  return e->setFork (this);
}
Element * Element::addRoot (void) {
  dbg;
  root = this;
  return this;
}

void Element::print (void) {
  if (!back && this!=root) fprintf (stderr, "Element %p nema back\n", this);
  if (next) next->print();
}
Element * Element::addLabel 	(char *   name ) {
  fprintf (stderr, "Error %s - %s", __FUNCTION__, name);
  return this;
};
Element* Element::findLabel ( const char* name ) {
  Element * e = NULL;
  char * lbl  = getLabel();
  if (lbl) {
    if (!strcmp (name, lbl)){
      debug ("Result: %s \tat %p\n", name, this);
      e  =   this;
      return this;
    }
  }
  if (getFork()) {
    e = getFork()->findLabel (name);
    if (e) return e;
  }
  if (next) {
    e = next->findLabel      (name);
    if (e) return e;
  }
  return e;
}

int Element::nElements (void) {
  int res = 0;
  if (next) res = next->nElements();
  debug ("nElements %d\n", res);
  return  ++res;
}

/** *******************************************************************/

String::String (char* name) : Element() {
  data = name;
  debug ("Konstruktor\tthis=%p String = {%s}\n", this, data);
}

Integer::Integer (int n) : Element() {
  debug ("Konstruktor\tthis=%p Integer = %d\n", this, n);
  data = n;
}
Nested::Nested() {
  debug ("Konstruktor\tthis=%p Nested\n", this);
  fork  = NULL;
  label = NULL;
}
Nested::~Nested() {
 if (label) delete label;
 if (fork)  delete fork;
}

/* Label byla předtím vytvořena pomocí strdup, na konci nutno použít free */
Nested* Nested::addLabel ( char* p ) {
  if (!p) fprintf (stderr, "Adding Empty label\n");
  //else   printf ("Add Label %s\n", p);
  label = p;
  debug ("%s:\tthis %p (%s)\n", __FUNCTION__, this, label);
  return this;
}
char* Nested::getLabel ( void ) {
  return label;
}

Nested * Nested::setFork ( Element* e ) {
  fork = e;
  return this;
}

void Integer::print (void) {
  fprintf (output,"%d ", data);
  Element::print();
}
void String::print (void) {
  fprintf (output, "%s ", data);
  Element::print();
}
void Nested::print ( void ) {
  fprintf (output, "\n");
  if (label) {
    fprintf (output,"%s ", label);
  }
  fprintf (output,"( ");
  if (fork ) fork->print();
  fprintf (output,") ");
  Element::print();
}

/** *******************************************************************/

Element * root = NULL;

void FmInit (char * name) {
  if (name && *name)
    output = fopen (name, "w");
  else output = stdout;
}

void FmFini (void) {
  printf ("--------\n");
  if (root) {
    // root->print(); // chyby budou zde
    BoardInit (root);
  }
  printf ("\n--------\n");
  if (output && output != stdout)
    fclose (output);
  if (root) delete root;
  BoardFini ();
  printf ("Max=%d, zbylo=%d\n", maxitems, cntitems);
}
