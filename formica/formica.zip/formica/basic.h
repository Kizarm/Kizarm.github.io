#ifndef BASIC_H
#define BASIC_H

#include <stdio.h>
#include "formica.h"

struct Point {
  int x,y;
  bool isEqual  (Point * p);
  bool isAtLine (Point * b, Point * e);
};
/** ******************************************************************/

class Basic {
  public:
    Basic  (const char * name) : label(name) {
      //draft = NormalDraft;
    };
    virtual ~Basic () {};
    virtual const char * getLabel (void) {
      return label;
    };
    virtual void      print       (void) {
      fprintf (stderr, "Ignored field \"%s\"\n", label);
    };
    virtual Element * find      (Element * e) {
      Element * f = e->findLabel (label);
      //if (!f) fprintf (stderr, "Warning: %s - %s, ignored\n", __FUNCTION__, label);
      return f;
    };
    virtual bool      convert   (Element * e) {
      base = e;
      return false;
    };
    virtual bool      nAndDown  (int & value) {
      if (!base) return false;
      base = base->getFork();		// podřazený element
      if (!base) return false;
      value = base->nElements();
      return true;
    };
  private:
    const char * label;
  public:
    Element    * base;
};
class Component;

template <class T>
class List : public Basic {
  public:
    List (const char * name) : Basic(name) {
      size   = 0;
      data   = NULL;
      parent = NULL;
    }
    bool convert   (Element * e) {
      bool result = Basic::convert (e);
      int       n;
      // pro pojmenovanou strukturu
      base  = find (base);
      
      if (!nAndDown (n)) return false;
      //printf ("%d List %s: Nalezeno %d cest\n", draft, __FUNCTION__, n);

      create  (n);
      e = base;
      for (int i=0; i<n; i++) {
	data[i].parent = parent;
	if (data[i].convert (e)) result = true;
	e = e->getNext();
	if (!e) break;
      }
      return result;
    }
    bool convertn  (Element * e) {
      bool result = Basic::convert (e);
      int       n;
      // pro pojmenovanou strukturu
      base  = find (base);
      
      if (!nAndDown (n)) return false;
      //printf ("%d List %s: Nalezeno %d cest\n", draft, __FUNCTION__, n);

      n += 1;
      create  (n);
      e = base;
      for (int i=1; i<n; i++) {
	if (data[i].convertn (e, i)) result = true;
	e = e->getNext();
	if (!e) break;
      }
      return result;
    }
    void printl     (void) {			// Layer
      const char * name = "TRACK";
      if (!size) return;
      fprintf (output, "$%s\n", name);
      for (int n=0; n<size; n++)
	data[n].printl ();
      fprintf (output, "$End%s\n", name);
    }
    void printm     (void) {			// Module
      for (int n=0; n<size; n++)
	data[n].printm ();
    }
    /* Uz neni potreba
    void print     (void) {
      for (int n=0; n<size; n++)
	data[n].print ();
    }
    */
    T * search (int no) {
      for (int i=0; i<size; i++) {
	if (no == data[i].type) return &data[i];
      }
      fprintf(stderr, "%s: Cannot find element %d\n", getLabel(), no);
      return NULL;
    }
    void translate (Point & p) {
      for (int n=0; n<size; n++)
	data[n].translate (p);
    }
    
    int create (int n) {
      size = n;
      data = new T [size];
      return size;
    };
    ~List () {
      delete [] data;
    };
  public:
    int   size;
    T   * data;
    Component    *      parent;	// potrebujeme vedet, kde je soucastka
};


#endif // BASIC_H
