#ifndef PCB_H
#define PCB_H

#include "formica.h"
#include "basic.h"
#include "layout.h"
#include "components.h"
#include "dims.h"
#include "netlist.h"
#include "setup.h"


/** ******************************************************************/
class Board : public Basic {
  public:
    Board (const char * name);
    void print   (void);
    bool convert (Element * e);
    void assignNets (void);
  protected:
    void assignNetsToPads   (void);
    void assignNetsToVias   (void);
    void assignNetsToTracks (void);
    void assignPadsToTracks (void);
    int  assignViasToNets   (void);
    
    void unassigned (void);
    
    void setVias    (void);
  public:
    Setup		setup;
    Dimensions		dims;
    Layout        	layout;
    List<Component>    	comp;
    List<Netlist>	net;
  };
extern const int KicadVias;
extern Board *   MainBoard;
extern void BoardInit (Element * e);
extern void BoardFini (void);


#endif // PCB_H
