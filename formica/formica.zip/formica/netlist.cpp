#include <string.h>
#include "netlist.h"

//#define debug printf
#define debug(...)

Netlist::Netlist() : Basic("Net") {
  parent = NULL;
  pair   = NULL;
  maxp   = 0;
  order  = 0;
}
Netlist::~Netlist() {
  if (pair) delete [] pair;
}


bool Netlist::convertn ( Element* e, int n ) {
  int        i;
  bool result = Basic::convert (e);
  // debug ("Base=%p\n", base);
  //debug ("Converting: %s - %d\n", getLabel(), n);

  if (!nAndDown (i)) return false;
  debug ("%d-%s: Nalezeno %d prvku\n",n , __FUNCTION__, i);
  if (i&1) fprintf (stderr, "Net: lichy pocet prvku %d\n", i);
  order = n;
  
  i >>= 1;
  maxp = i;
  pair = new NetPair [maxp];
  i = 0;
  pair[i].comp = (char *) "\"\"";
  pair[i].pin  = 0;
  Element * f = base;
  for (i=0; i<maxp; i++) {
    pair[i].comp = f->getString();
    f = f->getNext();        if (!f) break;
    if (!f->getInteger(pair[i].pin)) break;
    f = f->getNext();        if (!f) break;
  }
  result = true;
  return result;
}
void Netlist::printm ( void ) {
  debug ("Net\n");
  const char * name = "EQUIPOT";
  fprintf (output, "$%s\n",    name);
  if (order)
    fprintf (output, "Na %d \"N%05d\"\nSt ~\n", order, order);
  else
    fprintf (output, "Na %d \"\"\nSt ~\n", order);
  fprintf (output, "$End%s\n", name);
}

int Netlist::assingNet ( const char* ref, Pad* pad ) {
  int i, k = pad->no;
  for (i=0; i<maxp; i++) {
    if (!strcmp(ref, pair[i].comp)) {
      if (k == pair[i].pin) {
	pad->net = order;
	return order;
      }
    }
  }
  return 0;
}

