#include "dims.h"

// #define DEBUG 1
#ifdef DEBUG
  #define dbg {printf("%s,\tthis=%p\n",__FUNCTION__,this);}
  #define debug printf
#else
  #define dbg
  #define debug(...)
#endif

bool LineDim::convert ( Element* e ) {
  bool result = Basic::convert ( e );
  int i, j, k, n;
  if (!nAndDown (n)) return false;
  debug ("LineDim %s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  if (!e->getInteger(type)) return false;
  debug ("Line type : %d\n", type);
  e = e->getNext(); if (!e) return false;
  /**/
  n -= 1;
  Element * f, * g;
  int w, lay, nlay=0, lays [LayerMax];
  for (i=0; i<n; i++) {	// cely seznam
    f = e->getFork();	// e=((seznam_vrstev) sirka  | vrstva sirka)
    if (f) {		// f= (seznam_vrstev) sirka  | vrstva sirka
      g = f->getFork();
      if (g) {		//  g=seznam_vrstev
	debug ("seznam_vrstev\n");
	//h->print();
	for (k=0; k<LayerMax; k++) {
	  if (!g->getInteger(lays[nlay])) break;
	  nlay++;
	  g = g->getNext();
	  if (!g) break;
	}
	f = f->getNext();
	if (!f) return false;
	if (!f->getInteger(w))    	return false;
	debug ("Vrstvy=");
	for (int m=0; m<nlay; m++)
	  debug ("%d ", lays[m]);
	debug (", Sirka=%d\n", w);
	for (j=0; j<nlay; j++) {
	  lay = lays[j];
	  pair[lay].layer = lay;
	  pair[lay].width = w;
	}
	nlay = 0;
      }
      else {		//  g=vrstva sirka
	if (!f->getInteger(lay))	return false;
	f = f->getNext(); if (!f) 	return false;
	if (!f->getInteger(w))    	return false;
	debug ("Vrstva=%d, Sirka=%d\n", lay, w);
	pair[lay].layer = lay;
	pair[lay].width = w;
      }
    } else break;
    e = e->getNext();
    if (!e) break;
    result = true;
  }
  /**/
  return result;
}
/** **********************************************************/

bool PadDim::convert ( Element* e ) {
  bool result = Basic::convert ( e );
  int i, j, k, n;
  if (!nAndDown (n)) return false;
  debug ("PadDim  %s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  if (!e->getInteger(type)) return false;
  debug ("Pad  type : %d\n", type);
  e = e->getNext(); if (!e) return false;
  /**/
  n -= 1;
  Element * f, * g;
  int pt, pw, ph, lay, nlay=0, lays [LayerMax];
  for (i=0; i<n; i++) {	// cely seznam
    f = e->getFork();
    if (f) {
      g = f->getFork();
      if (g) {		//  g=seznam_vrstev
	debug ("seznam_vrstev\n");
	for (k=0; k<LayerMax; k++) {
	  if (!g->getInteger(lays[nlay])) break;
	  nlay++;
	  g = g->getNext();
	  if (!g) break;
	}
	f = f->getNext();
	if (!f) return false;
	if (!f->getInteger(pt))    	return false;
	f = f->getNext();
	pw = 0; ph = 0;
	if (f) {
	  if (f->getInteger(pw)) {
	    f = f->getNext();
	    if (f) {
	      f->getInteger(ph);
	    }
	  }
	}
	debug ("Vrstvy=");
	for (int m=0; m<nlay; m++)
	  debug ("%d ", lays[m]);
	debug (", Shape=%d, w=%d-h=%d\n", pt, pw, ph);
	for (j=0; j<nlay; j++) {
	  lay = lays[j];
	  desc[lay].shape  = pt;
	  desc[lay].width  = pw;
	  desc[lay].height = ph;
	}
	nlay = 0;
      }
      else {		//  g=vrstva sirka
	if (!f->getInteger(lay))	return false;
	f = f->getNext(); if (!f) 	return false;
	if (!f->getInteger(pt))    	return false;
	f = f->getNext();
	pw = 0; ph = 0;
	if (f) {
	  if (f->getInteger(pw)) {
	    f = f->getNext();
	    if (f) {
	      f->getInteger(ph);
	    }
	  }
	}
	debug ("Vrstva=%d, Shape=%d, w=%d-h=%d\n", lay, pt, pw, ph);
	desc[lay].shape  = pt;
	desc[lay].width  = pw;
	desc[lay].height = ph;
      }
    } else {
      g = e;
      if (g) {
	if (g->getInteger (drill)) {
	  g = g->getNext();
	  if (g) {
	    g->getInteger (oposite);
	  }
	}
      }
      debug ("Drill=%d, Oposite=%d\n", drill, oposite);
      break;
    }
    e = e->getNext();
    if (!e) break;
    result = true;
  }
  /**/
  return result;
}
/** **********************************************************/

bool Dimensions::convert ( Element* e ) {
  bool result = Basic::convert ( e );
  base = find (base);
  if (!base) return false;
  // base->print();
  Element * f = base->getFork();
  if (!f) return false;
  int i;
  if (f->getInteger(i)) {
    if (i) fprintf (stderr, "Warn.: Converting from metrics not supported !\n");
  }
  /// ... stejne - dalsi prvky - alespon jediny musi byt OK.
  if (pads .convert (base)) result = true;
  if (lines.convert (base)) result = true;
  return result;
}

/** **********************************************************/

void Dimensions::print ( void ) {
  pads .print();
  lines.print();
}
void PadDim::print ( void ) {
  printf ("Pad  %03d drill=%d, oposite=%d\n", type, drill, oposite);
  for (int i=0; i<LayerMax; i++) {
    printf ("%d-%d<%d %d> ", i, desc[i].shape, desc[i].width, desc[i].height);
  }
  printf ("\n");
}
void LineDim::print ( void ) {
  printf ("Line %03d\n", type);
  for (int i=0; i<LayerMax; i++) {
    printf ("%d<%d %d> ", i, pair[i].layer, pair[i].width);
  }
  printf ("\n");
}
