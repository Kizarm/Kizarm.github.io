#ifndef __FORMICA_H__
#define __FORMICA_H__


#include <stdio.h>
#include <stdlib.h>

class Element;
class Integer;

extern FILE    * output;
extern Element * root;
extern void  FmInit (char * name);
extern void  FmFini (void);


class Element {
  Element * next;
  Element * back;
  
public:
  Element ();
  virtual ~Element ();
  virtual void      print       (void);
  
  virtual char    * getLabel    (void) {
    return NULL;
  }
  virtual bool      getInteger  (int & n) {
    return false;
  }
  virtual char    * getString   (void) {
    return NULL;
  }
  virtual Element * findLabel   (const char * name);
  
  virtual Element * addLabel 	(char *   name );
  virtual Element * bracket 	(void);
  virtual Element * addRoot     (void);
  virtual Element * addItem 	(Element * );
  
  virtual Element * getFork     (void) {return NULL;};
  virtual Element * getNext     (void) {return next;};
  
  virtual int nElements (void);
  
};

class Integer : public Element {
  int	data;
public:
  Integer    (int n);
  void print (void );
  bool getInteger  (int & n) {
    n = data;
    return true;
  }
};

class String : public Element {
  char * data;	// Vždy alokováno funkcí strdup()
public:
   String (char* name);
  ~String () {
    free  (data);
  }
  void   print     (void);
  char * getString (void) {
    return data;
  }
};

class Nested : public Element {
  Element * fork;
  char    * label;
public:
  Nested();
 ~Nested();
  Nested * addLabel (char * );
  char   * getLabel (void   );
  void     print    (void   );
  
  Nested * setFork  (Element * e);
  Element* getFork  (void) {return fork;};   
};


#endif /* __FORMICA_H__ */
