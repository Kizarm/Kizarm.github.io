#include "maps.h"
#include "pcb.h"
#include <string.h>
//#include <strings.h>

LayerMap lM (24);
WidthMap wM (16);
DimesMap dM;

#ifdef WIN32
char * index (char * s, char c) {
  char t;
  while (1) {
    t = * s;
    if (t == c   ) return s;
    if (t == '\0') return NULL;
    s++;
  }
}
char * strndup (const char * s, const size_t l) {
  char * result = (char*) malloc (l+1);
  memcpy (result, s, l);
  result [l] = '\0';
  return result;
}
#endif // WIN32

char * stripClober (char * s) {
  s++;
  char * end = index (s, '\"');
  if (!end) return end;
  size_t len = end - s;
  return strndup (s, len);
};

/** Mělo by být vytvořeno z datové struktury Dimensions,
 *  zatím fix.
 * */
static const int fmLineWidths[] = {4, 6, 8, 10, 12, 16, 20, 24, 32, 40, 52, 60, 80, 100, 120, 200};

WidthMap::WidthMap(int max) : wmax(max) {
  internal = NULL;
}
WidthMap::~WidthMap() {
  if (internal) delete [] internal;
}
void WidthMap::remap ( void ) {
  //printf ("REMAP\n");
  List<LineDim> * ld = & MainBoard->dims.lines;
  int i, j, k, l, m = 0;
  const int n = ld->size;
  for (i=0; i<n; i++) {				// hledame maximum
    j = ld->data[i].type;
    if (j > m) m = j;
  }
  printf ("Maximum Lines : %d\n", m);
  wmax = m + 1;					// jsou cislovane od 0, takze max 15 je 16 hodnot
  internal = new LayerTable [wmax];
  memset (internal, 0, wmax * sizeof (LayerTable));
  for (i=0; i<n; i++) {
    j = ld->data[i].type;
    // ono je to jeste zavisle na vrstve
    for (k=0; k<LayerMax; k++) {
      l = ld->data[i].pair[k].layer;
      m = ld->data[i].pair[k].width;
      if (!m)   continue;	// nula uz tam je, nezapisuj
      if (l!=k) continue;	// logicka chyba,  nezapisuj
      if (j>=wmax) {
	fprintf (stderr, "Remap Overflow %d, max %d\n", j, wmax);
	break;
      }
      internal[j].tab[k] = m;	// Zapis do tabulky
    }
  }
}

int WidthMap::f2k ( int x, int ly ) {
  //printf ("F2K");
  if (internal) {
    if (x  > wmax)     x  = wmax;
    if (ly > LayerMax) ly = LayerMax;
    return 10 * internal[x].tab[ly];
  } else {
    if (x > wmax) x = wmax;
    return 10 * fmLineWidths [x];
  }
}

/** Fixne *******************************************/

typedef enum {
Back_Solder,		//00.
Inner_back,		//01.
Inner_front,		//02. 
Inner3,			//03.
Inner4,			//04.
Inner5,			//05.
Inner6,			//06.
Inner7,			//07.
Inner8,			//08.
Inner9,			//09.
Inner10,		//10.
Inner11,		//11.
Inner12,		//12.
Inner13,		//13.
Inner14,		//14.
Front_Component,	//15.-

Adhestive_Back,		//16.
Adhestive_Front,	//17.
Solder_Paste_Back,	//18.
Solder_Paste_Front,	//19.-
SilkScreen_Back,	//20.
SilkScreen_Front,	//21.
SolderMask_Back,	//22.
SolderMask_Front,	//23.-
Drawings,		//24.
Comments,		//25.
ECO1,			//26.
ECO2,			//27.
Edge_Cuts,		//28.
} KICAD_LAYERS;
// To přemapování může být divné, lze upravit podle potřeby.
static const int scLayerMap [] = {
// 0			1			2			3			4
  SilkScreen_Back,	ECO1,	SilkScreen_Back,	Solder_Paste_Back,	SolderMask_Back,
// 5			6			7			8			9
  Back_Solder,		Inner_back,		Inner_front,		Inner3,			Inner4,
// 10			11			12			13			14
  Front_Component,	SolderMask_Front,	Solder_Paste_Front,	SilkScreen_Front,	ECO2,
// 15
  SilkScreen_Front,
  /** Knihovny pouzivaji vice vrstev, k cemu tyto jsou neni jasne. */
// 16			17			18			19			20
  SilkScreen_Front,	SilkScreen_Front,	SilkScreen_Front,	SilkScreen_Front,	SilkScreen_Front,	
//  ECO1,			ECO1,			ECO1,			ECO1,			ECO2,
// 21			22			23			24
  SilkScreen_Front,	SilkScreen_Front,	Drawings,		SilkScreen_Front,
//  ECO2,			ECO2,			ECO2,			ECO2,
};
void LayerMap::setLayers ( int t, int b ) {
  top    = t;
  bottom = b;
  map[t] = Front_Component;
  map[b] = Back_Solder;
}

LayerMap::LayerMap (int max) : lmax(max) {
  map = new int [max];
  for (int i=0; i<lmax; i++) map [i] = 0;
  for (int i=0; i<lmax; i++) {
    map [i] = scLayerMap [i];
  }
}
LayerMap::~LayerMap() {
  delete [] map;
}

int LayerMap::f2k ( int x ) {
  if (x > lmax) x = lmax;
  return map [x];
}

DimesMap::DimesMap() {

}
/*
static long xmax = 0;
static long xmin = 0;

void printext (void) {
  printf ("Max = %ld, Min = %ld\n", xmax, xmin);
}
*/
int DimesMap::f2k ( int x ) {
  return 10 * x;
}
/** ************************************************************************/

KicadPad::KicadPad ( int type, int orient ) {
    
  int layer = lM.top;
  if (orient & (1<<4)) layer = lM.bottom; 
  List<PadDim> * pd = &MainBoard->dims.pads;
  // int n = pd->size - 1;
  // liší-li se bity 6 a 7, značí to rotaci pájecího bodu o 90 ◦, Orientation = 900
  int i1 = (type >> 6) & 1;
  int i2 = (type >> 7) & 1;
  Orientation = i1 ^ i2; // ^ (orient & 1); ne, podle knihovny to neni
  // Urceni typu a orientace je ve hvezdach, neni popsano
  // Zkusme proste nechat 6.bitu, zbytek (6.7.8.->6.7.) pak nejak premapovat
  i1  = (type >> 6);
  switch (i1) {
    case 0: i1 = (0 << 6); break;	// puvodni mapovani V 4.3
    case 1: i1 = (0 << 6); break;
    // Orientation ^= 1 ??? bez toho je to ale uplne blbe
    case 2: i1 = (1 << 6); Orientation ^= 1; break;
    case 3: i1 = (1 << 6); Orientation ^= 1; break;
    // verze 4.4 ma o 1 bit vic, certi vedi jak je to spravne
    case 4: i1 = (2 << 6); break;
    case 5: i1 = (3 << 6); break;
    case 6: i1 = (2 << 6); break;
    case 7: i1 = (3 << 6); break;
    default: fprintf (stderr, "Too large number of pad %d\n", type);
    i1 = 0; break;
  }
  i2  = type  &  0x3F;
  i2 |= i1;
  
  PadDim  * p = pd->search (i2);
  if (!p) {
    fprintf (stderr, "Logical type pad %d not in table\n", i2);
    p = & pd->data[0];
  }
  layer = detLayers (p, layer);
  //printf ("Determined PadType %d : %08X\n", i2, Layers);
  
  if (p->drill) SmdStd = "STD";
  else          SmdStd = "SMD";
  
  PadDesc * dsc = & p->desc [layer];
  if (Orientation) {	 // asi takto ?
    Orientation = 900;
  } else
    Orientation = 0;
  
  Height = dM.f2k (dsc->height);
  Width  = dM.f2k (dsc->width );
  Shape  = 'C';
  if (!Height) Height = Width;
  // printf ("Type1=%d, Type2=%d - Shape=%d, bits=0x%02x\n", ty, i2, dsc->shape, i1);
  switch (dsc->shape) {
    case 1: 
      if (Height != Width) Shape = 'O';
      break;
    case 2: Shape = 'R'; break;
    case 3: Shape = 'C'; break;
    case 4: Shape = 'T'; break;
    default:
      //Height = 0; Width = 0;
      break;
    
  }
  Drill = dM.f2k (p->drill);
}
int KicadPad::detLayers ( PadDim* p, int inl ) {
  int i,k, res = inl;
  Layers = 0U;
  for (i=0; i<LayerMax; i++) {	// Formica Layers
    k = lM.f2k (i);
    if (p->desc[i].height || p->desc[i].width)
      Layers |= (1U<<k);
    else {
      if (i==inl) {
	fprintf (stderr, "No Dims Pad at layer %d\n", inl);
	if (inl == lM.bottom ) res = lM.top;	// zkus zmenit vrstvy.
	if (inl == lM.top)     res = lM.bottom;
      }
    }
  }
  return res;
}


