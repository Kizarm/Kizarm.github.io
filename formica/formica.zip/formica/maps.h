#ifndef MAPS_H
#define MAPS_H
#include "dims.h"

class LayerMap {
  public:
    LayerMap (int max);
    ~LayerMap ();
    int f2k (int x);
    void setLayers (int t, int b);
  public:
    const int lmax;
    int   *   map;
    
    int       top, bottom;
};

struct LayerTable {
  int tab [LayerMax];
};

class WidthMap {
  public:
    WidthMap (int max);
    ~WidthMap ();
    int  f2k (int x, int ly);
    void remap (void);
  public:
    int          wmax;
    LayerTable * internal;
};

class DimesMap {
  public:
    DimesMap ();
    int f2k (int x);
};
class KicadPad {
public:
  KicadPad (int type, int orient);
  int detLayers (PadDim  * p, int inl);
public:
  char		Shape;
  int 		Width,
		Height,
		Orientation;
  int 		Drill;
  
  unsigned      Layers;
  char const *  SmdStd;
};

extern LayerMap lM;
extern WidthMap wM;
extern DimesMap dM;

extern char * stripClober (char * s);
#endif // MAPS_H
