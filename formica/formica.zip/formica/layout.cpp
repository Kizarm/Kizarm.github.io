#include "layout.h"
#include "maps.h"
#include "pcb.h"
#include <string.h>

//#define DEBUG 1
#ifdef DEBUG
  #define dbg {printf("%s,\tthis=%p\n",__FUNCTION__,this);}
  #define debug printf
#else
  #define dbg
  #define debug(...)
#endif

int Line::onTrack ( Line* l ) {
  if (l->layer != layer) return 0;
  if (net)               return 0;
  if (begin.isAtLine (& l->begin, & l->end)) {
    net = l->net;
    return net;
  }
  if (end.isAtLine (& l->begin, & l->end)) {
    net = l->net;
    return net;
  }
  return 0;
}
int Line::onTrack ( Point* p ) {
  if (!net) return 0;
  if (p->isAtLine (& begin, & end)) {
    return net;
  }
  return 0;
}
int Via::onTrack ( Line* l ) {
  if (!net) return 0;
  if (pos.isAtLine (& l->begin, & l->end)) {
    return net;
  }
  return 0;
}

void Line::translate ( Point& p ) {
  begin.x -= p.x;
  begin.y -= p.y;
  end.x   -= p.x;
  end.y   -= p.y;
}
void Text::printm ( void ) {
  debug ("Text: %s <%d,%d> %d-%d\n", id, pos.x, pos.y, height, layer);
  const char * name = "TEXTPCB";
  fprintf (output, "$%s\n",    name);
  fprintf (output, "Te %s\n", id);
  // Po x y height width thickness angle
  int angle = 0;
  if (orient & 1) angle = 900;
  fprintf (output, "Po %d %d %d %d %d %d\n", pos.x, pos.y, 6 * height, 6 * height, type, angle);
  // De layerNum mirror 0 style
  int m = 1;
  if (orient & 4) m = 0;
  fprintf (output, "De %d %d 0 Normal\n", layer, m);
  fprintf (output, "$End%s\n", name);
}

void Via::printm ( void ) {
  if (asg) return;
  // fprintf (output, "Via at <%d %d> t=%d\n", pos.x, pos.y, type);
  const char * mod = "MODULE";
  const char * pin = "PAD";
  
  fprintf (output, "$%s VIA%02d\n", mod, type);
  fprintf (output, "Po %d %d 0 0 0 ~~\n", pos.x, pos.y);
  fprintf (output, "$%s\n", pin);
  KicadPad pad (type, 0);
  fprintf (output, "Sh \"%d\" %c %d %d 0 0 %d\n",
	   1, pad.Shape, pad.Width, pad.Height, pad.Orientation);
  // Dr Size X Y
  fprintf (output, "Dr %d 0 0\n", pad.Drill);	// vrtani
  // At Type N Mask - pevna maska by mela byt odvozena z mapy.
  unsigned nmask = 0x00E0FFFF;
  fprintf (output, "At STD N %08X\n", nmask);
  if (net) fprintf (output, "Ne %d \"N%05d\"\n", net, net);	// net
  fprintf (output, "Po 0 0\n");
  
  fprintf (output, "$End%s\n", pin);
  fprintf (output, "$End%s\n", mod);
}
void Line::printl ( void ) {
  int vial = 0, vtype = 0, nett = 0;
  if (via) {
    KicadPad pad (via - 1, 0);
    vial = 3; vtype = 1;
    fprintf (output, "Po %d %d %d %d %d %d -1\n", vial, begin.x, begin.y, begin.x, begin.y, pad.Width);
    fprintf (output, "De %d %d %d 0 0\n", layer, vtype, nett);
    vial = 0; vtype = 0;
  }
  if (type < 40) return;	// sirka musi byt vetsi nez 40 mil. Mensi ignorujeme.
  // if (!net) return;
  // const char * name = "DRAWSEGMENT";
  debug ("LayersDraft\n");
  //fprintf (output, "$%s\n",    name);
  fprintf (output, "Po %d %d %d %d %d %d -1\n", vial, begin.x, begin.y, end.x, end.y, type);
  fprintf (output, "De %d %d %d 0 0\n", layer, vtype, nett);
  //fprintf (output, "$End%s\n", name);
}
void Line::printm ( void ) {
  debug ("NormalDraft\n");	// Component
  fprintf (output, "DS %d %d %d %d %d %d\n", begin.x, begin.y, end.x, end.y, type, layer);
}
void Layout::print ( void ) {
  pads  .printm();
  texts .printm();
  if (KicadVias)  sort  .printl();
  else            tracks.printl();
  adds  .printl();
}
bool Text::convert ( Element* e ) {
  bool result = Basic::convert (e);
  int        n,i;
  const int  size = 6;
  static int k[size];
  // debug ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  debug ("Texts %s: Nalezeno %d cest\n", __FUNCTION__, n);
  e = base;
  id = e->getString();
  if (id) result = true;
  e = e->getNext(); if (!e) return false;
  for (i=0; i<size; i++) {
    if (e->getInteger (k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  int tmp;
  pos.x = dM.f2k (k[n++]); pos.y = -dM.f2k (k[n++]);
  // tyto parametry budou asi taky chtit premapovat 
  height = dM.f2k (k[n++]);
  orient = k[n++];
  tmp    = k[n++];
  layer  = k[n++];
  type   = wM.f2k (tmp, layer);
  layer  = lM.f2k (layer);
  return result;
}

bool Via::convert ( Element* e ) {
  const int  size = sizeof (Via) / sizeof (int);
  int        i, n;
  static int k [size];
  bool result = Basic::convert (e);
  // debug ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  // debug ("%s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  for (i=0; i<size; i++) {
    if (e->getInteger(k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  pos.x = dM.f2k (k [n++]); pos.y = -dM.f2k (k [n++]);
  type  = k [n++];
  return result;
}
bool Line::convert ( Element * e ) {
  const int  size = sizeof (Line) / sizeof (int);
  int        i, n, tmp;
  // statické pole, protože někde chybí údaje takže se kopírují z předchozího
  // možná tak, kde ty údaje jsou začíná nová cesta.
  static int k [size];
  bool result = Basic::convert (e);
  // debug ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  // debug ("%s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  for (i=0; i<size; i++) {
    if (e->getInteger(k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  begin.x = dM.f2k (k [n++]); begin.y = -dM.f2k (k [n++]);
  end.x   = dM.f2k (k [n++]); end.y   = -dM.f2k (k [n++]);
  tmp     = k [n++];
  layer   = k [n++];
  type    = wM.f2k (tmp, layer);
  layer   = lM.f2k (layer);
  return result;
}
bool Layout::convert ( Element * e ) {
  bool result = Basic::convert (e);
  base = find (base);
  if (!base) return false;
  // base->print();
  /// ... stejne - dalsi prvky (ARC,...) - alespon jediny musi byt OK.
  if (tracks.convert (base)) result = true;
  if (pads  .convert (base)) result = true;
  if (texts .convert (base)) result = true;
  // Tohle je hodne krkolomny pridavek - nektere desky obsahuji 2xLines v Layout
  Element * f = base;
  f = f->getFork();		// Layout
  if (!f) return result;
  f = f->getNext();		// za 1. Lines
  if (!f) return result;
  if (adds  .convert (f   )) result = true;
  return result;
}
void Line::copyTo ( Line* l ) {
  memcpy (l, this, sizeof (Line));
}
