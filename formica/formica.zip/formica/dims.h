#ifndef DIMS_H
#define DIMS_H

#include "basic.h"

static const int LayerMax = 24;

class Component;

struct LayerPair {
    int	layer;
    int	width;
};

class LineDim : public Basic {
  public:
    LineDim () : Basic ("Noname") {
      type = 0;	// vynulovat prvky
      for (int i=0; i<LayerMax; i++) {
	pair [i].layer = 0;
	pair [i].width = 0;
      }
      parent = NULL;
    };
    bool convert (Element * e);
    void print   (void);
  public:
    int		type;
    LayerPair   pair[LayerMax];
    Component * parent;	// potrebujeme vedet, kde je soucastka
};
/** **********************************************************/
struct PadDesc {
    int		shape;
    int		width,
		height;
};

class PadDim : public Basic {
  public:
    PadDim () : Basic ("Noname") {
      type = 0;	// vynulovat prvky
      for (int i=0; i<LayerMax; i++) {
	desc [i].shape  = 0;
	desc [i].width  = 0;
	desc [i].height = 0;
      }
      parent = NULL;
    };
    bool convert (Element * e);
    void print   (void);
  public:
    int		type;
    PadDesc     desc [LayerMax];
    int		drill,
		oposite;
  
    Component * parent;	// potrebujeme vedet, kde je soucastka
};
/** **********************************************************/

class Dimensions : public Basic {
  public:
    Dimensions (const char * name) : Basic (name),
      pads("Pads"), lines("Lines") {};
    bool convert (Element * e);
    void print   (void);
  public:
    List<PadDim>     pads;
    List<LineDim>    lines;
};


#endif // DIMS_H
