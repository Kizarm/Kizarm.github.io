#include <stdio.h>
#include <string.h>
#include "pcb.h"
#include "maps.h"

Board  *  MainBoard;
/** Kicad přistupuje k Vias úplně jinak.
 * Pokud nastavíme KicadVias ma nulu, budou chápány jako MODULE,
 * jiná hodnota se pokusí je udělat správně. Protože to není
 * dobře dokumentováno, může to dělat blbosti.
 */
const int KicadVias = 1;

void BoardInit (Element * e) {
  MainBoard = new Board ("MainBoard");
  if (MainBoard->convert (e))
      MainBoard->print   ( );
}
void BoardFini (void) {
  delete MainBoard;
}

/** **********************************************/
// lezi v krouzku o polomeru 3 mil
static inline bool iabs (double dx, double dy) {
  if ((dx*dx + dy*dy) > 1000.0) return false;
  return true;
}


bool Point::isEqual (Point * p) {
  /*
  if (p->x != x) return false;
  if (p->y != y) return false;
  return true;
  */
  return iabs ((p->x - x), (p->y - y));
}
bool Point::isAtLine (Point * b, Point * e) {
  if (isEqual(b)) return true;
  if (isEqual(e)) {
    Point t; // swab points
    t.x  = b->x; t.y  = b->y;
    b->x = e->x; b->y = e->y;
    e->x = t.x;  e->y = t.y;
    return true;
  }
  return false;
}
/** **********************************************/
Board::Board ( const char* name) : Basic ( name ),
  setup("Setup"), dims("Dimensions"), layout("Layout"),
  comp("Components"), net("Netlist") {
}
bool Board::convert (Element * e) {
  // pocatecni base
  bool result = Basic::convert (e);
  printf ("Converting data from %p\n", base);
  if (setup .convert (base)) result = true;
  if (dims  .convert (base)) result = true;
  wM.remap();		// mame nacteno, premapovat rozmer linky
  if (layout.convert (base)) result = true;
  if (comp  .convert (base)) result = true;
  if (net   .convertn(base)) result = true;
  
  return result;
}
void Board::print ( void ) {
  assignNets();
  fprintf (output, "PCBNEW-BOARD Version 1 date 13/3/2008-23:41:14\n");
  setup .print ();
  //dims  .print();	// jen debug
  net   .printm();
  
  comp  .printm();
  layout.print ();
  
  fprintf (output, "$ZONE\n$EndZONE\n$EndBOARD\n");
}

void Board::assignNets ( void ) {
  if (!net.size) return;
  assignNetsToPads  ();			// přiřaď net z netlistu pro všechny piny všech součástek
  if (KicadVias) {
    setVias(); return;
  }
  assignPadsToTracks();			// z toho udělej počáteční přiřazení tracků
  assignNetsToTracks();			// projdi všechny tracky a přiřaď co se dá
  for (int i=0; i<10; i++) {			// ... iterujeme ...
    assignNetsToVias  ();		// přiřaď net k průchodkám
    assignNetsToTracks();		// projdi všechny tracky a přiřaď co se dá
    int j = assignViasToNets();		// zpětně přiřaď průchodky na tracky
    if (!j) break;			// už nic nezbývá, skonči.
  }
  unassigned();
}
void Board::setVias ( void ) {
  printf ("%s...\n", __FUNCTION__);
  int i, j, k=0, nl, nv, flag;
  Via  * pv;
  Line * pl, * pc;
  nl = layout.tracks.size;
  layout.sort.create (nl);
  nv = layout.pads  .size;
  for (i=0; i<nv; i++) {		// vezmi vsechny pruchody
    pv   = & layout.pads.data[i];
    flag = 0;
    for (j=0; j<nl; j++) {		// projdi vsechny tracky
      pl = & layout.tracks.data[j];
      if (pl->via) continue;
      if (pv->pos.isAtLine (& pl->begin, & pl->end)) {
	pc = & layout.sort.data[k++];
	pl->copyTo (pc);
	if (!flag) pc->via = pv->type + 1;
	pl->via = 1;
	flag = 1;
      }
    }
    pv->asg = flag;
  }
  for (j=0; j<nl; j++) {		// projdi vsechny tracky
    pl = & layout.tracks.data[j];
    if (pl->via) continue;
    pc = & layout.sort.data[k++];
    pl->copyTo(pc);
    if (k>nl) fprintf (stderr, "Overflow Copy Tracks %d\n", k);
  }
  printf ("Copy Tracks %d, Total %d\n", k, nl);
}


void Board::assignNetsToPads ( void ) {
  printf ("%s...\n", __FUNCTION__);
  char const * ref;
  int nc, np, nn, i, j, k;
  Pad * pp;
  nc = comp.size;
  for (i=0; i<nc; i++) {		// vsechny prvky
    np  = comp.data[i].pins.size;
    ref = comp.data[i].texts.data[0].id;
    for (j=0; j<np; j++) {		// jejich piny
      pp = & comp.data[i].pins.data[j];
      nn = net.size;
      for (k=1; k<nn; k++) {		// projdi vsechny nety
	net.data[k].assingNet (ref, pp);
      }
    }
  }
}
void Board::assignPadsToTracks ( void ) {
  int CountNets = 0;
  printf ("%s...\n", __FUNCTION__);
  int nt, nc, np, i, j, k;
  Pad  * pp;
  Line * pl;
  nt = layout.tracks.size;
  nc = comp.size;
  for (i=0; i<nt; i++) {		// pro vsechny cesty
    pl = & layout.tracks.data[i];
    for (j=0; j<nc; j++) {		// projdi vsechny prvky
      np = comp.data[j].pins.size;
      for (k=0; k<np; k++) {		// a jejich piny
	pp = & comp.data[j].pins.data[k];
	if (pp->onTrack (pl)) CountNets++;
	if (pp->no != (k+1)) {
	  fprintf (stderr, "\t---Pad Logic Error %d-%d\n", pp->no, k);
	}
      }
    }
  }
  printf ("Assigned %d Pads to Tracks (from %d Total)\n", CountNets, nt);

}

void Board::assignNetsToTracks ( void ) {
  int CountNets = 0;
  printf ("%s...\n", __FUNCTION__);
  int nt, i, j, k;
  Line * pl;
  nt = layout.tracks.size;
  Line * pk;
  for (k=0; k<50; k++) {		// maximalni pocet zlomu tracku
    CountNets = 0;
    for (i=0; i<nt; i++) {		// pro vsechny cesty
      pl = & layout.tracks.data[i];
      if (!pl->net) {
	for (j=0; j<nt; j++) {
	  pk = & layout.tracks.data[j];
	  if (pk->net) {
	    if (pl->onTrack(pk)) CountNets++;
	  }
	}
      }
    }
    if (!CountNets) break;		// uz jsme nic nenasli, konec
    printf ("Reassigned %d Tracks\n", CountNets);
  }
}
void Board::assignNetsToVias ( void ) {
  int CountNets = 0;
  printf ("%s...\n", __FUNCTION__);
  int nv, nt, i, j, k;
  Line * pl;
  Via  * pv;
  nv = layout.pads  .size;
  nt = layout.tracks.size;
  for (i=0; i<nv; i++) {
    pv = & layout.pads.data[i];
    for (j=0; j<nt; j++) {
      pl = & layout.tracks.data[j];
      k  = pl->onTrack (& pv->pos);
      if (k) {
	if (pv->net) {
	  if (pv->net != k) fprintf (stderr, "Reassigned Via Error: %d->%d\n", k, pv->net);
	  break;
	}
	pv->net = k;
	CountNets++;
      }
    }
  }
  printf ("Assigned %d Tracks to Vias (from total %d)\n", CountNets, nv);
}
int Board::assignViasToNets ( void ) {
  int CountNets = 0;
  printf ("%s...\n", __FUNCTION__);
  int nv, nt, i, j, k;
  Line * pl;
  Via  * pv;
  nv = layout.pads  .size;
  nt = layout.tracks.size;
  for (i=0; i<nv; i++) {
    pv = & layout.pads.data[i];
    for (j=0; j<nt; j++) {
      pl = & layout.tracks.data[j];
      k  = pv->onTrack (pl); 
      if (k) {
	if (pl->net) {
	  if (pl->net != k) fprintf (stderr, "Reassigned Net Error: %d->%d\n", k, pl->net);
	  break;
	}
	pl->net = k;
	CountNets++;
      }
    }
  }
  printf ("Assigned %d Vias to Tracks (from total %d)\n", CountNets, nt);
  return CountNets;
}

void Board::unassigned ( void ) {
  int count;
  int i, n;
  n = layout.pads.size;
  for (i=0, count=0; i<n; i++) {
    if (layout.pads.data[i].net) count++;
  }
  printf ("Assigned Vias   %4d from %4d\n", count, n);
  n = layout.tracks.size;
  for (i=0, count=0; i<n; i++) {
    if (layout.tracks.data[i].net) count++;
  }
  printf ("Assigned Tracks %4d from %4d\n", count, n);
}
