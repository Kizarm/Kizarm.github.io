#include "components.h"
#include "maps.h"
#include <string.h>

//#define DEBUG 1
#ifdef DEBUG
  #define dbg {printf("%s,\tthis=%p\n",__FUNCTION__,this);}
  #define debug printf
#else
  #define dbg
  #define debug(...)
#endif

bool XPad::convert ( Element* e ) {
  const int  size = sizeof (XPad) / sizeof (int);
  int        i, n;
  static int k [size];
  bool result = Basic::convert (e);
  // debug ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  // debug ("%s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  for (i=0; i<size; i++) {
    if (e->getInteger(k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  pos.x = dM.f2k (k [n++]); pos.y = -dM.f2k (k [n++]);
  type  = k [n++];
  return result;
}

bool Pad::convert ( Element* e ) {
  const int  size = sizeof (Pad) / sizeof (int);
  int        i, n;
  // statické pole, protože někde chybí údaje takže se kopírují z předchozího
  // možná tak, kde ty údaje jsou začíná nová cesta.
  static int k [size];
  bool result = Basic::convert (e);
  // printf ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  debug ("Pad %s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  for (i=0; i<size; i++) {
    if (e->getInteger(k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  no = k [n++];
  pos.x   = dM.f2k (k [n++]); pos.y = -dM.f2k (k [n++]);
  abs.x   = pos.x;            abs.y = pos.y;
  type    = k [n++];
  return result;
}
bool Arc::convert ( Element* e ) {
  const int  size = sizeof (Arc) / sizeof (int);
  int        i, n;
  // statické pole, protože někde chybí údaje takže se kopírují z předchozího
  // možná tak, kde ty údaje jsou začíná nová cesta.
  static int k [size];
  bool result = Basic::convert (e);
  // printf ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  debug ("Arc %s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  for (i=0; i<size; i++) {
    if (e->getInteger(k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  int tmp;
  kvadrant = k [n++];
  pos.x   = dM.f2k (k [n++]); pos.y = -dM.f2k (k [n++]);
  radius  = dM.f2k (k [n++]);
  tmp     =  k [n++];
  layer   =  k [n++];
  type    = wM.f2k (tmp, layer);
  layer   = lM.f2k (layer);
  return result;
}
bool CompText::converts ( Element* e, int no ) {
  //static int no=1;
  bool result = Basic::convert (e);
  int        n,i;
  const int  size = 6;
  static int k[size];
  // debug ("Base=%p\n", base);

  if (!nAndDown (n)) return false;
  debug ("Texts %s: Nalezeno %d cest\n", __FUNCTION__, n);
  e = base;
  id = e->getString();
  if (id) result = true;
  e = e->getNext(); if (!e) return false;
  for (i=0; i<size; i++) {
    if (e->getInteger (k[i])) result = true;
    e = e->getNext();
    if (!e) break;
  }
  n = 0;
  int tmp;
  pos.x = dM.f2k (k[n++]); pos.y = -dM.f2k (k[n++]);
  // tyto parametry budou asi taky chtit premapovat 
  height = dM.f2k (k[n++]);
  orient = k[n++];
  tmp    = k[n++];
  layer  = k[n++];
  type   = wM.f2k (tmp, layer);
  if (!no &&  (layer < 5)) {	// 1.text (reference) musí být na stejné straně jako součástka
    debug ("Component text %s bottom %d\n", id, layer);
    if (!parent) {
      fprintf(stderr, "Parent not set\n");
    }
    else parent->orientation |= (1<<4);
  }
  layer  = lM.f2k (layer);
//printf ("id=%s, x=%d, y=%d, h=%d, result=%d\n", id, pos.x, pos.y, height, result);
  return result;
}

bool Component::convert ( Element* e ) {
  int       i, n, k;
  bool result = Basic::convert (e);
  // printf ("Base=%p\n", base);
  Element * f;
  Element * g;

  if (!nAndDown (n)) return false;
  debug ("Component %s: Nalezeno %d prvku\n", __FUNCTION__, n);
  e = base;
  if (e->getInteger(orientation)) result = true;
  e = e->getNext(); if (!e) return false;
  if (e->getInteger(flags)) result = true;
  e = e->getNext(); if (!e) return false;
  debug ("Cisla = %d, %d\n", orientation, flags);
  // Texty nemaji label, konverze se tedy dela jinak -
  g = e; k = 0;
  for (;;) {
    f = g->getFork(); 
    if (f) {
      if (f->getString()) k++;
    } else break;
    g = g->getNext();
    if (!g) break;
  }
  debug ("Component %s: Nalezeno %d textu\n", __FUNCTION__, k);
  texts.create (k);
  ///... zde pouzit texty v e
  for (i=0; i<k; i++) {
    texts.data[i].parent = this;
    if (texts.data[i].converts(e, i)) result = true;
    texts.data[i].no = i;
    e = e->getNext();
  }
  
  pins .parent = this;
  if (pins .convert(e)) {
    result = true;
    e = e->getNext(); if (!e) return false;
  }
  lines.parent = this;
  if (lines.convert(e)) {
    result = true;
    e = e->getNext(); if (!e) return result;
  }
  arcs .parent = this;
  if (arcs.convert(e))  result = true;
  
  
  xpads.parent = this;
  //e = e->getNext(); if (!e) return result;
  if (xpads.convert(e))  result = true;
  xlines.parent = this;
  //e = e->getNext(); if (!e) return result;
  if (xlines.convert(e)) result = true;
  
  return result;
}
/** ************************************************/

void Component::remap ( void ) {
  int i,n;
  Pad * pd = &pins.data[0];	// pozice soucastky = pozice 1. pinu
  if (pd) {
    pos.x = pd->pos.x;
    pos.y = pd->pos.y;
  } else return;
  n = pins.size;
  for (i=0; i<n; i++) pins .data[i].translate (pos);
  n = lines.size;
  for (i=0; i<n; i++) lines.data[i].translate (pos);
  n = arcs.size;
  for (i=0; i<n; i++) arcs .data[i].translate (pos);
  n = texts.size;
  for (i=0; i<n; i++) texts.data[i].translate (pos);
  
  n = xpads.size;
  for (i=0; i<n; i++) xpads.data[i].translate (pos);
  n = xlines.size;
  for (i=0; i<n; i++) xlines.data[i].translate (pos);
}
void XPad::translate ( Point& p ) {
  pos.x -= p.x;
  pos.y -= p.y;
}

void Pad::translate ( Point& p ) {
  pos.x -= p.x;
  pos.y -= p.y;
}
void CompText::translate ( Point& p ) {
  pos.x -= p.x;
  pos.y -= p.y;
}
void Arc::translate ( Point& p ) {
  pos.x -= p.x;
  pos.y -= p.y;
}

/** ************************************************/
void XPad::printm ( void ) {
  int ori = 0;
  const char * xid = "XX";
  if (parent) ori = parent->orientation;
  
  KicadPad pad (type, ori);
  
  const char * name = "PAD";
  fprintf (output, "$%s\n", name);
  // Sh “Name” Shape Width Height Xdelta Ydelta Orientation
  fprintf (output, "Sh \"%s\" %c %d %d 0 0 %d\n",
	   xid, pad.Shape, pad.Width, pad.Height, pad.Orientation);
  // Dr Size X Y
  fprintf (output, "Dr %d 0 0\n", pad.Drill);	// vrtani
  // At Type N Mask - pevna maska by mela byt odvozena z mapy.
  fprintf (output, "At %s N %08X\n", pad.SmdStd, pad.Layers);
  /*
  fprintf (output, "At \n");	// na vrstvach
  */
  fprintf (output, "Po %d %d\n", pos.x, pos.y);
  fprintf (output, "$End%s\n", name);
}

void Pad::printm ( void ) {
  int ori = 0;
  if (parent) ori = parent->orientation;
  
  KicadPad pad (type, ori);
  
  const char * name = "PAD";
  fprintf (output, "$%s\n", name);
  // Sh “Name” Shape Width Height Xdelta Ydelta Orientation
  fprintf (output, "Sh \"%d\" %c %d %d 0 0 %d\n",
	   no, pad.Shape, pad.Width, pad.Height, pad.Orientation);
  // Dr Size X Y
  fprintf (output, "Dr %d 0 0\n", pad.Drill);	// vrtani
  // At Type N Mask - pevna maska by mela byt odvozena z mapy.
  fprintf (output, "At %s N %08X\n", pad.SmdStd, pad.Layers);
  if (net) fprintf (output, "Ne %d \"N%05d\"\n", net, net);	// net
  else     fprintf (output, "Ne %d \"\"\n", net);
  /*
  fprintf (output, "At \n");	// na vrstvach
  */
  fprintf (output, "Po %d %d\n", pos.x, pos.y);
  fprintf (output, "$End%s\n", name);
}
int Pad::onTrack ( Line* l ) {
  // printf ("Pad <%d,%d> net=%d %p\n", abs.x, abs.y, net, parent);
  if (!l) {
    fprintf(stderr, "Error onTrack layer=NULL\n");
    return 0;
  }
  if (!(net))              return 0;	// neni prirazena net
  
  int ori = 0;
  if (parent) ori = parent->orientation;
  
  KicadPad pad (type, ori);
  
  //Point * lp;
  int onl = (1<<l->layer);
  
  if (!(pad.Layers & onl)) return 0;	// pad neni na vrstve tracku
  if (!abs.isAtLine (& l->begin, & l->end)) return 0;
  if (l->net && (net != l->net)) fprintf (stderr, "\tReassigned NET %d->%d\n", net, l->net);
  l->net = net;
  return net;  
}

void Arc::printm ( void ) {
  // DA X Y Xp Yp Angle Pen Layer
  Point ba;
  ba.x = pos.x; ba.y = pos.y;
  int   kv = kvadrant & 3;
  int   an = 900;
  // To je divne (obracene), ale kresli (snad) dobre.
  switch (kv) {
    case 0: ba.y -= radius; break;
    case 1: ba.x -= radius; break;
    case 2: ba.y += radius; break;
    case 3: ba.x += radius; break;
    default: break;
  }
  fprintf (output, "DA %d %d %d %d %d %d %d\n", pos.x, pos.y, ba.x, ba.y, an, type, layer);
}
void CompText::printm ( void ) {
  //T0 X Y H W Angle Pen N Visible Layer N "Text"
  char visible = 'V';	// or 'H' for hidden
  int  rot = 0;		// v desetinach stupne 0 nebo 900
  if (orient & 1) rot = 900;
  if (strcmp (id, "\"\""))
    fprintf (output, "T%d %d %d %d %d %d %d N %c %d N %s\n",
            no, pos.x, pos.y, 6 * height, 4 * height, rot, type, visible, layer, id);
  // Není uděláno zrcadlení a otočení textu vzhůru nohama. Není to jak zapsat.
  // if ((orient & 2)) printf ("Component %s mirror\n", id);
}

void Component::printm ( void ) {
  remap ();
  const char * name = "MODULE";
  char * cid = stripClober (texts.data[2].id); // pouzdro
  int lyr =  15;		// zrejme 0 nebo 15 - seshora nebo zespoda
  if (orientation & (1<<4)) lyr = 0;
  if (!cid) return;
  fprintf (output, "$%s  %s\n", name, cid);
  fprintf (output, "Po %d %d %d %d 0 ~~\n", pos.x, pos.y, 0, lyr);
  /* jeste prozkoumat
  fprintf (output, "Li \n");
  fprintf (output, "Sc \n");
  fprintf (output, "AR \n");
  fprintf (output, "Op \n");
  */
  pins .printm ();
  xpads.printm ();
  texts.data[0].printm();	// texty Reference
  texts.data[1].printm();	// texty Value jsou ve formice vestimou nulove vysky
  lines.printm ();		// grafika soucastky (cary)
  xlines.printm();
  arcs .printm ();
  
  fprintf (output, "$End%s\n", name);
  free (cid);
}
