#include <stdio.h>
#include <stdlib.h>
#include "formica.h"
#include "formica.yy.h"

/**
 * @mainpage Formica to Kicad Board.
 * 
 * @section mot Motivace.
 * 
 * Pokud chcete přejít z programu Formica na volný Kicad, většinou odradí množství knihoven,
 * které jste předtím vytvořili a které by bylo nutné překreslit. Tento problém by měl řešit
 * tento převodní prográmek.
 * 
 * Není to úplná konverze formátů, to by bylo dost složité (i když ne nemožné), pracuje to
 * jen nad deskou (*.BRD), pouzdra by to mělo zpracovat korektně. Je to ale zcela bez záruky,
 * mapování vrstev asi není úplně ideální - oba návrhové programy se koncepcí vrstev
 * poněkud liší, takže skoro vše je mapováno na SilkScreen. Dá se to opravit v souboru
 * maps.cpp, tabulka scLayerMap. Různé verze Formica používají i jiný počet vrstev.
 * Dále mapa pinů je poněkud nejasná, takže mnoho vlastností je děláno pouze odhadem
 * a následným zkoušením. Výstupní formát je starý, ale Kicad si s tím
 * poradí. Nový formát je složitější a nenašel jsem dobrý popis. Z desky lze generovat
 * i podklady pro výrobu, lze měnit i detaily, větší změny moc nejdou, nelze synchronizovat
 * schéma a desku (netlist). A samozřejmě lze exportovat knihovnu použitých modulů.
 * 
 * @section todo Není doděláno.
 * 
 * - Těžko říct, jestli funguje správně načtení netlistu a jeho překlad. Některý design projde
 * 	bez problémů i DRC. TRACK nemá příznak NET, Kicad si to dopočítá sám.
 * 	Formica používá pro vyplnění zón TRACKy, takže pokud je v designu zóna, trvá výpočet
 * 	dlouho a nemusí být úspěšný. Používá se iterace a jejich počet je omezen, takže třeba
 * 	klikatá čára (např. meandr) může dělat problém. Počet iterací lze zvětšit - Board::assignNetsToTracks.
 * 	Dá se vygenerovat GERBER (zřejmě korektní pro 1-2 vrstvy spojů včetně nepájivé
 * 	masky, texty součástek na straně spojů jsou zrcadlově obráceny).
 * - Vůbec jsem se nazabýval schematem. I když formát ascii by měl jít načíst do základního
 * 	seznamu objektů (class Element).
 * 
 * @section ends Závěr.
 * 
 * Program je napsán s ohledem na rychlé vytvoření něčeho funkčního. Takže dost prasecky.
 * Použité třídy jsou používány spíš jako struktury, takže data jsou veřejná. Chybí kontroly
 * které by korektně být měly. Dá se říct, že struktury dat nejsou dobře navrženy, kód se
 * mnohdy dost opakuje, ale je to tím, že předem nebylo jasné, co se s daty bude dít dál.
 * Takže pro pokračování by bylo dobře to překopat na základě znalosti věci, jinak to dost
 * postrádá smysl.
 * Parser textu používá flex a bison. Naštěstí jsem našel popis gramatiky PCB později,
 * takže jsem se nesnažil ho striktně přepsat. Možná by to stálo za úvahu. I když odlišnost přístupu
 * obou programů je dost velká a bylo by i s tím dost problémů.
 * 
 * Co není na první pohled zřejmé.
 * Formica má opačně orientovanou y-ovou osu. Součástky (souřadnice) jsou pojaty absolutně, v Kicadu
 * relativně vzhledem ke knihovně.
 * 
 * @section dnl Ke stažení.
 * 
 * Zdrojové texty v C/C++ pro prostředí Linuxu jsou ke stažení <a href="../formica.zip">zde</a>.
 * Kód je uvolněn pod <a href="http://www.gnugpl.cz/">GPL3</a> licencí, podklady pro program jsou z
 * veřejných zdrojů (web) a i když jsem si vědom, že tato aktivita může poškozovat původní autory
 * programu formica není zde použito žádné "reverzní inženýrství" nebo jiná metoda za hranicí etiky.
 * */

extern FILE* yyin;
extern void  yyparse ( void );
//extern void  printext (void);

int main ( int argc, char** argv ) {
  --argc;  /* skip over program name */
  if (!argc) {
    printf ("Program pro konverzi dat Formica PCB do Kicad BRD\n"
    "\tPouziti:\n"
    "\t%s file.pcb file.brd\n",
    argv[0]);
    return 0;
  }
  ++argv;
  if ( argc > 0 )
      yyin = fopen ( argv[0], "r" );
  else
      yyin = stdin;
  if ( !yyin ) return -1;

  char * name = NULL;
  if ( argc > 1 )
      name = argv [1];
  FmInit ( name );
  
  yyparse ();
  
  FmFini ();

  //printext();
  return 0;
}



