#ifndef LAYOUT_H
#define LAYOUT_H

#include "basic.h"

class Text : public Basic {
  public:
    Text (void) : Basic ("Noname") {
      no=0; parent = NULL; };
    void printm    (void);
    bool convert   (Element * e);
  public:
    int                 no;	// poradi textu
    char	 * 	id;
    Point  		pos;
    int    		height,	// vyska znaku (*6?)
			orient,	// orientace bity 0.1.=rotace(90),2.zrcadlo x
			type,	// typ (tloustka cary ?)
			layer;	// vrstva
    Component *  parent;	// potrebujeme vedet, kde je soucastka
};

class Line : public Basic {
  public:
    Line () : Basic ("Line") { parent = NULL; net=0; via=0; };
    bool convert (Element * e);
    void printl  (void);
    void printm  (void);
    void translate (Point & p);
    int  onTrack (Line  * l);
    int  onTrack (Point * p);
    void copyTo  (Line  * l);
  public:
    Point begin, end;
    int   type,  layer;
    Component *  parent;	// potrebujeme vedet, kde je soucastka
    int          net;
    int          via;
};
/**
 * Průchody prozatím uděláme jako MODUL s jedním pinem.
 * Tím jednoduše umožníme kreslit kompletní TRACK
 * bez netlistu. Formát VIA Kicadu stejně není popsán.
 * */
class Via : public Basic {
  public:
    Via () : Basic ("Pad") { parent = NULL; net=0; asg=0; };
    bool convert (Element * e);
    void printm  (void);
    int  onTrack (Line * l);
  public:
    Point pos;
    int   type;
    Component * parent;	// potrebujeme vedet, kde je soucastka
    int         net;
    int         asg;
};

class Layout : public Basic {
  public:
    Layout (const char * name) : Basic (name),
      tracks ("Lines"), pads("Pads"), texts("Text"),
      adds ("Lines"), sort("Sorted") {};
    void print   (void);
    bool convert (Element * e);
  public:
    List<Line> tracks;
    List<Via>  pads;
    List<Text> texts;
    List<Line> adds;	// mozne pridane linky v nekterych souborech
    
    List<Line> sort;
};


#endif // LAYOUT_H
