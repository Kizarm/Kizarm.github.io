#ifndef NETLIST_H
#define NETLIST_H
#include "basic.h"
#include "components.h"

struct NetPair {
  char * comp;
  int    pin;
};

class Netlist : public Basic {
  public:
    Netlist ();
   ~Netlist ();
    bool convertn  (Element * e, int n);
    void printm    (void);
    int  assingNet (const char * ref, Pad * pad);
  public:
    int         order;
    int         maxp;
    NetPair   * pair;
    Component * parent;
};


#endif // NETLIST_H
