#ifndef COMPONENTS_H
#define COMPONENTS_H

#include "basic.h"
#include "layout.h"

class Component;

class XPad : public Basic {
  public:
    XPad ( void ) : Basic ("Noname") {
      parent = NULL;
    };
    void printm    (void);
    bool convert   (Element * e);
    void translate (Point & p);
  public:
    //int   		no;	// necislovany
    Point 		pos;
    int   		type;
    Component    *      parent;	// potrebujeme vedet, kde je soucastka
};

class Pad : public Basic {
  public:
    Pad ( void ) : Basic ("Noname") {
      parent = NULL; net = 0;
    };
    void printm    (void);
    bool convert   (Element * e);
    void translate (Point & p);
    int  onTrack   (Line  * l);
  public:
    int   		no;
    Point 		pos;
    int   		type;
    Component    *      parent;	// potrebujeme vedet, kde je soucastka
    int                 net;
    Point		abs;	// absolutni souradnice pro hledani net
};
class CompText : public Basic {
  public:
    CompText (void) : Basic ("Noname") {
      parent=NULL; no=0; };
    void printm    (void);
    bool converts  (Element * e, int n);
    void translate (Point & p);
  public:
    int                 no;	// poradi textu
    char	 * 	id;
    Point  		pos;
    int    		height,	// vyska znaku (*6?)
			orient,	// orientace bity 0.1.=rotace(90),2.zrcadlo x
			type,	// typ (tloustka cary ?)
			layer;	// vrstva
    Component    *      parent;	// potrebujeme vedet, kde je soucastka
};

class Arc : public Basic {
  public:
    Arc ( void ) : Basic ("Noname") {
      parent = NULL;
    };
    void printm    (void);
    bool convert   (Element * e);
    void translate (Point & p);
  public:
    int   		kvadrant;
    Point 		pos;
    int   		radius;
    int   		type;
    int   		layer;

    Component    *      parent;	// potrebujeme vedet, kde je soucastka
};

class Component : public Basic {
  public:
    Component (void) : Basic ("Noname"),
      texts(NULL), pins ("Pins"), lines ("Lines"), arcs ("Arcs"), xpads("Pads"), xlines("Lines") {
	pos.x = 0; pos.y = 0;
      };
    void printm  (void);
    bool convert (Element * e);
    void remap   (void);
  public:
    // bity 0,1 udavaji rotaci, bit 2 zrcadleni, pridame bit 3 - pokud bude na spodni vrstve, nastavime na 1
    // coz se urci podle pozice textu
    int 		orientation,	// orientace vuci knihovne, ale v kicadu je pozice relativni
			flags;		// vlajky ignorujeme, tyka se knihovny
    List<CompText>	texts;
    List<Pad>  		pins;
    List<Line>		lines;
    List<Arc>		arcs;
    // v nektrych designech jsou jeste extra elementy
    List<XPad>          xpads;
    List<Line>		xlines;
    // pozice ve formice neni, v kicadu byt musi, vsechny souradnice pak jsou k ni relativni
    Point		pos;		// bud podle pinu 1, nebo 0
    Component    *      parent;		// potrebujeme vedet, kde je soucastka
};
#endif // COMPONENTS_H
