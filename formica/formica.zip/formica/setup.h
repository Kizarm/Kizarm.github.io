#ifndef SETUP_H
#define SETUP_H
#include "basic.h"

class Setup : public Basic {
  public:
    Setup (const char * name);
    void print     (void);
    bool convert   (Element * e);
    
    int  getField  (Element * e, int * p, int len);
  public:
    int  maj,  min;
    int  layA, layB;
    int  top,  bottom;
};

#endif // SETUP_H
