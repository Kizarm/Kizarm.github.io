#include "setup.h"
#include "maps.h"

#define debug printf

Setup::Setup ( const char* name ) : Basic ( name ) {
  maj = 0; min = 0;
  layA   = 5; layB = 10;
  bottom = 5; top  = 10;
}


bool Setup::convert ( Element* e ) {
  const int max = 24;
  int k,n;
  int parms[max];
  bool result = Basic::convert ( e );
  if (!nAndDown (n)) return false;
  //debug ("Setup %s: Nalezeno %d prvku\n", __FUNCTION__, n);
  
  Element * f = base;  if (!f) return false;
  f = f->getFork();    if (!f) return false;
  k = getField (f, parms, max);
  if (k>=1) {
    maj = parms [0];
    min = parms [1];
  }
  printf ("Formica version %d.%d\n", maj, min);
  
  f = base->getNext(); if (!f) return false;
  f = f->getFork();    if (!f) return false;
  k = getField (f, parms, max);
  if (k>=12) {
    bottom = parms [ 9];
    top    = parms [10];
    layA   = parms [11];
    layB   = parms [12];
  }
  printf ("Working Layers A = %2d, B = %2d\n", layA, layB);
  printf ("Cooper  Layers T = %2d, B = %2d\n", top, bottom);
  
  result = true;
  lM.setLayers (top, bottom);
  
  return result;
}
int Setup::getField ( Element* e, int* p, int len ) {
  int i,j;
  for (i=0, j=0; i<len; i++) {
    if (!e->getInteger (p[i])) break;
    else j++;
    e = e->getNext(); if (!e)  break;
  }
  return j;
}

void Setup::print ( void ) {
  if (min > 30) fprintf (stderr, "Probably Layer Mapping on version %d.%d\n", maj, min);
}
