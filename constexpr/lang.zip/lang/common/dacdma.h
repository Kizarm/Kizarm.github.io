#ifndef DACDMA_H
#define DACDMA_H

#include "oneway.h"
#include "gpio.h"

class DacDma : public OneWay {
  public:
    explicit DacDma ();
    void irq (void);
  private:
    Chunk * const pbuf0;
    Chunk * const pbuf1;
    Chunk buf [2];
};

#endif // DACDMA_H
