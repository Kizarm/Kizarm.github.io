#ifndef _M_MATH_H_
#define _M_MATH_H_

static constexpr double X_PI = 3.14159265358979323846;
static constexpr double D_PI = 2.0 * X_PI;
/* cmath nejde použít, tak si to mírně zjednodušíme, ale musí to fungovat */
static constexpr double dabs (const double a) { return a < 0.0 ? -a : +a; }
static constexpr int i_round (const double a) { return a < 0.0 ? int (a - 0.5) : int (a + 0.5); }
/* tahle divná funkce počítá sinus, pokud even=true i kosinus, pokud even=false */
static constexpr double sincos (const double x, const bool even) {
  double result (0.0), element(1.0), divider(0.0);
  if (even) { element *= x; divider += 1.0; }
  constexpr double eps = 1.0e-9;      // maximální chyba výpočtu
  const double aa = - (x * x);
  for (;;) {
    result  += element;
    if (dabs  (element) < eps) break;
    divider += 1.0;
    double fact = divider;
    divider += 1.0;
    fact    *= divider;
    element *= aa / fact;
  }
  return result;
}

#endif // _M_MATH_H_
