#ifndef _INIT_H_
#define _INIT_H_
/** @class TABLE
 *  @brief Konstantní look-up tabulka
 * 
 * Pokud se použije pro překlad clang, pak je možné předhodit
 * konstruktoru tt. třídy constexpr funkci, která inicializuje
 * všechna data a lze tak vytvořit konstantní pole, umístěné
 * v sekci .rodata. Není tak nutné používat k vytvoření tabulky
 * externí nástroj.
 * */
template<class T, const int N> class TABLE {
  T data [N];
  public:
    /** Konstruktor.
     *  @param f Ukazatel na constexpr funkci, která pak vytvoří tabulku,
     *           funkce nemusí být příliš efektivní, spouští se jen při překladu.
     *           Bohužel většinou nelze použít funkce z cmath, nejsou constexpr.
     * */
    explicit constexpr TABLE (T (* const f) (const int)) noexcept {
      for (int n=0; n<N; n++) data [n] = f (n);
    }
    /** operator[] vrátí konstantní odkaz na prvek pole, protože se předpokládá,
     *  že tato třída bude jako taková též konstantní
     */
    const T & operator[] (const int index) const {
      return data [index];
    }
    /** @class iterator
     *  @brief range-based for () */
    class iterator {
      const T * ptr;
      public:
        iterator(const T * _ptr) : ptr (_ptr) {}
        iterator  operator++ ()                             { ++ptr;   return * this;    }
        bool      operator!= (const iterator & other) const { return   ptr != other.ptr; }
        const T & operator*  ()                       const { return * ptr;              }
    };
    iterator begin () const { return iterator (data    ); }
    iterator end   () const { return iterator (data + N); }
  protected:
};
#endif // _INIT_H_
