#ifndef ONEWAY_H
#define ONEWAY_H
#include <stdint.h>
#include <stdlib.h>

static constexpr unsigned MaxChunkSize = 256u;

struct Chunk {
  uint16_t data [MaxChunkSize];
}__attribute__((aligned(4)));

class OneWay {
  public:
    explicit constexpr OneWay() : pUp (nullptr) {}
    virtual uint32_t   Send  (Chunk * const data) {
      if (pUp) return pUp->Send (data);
      return 0;
    };
    void attach (OneWay & bl) {
      bl.setUp (this);
    };
  protected:
    void setUp   (OneWay * p) { pUp = p; };
  private:
    OneWay * pUp;
};

#endif // ONEWAY_H
