#include "stm32f05x.h"
#include "common.h"
#include "core_cm0.h"
#include "dacdma.h"

static GpioClass led (GpioPortA, 0);

static DacDma * Instance = NULL;

static inline void EnableClock (void) {
  RCC.AHBENR.modify ([](RCC_AHBENR_s & r) -> auto {
    r.B.DMA1EN = 1u;
    r.B.IOPAEN = 1u;
    return r.R;
  });
  RCC.APB1ENR.modify([](RCC_APB1ENR_s & r) -> auto {
    r.B.TIM2EN = 1u;
    r.B.DACEN  = 1u;
    return r.R;
  });
}
static inline void Timer2Init (const uint32_t us) {
  TIM2.PSC.R = 47;  // 1 MHz
  TIM2.ARR.R = us - 1u;
  // Preload, enable
  TIM2.CR1.B.ARPE = 1u;
  // TRGO update for DAC
  TIM2.CR2.B.MMS  = 2u;
  TIM2.CR1.B.CEN  = 1u;
}
// DAC mapped DMA1 channel 3
static inline void Dma1Init (Chunk * const ptr) {
  // Configure the peripheral data register address
  DMA1.CPAR3.R  = reinterpret_cast<uint32_t> (&DAC.DHR12R1);
  // Configure the memory address
  DMA1.CMAR3.R  = reinterpret_cast<uint32_t> (ptr);
  // Configure the number of DMA tranfer to be performs on DMA channel
  DMA1.CNDTR3.R = 2 * MaxChunkSize;
  // configure increment, size, interrupts and circular mode
  DMA1.CCR3.modify([](DMA_CCR3_s & r) -> auto {
    r.B.MINC  = 1u;
    r.B.PSIZE = 1u;
    r.B.MSIZE = 1u;
    r.B.HTIE  = 1u;
    r.B.TCIE  = 1u;
    r.B.CIRC  = 1u;
    r.B.DIR   = 1u;
    return r.R;
  });
  // Enable DMA Stream
  DMA1.CCR3.B.EN  = 1u;
  // Enable DMA transfer on DAC and circular mode
  DAC.CR.B.DMAEN1 = 1u;
}
static inline void Dac_Init (void) {
  DAC.CR.modify([](DAC_CR_s & r) -> auto {
    r.B.TSEL1  = 4u;    // timer 2
    r.B.TEN1   = 1u;
    r.B.EN1    = 1u;
    return r.R;
  });
}
DacDma::DacDma() : OneWay(), pbuf0(buf + 0), pbuf1(buf + 1) {
  if (Instance) return;
  Instance = this;
  EnableClock();
  Timer2Init (125);
  NVIC_EnableIRQ (DMA1_Channel2_3_IRQn);
  Dma1Init   (buf);
  Dac_Init   ();
}

inline void DacDma::irq (void) {
  Chunk * cur = nullptr;
  DMA_ISR_s status (DMA1.ISR);
  if (status.B.HTIF3) cur = pbuf0;
  if (status.B.TCIF3) cur = pbuf1;
  // znuluj příznaky
  DMA1.IFCR.R = status.R;
  if (!cur) return;
  // zpracuj data, pokud je potřeba
  Send (cur);
  ~led;

}
extern "C" void DMA1_Channel2_3_IRQHandler (void) {
  if (Instance) Instance->irq();
}