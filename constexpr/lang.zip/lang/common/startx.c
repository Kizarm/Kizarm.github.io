#include <stdint.h>

#if defined (__cplusplus)
extern "C" {
#endif

/// V linker skriptu
extern void (*__init_array_start)();
extern void (*__init_array_end)  ();
/// Inicializace statických konstruktorů - použít explicitně po celkové inicializaci systému
static inline void static_init() {
  void (**p)();
  // Tohle je sice konstrukce značně nepřehledná (nalezená na webu), leč funguje.
  for (p = &__init_array_start; p < &__init_array_end; p++) (*p)();
}


#define WEAK     __attribute__ ((weak))
#define ALIAS(f) __attribute__ ((weak, alias (#f)))

extern unsigned int _estack;
/* start address for the initialization values of the .data section.
defined in linker script */
extern unsigned int _sidata;
/* start address for the .data section. defined in linker script */
extern unsigned int _sdata;
/* end address for the .data section. defined in linker script */
extern unsigned int _edata;
/* start address for the .bss section. defined in linker script */
extern unsigned int _sbss;
/* end address for the .bss section. defined in linker script */
extern unsigned int _ebss;

#define BootRAM ((void (*)(void))0xF108F85F)

WEAK void Reset_Handler     (void);
WEAK void DefaultHandler    (void);

void NMI_Handler                    (void) ALIAS(Default_Handler);
void HardFault_Handler              (void) ALIAS(Default_Handler);
void SVC_Handler                    (void) ALIAS(Default_Handler);
void PendSV_Handler                 (void) ALIAS(Default_Handler);
void SysTick_Handler                (void) ALIAS(Default_Handler);


extern void setup ();
extern void loop ();
extern void SystemInit ();

#if defined (__cplusplus)
} // extern "C"
#endif

__attribute__ ((section(".isr_vector")))
void (* const Vectors[])(void) = {
  (void (*)(void))&_estack,
  Reset_Handler,                    // The reset handler
  NMI_Handler,                      // The NMI handler
  HardFault_Handler,                // The hard fault handler
  0,                                // Reserved
  0,                                // Reserved
  0,                                // Reserved
  0,                                // Reserved
  0,                                // Reserved
  0,                                // Reserved
  0,                                // Reserved
  SVC_Handler,                      // SVCall handler
  0,                                // Reserved
  0,                                // Reserved
  PendSV_Handler,                   // The PendSV handler
  SysTick_Handler,                  // The SysTick handler
};

void Reset_Handler(void) {
  unsigned int * src, * dst, * end;

  /* Zero fill the bss section */
  dst = &_sbss;
  end = &_ebss;
  while (dst < end)  * dst++ = 0U;

  /* Copy data section from flash to RAM */
  src = &_sidata;
  dst = &_sdata;
  end = &_edata;
  while (dst < end) * dst++ = * src++;

  static_init();                    // Zde zavolám globální konstruktory

  setup ();

  for (;;) {
    loop ();
  }
}


void Default_Handler (void) {
  asm volatile ("bkpt 1");
}

