#include "dacdma.h"
#include "tone.h"
/** @file
 * Ukázka použitelného generátoru harmonického napětí
 * s dobře definovaným kmitočtem. Procesor používá krystal 8MHz,
 * hodiny se tedy už korektně nastavují (PLL 48MHz), DAC
 * používá DMA a časovač, vzorkovací frekvence je pevně 8kHz.
 * Pracuje to zhruba jako obvody DDS, krok ladění je 3.75 μHz,
 * tedy hodně jemně od nuly do 4kHz (Shannon-Kotelnikův teorém),
 * vyšší frekvence jsou samozřejmě hodně zubaté.
 * Celý program běží v přerušení, v main() se tedy jen čeká.
 * 
 * NOTE
 * Obě funkční třídy jsou zde instancovány v main(), mají tedy data
 * na zásobníku. Zde je to poměrně zbytečné a kontraproduktivní, je
 * to jen ukázka, že to opravdu funguje. Přepočet frekvence na krok
 * freq_to_step() je pak dobré udělat jako samostatnou statickou
 * constexpr proměnnou.
 * Bylo by přehlednější přenést tt. přepočet do konstruktoru třídy
 * Generator, ale pokud není tato třída instancována staticky, pak
 * překladač vygeneruje pro přepočet zbytečný kód o délce cca 5KiB.
 * A samozřejmě na toto chování neupozorní, je to docela normální.
 * I z tohoto je vidět jaká podivná úskalí má bare-metal programování.
 * 
 * A další, co z toho vlastně ani není vidět, ale je to důležité.
 * Z mapy se zdá jakoby program neměl v RAM žádná data. Ale má,
 * a je toho docela dost - jen bufer pro DMA má 1KiB. Je to však
 * skryto na zásobníku. To je další kámen úrazu - zásobník má omezenou
 * kapacitu a není na první pohled vidět jak je obsazen. Podobné
 * je to s haldou. Takže to chce nějakou metodu pro analýzu kódu.
 * Tady to jde udělat primitivně - napřed obě třídy instancujeme
 * staticky, přeložíme, podíváme se jak je obsazena RAM, a pak je
 * (pokud se to zdá být v pořádku) přeneseme do main(). Stačí tedy
 * copy - paste dvou řádků za definicí main().
 * Je to jen hrubý odhad, sice lepší než nic, nicméně existují
 * sofistikovanější metody pro analýzu stacku, ale to je na delší
 * povídání. A to se ani nezabývám haldou, zde není a po pravdě
 * se snažím docela úspěšně se jí vůbec vyhýbat. Jsou lidi, kteří
 * vám řeknou, že v C++ se bez operátorů new a delete nedá programovat,
 * ale jak vidíte jde to.
 * A pro úplnost - destruktory v tomto příkladu nejsou, třídy žijí
 * jen uvnitř funkce main() a z té není návratu. V bare-metal je to
 * podobné jako by byly třídy statické. Pokud není z main() návratu,
 * (a to je typický případ) pak je zbytečné mít i nějaké statické
 * destruktory.
 * */
static constexpr unsigned STEP = freq_to_step (50.0);

int main (void) {
  DacDma    dac;
  Generator tone (STEP);
  tone.attach (dac);
  for (;;) {
    asm volatile ("wfi");
  }
  return 0;
}
