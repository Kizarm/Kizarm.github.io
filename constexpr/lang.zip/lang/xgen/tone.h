#ifndef TONE_H
#define TONE_H
#include <math.h>
#include "oneway.h"
#include "init.h"
#include "mmath.h"

// jen tak pro srandu - jak použít něco jako jednotku v C++
static constexpr double operator"" _kHz (const long double arg) {
  return 1000.0 * arg;
}
static constexpr unsigned W_TB = 8u;
static constexpr double   AMPL = 2048.0;
static constexpr int      ULEN =  1  << W_TB;
static constexpr unsigned MASK = (1u << W_TB) - 1u;
// pozor - závisí na nastavení timeru (125us) v dacdma.cpp
static constexpr double   FSAM = 8.0_kHz;
static constexpr unsigned p_shift = 24u;
static constexpr unsigned freq_to_step (const double f) {
  return unsigned (i_round (double (1ull << (p_shift + W_TB)) * f / FSAM));
}
static constexpr uint16_t u16_sin (const int x) {
  const double a = (double (x) * D_PI) / double (ULEN);
  const double s = AMPL * (1.0 + 0.90 * sincos (a, true));
  return i_round (s);
}
static const TABLE<uint16_t, ULEN> onePeriod (u16_sin);

class Generator : public OneWay {
  public:
    explicit constexpr Generator (const unsigned step) : OneWay(),
    freq (step),
    base (0u) {};
    uint32_t  Send  (Chunk * const data) override;
  protected:
    uint16_t sample () {
      // Spočteme index x pro přístup do tabulky
      const unsigned x  = (base >> p_shift) & MASK;
      const uint16_t y  = onePeriod [x];     // vzorek vezmeme z tabulky
      base += freq;
      return y;
    }
  private:
    const unsigned int freq;
    unsigned       int base;
};
#endif // TONE_H
