#ifndef TONE_H
#define TONE_H
#include "mmath.h"
#include "oneway.h"

// jen tak pro srandu - jak použít něco jako jednotku v C++
static constexpr double operator"" _kHz (const long double arg) {
  return 1000.0 * arg;
}
static constexpr unsigned W_TB = 8u;
static constexpr int      ULEN = 1 << W_TB;
// pozor - FSAM závisí na nastavení timeru (125us) v dacdma.cpp
static constexpr double   FSAM = 8.0_kHz;
static constexpr unsigned P_SH = 24u;
static constexpr unsigned freq_to_step (const double f) {
  return unsigned (i_round (double (1ull << (P_SH + W_TB)) * f / FSAM));
}

class Generator : public OneWay {
  public:
    explicit constexpr Generator (const unsigned step) : OneWay(),
      freq (step),
      base (0u) {};
    uint32_t Send   (Chunk * const data) override;
  protected:
    uint16_t sample ();
  private:
    const unsigned int freq;
    unsigned       int base;
};
#endif // TONE_H
