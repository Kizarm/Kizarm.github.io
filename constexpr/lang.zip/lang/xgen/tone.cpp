#include "init.h"
#include "tone.h"

static constexpr unsigned MASK = (1u << W_TB) - 1u;
static constexpr double   AMPL = 2048.0;
static constexpr uint16_t u16_sin (const int x) {
  const double a = (double (x) * D_PI) / double (ULEN);
  const double s = AMPL * (1.0 + 0.90 * sincos (a, true));
  return i_round (s);
}
static const TABLE<uint16_t, ULEN> onePeriod (u16_sin);

uint32_t Generator::Send (Chunk * const data) {
  uint16_t * const ptr = data->data;
  for (unsigned n=0; n<MaxChunkSize; n++) {
    ptr [n] = sample();
  }
  return 1u;
}
inline uint16_t Generator::sample () {
  // Spočteme index x pro přístup do tabulky
  const unsigned x  = (base >> P_SH) & MASK;
  const uint16_t y  = onePeriod [x];     // vzorek vezmeme z tabulky
  base += freq;
  return y;
}
