#include "tone.h"
uint32_t Generator::Send (Chunk * const data) {
  uint16_t * const ptr = data->data;
  for (unsigned n=0; n<MaxChunkSize; n++) {
    ptr [n] = sample();
  }
  return 1u;
}
