#include "init.h"
#include "mmath.h"
#include "stm32f05x.h"

static constexpr unsigned W_TB = 8u;
static constexpr double   AMPL = 2048.0;
static constexpr int      ULEN =  1  << W_TB;
static constexpr unsigned MASK = (1u << W_TB) - 1u;

static constexpr uint16_t u16_sin (const int x) {
  const double a = (double (x) * D_PI) / double (ULEN);
  const double s = AMPL * (1.0 + 0.90 * sincos (a, true));
  return i_round (s);
}
static const TABLE<uint16_t, ULEN> sin_tab (u16_sin);
/**************************************************/
class DAC_Class {
  unsigned arg;
  public:
    explicit constexpr DAC_Class () noexcept : arg (0u) {}
    void init () const {
      RCC.AHBENR.B.IOPAEN = 1u;
      RCC.APB1ENR.B.DACEN = 1u;
      DAC.CR.B.EN1 = 1u;
    }
    void step () {
      DAC.DHR12R1.R = sin_tab [arg];
      arg += 1u;
      arg &= MASK;
    }
};
static DAC_Class dac;
/**************************************************/
extern "C" void setup () {
  dac.init();
}
extern "C" void loop () {
  dac.step();
}

