#include <math.h>
#include "stm32f05x.h"

#define STEP (M_PI / 128.0)
#define AMPL (2047.5)

double phi = 0.0;

void dac_init () {
  RCC->AHBENR.B.IOPAEN = 1u;
  RCC->APB1ENR.B.DACEN = 1u;
  DAC->CR.B.EN1 = 1u;
}
int dac_step () {
  double v = AMPL * (1.0 + sin (phi));
  phi += STEP;
  return (int) v;
}
/*******************************************/
void setup () {
  dac_init();
}
void loop () {
  int a = dac_step();
  DAC->DHR12R1.R = a;
}

