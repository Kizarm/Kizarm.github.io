#include <math.h>
#include "stm32f05x.h"

static unsigned arg = 0;
extern const uint16_t sin_tab [];

static void dac_init () {
  RCC->AHBENR.B.IOPAEN = 1u;
  RCC->APB1ENR.B.DACEN = 1u;
  DAC->CR.B.EN1 = 1u;
}
static unsigned dac_step () {
  const uint16_t v = sin_tab [arg];
  arg += 1u;
  arg &= 0x00FF;
  return v;
}
/*******************************************/
void setup () {
  dac_init();
}
void loop () {
  const unsigned a = dac_step();
  DAC->DHR12R1.R = a;
}

