#!/usr/bin/python
# -*- coding: utf-8 -*-

import math

header = '''/* Generated file */
#include <stdint.h>
const uint16_t sin_tab[] = {{{0:s}
}};
'''

def generate ():
  s = ''
  for n in range(0,256):
    if (n % 16) == 0:
      s += '\n  '
    a  = float(n) * math.pi / 128.0
    v  = int (round (2048.0 * (1.0 + 0.90 * math.sin (a))));
    s += '{0:+6d},'.format(v)
  return s

if __name__ == '__main__':
  s = generate()
  f = open ('sin.c','w')
  f.write(header.format(s))
  f.close()
