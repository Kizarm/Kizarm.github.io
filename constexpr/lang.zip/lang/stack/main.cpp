#include "main.h"

int main () {
  DAC_Class dac;
  for (;;) {
    dac.step();
  }
}
