#include <math.h>
#include "stm32f05x.h"

static const float STEP = 3.141592654f / 128.0f;
static const float AMPL = 2048.0f;

static unsigned arg = 0;
static uint16_t sin_tab [256];

static void dac_init () {
  RCC->AHBENR.B.IOPAEN = 1u;
  RCC->APB1ENR.B.DACEN = 1u;
  DAC->CR.B.EN1 = 1u;
}
static void tab_init () {
  unsigned n;
  for (n=0; n<256; n++) {
    const float phi = (float) n * STEP;
    const float v = AMPL * (1.0f + 0.90f * sinf (phi));
    sin_tab [n] = (uint16_t) v;
  }
}
static unsigned dac_step () {
  const uint16_t v = sin_tab [arg];
  arg += 1u;
  arg &= 0x00FF;
  return v;
}
/*******************************************/
void setup () {
  dac_init();
  tab_init();
}
void loop () {
  const unsigned a = dac_step();
  DAC->DHR12R1.R = a;
}

