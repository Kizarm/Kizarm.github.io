#include <math.h>
#include "stm32f05x.h"

static const float D_PI = 2.0f * 3.141592654f;
static const float STEP = 3.141592654f / 128.0f;
static const float AMPL = 2048.0f;

static float phi = 0.0;

static void dac_init () {
  RCC->AHBENR.B.IOPAEN = 1u;
  RCC->APB1ENR.B.DACEN = 1u;
  DAC->CR.B.EN1 = 1u;
}
static unsigned dac_step () {
  const float v = AMPL * (1.0f + 0.9f * sinf (phi));
  phi += STEP;
  // přetečení argumentu přes periodu -> divné chování
  if (phi > D_PI) phi -= D_PI;
  return (unsigned) v;
}
/*******************************************/
void setup () {
  dac_init();
}
void loop () {
  const unsigned a = dac_step();
  DAC->DHR12R1.R = a;
}

