/*
    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) <year>  <name of author>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

#ifndef COMPLEXDOUBLE_H
#define COMPLEXDOUBLE_H

// vlastní metoda sqrt - není nutné použít math lib.
static inline double sqrtx (double x) {
  double w,y = 2.0;     // aproximaci začneme od 2, u vyšších řádů lepší konvergence
  for (;;) {                  // končí cca za 3-4 iterace
    w = (y + x/y) / 2;  // Newtonova metoda
    if  (y == w) break; // konec iterace - lepší už to nebude
    else y =  w;
  }
  return y;             // výsledek
}


class ComplexDouble {
  private:
    double re;
    double im;
  public:
    ComplexDouble () {re = 0.0; im = 0.0;};               //!< konstruktor
    ComplexDouble (double x, double y) {re = x; im = y;}; //!< konstruktor
    void  setc    (double x, double y) {re = x; im = y;}; //!< nastavení hodnoty
    void  operator&= (ComplexDouble& x) {  //!< přičti a normuj na jednotku
      re += x.re;
      im += x.im;
      double a = re*re + im*im;
      a = 1.0 / sqrtx (a);
      re *= a;
      im *= a;
    };
    void operator*= (ComplexDouble& x) {  //!< znásob komplexním číslem
      double a;
      a  = x.re*re - x.im*im;
      im = x.re*im + x.im*re;
      re = a;
    };
    double gre  (void) {return re;};  //!< návrat reálné části
    double gim  (void) {return im;};  //!< návrat imaginární části
};

#endif // COMPLEXDOUBLE_H
