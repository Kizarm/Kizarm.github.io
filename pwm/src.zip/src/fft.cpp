//   fft.cpp - impelementation of class
//   of fast Fourier transform - FFT

#include "complexdouble.h"
#include "fft.h"
#include <math.h>
#include <stdio.h>


IFFT::IFFT (const unsigned int order) {
  M = order;
  N = 1 << M;
  reverse = new unsigned int [N];
  ones    = new Complex      [N/2];
  coeff   = 1.0;
  PrecomputeOrder ();
  PrecomputeOnes  ();
}
IFFT::~IFFT () {
  delete [] reverse;
  delete [] ones;
}
// s tímhle nebude potřeba se zabývat - prosté přehození pořadí bitů
// Zde do pole pouze pro zrychlení (není pro to instrukce procesoru)
// ARM Cortex m3 - thumb2 jí má - RBIT{c} rn,rm
void IFFT::PrecomputeOrder (void) {
  unsigned int half = N / 2;
  unsigned int last = N - 1;
  unsigned int i, j, k;
  j = 0;
  for (i = 0; i < last; i++) {
    reverse [i] = j;
    // printf ("i = %d, j = %d\n", i, j);
    k = half;
    while (k <= j) {
      j -= k;
      k /= 2;
    }
    j += k;
  }
  reverse [last] = last;
}
void IFFT::PrecomputeOnes (void) {
  unsigned int half = N / 2;
  unsigned int i,j,k;
  real reo, imo;
  // Tady to spočteme trochu jinak, bez použití sin a cos (ale stejně je potřeba sqrt)
  ComplexDouble  reone (1.0, 0.0), xx;        // reálná jednotka, pomocná proměnná
  ComplexDouble* aa = new ComplexDouble [M];  // pole komplexních jednotek - základní rotace
  k = M-1;
  aa[0].setc (0.0, 1.0);    // nultá rotace je o 90st. - komplexní jednotka
  for (i=1; i<k; i++) {     // další budou vždy polovinou předchozího úhlu
    aa[i]  = aa[i-1];       // tedy nastavíme předchozí úhel
    aa[i] &= reone;         // sečteme ho s reálnou jednotkou a normujeme
  }
  for (i=0; i<half; i++) {
    xx.setc (1.0, 0.0);     // nastavit základ, kterýn budeme rotovat = reálná jednotka
    for (j=0; j<k; j++) {   // procházíme jednotlivé bity indexu i
      // zleva - pokud je nastaven násobíme příslušně otočenou jednotkou
      if (i & (1 << (k-j-1))) xx *= aa[j];
    }
    // a sinus i kosinus je hotov
    reo = (real) (coeff * xx.gre());  // znásobíme koeficientem
    imo = (real) (coeff * xx.gim());  // a je to
    
    ones [i].setc (reo, imo);
  }
  delete [] aa;
}

//   FORWARD FOURIER TRANSFORM, INPLACE VERSION
//     Data - both input data and output
bool IFFT::Forward (Complex *const Data) {
  if (!Data) return false;
  Rearrange (Data);
  Perform   (Data, false);
  return true;
}
//   INVERSE FOURIER TRANSFORM, INPLACE VERSION
//     Data  - both input data and output
bool IFFT::Inverse (Complex *const Data) {
  if (!Data) return false;
  Rearrange (Data);
  Perform   (Data, true);
  return true;
}
// Změna pořadí ve vstupním poli
void IFFT::Rearrange (Complex* const Data) {
  unsigned int Target, Position;
  Complex      Temp;
  for (Position = 0; Position < N; Position++) {
    Target = reverse [Position];
    if (Target > Position) {
      Temp            = Data [Target];
      Data [Target]   = Data [Position];
      Data [Position] = Temp;
    }
  }
}

//   FFT implementation
void IFFT::Perform (Complex* const Data, const bool Inverse) {
  unsigned int Dest, Step, Jump, Group, Pair, Incr, Roti;
  Complex Factor, Produc;
  const real Shift = 0.5;     // Úprava velikosti při forwardu, jinak to přeteče

  for (Step = 1; Step < N; Step <<= 1) {   // 1,2,...N/2
    // printf ("1.cyklus Step=%4d\n", Step);
    Jump = Step << 1;   // 2,4,...N
    Incr = N / Jump;    // N/2....1
    Roti = 0;
    for (Group = 0; Group < Step; Group++) {
      // printf (" 2.cyklus Group=%4d, rotace=%4d\n", Group, Roti);
      for (Pair = Group; Pair < N; Pair += Jump) {
        Dest   = Pair + Step;
        Factor = ones [Roti];
        Produc = Data [Pair];
        if (!Inverse) {
          Factor.conj();
          Factor *= Shift;          // shifty s integer doprava o 1 bit
          Produc *= Shift;          // Zároveň normalizace (není potřeba při reverzi).
        }
        Factor *= Data [Dest];
        // printf ("  3.cyklus Pair=%4d, Dest =%4d\n", Pair, Dest);
        Data [Pair].add (Produc, Factor);
        Data [Dest].sub (Produc, Factor);
      }
      Roti += Incr;
    }
  }
}
// Kontrolní výpis
void IFFT::Print (Complex *const Data) {
  printf ("Complex:\n");
  for (unsigned i = 0; i < N; i++) {
    //printf ("%+10ld %+10ld\n", Data[i].getr(), Data[i].geti());
    printf ("%+10f %+10f\n", Data[i].getr(), Data[i].geti());
  }
}

