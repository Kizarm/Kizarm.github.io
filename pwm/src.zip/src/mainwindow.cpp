#include <locale.h>
#include <QDesktopWidget>
#include <QPalette>
/** EMSCRIPTEN si zazatím neumí poradit s dialogy,
 * proto MENU bude nefukční.
 * */
#ifndef EMSCRIPTEN
  #include <QFileDialog>
  #include <QPrintDialog>
#endif // EMSCRIPTEN
#include <QPrinter>
#include <QSplitter>
#include "mainwindow.h"
#include "ui_mainwindow.h"

#undef  qDebug
#define qDebug(p, ...)

MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent) {
  setlocale (LC_NUMERIC, "POSIX");
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  setWindowTitle ("PWM - Sigma/Delta");
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
  bracketptr = 0;

  pwm = new PWM (16);

  timePlot = new QCustomPlot (this);
  freqPlot = new QCustomPlot (this);
  splitter = new QSplitter   (Qt::Vertical);
  splitter->addWidget (timePlot);
  splitter->addWidget (freqPlot);
  ui->verticalLayout->addWidget (splitter);
  
  QBrush bg = QBrush (QColor (255,255,0, 64));
  timePlot->xAxis->setLabel ("Ticks (f0~6.5MHz)");
  timePlot->yAxis->setLabel ("A");
  timePlot->xAxis->setRange (0,4000);
  timePlot->yAxis->setRange (0,3);
  timePlot->addGraph();
  timePlot->addGraph();
  timePlot->addGraph();
  timePlot->graph (0)->setPen (QPen (Qt::red));
  timePlot->graph (0)->setName (QString::fromUtf8 ("Čistá PWM - A(t)"));
  timePlot->graph (1)->setPen (QPen (Qt::blue));
  timePlot->graph (1)->setName (QString::fromUtf8 ("SD PWM - A(t)"));
  QPen gpen(Qt::darkGreen);
  gpen.setWidth(3);
  timePlot->graph (2)->setPen (gpen);
  timePlot->graph (2)->setName (QString::fromUtf8 ("SINUS"));
  timePlot->setInteractions (QCP::iRangeDrag | QCP::iRangeZoom);
  timePlot->legend->setBrush (bg);
  timePlot->legend->setVisible (true);

  freqPlot->xAxis->setLabel ("f[Hz]");
  freqPlot->yAxis->setLabel ("A[dB]");
  freqPlot->xAxis->setRange (100,3400000);
  freqPlot->yAxis->setRange (-160,0);
  freqPlot->xAxis->setScaleType (QCPAxis::stLogarithmic);
  freqPlot->xAxis->setScaleLogBase (10);
  freqPlot->addGraph();
  freqPlot->addGraph();
  freqPlot->graph (0)->setPen (QPen (QColor (255,0,0, 255)));
  freqPlot->graph (0)->setName (QString::fromUtf8 ("Čistá PWM - A(f)"));
  QPen p1 = QPen (QColor (0,0,255, 128));
  p1.setWidth (2);
  freqPlot->graph (1)->setPen (p1);
  freqPlot->graph (1)->setName (QString::fromUtf8 ("SD PWM - A(f)"));
  freqPlot->legend->setBrush (bg);
  freqPlot->legend->setVisible (true);
/**/
  // add the bracket
  QCPItemBracket * bracket = new QCPItemBracket(freqPlot);
  bracketptr = bracket;
  bracket->left ->setCoords (100,   -30);
  bracket->right->setCoords (12800, -30);
  bracket->setStyle (QCPItemBracket::bsCurly);
  bracket->setLength(20);
  // add the text label at the top:
  QCPItemText * bandText = new QCPItemText(freqPlot);
  bandText->position->setParentAnchor(bracket->center);
  bandText->position->setCoords(0, -10); // move 10 pixels to the top from bracket center anchor
  bandText->setPositionAlignment(Qt::AlignBottom|Qt::AlignHCenter);
  bandText->setText(QString::fromUtf8("Akceptovatelná frekvence pro PWM"));
  // add the tracer (circle) which sticks to the graph data (and gets updated in bracketDataSlot by timer event):
  QCPItemTracer * pwmTracer = new QCPItemTracer (freqPlot);
  pwmTracer->setGraph(freqPlot->graph(0));
  pwmTracer->setGraphKey(25600);
  pwmTracer->setInterpolating(true);
  pwmTracer->setStyle(QCPItemTracer::tsCircle);
  pwmTracer->setPen(QPen(Qt::darkGreen));
  pwmTracer->setBrush(Qt::darkGreen);
  pwmTracer->setSize (8);
  // add label for tracer:
  QCPItemText * pwmTracerText = new QCPItemText(freqPlot);
  pwmTracerText->position->setType(QCPItemPosition::ptAxisRectRatio);
  pwmTracerText->setPositionAlignment(Qt::AlignRight|Qt::AlignBottom);
  pwmTracerText->position->setCoords(0.8, 0.95); // lower right corner of axis rect
  pwmTracerText->setText(QString::fromUtf8("1. harmonická\npulsů PWM"));
  pwmTracerText->setTextAlignment(Qt::AlignLeft);
  pwmTracerText->setPadding(QMargins(8, 0, 0, 0));
  // add arrow pointing at tracer, coming from label:
  QCPItemCurve * pwmTracerArrow = new QCPItemCurve(freqPlot);
  pwmTracerArrow->start->setParentAnchor(pwmTracerText->left);
  pwmTracerArrow->startDir->setParentAnchor(pwmTracerArrow->start);
  pwmTracerArrow->startDir->setCoords(-10, 0); // direction 10 pixels to the left of parent anchor (tracerArrow->start)
  pwmTracerArrow->end->setParentAnchor(pwmTracer->position);
  pwmTracerArrow->end->setCoords(10, 10);
  pwmTracerArrow->endDir->setParentAnchor(pwmTracerArrow->end);
  pwmTracerArrow->endDir->setCoords(30, 30);
  pwmTracerArrow->setHead(QCPLineEnding::esSpikeArrow);
  pwmTracerArrow->setTail(QCPLineEnding(QCPLineEnding::esBar,
         (pwmTracerText->bottom->pixelPoint().y()-pwmTracerText->top->pixelPoint().y())*0.85));
/**/
  ui->ovrCombo->addItem ("1 : 1");
  ui->ovrCombo->addItem ("2 : 1");
  ui->ovrCombo->addItem ("4 : 1");
  ui->ovrCombo->addItem ("8 : 1");
  connect (ui->ovrCombo,         SIGNAL (activated (int)),       this, SLOT (resample (int)));
  connect (ui->SpinBoxF,         SIGNAL (valueChanged(double)),  this, SLOT (setfreq  (double)));
#ifndef EMSCRIPTEN
  connect (ui->actionPrint,      SIGNAL (triggered(bool)),       this, SLOT (printDoc(bool)));
  connect (ui->actionExport_FFT, SIGNAL (triggered(bool)),       this, SLOT (exprtFFT(bool)));
#endif // EMSCRIPTEN
  oversample = 0;
  frequency  = 1000.0;
#ifdef EMSCRIPTEN
  setWindowState(Qt::WindowMaximized);
#endif // EMSCRIPTEN
  // Poměr výšek grafů (1:2)
  QSizePolicy sp1 = timePlot->sizePolicy();
  sp1.setVerticalStretch (1);
  timePlot->setSizePolicy(sp1);
  QSizePolicy sp2 = freqPlot->sizePolicy();
  sp2.setVerticalStretch (2);
  freqPlot->setSizePolicy(sp2);
  
  replot ();
}

MainWindow::~MainWindow () {
  delete ui;
  delete pwm;
}

void MainWindow::printDoc (bool) {
#ifndef EMSCRIPTEN
  QWidget  * pw = freqPlot;
  QPrinter * printer = new QPrinter (QPrinter::HighResolution);
  printer->setOutputFileName ("print.pdf");
  printer->setOrientation    (QPrinter::Landscape);
  QPrintDialog printDialog   (printer, this);
  if (printDialog.exec() == QDialog::Accepted) {
    QPainter painter;
    painter.begin  (printer);
    double xscale = printer->pageRect().width()  / double (pw->width ());
    double yscale = printer->pageRect().height() / double (pw->height());
    //double scale = qMin (xscale, yscale);
    painter.translate (printer->paperRect().x() + printer->pageRect().width()  / 2,
                       printer->paperRect().y() + printer->pageRect().height() / 2);
    painter.scale (xscale, yscale);
    painter.translate (-pw->width() / 2, -pw->height() / 2);

    pw->render (&painter);
  }
  delete printer;
#endif // EMSCRIPTEN
}
void MainWindow::exprtFFT (bool) {
#ifndef EMSCRIPTEN
  QWidget * pw = freqPlot;
  QString fileName = QFileDialog::getSaveFileName (this,
               tr ("Save File"), "", "Images(*.png)");
  if (!fileName.isEmpty()) {
    QImage    img (pw->width(), pw->height(), QImage::Format_ARGB32_Premultiplied);
    QPainter  painter(&img);
    pw->render (&painter);
    img.save   (fileName, "PNG", 0);
  }
#endif // EMSCRIPTEN
}

void MainWindow::resample (int n) {
  oversample = n;
  replot();
}
void MainWindow::setfreq (double f) {
  frequency = f;
  replot();
}

void MainWindow::replot (void) {
  pwm->compute (oversample, frequency);
  qDebug("Computed");
  pdata * pd = pwm->get_data();
  const unsigned m = pd->h;
  QVector<real> xt (2*m), pt (2*m), st (2*m), it (2*m);
  QVector<real> xf (m),   pf (m),   sf (m);
  for (unsigned i=0; i<2*m; i++) {
    xt [i] = (real) i;
    pt [i] = pd->pt[i];
    st [i] = pd->st[i] + 1.1;
    it [i] = pd->it[i] + 0.05;
  }
  for (unsigned i=0; i<m; i++) {
    xf [i] = (real) i * 100;
    pf [i] = pd->pf[i];
    sf [i] = pd->sf[i];
  }
  timePlot->graph (0)->setData (xt, pt);
  timePlot->graph (1)->setData (xt, st);
  timePlot->graph (2)->setData (xt, it);

  double miny = pwm->getminy();
  freqPlot->yAxis->setRange (miny, 0);
  freqPlot->graph (0)->setData (xf, pf);
  freqPlot->graph (1)->setData (xf, sf);
  if (bracketptr) {
    bracketptr->left ->setCoords(100,   miny);
    bracketptr->right->setCoords(12800, miny);
  }

  timePlot->replot();
  freqPlot->replot();
}
