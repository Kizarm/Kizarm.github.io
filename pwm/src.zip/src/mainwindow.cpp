#include <locale.h>
#include <QDesktopWidget>
#include <QPalette>
/** EMSCRIPTEN si zazatím neumí poradit s dialogy,
 * proto MENU bude nefukční.
 * */
#ifndef EMSCRIPTEN
  #include <QFileDialog>
  #include <QPrintDialog>
#endif // EMSCRIPTEN
#include <QPrinter>
#include <QSplitter>
#include "mainwindow.h"
#include "ui_mainwindow.h"

#undef  qDebug
#define qDebug(p, ...)

MainWindow::MainWindow (QWidget *parent)
  : QMainWindow (parent) {
  setlocale (LC_NUMERIC, "POSIX");
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  setWindowTitle ("PWM - Sigma/Delta");
//setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
  bracketptr = 0;

  pwm = new PWM (16);

  timePlot = new QCustomPlot (this);
  freqPlot = new QCustomPlot (this);
  splitter = new QSplitter   (Qt::Vertical);
  splitter->addWidget (timePlot);
  splitter->addWidget (freqPlot);
  ui->verticalLayout->addWidget (splitter);
  
  QBrush bg = QBrush (QColor (255,255,0, 64));
  timePlot->xAxis->setLabel ("Ticks (f0~65kHz)");
  timePlot->yAxis->setLabel ("A");
  timePlot->xAxis->setRange (0,4000);
  timePlot->yAxis->setRange (0,256);
  timePlot->addGraph();
  timePlot->addGraph();
  //timePlot->addGraph();
  timePlot->graph (0)->setPen (QPen (Qt::red));
  timePlot->graph (0)->setName (QString::fromUtf8 ("Čistá PWM - A(t)"));
  timePlot->graph (1)->setPen (QPen (Qt::blue));
  timePlot->graph (1)->setName (QString::fromUtf8 ("SD PWM - A(t)"));
  timePlot->setInteractions (QCP::iRangeDrag | QCP::iRangeZoom);
  timePlot->legend->setBrush (bg);
  timePlot->legend->setVisible (true);

  freqPlot->xAxis->setLabel ("f[Hz]");
  freqPlot->yAxis->setLabel ("A[dB]");
  freqPlot->xAxis->setRange (1,33000);
  freqPlot->yAxis->setRange (-160,0);
  freqPlot->xAxis->setScaleType (QCPAxis::stLogarithmic);
  freqPlot->xAxis->setScaleLogBase (10);
  freqPlot->addGraph();
  freqPlot->addGraph();
  freqPlot->graph (0)->setPen (QPen (QColor (255,0,0, 255)));
  freqPlot->graph (0)->setName (QString::fromUtf8 ("Čistá PWM - A(f)"));
  QPen p1 = QPen (QColor (0,0,255, 128));
  p1.setWidth (2);
  freqPlot->graph (1)->setPen (p1);
  freqPlot->graph (1)->setName (QString::fromUtf8 ("SD PWM - A(f)"));
  freqPlot->legend->setBrush (bg);
  freqPlot->legend->setVisible (true);
  ui->label->setText(QString::fromUtf8("Rozlišení PWM :"));
  for (unsigned n=0; n<4; n++) {
    QString s;
    s.sprintf("%d", (1 << (8-n)));
    ui->ovrCombo->addItem (s);
  }
  connect (ui->ovrCombo,         SIGNAL (activated (int)),       this, SLOT (resample (int)));
  connect (ui->SpinBoxF,         SIGNAL (valueChanged(double)),  this, SLOT (setfreq  (double)));
#ifndef EMSCRIPTEN
  connect (ui->actionPrint,      SIGNAL (triggered(bool)),       this, SLOT (printDoc(bool)));
  connect (ui->actionExport_FFT, SIGNAL (triggered(bool)),       this, SLOT (exprtFFT(bool)));
#endif // EMSCRIPTEN
  oversample = 8;
  frequency  = 10.0;
#ifdef EMSCRIPTEN
  setWindowState(Qt::WindowMaximized);
#endif // EMSCRIPTEN
  // Poměr výšek grafů (1:2)
  QSizePolicy sp1 = timePlot->sizePolicy();
  sp1.setVerticalStretch (1);
  timePlot->setSizePolicy(sp1);
  QSizePolicy sp2 = freqPlot->sizePolicy();
  sp2.setVerticalStretch (2);
  freqPlot->setSizePolicy(sp2);
  
  ui->SpinBoxF->setMinimum(1);
  ui->SpinBoxF->setValue  (10);
  replot ();
}

MainWindow::~MainWindow () {
  delete pwm;
  delete freqPlot;
  delete timePlot;
  delete splitter;
  delete ui;
}

void MainWindow::printDoc (bool) {
#ifndef EMSCRIPTEN
  QWidget  * pw = freqPlot;
  QPrinter * printer = new QPrinter (QPrinter::HighResolution);
  printer->setOutputFileName ("print.pdf");
  printer->setOrientation    (QPrinter::Landscape);
  QPrintDialog printDialog   (printer, this);
  if (printDialog.exec() == QDialog::Accepted) {
    QPainter painter;
    painter.begin  (printer);
    double xscale = printer->pageRect().width()  / double (pw->width ());
    double yscale = printer->pageRect().height() / double (pw->height());
    //double scale = qMin (xscale, yscale);
    painter.translate (printer->paperRect().x() + printer->pageRect().width()  / 2,
                       printer->paperRect().y() + printer->pageRect().height() / 2);
    painter.scale (xscale, yscale);
    painter.translate (-pw->width() / 2, -pw->height() / 2);

    pw->render (&painter);
  }
  delete printer;
#endif // EMSCRIPTEN
}
void MainWindow::exprtFFT (bool) {
#ifndef EMSCRIPTEN
  QWidget * pw = freqPlot;
  QString fileName = QFileDialog::getSaveFileName (this,
               tr ("Save File"), "", "Images(*.png)");
  if (!fileName.isEmpty()) {
    if (!fileName.endsWith(".png")) fileName.append(".png");
    QImage    img (pw->width(), pw->height(), QImage::Format_ARGB32_Premultiplied);
    QPainter  painter(&img);
    pw->render (&painter);
    img.save   (fileName, "PNG", 0);
  }
#endif // EMSCRIPTEN
}
void MainWindow::resample (int n) {
  oversample = (8 - n);
  timePlot->yAxis->setRange (0,1 << oversample);
  replot();
}
void MainWindow::setfreq (double f) {
  frequency = f;
  replot();
}

void MainWindow::replot (void) {
  pwm->compute (oversample, frequency);
  qDebug("Computed");
  pdata * pd = pwm->get_data();
  const unsigned m = pd->h;
  const unsigned mf = m;
  QVector<real> xt (2*m), pt (2*m), st (2*m), it (2*m);
  QVector<real> xf (mf),   pf (mf),   sf (mf);
  const real FACT = 1.0;
  for (unsigned i=0; i<2*m; i++) {
    xt [i] = (real) i;
    pt [i] = FACT * pd->pt[i];
    st [i] = FACT * pd->st[i];
    it [i] = FACT * pd->it[i];
  }
  for (unsigned i=0; i<mf; i++) {
    xf [i] = (real) i;
    pf [i] = pd->pf[i];
    sf [i] = pd->sf[i];
  }
  timePlot->graph (0)->setData (xt, pt);
  timePlot->graph (1)->setData (xt, st);
  //timePlot->graph (2)->setData (xt, it);

  double miny = pwm->getminy();
  freqPlot->yAxis->setRange (miny, 0);
  freqPlot->graph (0)->setData (xf, pf);
  freqPlot->graph (1)->setData (xf, sf);
  /*
  if (bracketptr) {
    bracketptr->left ->setCoords(100,   miny);
    bracketptr->right->setCoords(12800, miny);
  }
  */
  timePlot->replot();
  freqPlot->replot();
}
