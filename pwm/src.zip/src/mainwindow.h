#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "pwm.h"

class Ui_MainWindow;
class QSplitter;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow  (QWidget *parent = 0);
    ~MainWindow ();
protected:
    void replot   (void);
public slots:
    void resample (int n);
    void setfreq  (double);
    void printDoc (bool);
    void exprtFFT (bool);
    //void phaseTracerText (QFont QFont);
private:
    int    oversample;
    double frequency;
    Ui_MainWindow * ui;
    PWM           * pwm;
    QCustomPlot   * timePlot;
    QCustomPlot   * freqPlot;
    QSplitter     * splitter;
    QCPItemBracket * bracketptr;
};

#endif // MAINWINDOW_H
