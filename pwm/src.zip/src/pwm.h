#ifndef PWM_H
#define PWM_H
#include "fft.h"

typedef double real;

struct pdata {
  real * pt;
  real * st;
  real * it;
  real * pf;
  real * sf;
  unsigned h;
};

class PWM {
  public:
    PWM (unsigned order);
    ~PWM();
    void compute (unsigned rs, real f0=1000.0);
    pdata * get_data (void) {
      return & mdat;
    }
    real getminy (void) {
      return minyps;
    }
  protected:
    short pwm_max (int * data, int n, int max, unsigned (*fce) (const int, const int));
    void  analyze (const real* x, real* y);
    void  setFreq (unsigned f);
    short next    (void);
  private:
    unsigned order;
    unsigned maximum, half;
    unsigned resample;
    IFFT     fft;
    
    pdata mdat;
    
    double   minyps;
    unsigned freq;
    unsigned base;
    //int oldpwm, curpwm;
};

#endif // PWM_H
