//   fft.h - declaration of class
//   of fast Fourier transform - FFT
//
//   The code is property of LIBROW
//   You can use it on your own
//   When utilizing credit LIBROW site

#ifndef _FFT_H_
#define _FFT_H_

//   Include Complex numbers header
#include "complex.h"

class IFFT {
  public:
    IFFT             (const unsigned int order);
    bool Forward     (Complex *const Data);
    bool Inverse     (Complex *const Data);
    void Print       (Complex *const Data);
    ~IFFT ();
  protected:
    void Rearrange   (Complex *const Data);
    void Perform     (Complex *const Data, const bool Inverse = false);
    void PrecomputeOrder    (void);
    void PrecomputeOnes     (void);
  private:
    unsigned int    N,M;
    unsigned int*   reverse;
    double          coeff;
    Complex*        ones;
};

#endif
