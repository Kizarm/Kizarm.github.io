//
// C++ Interface: complex
//
// Description: 
//
//
// Author: Mrazik <mraz@seznam.cz>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef COMPLEX_H
#define COMPLEX_H

#include <math.h>
typedef double real;

/**
  \class Complex

  \author Mrazik <mrazik@volny.cz>

  \brief Komplexní číslo a práce s ním
  
  Zkrácená verze pracující s 16-bitovými integer. Pouze nutné metody pro FFT.

  Je to základní datová položka filtru. Všechny metody jsou jednoduché, takže je možné použít inline funkce. */
class Complex {
  private:
    real re;       //!< reálná část
    real im;       //!< imaginární část
  public:
    /**
     * Konstruktor
     * @param x reálná část
     * @param y imaginární část
     */
    Complex (real x, real y) {
      re = x;
      im = y;
    }
    /**
     * Default konstruktor (nastaví re=0.0,im=0.0)
     */
    Complex () {
      re = 0.0;
      im = 0.0;
    }
    /**
     * Sčítání
     * @param a odkaz na sčítanec
     * @param b odkaz na sčítanec
     */
    void add (Complex& a, Complex& b) {
      re = a.re + b.re;
      im = a.im + b.im;
    }
    /**
     * Odčítání
     * @param a odkaz na číslo, od něhož se odčítá
     * @param b odkaz na číslo, jež se odčítá
     */
    void sub (Complex& a, Complex& b) {
      re = a.re - b.re;
      im = a.im - b.im;
    }
    /**
     * Násobení - integer verze výsledek zmenší 2^16-krát. Čili 16.bit*16.bit=32.bit
     * a vezme se jen horní 16.bitová část, zbytek se zahodí.
     * @param a odkaz na násobenec
     * @param b odkaz na násobitel
     */
    void operator*= (Complex& a) {
      real rt;
      rt = (a.re * re - a.im * im);
      im = (a.re * im + a.im * re);
      re = rt;
    }
    void operator*= (real a) {
      re *= a;
      im *= a;
    }
    real squarabs (void) {
      return re*re + im*im;
    }
    void setc (real x, real y) {
      re = x;
      im = y;
    }
    real getr (void) {
      return re;
    }
    real geti (void) {
      return im;
    }
    void conj (void) {
      im = -im;
    }
};

#endif
