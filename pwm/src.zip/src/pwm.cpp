#include "pwm.h"

extern "C" const unsigned short sinTab[];

PWM::PWM (unsigned ord) : fft (ord) {
  order    = ord;
  maximum  = (1u <<  ord);
  half     = (1u << (ord-1));
  resample = 1;
  
  mdat.st = new real [maximum];
  mdat.pt = new real [maximum];
  mdat.it = new real [maximum];
  mdat.sf = new real [half];
  mdat.pf = new real [half];
  mdat.h  = half;
}

PWM::~PWM() {
  delete [] mdat.st;
  delete [] mdat.pt;
  delete [] mdat.it;
  delete [] mdat.sf;
  delete [] mdat.pf;
}

int pwm_sd (const int input, const unsigned maxpwm) {
  static unsigned sigma;
  unsigned sample = input + 0x8000u;
  sample *= maxpwm;
  sigma  += sample;
  unsigned result = sigma >> 16;
  sigma  &= 0xFFFFU;
  return result;
}
int pwm_pure (const int input, const unsigned maxpwm) {
  unsigned sample = input + 0x8000u;
  sample *= maxpwm;
  return sample >> 16;
}
void PWM::compute (unsigned int rs, real f0) {
  const unsigned nfreq = (unsigned)(655.36 * f0);
  resample = rs;
  unsigned len = maximum;
  
  real a1, a2;
  int * y1 = new int [len];
  int * y2 = new int [len];
  setFreq (nfreq);
  oldpwm = 1;
  for (unsigned i=0; i<len; i++) {
    short nn = pwm_max (y1, i, 0x100, pwm_pure);
    real xi = (real) nn * (1.0/32000.0) + 1.0;
    mdat.it[i] = xi;
    a1 = (real) y1[i];
    mdat.pt[i] = a1;
  }
  setFreq (nfreq >> resample);
  oldpwm = 1;
  for (unsigned i=0; i<len; i++) {
    pwm_max (y2, i, 0x100 >> resample, pwm_sd);
    a2 = (real) y2[i];
    mdat.st[i] = a2;
  }
  analyze (mdat.pt, mdat.pf);
  analyze (mdat.st, mdat.sf);
  delete [] y1;
  delete [] y2;
}
void PWM::setFreq (unsigned int f) {
  base = 0;
  freq = f;
}
short int PWM::next (void) {
  base += freq;
  return sinTab [(base >> 16) & 0xFF];
}

short PWM::pwm_max (int * data, int n, int max, int (*fce) (const int, const unsigned)) {
  static short res = 0;
  int a,b;
  a = n / max;
  b = n % max;
  if (oldpwm != a) {
    oldpwm = a;
    res = next();
    curpwm = fce (res, max);
  }
  if (curpwm > b) data [n] = 1;
  else            data [n] = 0;
  return res;
}
void PWM::analyze (const real * x, real * y) {
  unsigned i, Num = 1 << order;
  real z, max=-200.0f, min = -60.0;
  const real phd = 2.0 * M_PI / (real) Num;
  
  Complex* c = new Complex [Num];
  real pha = 0.0;
  for (i=0; i<Num; i++) {
    z  = x[i] - 0.5;
    z *= 1.0 - cos (pha);
    c[i].setc(z,0);
    pha += phd;
  }
  fft.Forward(c);
  for (i=0; i<half; i++)  {
    z = c[i].squarabs();
    if (z) y[i] = 10.0f * log10 (z); // ! sqrt z
    else   y[i] = max;
  }
  for (i=1; i<half; i++)  {     // najdi maximum a minimum
    if (y[i] > max) max = y[i];
    if (y[i] < min) min = y[i];
  }
  const double dmin = -158.0;
  for (i=0; i<half; i++)  {     // a odecti ho od vseho
    y[i] -= max;
    if (y[i] < dmin) y[i] = dmin;
  }
  if (min < dmin) minyps = dmin;
  else            minyps = min;
  delete [] c;
  return;
}
