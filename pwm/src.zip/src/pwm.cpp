#include "pwm.h"

extern "C" const unsigned short sinTab[];

PWM::PWM (unsigned ord) : fft (ord) {
  order    = ord;
  maximum  = (1u <<  ord);
  half     = (1u << (ord-1));
  resample = 1 << 8;
  
  mdat.st = new real [maximum];
  mdat.pt = new real [maximum];
  mdat.it = new real [maximum];
  mdat.sf = new real [half];
  mdat.pf = new real [half];
  mdat.h  = half;
}

PWM::~PWM() {
  delete [] mdat.st;
  delete [] mdat.pt;
  delete [] mdat.it;
  delete [] mdat.sf;
  delete [] mdat.pf;
}
static const int      INPUT_BIT_RANGE = 16;
static const unsigned SIGMA_MASK      = (1u << (INPUT_BIT_RANGE  + 0)) - 1u;
static const unsigned SIGNED_OFFEST   = (1u << (INPUT_BIT_RANGE  - 1));
// Předpokládá se na vstupu signed int o šířce INPUT_BIT_RANGE
// přičemž 0 na vstupu odpovídá maxpwm / 2 na výstupu
static unsigned pwm_sd (const int input, const int maxpwm) {
  static unsigned sigma = 0;    // podstatné je, že proměnná je statická
  const unsigned sample = (input + SIGNED_OFFEST) * maxpwm;
  sigma &= SIGMA_MASK;          // v podstatě se odečte hodnota PWM
  sigma += sample;              // integrace prostým součtem
  return sigma  >> INPUT_BIT_RANGE;
}
// Takto se počítá obyčejná PWM modulace
static unsigned pwm_pure (const int input, const int maxpwm) {
  const unsigned sample = (input + SIGNED_OFFEST) * maxpwm;
  return sample >> INPUT_BIT_RANGE;
}
/* nepřinese žádné podstatné zlepšení, pokud není potřeba jít
 * až na hranici max. frekvence - záleží i na výstupním filtru */
unsigned pwm_sd_2 (const int input, const int maxpwm) {
  static unsigned sigma = 0, old = 0;
  const unsigned sample = (input + SIGNED_OFFEST) * maxpwm;
  sigma &= SIGMA_MASK;
  sigma += (sample + old) >> 1; // integrace lichoběžníkovým pravidlem
  old = sample;
  return sigma  >> INPUT_BIT_RANGE;
}
void PWM::compute (unsigned int rs, real f0) {
  const real FACTOR = 1.0 / 32000.0;
  const unsigned nfreq = (unsigned)(256.0 * f0);
  resample = 1 << rs;
  unsigned len = maximum;
  
  real a1, a2;
  int * y1 = new int [len];
  int * y2 = new int [len];
  setFreq (nfreq);
  //oldpwm = 1;
  for (unsigned i=0; i<len; i++) {
    short nn = pwm_max (y1, i, resample, pwm_pure);
    mdat.it[i] = ((real) nn) * FACTOR;
    a1 = (real) y1[i];
    mdat.pt[i] = a1;
  }
  setFreq (nfreq);
  //oldpwm = 1;
  for (unsigned i=0; i<len; i++) {
    pwm_max (y2, i, resample, pwm_sd);
    a2 = (real) y2[i];
    mdat.st[i] = a2;
  }
  analyze (mdat.pt, mdat.pf);
  analyze (mdat.st, mdat.sf);
  delete [] y1;
  delete [] y2;
}
void PWM::setFreq (unsigned int f) {
  base = 0;
  freq = f;
}
short int PWM::next (void) {
  base += freq;
  return sinTab [(base >> 16) & 0xFF];
}

short PWM::pwm_max (int * data, int n, int max, unsigned (*fce) (const int, const int)) {
  short res = next();
  data[n] = fce (res, max);
  return res;
}
void PWM::analyze (const real * x, real * y) {
  unsigned i, Num = 1 << order;
  real z, max=-200.0f, min = -60.0;
  const real phd = 2.0 * M_PI / (real) Num;
  
  Complex* c = new Complex [Num];
  real pha = 0.0;
  for (i=0; i<Num; i++) {
    z  = x[i] - (0.5 * (double) resample);
    z *= 1.0 - cos (pha); // cos window
    c[i].setc(z,0);
    pha += phd;
  }
  fft.Forward(c);
  c[0].setc(0,0);
  for (i=0; i<half; i++)  {
    z = c[i].squarabs();
    if (z) y[i] = 10.0f * log10 (z); // ! sqrt z
    else   y[i] = max;
  }
  for (i=1; i<half; i++)  {     // najdi maximum a minimum
    if (y[i] > max) max = y[i];
    if (y[i] < min) min = y[i];
  }
  const double dmin = -158.0;
  for (i=0; i<half; i++)  {     // a odecti ho od vseho
    y[i] -= max;
    if (y[i] < dmin) y[i] = dmin;
  }
  if (min < dmin) minyps = dmin;
  else            minyps = min;
  delete [] c;
  return;
}
