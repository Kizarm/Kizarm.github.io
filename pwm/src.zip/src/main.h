#ifndef _MAIN_H_
#define _MAIN_H_
#include <QApplication>
#include "mainwindow.h"
#include <qstyle.h>

/**
 * @mainpage Vylepšení PWM.
 * 
 * @section s01 Motivace.
 * 
 * Moderní jednočipy někdy obsahují DA převodník, ale v některých situacích potřebujeme
 * výstup analogového signálu a tento převodník chybí. Nabízí se použít časovač a generovat
 * jím signál s pulsně šířkovou modulací (PWM) a ten pak analově filtrovat dolní propustí.
 * Jenže pro rozumnou frekvenci buzení časovače a rovněž rozumnou maximální frekvenci výstupního
 * signálu bývá rozlišení PWM poměrně malé - např. 256 kroků, tedy 8 bitů. To vadí především
 * tam, kde je potřeba udržovat na výstupu přesné a stabilní napětí.
 * 
 * @section s02 Jak to funguje.
 * 
 * Můžeme to zkusit vylepšit. Půjčíme si na to techniku Sigma-Delta převodníku. Spíš než dlouhý
 * popis je lépe se podívat na tento kousek kódu:
 * @code
 *  #include <stdint.h>
 *  extern short sampleCallback ();         // externí funkce pro získání 16.bit vzorku
 *  extern void ReloadTimer (uint16_t);     // Systémová funkce pro obsluhu timeru a reload PWM.
 *  static const unsigned maxpwm = 256;
 *  void PWM_Timer_Interrupt (void) {       // přerušení od časovače PWM na fN
 *    static unsigned sigma  = 0, resample = 0;
 *    static unsigned sample = 0; // 16.bit signed, převedeme na unsigned
 *    static uint16_t pwm;        // šířka pulsu od 0 do maxpwm
 *    ReloadTimer (pwm);          // zapiš minulou šířku a pak v klidu počítej
 *    if ((resample & 0x1u) == 0) {   // převzorkování 1/2, tedy fN/2 callback
 *      if (sampleCallback) sample = sampleCallback () + 0x8000;
 *      sample *= maxpwm;             // finta
 *    }
 *    sigma += sample;                // sigma
 *    pwm    = sigma >> 16;           // delta
 *    sigma &= 0xFFFFu;               // zůstatek do dalšího kola
 *    resample += 1;
 *  }
 * @endcode
 * 
 * @section s03 Můžete si vyzkoušet.
 * 
 * Jednoduchý prográmek je napsán v Qt.
 * @image html pwm.png
 * I z tohoto obrázku je vidět, že odstup signál/šum je na nízkých frekvencích opravdu o dost nižší.
 * Pokud si chcete pohrát, <a href="../bin/pwm.html">verze pro WebAssembly je zde</a>.
 * 
 * Pozn.:
 * -# Zřejmě to nebude fungovat ve všech prohlížečích (technologie je zatím dost neodladěná).
 * -# Je to pomalejší než nativní aplikace a i ta je dost pomalá - vykresluje poměrně dost bodů ve frekvenční oblasti. Takže po změně
 * parametru je potřeba několik sekund počkat než se to překreslí.
 * -# Horní graf (časová závislost) je možné kolečkem myši zoomovat a myší tahat po widgetu.
 * -# Spodní graf je pevný.
 * -# Menu ve verzi pro WebAssembly nic nedělá. Zatím není podpora pro vlákna.
 * 
 * Simulovaný čítač je krmen frekvencí cca 6.5 MHz, rozlišení PWM je 256 kroků, což dává opakovací frekvenci
 * PWM 25 kHz. Parametrem převzorkování můžeme zmenšit pro SD-PWM tuto frekvenci a tím zároveň ve stejném
 * poměru zmenšit i rozlišení (čítač je krmen stále 6.5 MHz, krok tedy zůstává). Samozřejmě se tím zvětší
 * i frekvence přerušení, takže je potřeba v praxi s tím zacházet rozumně. Převzorkování 1:256 by zde znamenalo
 * čistou Sigma-Delta modulaci (střídání 0 a 1 s frekvencí 6.5 MHz).
 * 
 * 
 * @section s04 Ke stažení.
 * 
 * Zdrojáky pro Qt5 jsou <a href="../src.zip">zde</a>.
 * 
 * */

#endif // _MAIN_H_
