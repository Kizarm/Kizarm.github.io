#ifndef INPUT_H
#define INPUT_H
#include <stdio.h>
#include "FIR.h"
/**
@file
@class Input
Třída načítající data ze souboru.
*/
class Input {
  public:
    /// Konstruktor
    /// @param filename jméno souboru s daty
    Input (const char* filename);
    /// Načtení jedné hodnoty.
    /// @param out odkaz na proměnnou, kam se načte float číslo
    /// @return false, pokud už další data nejsou
    bool run (real& out);
    /// Destruktor
    ~Input();
  private:
    /// Soubor
    FILE* infile;
};

#endif // INPUT_H
