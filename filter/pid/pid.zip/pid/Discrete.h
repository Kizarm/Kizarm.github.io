#ifndef DISCRETE_H
#define DISCRETE_H
#include "FIR.h"
/**
@file
@class Discrete
  Simulace nepřesného měření pomocí např. rotačního enkodéru.
*/
class Discrete {
  public:
    /// Konstruktor
    /// @param coef koeficient normalizace, udávající přesnost měření
    Discrete (real coef);
    /// Jeden průchod - vrátí celočíselnou část vstupu + minulého zbytku,
    /// současný zbytek si schová do dalšího kola.
    /// @param  in reálná vstupní hodnota
    /// @return výstup, v podstatě celá čísla, ale jsou vydělena koeficientem normalizace
    real run (real in);
  private:
    real  frac;   //!< pomocná proměnná (zbytek)
    real  sum;    //!< koeficient normalizace
    real  isum;   //!< převrácený koeficient normalizace
};

#endif // DISCRETE_H
