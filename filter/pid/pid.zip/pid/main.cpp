#include <stdio.h>
#include <stdlib.h>

#include "Input.h"
#include "FIR.h"
#include "Discrete.h"
#include "PID.h"
#include "PIDIIR.h"
#include "PIDBIL.h"
#include "PIDINT.h"

/**
@mainpage PID Diskrétní regulátor
@author Mrazík mrazik@volny.cz
@section Pream Úvod.
PID regulátor je často používaný prvek v automatizaci. Celá problematika regulace je dost obsáhlá, teorie řeší stabilitu systému, kvalitu regulace atd. V zásadě je dobře vypracována pro lineární spojité systémy, pokud má v systému některý z prvků nelineární závislosti, což je v praxi dost častý případ, stejně je nutné použít nějakou heuristickou metodu nebo číslicový model.\n
Na webu lze najít klasický analogový přístup, přechod na číslicovou metodu regulace - a to je v době mikroprocesorů docela důležité - je řešen jen okrajově. Takže se zkusme na problém podívat trochu blíže.
Jako výchozí bod lze vzít například dokument <a href="http://www.atmel.com/images/doc2558.pdf">AVR221</a> od fy Atmel. Zde se pokusíme ukázat co v něm chybí, resp. udělat to snad o trochu lépe. Není zde snaha to matematicky precizovat, na to jsou jiní, ale bez pár vzorečků se to neobejde. Výpočet koeficientů IIR je sice o něco náročnější než jen výpočet koeficientů PID, ale není to tragédie a metoda generuje o něco čistší kód.

@section ANALOG Analogová část.
@image html blok.png
To je popsáno dobře. Alespoň v časové oblasti. Pokud vstup regulátoru označíme jako \f$ e(t) \f$, výstup jako \f$ u(t) \f$, samotný regulátor je pak popsán odezvou:
\f[
u(t) = K_p \left\{ e(t) + \frac {1}{T_i} \int_0^t e(\tau) d\tau + T_d \frac{de(t)}{dt} \right\}
\f]
Koeficienty \f$ K_p \f$, \f$ T_i \f$, \f$ T_d \f$ lze určit pomocí <a href="http://en.wikipedia.org/wiki/Ziegler%E2%80%93Nichols_method">Ziegler–Nicholsovy metody</a>. Praktická realizace PID regulátoru pak používá namísto integrace prostou sumaci, místo derivace diferenci.
\f[
\int_0^t e(\tau) d\tau = T \sum_{k = 0}^n e_k ; \frac {de(t)}{dt} = \frac {e_n - e_{n - 1}}{T} ; t = n T
\f]
n je diskrétní krok v čase t, T perioda vzorkování. Realizujeme tak digitální formuli
\f[
u_n = K_p \left\{ e_n + K_i \sum_{k=0}^n e_k + K_d ( e_n - e_{n-1} ) \right\}
\f]
Je zřejmé, že \f$ K_i = \frac{T}{T_i} , K_d = \frac{T_d}{T} \f$. To je srozumitelné, výpočetně poměrně nenáročné, leč má to omezení.
<b>
Tuto metodu lze použít jen v tom případě, pokud perioda vlastních kmitů soustavy ( viz. @ref ZNM ) \f$ T_u \f$ je daleko větší než perioda vzorkování (opakování výpočtu) T.
</b>
Pro kontrolu je tato metoda aplikována ve třídě @ref PID. Zde se pokusíme to trochu zdigitalizovat - převést problém na jednoduchý číslicový filtr typu IIR (Infinite Impulse Response). Blíže viz. @ref PIDIIR.

@section ZNM Ziegler–Nicholsova metoda.
Používá se pro otimální nastavení analogového PID regulátoru. Předpokladem je, že je možné regulovanou soustavu spolu s regulátorem rozkmitat. Měří se tedy na uzavřené smyčce, přičemž koeficient integrální části Ki a diferenciální části Kd regulátoru jsou nulové a proporcionální koeficient Kp se zvětšuje postupně tak, aby systém právě začal neomezeně kmitat (unstable).
Tím dostaneme koeficient Ku a periodu kmitání Tu. Pak lze vyjít z tabulky koeficientů (Z anglické wikipedie, údaje z různých zdrojů se mírně liší, jednotky jsou uvedeny podle použitého výrazu pro PID, ale třeba AVR221 používá jiné jednotky, takže koeficienty se liší dost podstatně. Když to pak aplikujeme v praxi, musí to rozměrově "sedět".)

- Kp - zde násobek celkového kritického zesílení Ku (viz vzorce výše)
- Ti - (časová) integrační konstanta v násobcích periody Tu
- Td - (časová) derivační  konstanta v násobcích periody Tu

<TABLE BORDER="1">
<TR><TH> Typ          </TH><TH>  Kp  </TH><TH>  Ti  </TH><TH>  Td  </TH></TR>
<TR><TH> P            </TH><TD> 0.50 </TD><TD> -    </TD><TD> -    </TD></TR>
<TR><TH> PI           </TH><TD> 0.45 </TD><TD> 0.83 </TD><TD> -    </TD></TR>
<TR><TH> Klasický PID </TH><TD> 0.60 </TD><TD> 0.50 </TD><TD> 0.12 </TD></TR>
<TR><TH> Malý překmit </TH><TD> 0.33 </TD><TD> 0.50 </TD><TD> 0.33 </TD></TR>
<TR><TH> Bez překmitu </TH><TD> 0.20 </TD><TD> 0.50 </TD><TD> 0.33 </TD></TR>
</TABLE>

<b>Dále - výsledky simulací -</b> viz dokumentace @ref main.cpp

@section SRC Zdrojové kódy.
<a href="../pid.zip">Kdyby si s tím někdo chtěl pohrát.</a>

@file main.cpp
  Testy. Respektive digitální simulace. Vstupní data jsou (ručně vytvořená) v souboru, třída Input je načítá. Zde jsou použity skoky, protože ty nejlépe charakterizují odezvu systému. Používají se pak pro následující simulace:
*/

/**
Simulace přechodové charakteristiky regulované soustavy. Ta je simulována FIR filtrem, protože to umožňuje jednoduše vytvářet naprosto libovolné průběhy. Zde by se to mělo podobat reálnému systému - zde např. odezva rychlosti otáčení motoru v závislosti na napětí kotvy, pokud přidáme dopravní zpoždění pak to může představovat třeba závislost teploty na výkonu vytápění (chlazení) atd.
@image html motor.png
@image latex motor.eps "motor" width=10cm
Je vidět, že výstup - to je měrená veličina je na vstupu závislý, není mu roven, ale je tam nějaká konstanta úměrnosti. Při použití @ref ZNM nás celkem nemusí zajímat její velikost.

@param outfilename Jméno výstupního souboru.
*/
void odezva0RegulovaneSoustavy (const char* outfilename) {
  Input     in    ("input.dat");
  FIR       motor ("iir.cfc", 0x100);
  real      x0, x1, x2;
  FILE*     out;
  
  out = fopen (outfilename, "w");
  x0 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    x2  = motor.run (x1);
    fprintf (out,"%lg %lg %lg\n", x0, x1, x2);
    x0 += 1.0;
  }
  fclose (out);
}
/**
Simulace regulace soustavy z @ref odezva0RegulovaneSoustavy PID regulátorem nastaveným za pomoci @ref ZNM. Vstupní data jsou pro všechny simulace stejná.  
@image html loop1.png
@image latex loop1.eps "loop1" width=10cm
Zde je vidět, že to funguje. Pokud bychom použili jen P regulátor, výstup by nikdy nedosáhl přesně požadované hodnoty. Lze si pohrát s koeficienty. 
@param outfilename Jméno výstupního souboru.
*/
void odezva1Systemu (const char* outfilename) {
  Input     in    ("input.dat");
  FIR       motor ("iir.cfc", 0x100);
  // Ku = 6.4, Tu = 5.0
  // Zjevně máme příliš hrubé vzorkování, derivace zlobí, ale to celkem nevadí
  // PID       regul (3.2,  0.0,   0.0);    // P
  // PID       regul (2.88, 0.24,  0.0);    // PI
  // PID       regul (1.28, 0.4, 0.2);         // vyzkouseny PID s rozumným překmitem
  // PIDIIR    regul (3.2,  0.0,   0.0);    // P
  // PIDIIR    regul (2.88, 0.24,  0.0);    // PI
  PIDIIR    regul (1.28, 0.4, 0.2);         // vyzkouseny PID s rozumným překmitem
  real      x0, x1, x2, x3, eps;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  x3 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    eps = x1 - x3;
    x2  = regul.run (eps);
    x3  = motor.run (x2);
    fprintf (out,"%lg %lg %lg %lg\n", x0, x1, x2, x3);
    x0 += 1.0;
  }
  fclose(out);
}
/**
Tato simulace je přidána jako ukázka, co se stane, pokud budeme měřit odezvu poněkud nepřesně. Typicky - pokud snímáme otáčky motoru rotačním enkodérem - dává nám to za každou periodu T celočíselnou hodnotu, přičemž celkový počet otáček (integrál) je změřen vcelku přesně. 
@image html loop2.png
@image latex loop2.eps "loop2" width=10cm
Je vidět, že ta integrující složka regulátoru to trochu srovná. Pokud by to mělo být přesnější, bylo by potřeba měřit dobu mezi jednotlivými otáčkami a počítat převrácenou hodnotu. S dělením však bývají problémy.
@param outfilename Jméno výstupního souboru.
*/
void odezva2DiskretnihoSystemu (const char* outfilename) {
  Input     in    ("input.dat");
  FIR       motor ("iir.cfc", 0x100);
  Discrete  discr (0.05);
  // Ku = 6.4, Tu = 5.0
  PIDIIR    regul (1.28, 0.4, 0.2);         // vyzkouseny PID s rozumným překmitem
  real      x0, x1, x2, x3, x4, eps;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  x4 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    eps = x1 - x4;
    x2  = regul.run (eps);
    x3  = motor.run (x2);
    x4  = discr.run (x3);
    fprintf (out,"%lg %lg %lg %lg\n", x0, x1, x2, x3);
    x0 += 1.0;
  }
  fclose(out);
}
/**
Simulace regulace soustavy z @ref odezva0RegulovaneSoustavy PID regulátorem nastaveným za pomoci @ref ZNM. Zde je použita bilineární metoda realizace digitálního PID jako IIR.
@image html loop3.png
@image latex loop3.eps "loop3" width=10cm
Zde je vidět, že i to funguje. Lze si opět pohrát s koeficienty, možná by to mělo i lepší odezvu než prostá aproximace derivací diferencemi. Ani výpočetně to není o moc složitější. 
@param outfilename Jméno výstupního souboru.
*/
void odezva3Systemu (const char* outfilename) {
  Input     in    ("input.dat");
  FIR       motor ("iir.cfc", 0x100);
  // Ku = 6.4, Tu = 5.0
  // Zjevně máme příliš hrubé vzorkování, derivace zlobí, ale to celkem nevadí
  PIDBIL    regul (1.28, 0.4, 0.1);         // vyzkouseny PI s rozumným překmitem
  real      x0, x1, x2, x3, eps;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  x3 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    eps = x1 - x3;
    x2  = regul.run (eps);
    x3  = motor.run (x2);
    fprintf (out,"%lg %lg %lg %lg\n", x0, x1, x2, x3);
    x0 += 1.0;
  }
  fclose(out);
}
/**
Bilineární metoda, diskrétní měření +/- 10, Kd nastaveno na nulu.
@image html loop4.png
@image latex loop4.eps "loop4" width=10cm
Je vidět, že je to trochu něco jiného než prostá aproximace derivací diferencemi. Ta diferenciální složka tam působila jen problémy, odezvu ve skutečnosti nezlepšuje.
@param outfilename Jméno výstupního souboru.
*/
void odezva4DiskretnihoSystemu (const char* outfilename) {
  Input     in    ("input.dat");
  FIR       motor ("iir.cfc", 0x100);
  Discrete  discr (0.1);  // přesnost na celé desítky
  // Ku = 6.4, Tu = 5.0
  // Zjevně máme příliš hrubé vzorkování, derivace zlobí, ale to celkem nevadí
  PIDBIL    regul (1.28, 0.4, 0.0);         // vyzkouseny PI s rozumným překmitem
  real      x0, x1, x2, x3, x4, eps;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  x4 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    eps = x1 - x4;
    x2  = regul.run (eps);
    x3  = motor.run (x2);
    x4  = discr.run (x3);
    fprintf (out,"%lg %lg %lg %lg %lg\n", x0, x1, x2, x3, x4);
    x0 += 1.0;
  }
  fclose(out);
}
/**
Bilineární metoda, diskrétní výpočet v celých 16.bitových číslech. V grafu přidána regulační odchylka.
@image html loop5.png
@image latex loop5.eps "loop4" width=10cm
Ani to není problém.
@param outfilename Jméno výstupního souboru.
*/
void odezva5CelociselnehoSystemu (const char* outfilename) {
  Input     in    ("input.dat");
  //Input     in    ("iregu.dat");
  FIR       motor ("iir.cfc", 0x100);
  // Ku = 6.4, Tu = 5.0
  // Zjevně máme příliš hrubé vzorkování, derivace zlobí, ale to celkem nevadí
  PIDINT    regul (1.28, 0.4, 0.0);         // vyzkouseny PI s rozumným překmitem
  real      x0, x1, x2, x3, eps;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  x3 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    eps = x1 - x3;
    // limitace vstupu regulatoru
    if (eps > +30000.0) eps = +30000.0;
    if (eps < -30000.0) eps = -30000.0;
    x2  = (real) regul.run ((int) eps);
    x3  = motor.run (x2);
    fprintf (out,"%lg %lg %lg %lg %lg\n", x0, x1, x2, x3, eps);
    x0 += 1.0;
  }
  regul.check ();
  fclose(out);
}
/**
<b>Tohle nakonec jako největší problém implementace v celých číslech.</b> Odezva samotného regulátoru, bilineární metoda.\n Je zde vidět rozdíl a to hodně podstatný pokud se to počítá v aritmetice plovoucí řádové čárky (a tedy bez limitace) a v pevné řádové čárce - v celých číslech. Ta integrální část může v zásadě růst nade všechny meze, v celých číslech je tedy nutné to omezit. Je nutné limitovat jak vstup tak výstup na šířku 16.bit celého čísla se znaménkem. Samotný výpočet sice dává výsledek ve 32.bitech (16.b x 16.b = 32.b), ten je však upraven (SCALING_FACTOR) pro další výpočet, použije se jen těch 16.bitů.
@image html loop6.png
@image latex loop6.eps "loop4" width=10cm
Je vidět, že i to může fungovat. Ta numerická nestabilita celočíselného regulátoru na konci celkem nic neznamená - reálný vstup bude jiný - zpětná vazba takovéto fluktuace srovná. Reálný systém stejně akční veličinu nemůže zvětšovat nade všechny meze, nakonec je to stejně fyzikálně limitováno nějakým výstupním rozsahem. To samé platí i pro vstup.<b>Co je důležité - i při léto limitaci je IIR použitelný, není nestabilní, nerozkmitá se a drží tu limitní hodnotu.</b>
@param outfilename Jméno výstupního souboru.
*/
void odezva6regulatoru (const char* outfilename) {
  Input     in    ("iregu.dat");
  // Ku = 6.4, Tu = 5.0
  PIDBIL    fregul (1.28, 0.4, 0.0);         // vyzkouseny PI s rozumným překmitem
  PIDINT    iregul (1.28, 0.4, 0.0);         // vyzkouseny PI s rozumným překmitem
  real      x0, x1, x2, x3, x4;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    // x1 = +/- 25000
    x2  = (real) iregul.run ((int) x1);
    x3  =        fregul.run (      x1);
    x4  = iregul.get_unlimited();
    fprintf (out,"%lg %lg %lg %lg %lg\n", x0, x1, x2, x3, x4);
    x0 += 1.0;
  }
  iregul.check();
  fclose(out);
}
/**
Bilineární metoda, diskrétní výpočet v celých 16.bitových číslech. Velké hodnoty na vstupu, limitace výstupu.
@image html loop7.png
@image latex loop7.eps "loop4" width=10cm
Na konci je vidět, že se systém nakonec ustálí. Pokud by byla vstupní veličina o něco větší, regulátor už by to "nedotáhl", ale i tak by zůstal stabilní.
@param outfilename Jméno výstupního souboru.
*/
void odezva7intSystemuLimity (const char* outfilename) {
  Input     in    ("iregu.dat");
  FIR       motor ("iir.cfc", 0x100);
  // Ku = 6.4, Tu = 5.0
  PIDINT    regul (1.28, 0.4, 0.0);         // vyzkouseny PI s rozumným překmitem
  real      x0, x1, x2, x3, eps;
  FILE*     out;
  
  out = fopen(outfilename, "w");
  x0 = 0.0;
  x3 = 0.0;
  for (;;) {
    if (!in.run (x1)) break;
    eps = x1 - x3;
    // limitace vstupu regulatoru
    if (eps > +30000.0) eps = +30000.0;
    if (eps < -30000.0) eps = -30000.0;
    x2  = (real) regul.run ((int) eps);
    x3  = motor.run (x2);
    fprintf (out,"%lg %lg %lg %lg %lg\n", x0, x1, x2, x3, eps);
    x0 += 1.0;
  }
  regul.check ();
  fclose(out);
}
/**
Hlavní program
*/

int main (void) {
  // ty názvy jsou divné protože doxygen to řadí podle abecedy
  odezva0RegulovaneSoustavy   ("./data/data1.dat");
  odezva1Systemu              ("./data/data2.dat");
  odezva2DiskretnihoSystemu   ("./data/data3.dat");
  odezva3Systemu              ("./data/data4.dat");
  odezva4DiskretnihoSystemu   ("./data/data5.dat");
  odezva5CelociselnehoSystemu ("./data/data6.dat");
  odezva6regulatoru           ("./data/data7.dat");
  odezva7intSystemuLimity     ("./data/data8.dat");
  int i=0;
  i = system ("gnuplot eps.cmd");
  i = system ("gnuplot img.cmd");
  return i;
}
