#include <stdio.h>
#include "PIDIIR.h"


PIDIIR::PIDIIR (real kp, real ki, real kd) {
  b0  = 1.0 + ki + kd;
  b0 *=  kp;
  b1  = 1.0 + 2.0 * kd;
  b1 *= -kp;
  b2  =  kd;
  b2 *=  kp;
  printf ("PIDIIR: b0=%g, b1=%g, b2=%g\n", b0, b1, b2);
  x1  = 0.0;
  x2  = 0.0;
  y1  = 0.0;
}

real PIDIIR::run (real x0) {
  // Jednoduché - IIR tohoto řádu je sranda.
  real y0 = b0 * x0 + b1 * x1 + b2 * x2 + y1;
  y1 = y0;
  x2 = x1;
  x1 = x0;
  return y0;
}
