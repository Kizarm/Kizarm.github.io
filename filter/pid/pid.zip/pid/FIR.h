#ifndef FIR_H
#define FIR_H

/// přetypujeme si double na real
typedef double real;
/**
@file
@class FIR
Simulátor systému. Používá se jednoduchá implementace číslicového filtru <a href="http://cs.wikipedia.org/wiki/Filtr_s_kone%C4%8Dnou_impulzn%C3%AD_odezvou">FIR</a>. Koeficienty jsou v souboru, načítá je již konstruktor. FIR umožňuje udělat v zásadě libovolnou přenosovou funkci.
*/
class FIR  {
  public:
    /// Konstruktor
    /// @param filename jméno souboru s koeficienty. Podle jejich počtu je určen řád filtru.
    /// @param max maximální řád filtru.
    FIR (const char* filename, int max);
    /// Jeden průchod filtrem.
    /// @param x0 vstupní hodnota
    /// @return y0 výstupní hodnota
    real run (real x0);
    ~FIR();
  private:
    real  sum;    //!< koeficient pro normalizaci
    int   taps;   //!< řád filtru
    real* coef;   //!< pole koeficientů a_n
    real* vals;   //!< paměť pro vstupní hodnoty x_n
};

#endif // FIR_H
