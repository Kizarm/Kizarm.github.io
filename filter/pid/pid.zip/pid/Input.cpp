#include "Input.h"

Input::Input(const char* filename) {
  infile = fopen(filename, "r");
  if (!infile) fprintf (stderr, "No input\n");
}

bool Input::run (real& out) {
  if (!infile) return false;
  int i = fscanf(infile, "%lg", &out);
  out *= 100.0;
  if (i == 1) return true;
  return false;
}

Input::~Input() {
  fclose(infile);
}

