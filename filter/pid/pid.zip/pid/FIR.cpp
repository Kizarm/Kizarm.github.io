#include <stdio.h>
#include <math.h>
#include "FIR.h"

FIR::FIR(const char* filename, int max) {
  int i,j;
  taps = 0;
  // frac = 0.0;
  sum  = 0.0;
  coef = NULL;
  vals = NULL;
  FILE* in = fopen (filename, "r");
  if (!in) return;
  real* tmp = new real [max];
  for (i=0; i<max; i++) {
    j = fscanf (in, "%lg", tmp + i);
    if (j != 1) break;
  }
  taps = i;
  coef = new real [taps];
  vals = new real [taps];
  for (i=0; i<taps; i++) {
    coef[i] = tmp [i];
    vals[i] = 0.0;
    sum    += coef[i];
  }
  sum = 1.0 / sum;
  printf ("SUM=%g, taps=%d\n", sum, taps);
  fclose (in);
  delete tmp;
}

real FIR::run (real in) {
  real out = 0.0;
  if (!taps) return out;
  int  inc = taps - 1;
  vals[0]  = in;
  for (;;) {
    out += coef[inc] * vals[inc];
    inc -= 1;
    vals [inc+1] = vals [inc];
    if (!inc) break;
  }
  out *= sum;     // normalizace
  return out;
}

FIR::~FIR() {
  if (coef) delete [] coef;
  if (vals) delete [] vals;
}

