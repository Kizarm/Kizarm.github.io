#include <stdio.h>
#include "PIDINT.h"
/// Pro výpočet v celých číslech je potřeba posunout koeficienty bn o daný počet bitů doleva.
/// Týká se to jen koeficientů bn - nesmí přesáhnout ~ +/- 32000
#define SCALING_FACTOR 12

PIDINT::PIDINT (real kp, real ki, real kd) {
  real a0, a1, a2;
  // c0 je "jednotka" v celých číslech
  c0  = (real)(1L << SCALING_FACTOR);
  a0  = ki * 0.5;
  a1  = kd * 2.0;
  
  a2  = a0 + a1;
  a1  = a0 - a1;
  a0  = a2;
  
  a0 += 1.0;
  a1 *= 2.0;
  a2 -= 1.0;
  
  kp *= c0;
  a0 *= kp;
  a1 *= kp;
  a2 *= kp;
  
  b0 = (int16_t) a0;
  b1 = (int16_t) a1;
  b2 = (int16_t) a2;
  
  printf ("PIDINT: a0=%g, a1=%g, a2=%g\n", a0, a1, a2);
  printf ("PIDINT: b0=%d, b1=%d, b2=%d\n", b0, b1, b2);
  oflplus  = 0;
  oflminus = 0;
  
  x1  = 0.0;
  x2  = 0.0;
  y1  = 0.0;
  y2  = 0.0;
}
/**
 Pokud je dobře zvolen SCALING_FACTOR vzhledem ke koeficientům, nikde by nic přetékat nemělo. Jde to trochu proti sobě - SCALING_FACTOR by měl být co největší kvůli přesnosti výpočtu, zároveň však nemůže být tak velký, aby výpočet nepřesáhl rozsah celého čísla.
@param in 32.bit číslo
@return 16.bit, zároveň počítá, pokud vstup přesahuje rozsah, počet přesahů.
*/
inline int16_t PIDINT::limits_16b (int32_t in) {
  int32_t lim = 32000;
  if (in > lim) {
    oflplus++;
    in = lim;
  }
  if (in < -lim) {
    oflminus++;
    in = -lim;
  }
  int16_t rv = (int16_t) in;
  return rv;
}

void PIDINT::check (void) {
  printf ("PIDINT: +Overflow = %d, -Overflow = %d\n", oflplus, oflminus);
  oflplus  = 0;
  oflminus = 0;
}

real PIDINT::get_unlimited (void) {
  return unlimited;
}

int16_t PIDINT::run (int16_t x0) {
//x0 = limits_16b (x0); // není potřeba, vstupní data jsou limitována
  int32_t iy0 = b0 * x0 + b1 * x1 + b2 * x2;
  iy0 >>= SCALING_FACTOR;
  // Tady nezapomenout na y2
  iy0  += (int32_t) y2;
  unlimited = (real) iy0;
  // Vyzkoušeno, že je nejlépe to umístit právě sem.
  int16_t y0  = limits_16b (iy0);
  
  y2  = y1;
  y1  = y0;
  x2  = x1;
  x1  = x0;
  return y0;
}

