#include <math.h>
#include "Discrete.h"

Discrete::Discrete (real coef) {
  sum  = coef;
  isum = 1.0 / sum;
  frac = 0.0;
}


real Discrete::run (real in) {
  // Pokud měřím diskrétní hodnoty (otáčky) dostanu asi tohle (integrálně to musí "sedět")
  real xxx = in * sum + frac;
  real flr = floor (xxx);
  frac = xxx - flr;
  flr *= isum;     // normalizace
  return flr;
}
