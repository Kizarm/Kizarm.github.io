#include "PID.h"


PID::PID (real kp, real ki, real kd) {
  cp = kp;
  ci = ki * cp;
  cd = kd * cp;
  x1 = 0.0;
  y1 = 0.0;
  sum = 0.0;
}

real PID::run (real in) {
  real res, der;
  sum += in;
  der  = in - x1;
  x1   = in;
  res  = cp * in + cd * der + ci * sum;
  y1   = res;
  return res;
}
