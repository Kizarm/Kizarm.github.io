#ifndef PID_H
#define PID_H
#include "FIR.h"
/**
@file
@class PID
Diskrétní PID regulátor, klasicky řešený. Analogový přenos je
\f[
u(t) = K_p \left\{ e(t) + \frac {1}{T_i} \int_0^t e(\tau) d\tau + T_d \frac{de(t)}{dt} \right\}
\f]
což je digitalizováno přiblížením
\f[
\int_0^t e(\tau) d\tau = T \sum_{k = 0}^n e_k ; \frac {de(t)}{dt} = \frac {e_n - e_{n - 1}}{T} ; t = n T
\f]
n je diskrétní krok v čase t, T perioda vzorkování. Realizujeme tak digitální formuli
\f[
u_n = K_p \left\{ e_n + K_i \sum_{k=0}^n e_k + K_d ( e_n - e_{n-1} ) \right\}
\f]
Koeficienty \f$ K_p, K_i = \frac{T}{T_i} , K_d = \frac{T_d}{T} \f$ jsou použity v konstruktoru. V metodě run() je pak použita upravená formule
\f[
u_n = C_p e_n + C_i \sum_{k=0}^n e_k + C_d ( e_n - e_{n-1} )
\f]
Koeficienty \f$ C_p = K_p, C_i = K_p K_i, C_d = K_p K_d \f$ přepočítá konstruktor
*/
class PID {
  public:
    /// Konstruktor - přepočítá koeficienty
    /// @param kp společný proporcionální koeficient Kp
    /// @param ki Ki
    /// @param kd Kd
    PID (real kp, real ki, real kd);
    /// Jeden průchod regulátorem (realizace uvedené funkce)
    /// @param en vstup
    /// @return výstup un
    real run (real en);
  private:
    /// Minulé hodnoty
    real x1, y1;
    /// Koeficienty metody run()
    real cp, ci, cd;
    /// Pomocná proměnná pro výpočet sumace
    real sum;
};

#endif // PID_H
