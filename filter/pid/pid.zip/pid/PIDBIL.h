#ifndef PIDBIL_H
#define PIDBIL_H
#include "FIR.h"

/**
@file
@class PIDBIL
Zkusíme udělat bilineární transformaci (viz PIDIIR). Obraz přenosu (přechodová charakteristika) je opět:
\f[
H(p) = \frac{U(p)}{E(p)} = K_p \left\{ 1 + \frac{1}{p T_i} + p T_d \right\}
\f]
Po dosazení \f$ pT = 2 \frac{z-1}{z+1} = 2 \frac{1-z^{-1}}{1+z^{-1}} \f$ dostaneme pro
\f[
H(z) = K_p \frac{ ( \frac{1}{2}K_i + 2K_d + 1 ) + 2 ( \frac{1}{2}K_i - 2K_d)z^{-1} +
( \frac{1}{2}K_i + 2K_d - 1 ) z^{-2} }{1-z^{-2}}
\f]
Koeficienty b0, b1, b2 jsou z toho snad jasné. Za zmínku snad stojí, že a1 = 0, a2 = 1 -> tedy zvyšuje se řád filtru. Nicméně výpočet to zatěžuje jen jedním přesunem dat v paměti navíc proti PIDIIR. To je uspokojivé, i výsledky jsou celkem rozumné.
*/

class PIDBIL {
  public:
    /// Konstruktor
    PIDBIL (real kp, real ki, real kd);
    /// Průchod
    real run (real in);
  private:
    /// minulá data
    real x1, x2, y1, y2;
    /// koeficienty
    real b0, b1, b2;
};

#endif // PIDBIL_H
