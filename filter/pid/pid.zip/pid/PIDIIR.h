#ifndef PIDIIR_H
#define PIDIIR_H
#include "FIR.h"
/**
@file
@class PIDIIR
Klasický analogový přenos spojitého PID regulátoru
\f[
u(t) = K_p \left\{ e(t) + \frac {1}{T_i} \int_0^t e(\tau) d\tau + T_d \frac{de(t)}{dt} \right\}
\f]
lze pomocí <a href="http://cs.wikipedia.org/wiki/Laplaceova_transformace">Laplaceovy transformace</a> zapsat jako obraz přenosu (přechodová charakteristika):
\f[
H(p) = \frac{U(p)}{E(p)} = K_p \left\{ 1 + \frac{1}{p T_i} + p T_d \right\}
\f]

Tady zkusíme trochu exaktnější způsob přechodu na digitální systém. I když výsledek bude stejný jako u řešení ve třídě PID, bude z toho možná alespoň trochu vidět i jiné souvislosti a výsledný kód bude čistší. Použijeme zde metody pro návrh digitálních filtrů, v daném případě typu <a href="http://cs.wikipedia.org/wiki/Filtr_s_nekone%C4%8Dnou_impulzn%C3%AD_odezvou">IIR</a> <a href="http://en.wikipedia.org/wiki/Infinite_impulse_response">(Infinite Impulse Response)</a>. Nebudeme se zde hlouběji zabývat teorií, zůstaňme u konstatování, že filtrem IIR lze jednoduše realizovat jakýkoli obvod s vlastnostmi podobnými obvodu, realizovaného z klasických prvků analogové techniky. Míra podobnosti ve frekvenční nebo časové oblasti je pak dána zvolenou metodou přechodu od spojitého systému k diskrétnímu, tedy od Laplaceova obrazu přenosu k obrazu v <a href="http://cs.wikipedia.org/wiki/Z-transformace">transformaci Z</a>. V podstatě se dají použít následující metody:
 - <b>Metoda aproximace derivací diferencemi.</b> Transformační vztah je jednoduchý - \f$ pT = 1 - z^{-1} \f$ Tu zde  použijeme, i když není ideální, je jednoduchá a dá stejný výsledek jako klasický PID. Z teorie plyne, že bude-li vzorový analogový obvod stabilní, bude stabilní i výsledný návrh. Frekvenční charakteristika se bude lišit pro vyšší frekvence - srovnatelné se vzorkovací frekvencí. <b>Tohle omezení je dobré si uvědomit.</b>
 - <b>Metoda impulzně invariantní transformace.</b> Zachovává impulsní odezvu původního analogového obvodu. Pro svou složitost je zde téměř nepoužitelná, takže se jí nebudeme blíže zabývat.
 - <b>Metoda bilineární transformace.</b> O něco složitější transformační vztah \f$ pT = 2 \frac{z-1}{z+1} \f$ je dán tím, že se derivace neaproximuje diferencí, ale derivace se integruje a integrál se počítá podle trojúhelníkového pravidla. To dá o něco lepší vlastnosti, zachovává stabilitu vzoru a měla by být i trochu odolná proti aliasingu, ale pro vyšší frekvence je třeba při návrhu postupovat podle pravidel, která přesahují obsah tohoto pojednání. Nakonec na zkoušku je to i zde zjednodušeně aplikováno ve třídě PIDBIL, případně - <b>pro praxi důležitější - v celých číslech PIDINT (včetně limitace).</b>
 
Dobrá, dostali jsme tedy formuli
 \f[
 H(z) = K_p \left\{ 1 + \frac{T}{T_i} \frac{1}{1-z^{-1}} + \frac{T_d}{T} (1-z^{-1}) \right\}
 \f]
K čemu nám to bude ? Obecný IIR filtr se v časové oblasti dá popsat diferenční rovnicí takto:
 \f[
 y_n = \sum_{i=0}^M b_i x_{n-i} + \sum_{i=1}^N a_i y_{n-i}
 \f]
což se dá jednoduše realizovat. Transformace Z pak pro tuto diferenční rovnici dává 
 \f[
 H(z) = \frac{Y(z)}{X(z)} = \frac{b_0 + b_1 z^{-1} + b_2 z^{-2} + ... + b_M z^{-M}}
 {1 - a_1 z^{-1} - a_2 z^{-2} - ... - a_N z^{-N}}
 \f]
Takže si tu naší formulku přepíšeme
 \f[
 H(z) = K_p \frac{(1 + \frac{T}{T_i} + \frac{T_d}{T} ) - (1 + 2 \frac{T_d}{T} ) z^{-1} + \frac{T_d}{T} z^{-2} }{(1-z^{-1})}
 \f]
A z toho jsou už jasně vidět koeficienty \f$ a_1 = 1, b_0 = K_p (1 + \frac{T}{T_i} + \frac{T_d}{T}) = K_p (1 + K_i + K_d) \f$ , \f$ b_1 = - K_p (1 + 2 \frac{T_d}{T}) = - K_p (1 + 2 K_d) \f$ , \f$ b_2 = K_p \frac{T_d}{T} = K_p K_d \f$ . A to je vše. Přepočet provedeme v konstruktoru a metoda run() je prostá
@code
real PIDIIR::run (real x0) {
  real y0 = (b0 * x0) + (b1 * x1) + (b2 * x2) + y1;
  y1 = y0; x2 = x1; x1 = x0;
  return y0;
}
@endcode
*/
class PIDIIR {
  public:
    /// Konstruktor
    PIDIIR (real kp, real ki, real kd);
    /// Průchod
    real run (real in);
  private:
    /// minulá data
    real x1, x2, y1;
    /// koeficienty
    real b0, b1, b2;
};

#endif // PIDIIR_H
