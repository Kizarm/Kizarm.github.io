#ifndef PIDINT_H
#define PIDINT_H
#include <stdint.h>
#include "FIR.h"
/**
@file
@class PIDINT
Bilineární transformace jako v PIDBIL, IIR, zkusíme to celé počítat v celých číslech. Zde už se dostáváme trochu blíže realitě. Protože máme omezený číselný rozsah, je nutné přidat někam omezení. V klasickém analogovém systému je toto omezení dáno např. napájecím napětím použitých operačních zesilovačů nebo max. výkonem akčního členu. Digitální systém má takovéto fyzikální omezení samosebou také. Toto omezení vkládá nelinearitu do jinak lineárního systému a dá se proto předpokládat, že s tím budou problémy.\n
- Právě integrační složka PID regulátoru by mohla růst nade všechny meze - to je nutné omezit (problém přetékání integrátoru - windup). Pokud se to počítá stejně jako ve třídě PID, pak je lépe omezit zvlášť ještě tu integrační složku. Pokud to počítáme jako IIR, můžeme omezit jen výstup s tím, že rekurzívní formule filtru <b>může být nestabilní</b> - rozbor této situace není úplně jednoduchý. V případě tohoto jednoduchého PID regulátoru je možné odhadnout, že se problém rekurzívní nestability neprojeví. Což je možné jednoduše nasimulovat - viz odezva6regulatoru() a odezva7intSystemuLimity().
- Toto omezení způsobí změnu odezvy systému, resp. zhoršení regulačních vlastností. Existuje několik víceméně sofistikovaných metod (anti-windup) jak se této situaci bránit, nicméně to již přesahuje obsah tohoto pojednání. Nehledě na to, zvětšení složitosti regulátoru většinou nepřinese úměrné zlepšení jeho vlastností. Narážíme na čistě fyzikální bariéry a ty není tak snadné překonat.

*/

class PIDINT {
  public:
    /// Konstruktor
    PIDINT (real kp, real ki, real kd);
    /// Průchod
    int16_t run (int16_t in);
    /// Výpis počtu limitů
    void check (void);
    /// vrátí výstup před limitací jako číslo v plovoucí řádové čárce
    real get_unlimited (void);
  protected:
    int16_t limits_16b (int32_t in);
  private:
    /// minulá data
    int16_t x1, x2, y1, y2;
    /// koeficienty
    int16_t b0, b1, b2, c0;
    int32_t oflplus, oflminus;
    real    unlimited;
};

#endif // PIDINT_H
