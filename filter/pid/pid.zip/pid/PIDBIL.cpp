#include <stdio.h>
#include "PIDBIL.h"


PIDBIL::PIDBIL (real kp, real ki, real kd) {
  b0  = ki * 0.5;
  b1  = kd * 2.0;
  
  b2  = b0 + b1;
  b1  = b0 - b1;
  b0  = b2;
  
  b0 += 1.0;
  b1 *= 2.0;
  b2 -= 1.0;
  
  b0 *= kp;
  b1 *= kp;
  b2 *= kp;
  
  printf ("PIDBIL: b0=%g, b1=%g, b2=%g\n", b0, b1, b2);
  x1  = 0.0;
  x2  = 0.0;
  y1  = 0.0;
  y2  = 0.0;
}

real PIDBIL::run (real x0) {
  // Jednoduché - IIR tohoto řádu je sranda.
  real y0 = b0 * x0 + b1 * x1 + b2 * x2 + y2;
  y2 = y1;
  y1 = y0;
  x2 = x1;
  x1 = x0;
  return y0;
}
