#include <stdio.h>
#include <math.h>
#include <string.h>
#include "IIRFilter.h"

#undef  PI
#define PI          3.14159265358979323846  /* Microsoft C++ does not define M_PI ! */
#define TWOPI       (2.0 * PI)
#define EPS         1e-10
#define MAXORDER    16

static const c_complex bessel_poles[] = {
  /* table produced by /usr/fisher/bessel --  N.B. only one member of each C.Conj. pair is listed */
  { -1.00000000000e+00, 0.00000000000e+00}, { -1.10160133059e+00, 6.36009824757e-01},
  { -1.32267579991e+00, 0.00000000000e+00}, { -1.04740916101e+00, 9.99264436281e-01},
  { -1.37006783055e+00, 4.10249717494e-01}, { -9.95208764350e-01, 1.25710573945e+00},
  { -1.50231627145e+00, 0.00000000000e+00}, { -1.38087732586e+00, 7.17909587627e-01},
  { -9.57676548563e-01, 1.47112432073e+00}, { -1.57149040362e+00, 3.20896374221e-01},
  { -1.38185809760e+00, 9.71471890712e-01}, { -9.30656522947e-01, 1.66186326894e+00},
  { -1.68436817927e+00, 0.00000000000e+00}, { -1.61203876622e+00, 5.89244506931e-01},
  { -1.37890321680e+00, 1.19156677780e+00}, { -9.09867780623e-01, 1.83645135304e+00},
  { -1.75740840040e+00, 2.72867575103e-01}, { -1.63693941813e+00, 8.22795625139e-01},
  { -1.37384121764e+00, 1.38835657588e+00}, { -8.92869718847e-01, 1.99832584364e+00},
  { -1.85660050123e+00, 0.00000000000e+00}, { -1.80717053496e+00, 5.12383730575e-01},
  { -1.65239648458e+00, 1.03138956698e+00}, { -1.36758830979e+00, 1.56773371224e+00},
  { -8.78399276161e-01, 2.14980052431e+00}, { -1.92761969145e+00, 2.41623471082e-01},
  { -1.84219624443e+00, 7.27257597722e-01}, { -1.66181024140e+00, 1.22110021857e+00},
  { -1.36069227838e+00, 1.73350574267e+00}, { -8.65756901707e-01, 2.29260483098e+00},
};

IIRFilter::IIRFilter () {
    // initial (default) settings
    prototype  = BUTTERWORTH;
    filterType = LP;
    designed.order = 1;
    ripple = 1.0f;
    rate = 8000.0f;
    fN  = 0.5f*rate;
    fp1 = 0.0f;
    fp2 = 1000.0f;
    ImpX = NULL;
    ImpY = NULL;
    use_matched = false;
    add_zero    = false;
    freqPoints  = 512;
    ImpX = new double [freqPoints];
    ImpY = new double [freqPoints];
    raw_alphaz = 1000.0 / rate;
}

IIRFilter::~IIRFilter() {
  delete [] ImpX;
  delete [] ImpY;
}
void IIRFilter::createXXYY (void) {
  for (unsigned i=0; i<MaxOrder; i++) {
    xx[i] = 0.0f;
    yy[i] = 0.0f;
  }
}

void IIRFilter::ImpulseResponse (void) {
  int i;
  createXXYY();
  double v = 0.0f, w;
  double ymin = 0.0f, ymax = 0.0f;
  for (i=0; i<freqPoints; i++) {
    if (i == 100) v = 100.0f;
    ImpX[i] = v;
    ImpY[i] = run (ImpX[i]);
    if (ImpY[i] < ymin) ymin = ImpY[i];
    if (ImpY[i] > ymax) ymax = ImpY[i];
  }
  
  v  = ymax - ymin;
  w  = ymax + ymin;
  w *= 0.5f;
  if (v == 0.0f) return;
  v = 400.0 / v;
  for (i=0; i<freqPoints; i++) {
    ImpX[i] -= w;
    ImpY[i] -= w;
    ImpX[i] *= v;
    ImpY[i] *= v;
  }
  
}

double IIRFilter::run (double x0) {
  int    i,k,m;
  double y0 = 0.0;
  
  xx[0] = x0 * designed.gain ;
  m = i = k = zplane.numzeros;
  y0 += designed.a[k] * xx[0];
  if (m) {
    for (;;) {
      k -= 1;
      y0 += designed.a[m-i] * xx[i];
      xx[i] = xx[k];
      if (!k) break;
      i = k;
    }
  }
  m = i = k = zplane.numpoles;
  for (;;) {
    k -= 1;
    y0 += designed.b[m-i] * yy[i-1];
    if (!k) break;
    yy[i-1] = yy[k-1];
    i = k;
  }
  yy[0] = y0;
  return y0;
}
void IIRFilter::test (void) {
  int    i,k,m;
  double x0 = 0;
  double y0 = 0;
  
  xx[0] = x0 * designed.gain ;
  printf ("x[0] = x0 * %e\n", designed.gain);
  m = i = k = zplane.numzeros;
  y0   += designed.a[k] * xx[0];
  printf ("y0 += (%f) a[%d] * x[%d]\n", designed.a[k], k, 0);
  if (m) {
    for (;;) {
      k -= 1;
      y0 += designed.a[m-i] * xx[i];
      //xx[i] = xx[k];
      printf ("y0 += (%f) a[%d] * x[%d]\n", designed.a[m-i], m-i, i);
      printf ("x[%d] = x[%d]\n", i, k);
      if (!k) break;
      i = k;
    }
  }
  printf("\n");
  m = i = k = zplane.numpoles;
  for (;;) {
    k -= 1;
    y0 += designed.b[m-i] * yy[i-1];
    printf ("y0 += (%f) b[%d] * y[%d]\n", designed.b[m-i], m-i, i-1);
    if (!k) break;
    //yy[i-1] = yy[k-1];
    printf ("y[%d] = y[%d]\n", i-1, k-1);
    i = k;
  }
  yy[0] = y0;
  printf ("y[%d] = y0\n", 0);
  return;

}

void IIRFilter::print (void) {
  printf ("Order: %d, Prototype: %d, Type: %d\n", designed.order, prototype, filterType);
  printf ("f1=%g, f2=%g, fs=%g\n", fp1, fp2, rate);

}

double* IIRFilter::filterGain (void) {

  // filter gain at uniform frequency intervals
  double* g = new double[freqPoints+1];
  double theta, s, c, sac, sas, sbc, sbs;
  double gMax = -100.0f;
  double sc = 10.0f/(double)log(10.0f);
  double t = M_PI / freqPoints;
  for (int i = 0; i <= freqPoints; i++) {
    theta = i*t;
    if (i == 0) theta = M_PI*0.0001;
    if (i == freqPoints) theta = M_PI*0.9999;
    sac = 0.0f;
    sas = 0.0f;
    sbc = 0.0f;
    sbs = 0.0f;
    for (int k = 0; k <= zplane.numzeros; k++) {
      c = cos(k*theta);
      s = sin(k*theta);
      sac += c*designed.a[k];
      sas += s*designed.a[k];
    }
    for (int k = 0; k <= zplane.numpoles; k++) {
      c = cos(k*theta);
      s = sin(k*theta);
      sbc += c*designed.b[k];
      sbs += s*designed.b[k];
    }
    g[i] = sc*(double)log((sqr(sac) + sqr(sas))/(sqr(sbc) + sqr(sbs)));
    gMax = fmax(gMax, g[i]);
  }
  // normalise to 0 dB maximum gain
  for (int i=0; i<=freqPoints; i++) g[i] -= gMax;
  // normalise numerator (a) coefficients
  double normFactor = pow (10.0, -0.05*gMax);
  designed.gain = normFactor;
  return g;

}
#include "fft.h"
double * IIRFilter::filterGainFFT (void) {
  double gMax = -100.0;
  createXXYY();
  double   * g = new double   [  freqPoints+1];
  complex  * c = new complex  [2*freqPoints+1];
  //memset (c, 0, (2*freqPoints+1) * sizeof (complex));
  double t;
  for (int i=0; i<freqPoints; i++) {
    if (i) t = run (0.0);
    else   t = run (100.0);
    if (isnan(t)) t = 0.0;
    c[i].re = t;
  }
  FFT fft (10);
  fft.F   (c);
  double ff;
  for (int i=0; i<freqPoints; i++) {
    ff   = 20.0f * (double) log10 (hypot (c[i]));
    if (isnan (ff)) ff = 0.0f;
    g[i] = ff;
    gMax = fmax(gMax, ff);
  }
  // normalise to 0 dB maximum gain
  for (int i=0; i<freqPoints; i++) g[i] -= gMax;

  delete [] c;
  return g;
}
void IIRFilter::compute (void) {
  createXXYY();
  switch (filterType) {
    case LP: raw_alpha1 = fp2 / rate; raw_alpha2 = raw_alpha1; break;
    case BP: raw_alpha1 = fp1 / rate; raw_alpha2 = fp2 / rate; break;
    case BS: raw_alpha1 = fp1 / rate; raw_alpha2 = fp2 / rate; break;
    case HP: raw_alpha1 = fp1 / rate; raw_alpha2 = raw_alpha1; break;
  }
  polemask    = ~0U;
  compute_s ();
  prewarp   ();
  normalize ();

  if (use_matched) compute_z_mzt ();
  else             compute_z_blt ();
  if (add_zero)    add_extra_zero();
  expandpoly    ();
}
void IIRFilter::compute_s (void) {
  int order = designed.order;
  chebrip   = - ripple;
  splane.numpoles = 0;
  if (prototype & BESSEL) {
    /* Bessel filter */
    int p = (order*order) /4; /* ptr into table */
    if (order & 1) choosepole (bessel_poles[p++]);
    for (int i = 0; i < order/2; i++) {
      choosepole (bessel_poles[p]);
      choosepole (cconj (bessel_poles[p]));
      p++;
    }
  }
  if (prototype & (BUTTERWORTH | CHEBYSHEV)) {
    /* Butterworth filter */
    for (int i = 0; i < 2*order; i++) {
      double theta = (order & 1) ? (i*PI) / order : ( (i+0.5) *PI) / order;
      choosepole (expj (theta));
    }
  }
  if (prototype & CHEBYSHEV) {
    /* modify for Chebyshev (p. 136 DeFatta et al.) */
    if (chebrip >= 0.0) {
      fprintf (stderr, "Chebyshev ripple is %g dB; must be .lt. 0.0\n", chebrip);
    }
    double rip = pow (10.0, -chebrip / 10.0);
    double eps = sqrt (rip - 1.0);
    double y = asinh (1.0 / eps) / (double) order;
    if (y <= 0.0) {
      fprintf (stderr, "bug: Chebyshev y=%g; must be .gt. 0.0\n", y);
    }
    for (int i = 0; i < splane.numpoles; i++) {
      splane.poles[i].re *= sinh (y);
      splane.poles[i].im *= cosh (y);
    }
  }

}
static complex blt (complex pz) {
  return (2.0 + pz) / (2.0 - pz);
}

void IIRFilter::compute_z_blt (void) {
  int i;
  zplane.numpoles = splane.numpoles;
  zplane.numzeros = splane.numzeros;
  for (i=0; i < zplane.numpoles; i++) zplane.poles[i] = blt (splane.poles[i]);
  for (i=0; i < zplane.numzeros; i++) zplane.zeros[i] = blt (splane.zeros[i]);
  while (zplane.numzeros < zplane.numpoles) zplane.zeros[zplane.numzeros++] = -1.0;
}
void IIRFilter::compute_z_mzt (void) {
  int i;
  zplane.numpoles = splane.numpoles;
  zplane.numzeros = splane.numzeros;
  for (i=0; i < zplane.numpoles; i++) zplane.poles[i] = cexp (splane.poles[i]);
  for (i=0; i < zplane.numzeros; i++) zplane.zeros[i] = cexp (splane.zeros[i]);
}
void IIRFilter::prewarp (void) {
  /* for bilinear transform, perform pre-warp on alpha values */
  if (use_matched) {
    warped_alpha1 = raw_alpha1;
    warped_alpha2 = raw_alpha2;
  } else {
    warped_alpha1 = tan (PI * raw_alpha1) / PI;
    warped_alpha2 = tan (PI * raw_alpha2) / PI;
  }
}
void IIRFilter::normalize (void) {
  double w1 = TWOPI * warped_alpha1;
  double w2 = TWOPI * warped_alpha2;
  /* transform prototype into appropriate filter type (lp/hp/bp/bs) */
  switch (filterType) {
    case LP: {
      for (int i = 0; i < splane.numpoles; i++) splane.poles[i] = splane.poles[i] * w1;
      splane.numzeros = 0;
      break;
    }

    case HP: {
      int i;
      for (i=0; i < splane.numpoles; i++) splane.poles[i] = w1 / splane.poles[i];
      for (i=0; i < splane.numpoles; i++) splane.zeros[i] = 0.0;   /* also N zeros at (0,0) */
      splane.numzeros = splane.numpoles;
      break;
    }

    case BP: {
      double w0 = sqrt (w1*w2), bw = w2-w1;
      int i;
      for (i=0; i < splane.numpoles; i++) {
        complex hba = 0.5 * (splane.poles[i] * bw);
        complex temp = csqrt (1.0 - sqrc (w0 / hba));
        splane.poles[i] = hba * (1.0 + temp);
        splane.poles[splane.numpoles+i] = hba * (1.0 - temp);
      }
      for (i=0; i < splane.numpoles; i++) splane.zeros[i] = 0.0;   /* also N zeros at (0,0) */
      splane.numzeros = splane.numpoles;
      splane.numpoles *= 2;
      break;
    }

    case BS: {
      double w0 = sqrt (w1*w2), bw = w2-w1;
      int i;
      for (i=0; i < splane.numpoles; i++) {
        complex hba = 0.5 * (bw / splane.poles[i]);
        complex temp = csqrt (1.0 - sqrc (w0 / hba));
        splane.poles[i] = hba * (1.0 + temp);
        splane.poles[splane.numpoles+i] = hba * (1.0 - temp);
      }
      for (i=0; i < splane.numpoles; i++) {  // also 2N zeros at (0, +-w0)
        splane.zeros[i] = complex (0.0, +w0);
        splane.zeros[splane.numpoles+i] = complex (0.0, -w0);
      }
      splane.numpoles *= 2;
      splane.numzeros = splane.numpoles;
      break;
    }
  }
}
static void multin (complex w, int npz, complex coeffs[]) {
  /* multiply factor (z-w) into coeffs */
  complex nw = -w;
  for (int i = npz; i >= 1; i--) coeffs[i] = (nw * coeffs[i]) + coeffs[i-1];
  coeffs[0] = nw * coeffs[0];
}
static void expand (complex pz[], int npz, complex coeffs[]) {
  /* compute product of poles or zeros as a polynomial of z */
  int i;
  coeffs[0] = 1.0;
  for (i=0; i < npz; i++) coeffs[i+1] = 0.0;
  for (i=0; i < npz; i++) multin (pz[i], npz, coeffs);
  /* check computed coeffs of z^k are all real */
  for (i=0; i < npz+1; i++) {
    if (fabs (coeffs[i].im) > EPS) {
      fprintf (stderr, "coeff of z^%d is not real; poles/zeros are not complex conjugates\n", i);
    }
  }
}
void IIRFilter::add_extra_zero (void) {
  if (zplane.numzeros+2 > (int) MAXPZ) {
    fprintf (stderr, "too many zeros; can't do\n");
    return;
  }
  double theta = TWOPI * raw_alphaz;
  complex zz = expj (theta);
  zplane.zeros[zplane.numzeros++] = zz;
  zplane.zeros[zplane.numzeros++] = cconj (zz);
  while (zplane.numpoles < zplane.numzeros) zplane.poles[zplane.numpoles++] = 0.0;   /* ensure causality */
}

void IIRFilter::clear (void) {
  for (unsigned i=0; i<MaxOrder; i++) {
    designed.a[i] = 0.0; designed.b[i] = 0.0;
  }

}
void IIRFilter::expandpoly (void) {
  double * xcoeffs = designed.a;
  double * ycoeffs = designed.b;
  complex topcoeffs[MAXPZ+1], botcoeffs[MAXPZ+1];
  int i;
  clear  ();
  expand (zplane.zeros, zplane.numzeros, topcoeffs);
  expand (zplane.poles, zplane.numpoles, botcoeffs);
  dc_gain = evaluate (topcoeffs, zplane.numzeros, botcoeffs, zplane.numpoles, 1.0);
  double theta = TWOPI * 0.5 * (raw_alpha1 + raw_alpha2); /* "jwT" for centre freq. */
  fc_gain = evaluate (topcoeffs, zplane.numzeros, botcoeffs, zplane.numpoles, expj (theta));
  hf_gain = evaluate (topcoeffs, zplane.numzeros, botcoeffs, zplane.numpoles, -1.0);
  for (i = 0; i <= zplane.numzeros; i++) xcoeffs[i] = + (topcoeffs[i].re / botcoeffs[zplane.numpoles].re);
  for (i = 0; i <= zplane.numpoles; i++) ycoeffs[i] = - (botcoeffs[i].re / botcoeffs[zplane.numpoles].re);

  // printf ("zplane.numpoles : %d, zplane.numzeros : %d\n", zplane.numpoles, zplane.numzeros);
}

void IIRFilter::choosepole (complex z) {
  if (z.re < 0.0) {
    if (polemask & 1) splane.poles[splane.numpoles++] = z;
    polemask >>= 1;
  }
}
int IIRFilter::print_design (char * buf, int max) {
  int k = 0;

  k += snprintf      (buf + k, max - k, "/*\n");
  k += print_S_plane (buf + k, max - k);
  k += print_Z_plane (buf + k, max - k);
  k += snprintf      (buf + k, max - k, "*/\n");
  k += print_code    (buf + k, max - k);
  return k;
}
int IIRFilter::print_code (char * buf, int code_max) {
  int i, k = 0;
  k += snprintf (buf + k, code_max - k,
            "#ifndef _IIR_FILTER_H\n"
            "#define _IIR_FILTER_H\n"
            "typedef double real;\n"
            "class Filtr {\n"
            "  public:\n"
            "    Filtr() {\n"
            "      for (int i=0; i<%d; i++) x[i] = 0.0;\n"
            "      for (int i=0; i<%d; i++) y[i] = 0.0;\n"
            "    };\n"
            , zplane.numzeros+1, zplane.numpoles);
  k += snprintf (buf + k, code_max - k,
            "    real run (real x0) {\n"
            "      real y0 = 0;\n"
            "      x[0] = x0 * %e;\n", designed.gain);
  if (zplane.numzeros) {
    for (i=0; i<=zplane.numzeros; i++) {
      k += snprintf (buf + k, code_max - k,
            "      y0  += %+20.15f * x[%d];\n", designed.a[i], zplane.numzeros - i);
    }
    for (i=zplane.numzeros; i>0; i--) {
      k += snprintf (buf + k, code_max - k,
            "      x[%d] = x[%d];\n", i, i-1);
    }
  } else {
    k += snprintf (buf + k, code_max - k,
            "      y0  += %+20.15f * x[0];\n",  designed.a[0]);
  }
  for (i=0; i<zplane.numpoles; i++) {
    k += snprintf (buf + k, code_max - k,
            "      y0  += %+20.15f * y[%d];\n", designed.b[i], zplane.numpoles - i - 1);
  }
  for (i=zplane.numpoles-1; i>0; i--) {
    k += snprintf (buf + k, code_max - k,
            "      y[%d] = y[%d];\n", i, i-1);
  }
  k += snprintf (buf + k, code_max - k,
            "      y[0] = y0;\n"
            "      return y0;\n"
            "    };\n");
  k += snprintf (buf + k, code_max - k,
            "  private:\n"
            "    real  x [%d], y [%d];\n"
            "};\n"
            "#endif // _IIR_FILTER_H\n", zplane.numzeros+1, zplane.numpoles);
  return k;
}
int IIRFilter::prcomplex (char * buf, int max, complex z) {
  int k = 0;
  k += snprintf (buf + k, max - k, "%14.10f + j %14.10f", z.re, z.im);
  return k;
}

int IIRFilter::printpz (char * buf, int max, complex * pzvec, int num) {
  int k = 0;
  int n1 = 0;
  while (n1 < num) {
    k += snprintf  (buf + k, max - k, "\t");
    k += prcomplex (buf + k, max - k, pzvec[n1]);
    int n2 = n1+1;
    while (n2 < num && pzvec[n2] == pzvec[n1]) n2++;
    if (n2-n1 > 1) k += snprintf (buf + k, max - k, "\t%d times", n2-n1);
    k += snprintf  (buf + k, max - k, "\n");
    n1 = n2;
  }
  k += snprintf    (buf + k, max - k, "\n");

  return k;
}

int IIRFilter::print_S_plane (char * buf, int max) {
  int k = 0;
  k += snprintf (buf + k, max - k, "S-plane zeros:\n");
  k += printpz  (buf + k, max - k, splane.zeros, splane.numzeros);
  k += snprintf (buf + k, max - k, "S-plane poles:\n");
  k += printpz  (buf + k, max - k, splane.poles, splane.numpoles);
  return k;
}
int IIRFilter::print_Z_plane (char * buf, int max) {
  int k = 0;
  k += snprintf (buf + k, max - k, "Z-plane zeros:\n");
  k += printpz  (buf + k, max - k, zplane.zeros, zplane.numzeros);
  k += snprintf (buf + k, max - k, "Z-plane poles:\n");
  k += printpz  (buf + k, max - k, zplane.poles, zplane.numpoles);
  return k;
}
