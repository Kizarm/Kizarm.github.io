#ifndef POLEGRAPH_H
#define POLEGRAPH_H

#include <QWidget>
struct pzrep;

class PoleGraph : public QWidget {
  Q_OBJECT
  public:    
    PoleGraph  (QWidget* parent);
    //void setPolesZeros (double* poleRe, double* poleIm, double* zero, int n);
    void setPolesZeros (pzrep * p);
    ~PoleGraph ();
  protected:
    void paintEvent (QPaintEvent*);
    void plotPole (const QPointF& pt, QPainter& painter);
    void plotZero (const QPointF& pt, QPainter& painter);
  private:
    QWidget*   parent;
    QSize      size;
    // QPixmap    bg;
    QMatrix    matrix;
    QVector<QPointF>  poles;
    QVector<QPointF>  zeros;
    int        npoles, nzeros;
    double     zoom;
};

#endif // POLEGRAPH_H
