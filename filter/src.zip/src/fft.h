/***************************************************************************
 *   Copyright (C) 2009 by Mrazik   *
 *   mraz@seznam.cz   *
 ***************************************************************************/
#ifndef FFT_H
#define FFT_H

#include "complex.h"
/**
\class FFT

\author Mrazik <mraz@seznam.cz>

\brief Rychlá Fourierova transformace

Výpočet komplexní Fourierovy transformace pomocí algoritmu FFT.
Používá se rekurzívní volání #FR ()
*/
class FFT {
  private:
    //complex*  tmp;            //!< dočasná data pro výpočet
    //complex*  data;           //!< ukazatel na zpracovávaná data
    double*   stab;           //!< tabulka goniometrické funkce sinus pro FFT
    double*   ctab;           //!< tabulky goniometrické funkce kosinus pro FFT
    int       N;              //!< N=2^m počet koeficientů
    int       M;              //!< m = řád transformace
  protected:
    // rekurzivni funkce
    /**
     * Rekurzívní funkce výpočtu FFT
     * @param x ukazatel na data
     * @param rad řád transformace, musí být dělitelný 2^n
     */
    void        FR      (complex * x, int rad);
  public:
    /**
     * Konstruktor
     * @param  len délka bloku dat (musí být dělitelná 2^n)
     */
    FFT         (int len);
    void        F       (complex * data);               //!< transformace        T->F
    void        T       (complex * data);               //!< zpetna transformace F->T
    /**
     * Destruktor
     */
    ~FFT        ();

};

#endif
