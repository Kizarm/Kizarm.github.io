#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class Ui_MainWindow;
class IIRFilter;
class FreqGraph;
class PoleGraph;
class ImpulseGraph;
class TextWindow;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow  (QWidget *parent = 0);
    ~MainWindow ();
protected:
    void CreateCode (void);

//  void resizeEvent ( QResizeEvent * event );
public slots:
    void Bilinear  (bool);
    void AddZero   (bool);
    void setLPtype (void);
    void setBPtype (void);
    void setBStype (void);
    void setHPtype (void);
    void setCheb   (void);
    void setButt   (void);
    void setBess   (void);
    void setOrder  (int);
    void setFmin   (double);
    void setFmax   (double);
    void setRipple (double);
    void Design    (void);
    void setZero   (double);
    
    void Exit (void);
    void Save (void);
private:
    Ui_MainWindow   * ui;
    IIRFilter       * iir;
    FreqGraph       * fg;
    PoleGraph       * pg;
    ImpulseGraph    * ig;
    TextWindow      * tw;
    double          fs;
    char            * iir_code;
    int             code_len;
};

#endif // MAINWINDOW_H
