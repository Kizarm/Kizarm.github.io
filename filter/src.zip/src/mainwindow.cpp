#include <locale.h>
#ifndef EMSCRIPTEN
 #include <QFileDialog>
 #include <QSettings>
#endif // EMSCRIPTEN
#include <QTime>
#include <QPainter>

#include "mainwindow.h"
#include "IIRFilter.h"
#include "freqgraph.h"
#include "polegraph.h"
#include "impulsegraph.h"
#include "TextWindow.h"
#include "ui_mainwindow.h"

#undef  qDebug
#define qDebug(p, ...)

MainWindow::MainWindow (QWidget *parent)
    : QMainWindow (parent) {
  setlocale (LC_NUMERIC, "POSIX");
  iir_code = NULL;
  code_len    = 0;
  iir = new IIRFilter;
  //iir->setFreqPoints (512);
  ui  = new Ui_MainWindow;
  ui->setupUi (this);
  
  ui->tabWidget->setMinimumHeight(600);
  fg = new FreqGraph    (this);
  ig = new ImpulseGraph (this);
  pg = new PoleGraph    (this);
  tw = new TextWindow   (this);
  ui->tabWidget->addTab (fg, "Frequency");
  ui->tabWidget->addTab (ig, "Impulse");
  ui->tabWidget->addTab (pg, "Poles+Zeros");
  ui->tabWidget->addTab (tw, "Description");
  
  setWindowTitle (QString("IIR Filter Design"));
  ui->ordBox->setMaximum (16);
  fs = 8000.0f;
  ui->fromSb->setMaximum  (0.5f * fs);
  ui->toSb->setMaximum    (0.5f * fs);
  ui->spinZero->setMaximum(0.5f * fs);
  
  connect (ui->typeLP, SIGNAL(clicked(bool)), this, SLOT (setLPtype()));
  connect (ui->typeBP, SIGNAL(clicked(bool)), this, SLOT (setBPtype()));
  connect (ui->typeBS, SIGNAL(clicked(bool)), this, SLOT (setBStype()));
  connect (ui->typeHP, SIGNAL(clicked(bool)), this, SLOT (setHPtype()));
  connect (ui->proBut, SIGNAL(clicked(bool)), this, SLOT (setButt()));
  connect (ui->proCeb, SIGNAL(clicked(bool)), this, SLOT (setCheb()));
  connect (ui->proBes, SIGNAL(clicked(bool)), this, SLOT (setBess()));
  
  connect (ui->design, SIGNAL(clicked(bool)), this, SLOT (Design ()));
  
  connect (ui->ripSB,  SIGNAL(valueChanged(double)), this, SLOT (setRipple(double)));
  connect (ui->ordBox, SIGNAL(valueChanged(int)),    this, SLOT (setOrder (int   )));
  connect (ui->fromSb, SIGNAL(valueChanged(double)), this, SLOT (setFmin  (double)));
  connect (ui->toSb,   SIGNAL(valueChanged(double)), this, SLOT (setFmax  (double)));
  connect (ui->spinZero, SIGNAL(valueChanged(double)), this, SLOT(setZero(double)));
  
  connect (ui->boxBilinear, SIGNAL(clicked(bool)), this, SLOT(Bilinear(bool)));
  connect (ui->boxZero,     SIGNAL(clicked(bool)), this, SLOT(AddZero (bool)));

  connect (ui->actionExit, SIGNAL(triggered(bool)),  this, SLOT(Exit()));
  connect (ui->actionSave, SIGNAL(triggered(bool)),  this, SLOT(Save()));
  
  ui->typeLP->setChecked (true);
  setLPtype();
  ui->proCeb->setChecked (true);
  setCheb  ();
  ui->ordBox->setValue(3);
  ui->ripSB->setValue (1);
  ui->fromSb->setValue(0);
  ui->toSb->setValue  (1000);
  ui->spinZero->setValue  (1000);
  ui->spinZero->setEnabled(false);
  ui->actionSave->setEnabled (false);
  ui->boxBilinear->setChecked(true);
}
void MainWindow::setZero (double f) {
  iir->setAdZeroF (f);
}

void MainWindow::AddZero (bool b) {
  iir->addZero (b);
  ui->spinZero->setEnabled (b);
}
void MainWindow::Bilinear (bool b) {
  qDebug("Bilinear:%d", !b);
  iir->setMatched (!b); // default=checked, matched=false, use Bilinear transforms
}


void MainWindow::Design (void) {
  double * g, * gf;
  iir->compute();
  g = iir->filterGain();
  gf= iir->filterGainFFT();
  // iir->printCoefs();
  fg->setPolygon (g, iir->getFreqPoints());
  fg->setPolygonF(gf,iir->getFreqPoints());
  delete [] g;
  delete [] gf;
  pg->setPolesZeros (iir->GetZPlane());
  iir->ImpulseResponse ();
  ig->setResponse   (iir->getImpX(), iir->getImpY(), iir->getFreqPoints());
  fg->update();
  ig->update();
  pg->update();
  ui->actionSave->setEnabled (true);
  
  CreateCode();
  tw->SetCode(iir_code);
  
  //iir->test();
}

void MainWindow::setHPtype (void) {
  ui->fromSb->setEnabled(true);
  ui->toSb->setValue    (0.5f * fs);
  ui->toSb->setEnabled  (false);
  iir->setFilterType(HP);
}

void MainWindow::setBPtype (void) {
  ui->fromSb->setEnabled(true);
  ui->toSb->setEnabled  (true);
  iir->setFilterType(BP);
}
void MainWindow::setBStype (void) {
  ui->fromSb->setEnabled(true);
  ui->toSb->setEnabled  (true);
  iir->setFilterType(BS);
}

void MainWindow::setLPtype (void) {
  ui->fromSb->setValue  (0.0f);
  ui->fromSb->setEnabled(false);
  ui->toSb->setEnabled  (true);
  iir->setFilterType(LP);
}

void MainWindow::setButt (void) {
  ui->ripSB->setEnabled(false);
  iir->setPrototype (BUTTERWORTH);
}

void MainWindow::setCheb (void) {
  ui->ripSB->setEnabled(true);
  iir->setPrototype (CHEBYSHEV);
}
void MainWindow::setBess (void) {
  ui->ripSB->setEnabled(false);
  iir->setPrototype (BESSEL);
}

void MainWindow::setFmin (double f) {
  iir->setFreq1(f);
}

void MainWindow::setFmax (double f) {
  iir->setFreq2(f);
}

void MainWindow::setOrder (int n) {
  iir->setOrder(n);
}

void MainWindow::setRipple (double r) {
  iir->setRipple(r);
}

void MainWindow::Exit (void) {
  close ();
}

void MainWindow::Save (void) {
#ifndef EMSCRIPTEN
  QString name = QFileDialog::getSaveFileName(this, QString("Save Coeficients"), QString ("."),
                 QString("Header files (*.h)"));
  if (name.isEmpty()) return;
  QFile file (name);
  if (!file.open (QIODevice::WriteOnly)) return;
  file.write(iir_code, code_len);
  file.close();
#endif // EMSCRIPTEN
}
void MainWindow::CreateCode (void) {
  if (iir_code) delete [] iir_code;
  const int code_max = 0x4000;
  iir_code = new char [code_max];
  setlocale(LC_NUMERIC, "C");

  code_len = iir->print_design (iir_code, code_max);
}
/*
void MainWindow::resizeEvent (QResizeEvent* event) {
  QWidget::resizeEvent (event);

  QSize ms = ui->tabWidget->size();
  QSize ts = ui->tab1->size();
  qDebug ("TAB: %dx%d, TEXT: %dx%d", ms.width(), ms.height(), ts.width(), ts.height());

}
*/

MainWindow::~MainWindow () {
  delete iir;
  delete ui;
  delete fg;
  delete ig;
  delete pg;
  delete tw;
  if (iir_code) delete [] iir_code;
}

