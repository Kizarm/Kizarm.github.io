/***************************************************************************
 *   Copyright (C) 2009 by Mrazik   *
 *   mraz@seznam.cz   *
 ***************************************************************************/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "fft.h"

FFT::FFT (int len) {
  double ang = -M_PI;
  M = len;
  N = 1 << M;
  /*
  if (N != getSize()) {
    printf ("Chybna delka dat");
  }
  data = getData ();
  */
  stab = new double  [M];
  ctab = new double  [M];
  for (int i=0; i<M; i++) {
    stab[i] = sin (ang);
    ctab[i] = cos (ang);
    ang /= 2;
  }
  //tmp = new complex [N];
}

// parametry u tt. funkce jsou potreba pro rekursi
void    FFT::FR       (complex * x, int rad) {
  int     k,l,Half;                 // pomocne promenne
  complex t;
  
  // zakladni pripad
  if (rad == 0) {
    return;
  }
  rad -= 1;
  Half = 1 << rad;                    // polovicni krok
  // kupodivu to chodi i takhle (pole je asi ve stacku)
  complex even [Half];                // suda a
  complex odd  [Half];                // licha cast
  for (k = 0; k < Half; k++) {        // vsechna vstupni data
    l  = 2*k;                         // suda
    even[k] = x[l];                   // dej do even
    l += 1;                           // licha
    odd [k] = x[l];                   // dej do odd
  }
  l    = rad;
  // rekurzivni volani teto funkce pro sudou a lichou cast
  FR (even, l);
  FR (odd,  l);

  complex wk (1.0,0.0);               // komplexni jednotka e^0i = 1 + 0i
  complex rej (ctab[l], stab[l]);     // rej = e^i*ang
  for (k = 0; k < Half; k++) {
    t    = wk * odd[k];
    l    = k;
    x[l] = even[k] + t;               // y[dolni] = even + wk*odd
    l   += Half;
    x[l] = even[k] - t;               // y[horni] = even - wk*odd
    // "pootoceni" komplexni jednotky => wk *= rej (rychlejsi nez sin,cos)
    wk = wk * rej;
  }
}

void    FFT::F (complex * data) {
  FR (data, M);
}
void    FFT::T (complex * data) {
  int i;
  for (i = 0; i < N; i++)
    // komlexni sdruzeni
    cconj (data[i]);

  // normalni FFT
  FR (data, M);

  for (i = 0; i < N; i++) {
    // komlexni sdruzeni
    cconj (data[i]);
    // normalizace se pri SFT nepouzije
    data[i].norm ((double) N);
  }
}


FFT::~FFT() {
  delete []stab;
  delete []ctab;
  //delete [] tmp;
}


