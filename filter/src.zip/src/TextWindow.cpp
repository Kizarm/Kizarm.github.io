#include "TextWindow.h"

TextWindow::TextWindow (QWidget * p) : QTextEdit (p) {
  parent = p;
  size = parent->size();
  setReadOnly (true);
  
  setFontFamily ("Monospace");
  setFontPointSize (10);
}

TextWindow::~TextWindow() {

}
void TextWindow::SetCode (const char * code) {
  QString s (code);
  setText (s);
}
