#ifndef TEXTWINDOW_H
#define TEXTWINDOW_H
#include <QTextEdit>

class TextWindow : public QTextEdit {
  Q_OBJECT
  public:
    TextWindow (QWidget * parent);
    ~TextWindow();
    
    void SetCode (const char * code);
  private:
    QSize      size;
    QWidget *  parent;
};

#endif // TEXTWINDOW_H
