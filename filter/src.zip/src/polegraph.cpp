#include "polegraph.h"
#include "IIRFilter.h"
#include <qevent.h>
#include <QPainter>


PoleGraph::PoleGraph (QWidget* p) : QWidget (p) {
  parent = p;
  size   = QSize(512,512);
  poles.clear();
  zeros.clear();
  zoom   = 250.0f;
  matrix = QMatrix (1,0,0,-1,0,0);
  matrix.translate (zoom + 6.0f, -zoom - 6.0f);
  npoles = nzeros = 0;
}

PoleGraph::~PoleGraph() {

}
void PoleGraph::setPolesZeros (pzrep * pz) {
  QPointF p,z;
  z.setY(0.0f);
  npoles = pz->numpoles;
  nzeros = pz->numzeros;
  poles.resize (npoles);
  zeros.resize (nzeros);
  for (int i=0; i<npoles; i++) {
    p.setX (zoom * pz->poles[i].re);
    p.setY (zoom * pz->poles[i].im);
    poles.replace (i, p);
  }
  for (int i=0; i<nzeros; i++) {
    z.setX (zoom * pz->zeros[i].re);
    z.setY (zoom * pz->zeros[i].im);
    zeros.replace (i, z);
  }
}

void PoleGraph::plotPole (const QPointF& pt, QPainter& painter) {
  const double delta = 2.0f;
  QPointF ld = pt + QPointF (-delta, -delta);
  QPointF ph = pt + QPointF (+delta, +delta);
  QPointF lh = pt + QPointF (-delta, +delta);
  QPointF pd = pt + QPointF (+delta, -delta);
  painter.drawLine (ld, ph);
  painter.drawLine (lh, pd);
}

void PoleGraph::plotZero (const QPointF& pt, QPainter& painter) {
  const double delta = 4.0f;
  painter.drawEllipse (pt, delta, delta);
}

void PoleGraph::paintEvent (QPaintEvent * e) {
  QRect r = e->rect();
  size = QSize (r.width(), r.height());
  double mx = (double) r.width()  / 512.0;
  double my = (double) r.height() / 512.0;
  double mz = qMin(mx, my);
  matrix.setMatrix(mz,0,0,-mz, 0, 0);
  matrix.translate (zoom + 6.0f, -zoom - 6.0f);
  QPixmap bg (size);
  bg.fill(QColor(255,255,224,255));
  
  int i, max = (int) zoom;
  QPainter painter (this);
  painter.drawPixmap(0,0,bg);
  painter.setMatrix (matrix);
  QPen p;
  p.setStyle (Qt::DashDotDotLine);
  p.setWidth (1);
  p.setColor (QColor(192,192,192));
  painter.setPen (p);
  for (i=-max; i<=max; i+= 20) {
    painter.drawLine (-max, i, max, i);
    painter.drawLine (i, -max, i, max);
  }
  p.setStyle (Qt::SolidLine);
  p.setColor (QColor(0,0,0));
  painter.setPen (p);
  max += 20;
  painter.drawLine (-max, 0, max, 0);
  painter.drawLine (0, -max, 0, max);
  
  p.setWidth (2);
  p.setColor (QColor(0,255,0));
  painter.setPen (p);
  painter.setRenderHint (QPainter::Antialiasing, true);
  painter.drawEllipse (QPointF(), zoom, zoom);
  
  if (!npoles) return;
  p.setColor (QColor(0,0,255));
  painter.setPen (p);
  for (i=0; i<npoles; i++) plotPole (poles.at(i), painter);
  if (!nzeros) return;
  p.setColor (QColor(255,0,0));
  painter.setPen (p);
  for (i=0; i<nzeros; i++) plotZero (zeros.at(i), painter);
}
