#ifndef FREQGRAPH_H
#define FREQGRAPH_H

#include <QWidget>


class FreqGraph : public QWidget {
  Q_OBJECT
  public:  
    FreqGraph  (QWidget* parent);
    void setPolygon (double * pt, int size);
    void setPolygonF(double * pt, int size);
    ~FreqGraph ();
  protected:
    void paintEvent (QPaintEvent*);
  private:
    QWidget*   parent;
    QSize      size;
    // QPixmap    bg;
    QMatrix    matrix;
    QPolygonF* poly;
    QPolygonF* polf;
};

#endif // FREQGRAPH_H
