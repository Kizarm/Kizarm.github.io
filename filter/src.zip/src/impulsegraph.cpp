#include <stdio.h>
#include <qevent.h>
#include <QPainter>
#include "impulsegraph.h"


ImpulseGraph::ImpulseGraph (QWidget* p) : QWidget (p) {
  parent = p;
  points = 0;
  in  = NULL;
  out = NULL;
  size   = QSize(512,512);
  matrix = QMatrix (1,0,0,-1,0,size.height()/2);
}

ImpulseGraph::~ImpulseGraph() {
  if (in)  delete in;
  if (out) delete out;
}

void ImpulseGraph::setResponse (double* x, double* y, int n) {
  if (in)  delete in;
  if (out) delete out;
  points = n;
  // printf ("%d\n", points);
  in  = new QPolygonF (points);
  out = new QPolygonF (points);
  QPointF pt;
  for (int i=0; i<points; i++) {
    pt.setX (i);
    pt.setY (x[i]);
    in->replace  (i, pt);
    pt.setY (y[i]);
    out->replace (i, pt);
  }
}

void ImpulseGraph::paintEvent (QPaintEvent * e) {
  QRect r = e->rect();
  size = QSize (r.width(), r.height());
  double mx = (double) r.width()  / 512.0;
  double my = (double) r.height() / 512.0;
  matrix.setMatrix(mx,0,0,-my,10, r.height()/2.0);
  
  QPainter painter (this);
  QPen p;
  p.setWidth (2);
  QPixmap bg (size);
  bg.fill(QColor(224,255,255,255));
  painter.drawPixmap (0,0,bg);
  
  painter.setMatrix(matrix);
  if (!points) return;
  painter.setRenderHint (QPainter::Antialiasing, true);
  p.setColor (QColor(255,0,0));
  painter.setPen (p);
  painter.drawPolyline (*in);
  p.setColor (QColor(0,0,255));
  painter.setPen (p);
  painter.drawPolyline (*out);
}

