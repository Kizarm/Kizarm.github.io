#ifndef IMPULSEGRAPH_H
#define IMPULSEGRAPH_H

#include <QWidget>


class ImpulseGraph : public QWidget {
  Q_OBJECT
  public:
    ImpulseGraph (QWidget* parent);
    void setResponse (double* x, double* y, int n);
    ~ImpulseGraph ();
  protected:
    void paintEvent (QPaintEvent*);
  private:
    QWidget*   parent;
    QSize      size;
    QPolygonF* in;
    QPolygonF* out;
    QMatrix    matrix;
    int        points;
};

#endif // IMPULSEGRAPH_H
