#include <stdio.h>
#include <qevent.h>
#include <qpen.h>
#include <qpainter.h>
#include "freqgraph.h"


FreqGraph::FreqGraph (QWidget* p) : QWidget (p) {
  parent = p;
  poly   = NULL;
  polf   = NULL;
  size   = QSize(512,512);
  matrix.setMatrix(1,0,0,-1,10,size.height()-10);
}

void FreqGraph::paintEvent (QPaintEvent * e) {
  QRect r = e->rect();
  size = QSize (r.width(), r.height());
  // printf ("r:%d,%d\n", r.width(), r.height());
  int i,j,min,max;
  QPainter painter (this);
  QPen p1, p2;
  p1.setWidth(4);
  p1.setStyle(Qt::SolidLine);
  p1.setColor(QColor(255,0,0));
  p2.setWidth(2);
  p2.setStyle(Qt::SolidLine);
  p2.setColor(QColor(0,0,255));
  QFont f = parent->font();
  f.setPixelSize(14);
  f.setBold(true);
  painter.setFont(f);

  QPixmap bg (size);
  bg.fill(QColor(224,255,224,255));
  painter.drawPixmap (0,0,bg);
  painter.drawText (50,15, QString("X axis -> freq  from 0 to fs/2"));
  painter.drawText (50,30, QString("Y axis -> atten from -100dB to 0"));
  
  painter.drawText (350,15, QString("Theoretic"));
  painter.drawText (350,30, QString("Computed"));
  painter.setPen   (p1);
  painter.drawLine (300,10,340,10);
  painter.setPen   (p2);
  painter.drawLine (300,25,340,25);

  double mx = (double) r.width()  / 512.0;
  double my = (double) r.height() / 512.0;
  matrix.setMatrix(mx,0,0,-my,10, r.height()-10);
  painter.setMatrix (matrix);
  QPen p;
  p.setColor(QColor(192,192,192));
  p.setStyle(Qt::DashDotLine);
  p.setWidth(1);
  painter.setPen (p);
  max = 500;
  min = 0;
  j   = min;
  for (i=0; i<=20; i++) {
    painter.drawLine (0,j,max,j);
    j += 20;
  }
  max = j - 20;
  j   = 0;
  for (i=0; i<=20; i++) {
    painter.drawLine (j,min,j,max);
    j += 25;
  }
  min = j - 25;
  p.setColor(QColor(0,0,0));
  p.setStyle(Qt::SolidLine);
  p.setWidth(1);
  painter.setPen(p);
  painter.drawLine (0,0,min+20,0);
  painter.drawLine (0,0,0,max+20);
  painter.setPen(p1);
  painter.setRenderHint (QPainter::Antialiasing, true);
  if (poly) painter.drawPolyline (*poly);
  painter.setPen(p2);
  if (polf) painter.drawPolyline (*polf);
  // printf("min=%d, max=%d\n", min, max);
}

void FreqGraph::setPolygon (double* pt, int size) {
  if (poly) delete poly;
  poly = new QPolygonF (size);
  for (int i=0; i<size; i++) {
    QPointF pf (i, 4.0f * pt[i] + 400.0f);
    poly->replace(i, pf);
  }
}
void FreqGraph::setPolygonF (double * pt, int size) {
  if (polf) delete polf;
  polf = new QPolygonF (size);
  for (int i=0; i<size; i++) {
    QPointF pf (i, 4.0f * pt[i] + 400.0f);
    polf->replace(i, pf);
  }
}

FreqGraph::~FreqGraph() {
  if (poly) delete poly;
  if (polf) delete polf;
}
