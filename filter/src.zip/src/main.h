#ifndef MAIN_H_DEFINED
#define MAIN_H_DEFINED

#include <QApplication>
#include "mainwindow.h"
#include <qstyle.h>

/**
 * @mainpage Výpočet IIR filtru.
 * 
 * @section s01 Motivace.
 * Pro jednoduchou filtraci signálu v časové oblasti je docela výhodné používat
 * IIR (Infinite Impulse Response) filtry. Pokud známe jejich omezení, zbývá spočítat
 * koeficienty. Je na to spousta programů na webu, například
 * <a href="https://www-users.cs.york.ac.uk/~fisher/mkfilter/trad.html"> tento</a>.
 * Z těchto stránek vychází i zde uvedený program. Fakticky se to počítá stejně jako
 * klasický filtr z diskrétních prvků (kondenzátorů a indukčností), jen se nakonec
 * provede bilineární transformace z vyjádření v Laplaceově obrazu do Z-obrazu.
 * Jak to funguje (malý matematický background) jsem kdysi popisoval pro realizaci
 *  <a href="../pid/html/index.html">PID regulátoru</a>.
 * 
 * @section s02 K vyzkoušení.
 * Zde je <a href="../bin/filter.html">WebAssembly aplikace</a>. Není to celkem k ničemu,
 * ale umožňuje interaktivně vyzkoušet odezvy na změnu různých voleb. Program používá
 * fixní vzorkovací frekvenci fs=8000Hz, nechtělo se mi dohledávat všechny závislosti.
 * I v původním programu se frekvence zlomu přepočítávají vzhledem ke vzorkování ručně.
 *
 * @section s03 Ke stažení.
 * <a href="../src.zip">Zdrojáky</a> v Qt4/5, nativní aplikace funguje lépe. Lze z ní vyexportovat
 * fungující C++ kód, který realizuje zadaný filtr. WebAssembly tohle zatím neumí.
 * */

#endif // MAIN_H_DEFINED
