#ifndef IIRFilter_H
#define IIRFilter_H
#include "complex.h"

enum filtTypes {
  LP = 1,
  HP = 2,
  BP = 3,
  BS = 4,
  BUTTERWORTH = 0x10,
  CHEBYSHEV   = 0x20,
  BESSEL      = 0x40
};

static const unsigned MaxOrder = 0x100;
static const unsigned MAXPZ    = MaxOrder;

struct IIR_Design {
  int      order;
  double   gain;
  double a [MaxOrder];
  double b [MaxOrder];
};
struct pzrep {
  complex poles[MAXPZ], zeros[MAXPZ];
  int numpoles, numzeros;
};

class IIRFilter {

  public:
    void print (void);
  private:
    filtTypes prototype;
    int filterType, freqPoints;
    double fp1, fp2, fN, ripple, rate;
    double   xx[MaxOrder];
    double   yy[MaxOrder];
    double * ImpX;
    double * ImpY;
    IIR_Design designed;

    pzrep    splane, zplane;
    double   raw_alpha1, raw_alpha2, raw_alphaz;
    complex  dc_gain, fc_gain, hf_gain;
    double   warped_alpha1, warped_alpha2, chebrip;
    // bool     infq;
    unsigned polemask;
    bool     use_matched;  // false = bilinear
    bool     add_zero;     // zatim nic
  public:
    IIRFilter();
    ~IIRFilter();
    double run (double x0);
    void   ImpulseResponse (void);

    void    setAdZeroF     (double f) {
      raw_alphaz = f / rate;
    }
    void    setMatched     (bool b) {
      use_matched = b;
    }
    void    addZero        (bool b) {
      add_zero = b;
    }
    IIR_Design * GetDesign (void) {
      return & designed;
    }
    pzrep * GetSPlane (void) {
      return & splane;
    }
    pzrep * GetZPlane (void) {
      return & zplane;
    }
    double * getImpX (void) {
      return ImpX;
    }
    double * getImpY (void) {
      return ImpY;
    }
    void setPrototype (int p) {
      prototype = (filtTypes) p;
    }

    int getPrototype() {
      return (int) prototype;
    }
    int getFilterType() {
      return filterType;
    }

    void setFilterType (int ft) {
      filterType = ft;
      //if ( (filterType == BP) && odd (designed.order)) designed.order++;
    }

    void setOrder (int n) {
      if (n < 0) n = -n;
      designed.order = n;
      //if ( (filterType == BP) && odd (designed.order)) designed.order++;
    }

    int getOrder() {
      return designed.order;
    }

    void setRate (double r) {
      rate = r;
      fN = 0.5f * rate;
    }

    double getRate() {
      return rate;
    }

    void setFreq1 (double fpi) {
      this->fp1 = fpi;
    }

    double getFreq1() {
      return fp1;
    }

    void setFreq2 (double fpi) {
      this->fp2 = fpi;
    }

    double getFreq2() {
      return fp2;
    }

    void setRipple (double r) {
      ripple = r;
    }

    double getRipple() {
      return ripple;
    }
/*
    void setFreqPoints (int f) {
      freqPoints = f;
    }
*/
    int getFreqPoints() {
      return freqPoints;
    }

    double sqr (double x) {
      return x * x;
    }
    bool odd (int n) {
      // returns true if n odd
      return (n % 2) != 0;
    }
  protected:
    void createXXYY (void);
    
    void  compute_s (void);
    void  prewarp   (void);
    void  normalize (void);
    void  compute_z_mzt (void);
    void  compute_z_blt (void);
    void  expandpoly    (void);
    void  clear         (void);
    void  add_extra_zero(void);
    
    void choosepole     (complex z);
    int  print_code     (char * buf, int max);
    int  print_Z_plane  (char * buf, int max);
    int  print_S_plane  (char * buf, int max);
    int  printpz        (char * buf, int max, complex *pzvec, int num);
    int  prcomplex      (char * buf, int max, complex z);
  public:
    void    compute        (void);
    double * filterGain    (void);
    double * filterGainFFT (void);
    int     print_design   (char * buf, int max);
    
    void test (void);
};

#endif // IIRFilter_H
