class Tag:
  def __init__(self, n, v):
      self.name  = n
      self.value = v
  def to_str (self):
    return ' ' +  self.name + '=\"' + self.value + '\"'

class Element:
  def __init__(self, n, v=None):
      self.name   = n
      self.value  = v
      self.tags   = []
      self.childs = []
      self.id = 0
  def addE (self, e):
    self.childs.append(e)
  def addT (self, t):
    self.tags.append(t)
  def addF (self, f):
    t = Tag ('class','formulaDsp')
    for p in f:
      n = Element('p', '\\[' + p + '\\]')
      n.addT(t)
      self.addE(n)
    
  def to_str (self):
    s = self.indent()
    s+= '<' + self.name
    for n in self.tags: s += n.to_str()
    s+= '>'
    if self.value != None: s += self.value
    for n in self.childs:  s += n.to_str()
    s+= self.indent()
    s+= '</' + self.name + '>'
    return s
  def cal (self, k=0):
    self.id = k
    for n in self.childs: n.cal (k+2)
  def indent (self):
    s = '\n'
    for n in range (0, self.id): s += ' '
    return s

def set_root (e, root):
  scfg = 'MathJax.Hub.Config({\n    extensions: [\"tex2jax.js\"],\n    jax: [\"input/TeX\",\"output/HTML-CSS\"],\n    tex2jax: {inlineMath: [[\'$\',\'$\']]},\n    displayAlign: \"left\"});'
  head = Element('head')
  meta = Element('META')
  titl = Element('title', 'Metrika')
  s1 = Element('script', scfg)
  s2 = Element('script')
  s1.addT(Tag('type','text/x-mathjax-config'))
  s2.addT(Tag('type','text/javascript'))
  s2.addT(Tag('src','https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js'))
  meta.addT(Tag('HTTP-EQUIV','CONTENT-TYPE'))
  meta.addT(Tag('CONTENT','text/html; charset=utf-8'))
  head.addE(meta)
  head.addE(titl)
  head.addE(s1)
  head.addE(s2)
  e.addE (head)
  body = Element('body')
  body.addE(root)
  e.addE (body)
  e.cal()
def html_head ():
  s = '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">'
  return s
