#!/usr/bin/env python
# -*- coding: utf-8 -*-

preamble = """
Příklad ukazuje jak spočítat Schwarzschildovu metriku v jazyce python. Pro podobné
symbolické výpočty je určena knihovna <a href="https://www.sympy.org/cs/">SymPy</a>, 
která ku podivu zvládá i takovéto poměrně komplikované výpočty u nichž při ručním způsobu
snadno uděláme chybu (i když tady samozřejmě také, ale jde to o něco hůř). Mohla by to
tedy být jakási alternativa k programům jako je Wolfram Mathematica a jiné. Už proto,
že python je hodně obecný a tak umožňuje integrovat tyto výpočty do širších souvislostí.
Zde příkladně integruje výpočet a zobrazení jeho průběhu v html stránce. Je zajímavé, že původní
<a href="https://github.com/sympy/sympy/blob/master/examples/advanced/relativity.py">zdroj</a>,
ze kterého jsem čerpal jak nakládat s tenzory počítá tu výslednou metriku špatně - pokládá Ricciho tenzor
rovný nule, a přesto mu vychází správné řešení.
Tento příklad je tedy jakési doplnění především publikace pana profesora Kulhánka
<a href="https://www.aldebaran.cz/studium/otr.pdf">[1]Obecná relativita</a>, kapitola 10, kde se
podrobný výpočet z pochopitelných důvodů neprovádí.
"""

from sympy import (exp, symbols, Symbol, sin, Rational, Derivative, dsolve, Function,
                  Matrix, Eq, pprint, Pow, classify_ode, solve, latex, simplify, oo)
from html import *

gref   = '<a href="https://www.aldebaran.cz/studium/otr.pdf">[1]</a>'
eqt87  = '$ \\Gamma^{\\gamma}_{\\alpha\\beta} = \\frac{1}{2} g^{\\gamma\\xi} (g_{\\xi\\alpha,\\beta} + g_{\\xi\\beta,\\alpha} - g_{\\alpha\\beta,\\xi}) $'
eqt170 = '$ R^{\\eta}_{\\beta\\gamma\\delta} = \\Gamma^{\\eta}_{\\beta\\delta,\\gamma} - \\Gamma^{\\eta}_{\\beta\\gamma,\\delta} ' + \
         '+ \\Gamma^{\\xi}_{\\beta\\delta}\\Gamma^{\\eta}_{\\xi\\gamma} - \\Gamma^{\\xi}_{\\beta\\gamma}\\Gamma^{\\eta}_{\\xi\\delta} $'

def CreateHTML (filename, html):
    s = html_head ()
    r = Element ('html')
    set_root (r, html)
    s += r.to_str()
    # print s
    file = open (filename,'w')
    file.write(s)
    file.close()

class MT(object):           # metrika s hornimi i spodnimi indexy (inverzi matice)
    def __init__(self, m):
        self.gdd = m
        self.guu = m.inv()

    def __str__(self):
        return "g_dd =\n" + str(self.gdd)

    def dd(self, i, j):
        return self.gdd[i, j]

    def uu(self, i, j):
        return self.guu[i, j]


class Gama(object):              # Christoffel symbols from metric
    def __init__(self, g, x):
        self.g = g    # MT
        self.x = x    # souradnice

    def udd(self, gamma, alpha, beta):
        g = self.g
        x = self.x
        r = 0
        for ksi in [0, 1, 2, 3]:
            r += g.uu(gamma, ksi)/2 * (g.dd(ksi, alpha).diff(x[beta]) + g.dd(ksi, beta).diff(x[alpha]) - g.dd(alpha, beta).diff(x[ksi]))
        return r

    def pprint (self, i, j, k):
        pprint(Eq(Symbol('Gamma^%i_%i%i' % (i, j, k)), self.udd(i, j, k)))
    def latex  (self, i, j, k):
        return latex(Eq(Symbol('Gamma^%i_%i%i' % (i, j, k)), self.udd(i, j, k)))


class Riemann(object):
    def __init__(self, G, x):
        self.G = G          # Christoffel
        self.x = x

    def uddd(self, eta, beta, gamma, delta):
        G = self.G
        x = self.x
        r = G.udd(eta, beta, delta).diff(x[gamma]) - G.udd(eta, beta, gamma).diff(x[delta])
        for xi in [0, 1, 2, 3]:
            r += G.udd(xi, beta, delta) * G.udd(eta, xi, gamma)  \
               - G.udd(xi, beta, gamma) * G.udd(eta, xi, delta)
        return r

class Ricci(object):
    def __init__(self, R, x):
        self.R = R          # Riemann
        self.x = x
        self.g = R.G.g
    def dd(self, mu, nu):
        R = self.R
        x = self.x
        r = 0
        for lam in [0, 1, 2, 3]:
            r += R.uddd(lam, mu, lam, nu)
        return r
    def ud(self, mu, nu):
        r = 0
        for lam in [0, 1, 2, 3]:
            r += self.g.uu(mu, lam) * self.dd(lam, nu)
        return r.expand()
    def SC (self):
        r = 0;
        for i in [0,1,2,3]:
          r += self.ud(i,i)
        return r;
    def pprint (self, i, j):
        pprint(Eq(Symbol('R_%i%i' % (i, j)), self.dd(i, j)))
    def latex  (self, i, j):
        return latex(Eq(Symbol('R_%i%i' % (i, j)), simplify(self.dd(i, j))))

def printChristof (Gamma, html):
    text = 'Christoffelovy symboly.'
    print text
    form = []
    indexes = [0,1,2,3]
    for i in indexes:
      for j in indexes:
        for k in indexes:
          p = [i,j,k]
          f = Eq(0, Gamma.udd(i,j,k))
          if f != True:
            Gamma.pprint(i,j,k)
            form.append(Gamma.latex(i,j,k))
    text = '<h2>' + text + '</h2>'
    text+= '<p>'
    text+= 'Vzorec je z ' + gref + ', rovnice (87): ' + eqt87 + ' . Dále se pak tyto symboly používají k výpočtům Riemannova tenzoru. '
    text+= 'Vypíšeme jen nenulové členy.</p>'
    html.addE(Element('div', text))
    html.addF(form)
      
class Einstein(object):
    def __init__(self, R):
        self.R = R
        self.x = R.x
        self.g = R.g
        self.C = simplify (R.SC());
    def dd (self, mu, nu):
        G = self.R.dd (mu, mu) - self.C * self.g.dd(mu, nu) / 2
        return simplify (G)

def Schwarzschild():
    html  = Element ('div')
    nu  = Function("nu")
    lam = Function("lambda")
    t     = Symbol("t")
    r     = Symbol("r")
    theta = Symbol(r"theta")
    phi   = Symbol(r"phi")
    r0    = Symbol("r_0")
    
    A = lam(r)
    B = nu (r)
    gdd = Matrix((          # Initial metric
        (-A, 0, 0,    0                 ),
        ( 0, B, 0,    0                 ),
        ( 0, 0, r**2, 0                 ),
        ( 0, 0, 0,    r**2*sin(theta)**2)
    ))

    g = MT(gdd)
    X = (t, r, theta, phi)
    Gamma = Gama (g, X)
    Rmn   = Ricci(Riemann(Gamma, X), X)
    G     = Einstein (Rmn)

    html.addE (Element ('h1', 'Výpočet Schwarzschildovy metriky.'));    
    head = 'Počáteční metrika.'
    print  (head)
    pprint (gdd)
    text = '<p>'  + preamble
    text+= '</p>'
    text+= '<h2>' + head + '</h2>'
    text+= '<p>'
    text+= 'Vychází ze sférických souřadnic $ \\{ t, r, \\Theta, \\phi \\} $, přičemž r vlastně není radiální souřadnice ve zvoleném systému, '
    text+= 'ale jakýsi poloměr, který zachovává plochu koule $ 4\\pi r^2 $, symbol t zde má rozměr délky (správně by to tedy mělo být ct, '
    text+= 'což není podstatné, v $g_{00}$ by přibyla jen konstanta $c^2$). Je to tak pro snazší výpočet. Hledáme tedy funkce $ \\lambda(r), \\nu(r) $. '
    text+= 'Pro více informací proč se to dělá právě takto viz ' + gref + ' , kapitola 10.'
    text+= '</p>'
    html.addE(Element('div', text))
    html.addF(['g_{\\mu\\nu} = ' + latex(gdd)])
    
    print("-"*40)
    printChristof (Gamma, html)
    
    text = 'Ricciho tenzor.'
    print (text)
    for i in [0,1,2,3]:
      Rmn.pprint(i,i)
    print("-"*40)
    
    text = '<h2>' + text + '</h2>'
    text+= '<p>'
    text+= 'Výpočet je už dost komplikovaný. Nejprve spočteme Riemannův tenzor (256 složek) z ' + gref + ' rovnice (170): ' + eqt170
    text+= '. Pak jej zúžíme podle rovnice (174) : $ R_{\\alpha\\beta} = R^{\\xi}_{\\alpha\\xi\\beta} $ a máme výsledek. Vypíšeme nenulové členy.' 
    text+= '</p>'
    html.addE(Element('div', text))
    form = []
    for i in [0,1,2,3]:
      form.append(Rmn.latex(i,i))
    html.addF(form)
    
    text = 'Skalární křivost.'
    form = Eq(Symbol("R"), Rmn.SC())
    print  (text)
    pprint (form);
    text = '<h2>' + text + '</h2>'
    text+= '<p>'
    text+= 'Je už jen další zúžení Ricciho tenzoru podle (175): $ R = R^{\\xi}_{\\xi} $, '
    text+= 'které se dále používá v Einsteinových rovnicích. Pozor není to prostý součet výše uvedených členů, výpočet je o něco složitější '
    text+= '(zvýšení indexu pomocí metriky).</p>'
    html.addE(Element('div', text))
    html.addF([latex(form)])
    
    print("Solve Einstein's equations:")
    for i in [0,1]:
      pprint (Eq(Symbol('G_%i%i' % (i, i)), G.dd(i, i)))
    print("-"*40)
    text = 'Výpočet Einsteinovy rovnice $  G_{\\mu\\nu} = R_{\\mu\\nu} - \\frac{1}{2} R g_{\\mu\\nu} = \\frac{8\\pi G}{c^4}  T_{\\mu\\nu} $.'
    text = '<h2>' + text + '</h2>'
    text+= '<p> Je to vakuové řešení (hmotnost je jen ve "středu", tedy pro r=0), pravá strana T je tedy nulová. '
    text+= 'Použitelné rovnice jsou pouze na diagonále, zbytek jsou rovnosti typu 0=0</p>'
    form = []
    for i in [0,1,2,3]:
      form.append(latex(Eq(Symbol('G_%i%i' % (i, i)), G.dd(i, i))))
    html.addE(Element('div', text))
    html.addF(form)
    # Vlastní solver
    form = []
    print("Solving...")
    e = G.dd(0,0)
    e*= r**2 * nu(r)**2 / lam(r)  # zjednodus pro solver
    e = simplify (e)
    pprint(Eq(0,e))
    form.append (latex(Eq(0,e)) + ' => ')
    l = dsolve (e, nu(r))
    l  = l.subs ({Symbol("C1"): -r0}) # konstanta z Newtonovske limity r0=2GM/c^2
    pprint(l)
    form.append (latex(l))
    nusol = solve(l, nu(r))[0]
    
    e = G.dd(1,1)
    e = e.subs (nu(r), nusol)
    e*= r * (r - r0) * lam(r)  # zjednodus pro solver
    e = simplify (e)
    pprint(Eq(0,e))
    form.append (latex(Eq(0,e)) + ' => ')
    l  = dsolve(e, lam(r))
    l  = l.subs ({Symbol("C1"): 1})
    pprint(l)
    form.append (latex(l))
    lamsol = solve(l, lam(r))[0]
    #pprint(nusol)
    #pprint(lamsol)
    print("-"*40)
    text = '<h2>A nakonec je vyřešíme ...</h2>'
    text+= '<p> Použijeme jen první dvě rovnice (poslední dvě jsou závislé), vykrátíme co je možné, výsledek z první rovnice '
    text+= 'dosadíme do druhé, z Newtonovské limity určíme integrační konstanty a máme hotovo. Zbývá jen zkontrolovat výsledek.</p>'
    html.addE(Element('div', text))
    html.addF(form)

    metric = gdd
    metric = metric.subs (A, lamsol)
    metric = metric.subs (B, nusol)
    metric = simplify (metric)
    head = 'Výsledná metrika.'
    print  (head)
    pprint (metric)
    text = '<h2>' + head + '</h2>'
    text+= '<p>Z Newtonovské limity je $ r_0 = \\frac {2 GM}{c^2} $, kde G je gravitační konstanta, M hmotnost '
    text+= 'objektu a c rychlost světla ve vakuu. A je hotovo.</p>'
    html.addE(Element('div', text))
    html.addF(['g_{\\mu\\nu} = ' + latex(metric, long_frac_ratio = 10.0)])

    print ("Final control :")
    for i in [0,1,2,3]:
      Ctrl = G.dd(i,i)
      Ctrl = Ctrl.subs (lam(r), lamsol);
      Ctrl = Ctrl.subs (nu(r), nusol).doit();
      Ctrl = simplify(Ctrl, ratio=oo)
      pprint(Eq(Symbol('G_%i%i' % (i, i)),Ctrl))

    head = 'Nakonec přidáme i zdrojové texty programu.'
    text = '<h2>' + head + '</h2>'
    text+= '<p>Tady jsou : <a href="./schwarzschild.zip">schwarzschild.zip</a></p>'
    text+= '<p>A to je vše. Je celkem zřejmé, že provádět podobné výpočty tužkou na papíře a přitom se nesplést není asi legrace. '
    text+= 'Karl Schwarzschild to dělal v zákopech za světové války, stříleli po něm a spočítal to dobře. Za to určitě zaslouží úctu.</p>'
    html.addE(Element('div', text))

    return  html

if __name__ == "__main__":
    html = Schwarzschild()
    CreateHTML ('index.html', html)

