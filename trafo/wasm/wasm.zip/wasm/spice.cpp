#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <cstdarg>
#include <emscripten/emscripten.h>
#include <emscripten/bind.h>
#include "sharedspice.h"
#include "vector.h"

EM_JS (void, responseString, (const int type, const char * ptr), {
  postMessage ({id : type, text : UTF8ToString (ptr)});
});
void sendWrap(const MSG_TYPES type, const char * msg) {
  responseString ((const int) type, msg);
}
int cprintf (const char *__restrict fmt, ...) {
  const int len = 0x1000;
  char buffer [len];
  va_list arg;
  va_start (arg, fmt);
  const int res = vsnprintf(buffer, len, fmt, arg);
  va_end (arg);
  sendWrap (TYPE_SHOW, buffer);
  return res;
}
std::string xprintf (const char *__restrict fmt, ...) {
  const int len = 0x1000;
  char buffer [len];
  va_list arg;
  va_start (arg, fmt);
  vsnprintf(buffer, len, fmt, arg);
  va_end (arg);
  return std::string (buffer);
}
//////////////////////////////////////////////////////////////
static dataPlots    gPlots;
static       bool   SpiceIsInitialized = false;
static const char * CircuitDescription = R"---(.title coil nonlinear
.global gnd
.subckt trafo 1 2 3 4
.param MU0=1.26e-6 BS=1.0 MUR=100.0 LS=0.18 N1=600 N2=500
.model ltemp l IND=20.0e-4
.FUNC SATH(H) {BS * tanh(MU0 * MUR * H) + (MU0 * H)}
** 1. vinuti **
E1 1 2 100 0 {N1}
F1 101 0 E1  {N1}
** 2. vinuti **
E2 3 4 100 0 {N2}
F2 101 0 E2  {N2}
** atd ...
V0 101 0 0
BN 100 0 I=SATH(I(V0) / LS)
LX 100 0 ltemp
.ends trafo
* h1 pro mereni proudu 10V/A *
h1 0 /I v1 10
v1 /VS 0 sin(0 325 50 0m)
r1 /VS 2 2
r2 /VD 0 40k
x1 2 0 /VD 0 trafo
******************************
.tran 20u 100m uic
.end
)---";
//////////////////////////////////////////////////////////////
int recieve_char(char * str, int id, void* p) {
  int i, j = strlen(str);
  for (i=0; i<j; i++) {         // od 1. mezery (vynecha stderr, stdout)
    if (str[i] == ' ') break;
  }
  cprintf("%s\n", str + i);
  return 0;
}
int recieve_stat(char * status, int id, void* p){
  int i, j = strlen(status);
  bool isp = false;
  for (i=0; i<j; i++) {
    if (status[i] == '%') { isp = true; break; }
  }
  if (!isp) {           // pokud neobsahuje %, skonci
    if (strcmp (status, "--ready--")) return 0;
    sendWrap(TYPE_PROGRESS, "0"); // ready
    gPlots.get(true);
    return 0;
  }
  for (i=0; i<j; i++) { // výstup je string ve formátu "nn.n%"
    if (status[i] == ' ') { i += 1; break; }
  }
  sendWrap (TYPE_PROGRESS, status + i);
  return 0;
}
int ngexit(int status, bool unload, bool exit, int id, void* p){
  // sem se to samozřejmě nedostane, pokud nepoužiji 'quit'
  cprintf("exit: %d, unload=%d, exit=%d\n", status, (int) unload, (int) exit);
  return 0;
}
int recieve_data(vecvaluesall * data, int numstructs, int id, void* p){
//cprintf("data recieved: %f\n", data->vecsa[0]->creal);
  return 0;
}
int recieve_init_data(vecinfoall * data, int id, void * p){
  cprintf(" init data recieved from: %d\n", id);
  return 0;
}
int ngrunning(bool running, int id, void * p){
  if(running) cprintf("ng is running\n");
  else        cprintf("ng is not running\n");
  return 0;
}
// zatím nemá cenu zabývat se uvolněním paměti
static char ** getArray (const std::string & desc) {
  std::string str;
  std::vector<std::string> vs; 
  for (const char c : desc) {     // split desc by eol -> vs
    if ((c == '\n') or (c == '\r')) {
      if (!str.empty()) vs.push_back (str);
      str.clear();
    } else {
      str += c;
    }
  }
  if (!str.empty()) vs.push_back (str);
  const int vlen = vs.size();
  char ** array = (char **) malloc (sizeof(char*) * (vlen + 1));
  for (int n=0; n<vlen; n++) {
    array[n] = strdup (vs[n].c_str());
  }
  array [vlen] = nullptr;
  // for (int n=0; n<vlen; n++) {cprintf("%s\n", array[n]);}
  return array;
} 
///////////////////////////////////////////////////////////////

void SpiceInit () {
  sendWrap(TYPE_CIRCUIT, CircuitDescription);
  // init
  ngSpice_Init(& recieve_char, & recieve_stat, & ngexit,
               & recieve_data, & recieve_init_data, & ngrunning, nullptr);
  SpiceIsInitialized = true;  
}
extern "C" void  sh_delete_myvec();
void startSimulation (std::string circ) {
  if (!SpiceIsInitialized) return;
  sendWrap(TYPE_CLEAR, "");
  if (!SpiceIsInitialized) {
    cprintf("Init Sequence error\n");
  }
  // set circuit
  ngSpice_Circ   (getArray (circ));
  // run
  ngSpice_Command(strdup("run"));
  usleep(100000);                       // počkej ať se neuženeš
  //ngSpice_Command(strdup("quit"));    // nejde použít - zjistit proč
  sh_delete_myvec();                    // ale quit způsobí i toto, může pomoci
}
void setCanvasSize (const int w, const int h) {
  gPlots.setSize (w, h);
}
EMSCRIPTEN_BINDINGS (work) {
  emscripten::function("SpiceInit", SpiceInit);
  emscripten::function("startSimulation", startSimulation);
  emscripten::function("setCanvasSize", setCanvasSize);
}

