#include <stdio.h>
#include <math.h>
#include "sharedspice.h"
#include "vector.h"

void dataPlots::get(const bool en) {
  if (en) ready = true;
  if (!ready) return;
  plots.clear();
  char *  resp  = ngSpice_CurPlot();
  char ** vects = ngSpice_AllVecs(resp);
  int index = 0;
  char *  vect  = vects[index++];
  while (vect) {
    std::string name (vect);
    if (name.find ("#branch") == std::string::npos) {    // branch ignorovat
      pvector_info info = ngGet_Vec_Info(vect);
      dataVector nv;
      nv.name = info->v_name;
      for (int n=0; n<info->v_length; n++) {
        const double val = info->v_realdata[n];
        nv.data.push_back (val);
      }
      if (nv.name == "time") {
        base = nv;
      } else {
        if (nv.name[0] == '/') plots.push_back (nv);
      }
    }
    vect = vects [index++];
  }
  if (base.data.empty()) return;
  if (plots.empty())     return;
  draw();
}
void dataPlots::setSize(const int x, const int y) {
  size.x = x; size.y = y;
  get();
}
DPoint dataPlots::minimax_t () {
  double min = + __DBL_MAX__;
  double max = - __DBL_MAX__;
  for (auto & e: base.data) {
    if (e < min) min = e;
    if (e > max) max = e;
  }
  DPoint p (min, max);
  return p;
}
DPoint dataPlots::minimax_v () {
  double min = + __DBL_MAX__;
  double max = - __DBL_MAX__;
  for (auto & p: plots) {
    for (auto & e: p.data) {
      if (e < min) min = e;
      if (e > max) max = e;
    }
  }
  DPoint p (min, max);
  return p;
}
static constexpr double left_margin = 50.0;
static constexpr double min_grid_px = 70.0;
void dataPlots::computeMatrix() {
  DPoint tmm = minimax_t ();
  if (tmm.x == tmm.y) matrix.zoomx = 1.0;
  else matrix.zoomx = (size.x - left_margin) / (tmm.y - tmm.x);
  matrix.ofsx  = left_margin + matrix.zoomx * tmm.x;
  DPoint ymm = minimax_v ();
  if (ymm.x == ymm.y) matrix.zoomy = 1.0;
  else matrix.zoomy = size.y / (ymm.x - ymm.y);
  matrix.ofsy = size.y - matrix.zoomy * ymm.x;
  // determine steps
  const double mf [] = { 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0 };
  const double xl = round (log10 (tmm.y - tmm.x));  // order
  xord  = xl;
  const double xo = pow (10.0, xl - 2.0);
  double xr = xo;
  for (auto e: mf) {
    const double xp = abs (matrix.zoomx * xr);
    if (xp >= min_grid_px) break;
    xr = xo * e;
  }
  xstep = xr;
  const double yl = round (log10 (ymm.y - ymm.x));  // order
  yord  = yl;
  const double yo = pow (10.0, yl - 2.0);
  double yr = yo;
  for (auto e: mf) {
    const double yp = abs (matrix.zoomy * yr);
    if (yp >= min_grid_px) break;
    yr = yo * e;
  }
  ystep = yr;
  // printf("xstep=%f, ystep=%f\n", xstep, ystep);
  
}
IPoint Matrix::operator* (const DPoint & p) {
  IPoint r;
  r.x = lround (ofsx + zoomx * p.x);
  r.y = lround (ofsy + zoomy * p.y);  
  return r;
}

static const unsigned colors [] = {
  0xFF0000u, 0x00FF00u, 0x0000FFu, 0xFFFF00u,
  0xFF00FFu, 0x00FFFFu, 0x8080FFu, 0xFF8080u,
};
std::vector<PolyLine> dataPlots::resize() {
  computeMatrix();
  std::vector<PolyLine> result;
  const size_t maxl = base.data.size();  // všechny vektory mají stejnou délku
  int k = 0;    // střídání barev
  for (auto & plot: plots) {
    PolyLine part;
    part.name  = plot.name;
    part.color = colors [k & 7];
    for (unsigned n=0; n<maxl; n++) {
      const double x = base.data[n];
      const double y = plot.data[n];
      IPoint a = matrix * DPoint(x, y);
      part.data.push_back (a);
    }
    result.push_back (part);
    k += 1;
  }
  return result;
}
static const char * ctx = "context";

void dataPlots::draw() {
  std::string text;
  // smazat, cokoli tam bylo
  text += xprintf("%s.clearRect(0,0,%g,%g);\n", ctx, size.x, size.y);
  std::vector<PolyLine> vpoly = resize();
  background (text);
  for (auto & poly: vpoly) drawOne (text, poly);
  int order = 0;
  text += xprintf("%s.font = \'%dpx monospace\'\n", ctx, 16);
  text += xprintf("%s.fillStyle = \'yellow\'\n",  ctx);
  text += xprintf("%s.textAlign = \'left\'\n",  ctx);
  for (auto & poly: vpoly) drawDesc (text, poly, ++order);
  axes(text);
  sendWrap (TYPE_DRAWINGS, text.c_str());
}
void dataPlots::drawOne(std::string & text, const PolyLine & poly) {
  text += xprintf("%s.beginPath();\n", ctx);
  int n = 0;
  for (auto & e: poly.data) {
    if (!n) {
      text += xprintf("%s.moveTo(%d, %d);\n", ctx, e.x, e.y);
    } else {
      text += xprintf("%s.lineTo(%d, %d);\n", ctx, e.x, e.y);
    }
    n += 1;
  }
  text += xprintf ("%s.lineWidth = 2;\n", ctx);
  text += xprintf ("%s.strokeStyle = \'#%06X\';\n", ctx, poly.color);
  text += xprintf ("%s.stroke();\n", ctx);
}
void dataPlots::drawDesc(std::string & text, const PolyLine & poly, const int order) {
  IPoint b,e;
  const int ypos = 20 * order, bx = size.x - 100, ex = size.x - 50, et = ex + 5, posy = ypos - 5;
  b.x = bx, b.y = posy, e.x = ex, e.y = posy;
  text += xprintf ("%s.beginPath();\n", ctx);
  text += xprintf ("%s.moveTo(%d, %d);\n", ctx, b.x, b.y);
  text += xprintf ("%s.lineTo(%d, %d);\n", ctx, e.x, e.y);
  text += xprintf ("%s.lineWidth = 4;\n", ctx);
  text += xprintf ("%s.strokeStyle = \'#%06X\';\n", ctx, poly.color);
  text += xprintf ("%s.stroke();\n", ctx);
  text += xprintf ("%s.fillText(\'%s\', %d, %d);\n", ctx, poly.name.c_str(), et, ypos);
}
void dataPlots::background(std:: string & text) {
  text += xprintf ("%s.lineWidth = 1;\n", ctx);
  text += xprintf ("%s.strokeStyle = \'#%06X\';\n", ctx, 0x808080);
  text += xprintf ("%s.setLineDash([2,2]);\n", ctx);
  for (double nx = xstep; ; nx += xstep) {
    const double px = round(matrix.ofsx + matrix.zoomx * nx);
    if (px > size.x) break;
    grid_x (text, px);
  }
  for (double ny = ystep; ; ny += ystep) { // pouze pro kladne
    const double py = round(matrix.ofsy + matrix.zoomy * ny);
    if (py < 0.0) break;
    grid_y (text, py);
  }
  text += xprintf ("%s.setLineDash([]);\n", ctx);
}
void dataPlots::grid_x(std::string & text, const double xp) {
  text += xprintf ("%s.beginPath();\n", ctx);
  text += xprintf ("%s.moveTo(%g, %g);\n", ctx, xp, 0.0);
  text += xprintf ("%s.lineTo(%g, %g);\n", ctx, xp, size.y);
  text += xprintf ("%s.stroke();\n", ctx);
}
void dataPlots::grid_y(std::string & text, const double yp) {
  text += xprintf ("%s.beginPath();\n", ctx);
  text += xprintf ("%s.moveTo(%g, %g);\n", ctx, 0.0,    yp);
  text += xprintf ("%s.lineTo(%g, %g);\n", ctx, size.x, yp);
  text += xprintf ("%s.stroke();\n", ctx);
}
void dataPlots::axes(std:: string & text) {
  text += xprintf ("%s.lineWidth = 1;\n", ctx);
  text += xprintf ("%s.strokeStyle = \'#%06X\';\n", ctx, 0xFFFF00u);
  // osa x
  const double ypos = matrix.ofsy;
  text += xprintf ("%s.beginPath();\n", ctx);
  text += xprintf ("%s.moveTo(%g, %g);\n", ctx, 0.0,    ypos);
  text += xprintf ("%s.lineTo(%g, %g);\n", ctx, size.x, ypos);
  text += xprintf ("%s.stroke();\n", ctx);
  // osa y
  const double xpos = matrix.ofsx;
  text += xprintf ("%s.beginPath();\n", ctx);
  text += xprintf ("%s.moveTo(%g, %g);\n", ctx, xpos,    0.0);
  text += xprintf ("%s.lineTo(%g, %g);\n", ctx, xpos, size.y);
  text += xprintf ("%s.stroke();\n", ctx);
  // popis x
  for (double nx = xstep; ; nx += xstep) {
    const int px = lround(matrix.ofsx  + matrix.zoomx * nx);
    const int yp = lround(matrix.ofsy) - 2;
    if (px > (int) size.x) break;
    text += xprintf ("%s.fillText(\'%s\', %d, %d);\n", ctx, fmti(xord, nx).c_str(), px, yp);
  }
  // popis y
  text += xprintf("%s.textAlign = \'right\'\n", ctx);
  for (double ny = 0.0; ; ny += ystep) { // pouze pro kladne
    const int py = lround(matrix.ofsy  + matrix.zoomy * ny) - 2;
    const int xp = lround(matrix.ofsx) - 5;
    if (py < 0) break;
    text += xprintf ("%s.fillText(\'%s\', %d, %d);\n", ctx, fmti(yord, ny).c_str(), xp, py);
  }  
}
// formátování čísla do ing formátu - číslo + přípona
const char * multplus  [] = {"k","M","G","T","P"};
const char * multminus [] = {"m","u","n","p","f"};
std::string dataPlots::fmti(const int ord, const double num) {
  std::string result;
  const int mulf = (ord - 3) / 3;
  const double pnum = num * pow (10.0, - double (3 * mulf));
  if (mulf > 0) {
    const int mi = + mulf - 1;
    if (mi > 4) { result = "big"; return result; }
    result = xprintf("%g%s", pnum, multplus[mi]);
  } else if (mulf < 0) {
    const int mi = - mulf - 1;
    if (mi > 4) { result = "small"; return result; }
    result = xprintf("%g%s", pnum, multminus[mi]);
  } else {
    result = xprintf ("%g", num);
  }
  return result;
}


