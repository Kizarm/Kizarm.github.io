#ifndef VECTOR_H
#define VECTOR_H
#include <vector>
#include <string>

extern int cprintf (const char *__restrict fmt, ...)__attribute__((__format__(__printf__, 1, 2)));
extern std::string xprintf  (const char *__restrict fmt, ...)__attribute__((__format__(__printf__, 1, 2)));

enum MSG_TYPES {
  TYPE_CLEAR = 0,
  TYPE_SHOW,
  TYPE_PROGRESS,
  TYPE_CIRCUIT,
  TYPE_DRAWINGS
};
extern void sendWrap (const MSG_TYPES type, const char * msg);
struct IPoint {
  int x,y;
};
struct PolyLine {
  std::string         name;
  unsigned            color;
  std::vector<IPoint> data;
};
struct DPoint {
  double x,y;
  DPoint (const double mx, const double my) : x(mx), y(my) {}
};
struct Matrix {
  double zoomx, ofsx;
  double zoomy, ofsy;
  Matrix () : zoomx(0), ofsx(0), zoomy(0), ofsy (0) {}
  IPoint operator* (const DPoint & p);
};
struct dataVector {
  std::string         name;
  std::vector<double> data;
  dataVector () : name(), data() {}
};
class dataPlots {
  bool                    ready;
  DPoint                  size;
  dataVector              base;   // time - mandatory
  std::vector<dataVector> plots;
  Matrix                  matrix;
  double                  xstep, ystep;
  int                     xord,  yord;
public:
  dataPlots () : ready(false), size(0,0), base(), plots(), matrix(),
                 xstep(0), ystep(0), xord(0), yord (0) {};
  void                  get     (const bool en = false);
  void                  setSize (const int x, const int y);
protected:
  std::vector<PolyLine> resize ();
  std::string           fmti   (const int ord, const double num);
  void   draw          ();
  void   computeMatrix ();
  void   drawOne       (std:: string & text, const PolyLine & poly);
  void   drawDesc      (std:: string & text, const PolyLine & poly, const int order);
  DPoint minimax_t     ();
  DPoint minimax_v     ();
  void   background    (std:: string & text);
  void   grid_x        (std:: string & text, const double xp);
  void   grid_y        (std:: string & text, const double yp);
  void   axes          (std:: string & text);
};
#endif // VECTOR_H
