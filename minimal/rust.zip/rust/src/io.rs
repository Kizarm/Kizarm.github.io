#![allow(dead_code)]
extern crate volatile_cell;
use io::volatile_cell::VolatileCell;
// rcc
struct RccType {
    cr: VolatileCell<u32>,            /* rcc clock control register,                                  address offset: 0x00 */
    pllcfgr: VolatileCell<u32>,       /* rcc pll configuration register,                              address offset: 0x04 */
    cfgr: VolatileCell<u32>,          /* rcc clock configuration register,                            address offset: 0x08 */
    cir: VolatileCell<u32>,           /* rcc clock interrupt register,                                address offset: 0x0c */
    ahb1rstr: VolatileCell<u32>,      /* rcc ahb1 peripheral reset register,                          address offset: 0x10 */
    ahb2rstr: VolatileCell<u32>,      /* rcc ahb2 peripheral reset register,                          address offset: 0x14 */
    ahb3rstr: VolatileCell<u32>,      /* rcc ahb3 peripheral reset register,                          address offset: 0x18 */
        reserved0: u32,               /* reserved, 0x1c                                                                    */
    apb1rstr: VolatileCell<u32>,      /* rcc apb1 peripheral reset register,                          address offset: 0x20 */
    apb2rstr: VolatileCell<u32>,      /* rcc apb2 peripheral reset register,                          address offset: 0x24 */
        reserved1: [u32; 2],          /* reserved, 0x28-0x2c                                                               */
    ahbenr: VolatileCell<u32>,        /* upraveno pro kompatibilitu      */
    ahb2enr: VolatileCell<u32>,       /* rcc ahb2 peripheral clock register,                          address offset: 0x34 */
    ahb3enr: VolatileCell<u32>,       /* rcc ahb3 peripheral clock register,                          address offset: 0x38 */
        reserved2: [u32; 2],          /* reserved, 0x3c                                                                    */
    apb1enr: VolatileCell<u32>,       /* rcc apb1 peripheral clock enable register,                   address offset: 0x40 */
    apb2enr: VolatileCell<u32>,       /* rcc apb2 peripheral clock enable register,                   address offset: 0x44 */
        reserved3: [u32; 2],          /* reserved, 0x48-0x4c                                                               */
    ahb1lpenr: VolatileCell<u32>,     /* rcc ahb1 peripheral clock enable in low power mode register, address offset: 0x50 */
    ahb2lpenr: VolatileCell<u32>,     /* rcc ahb2 peripheral clock enable in low power mode register, address offset: 0x54 */
    ahb3lpenr: VolatileCell<u32>,     /* rcc ahb3 peripheral clock enable in low power mode register, address offset: 0x58 */
        reserved4: u32,               /* reserved, 0x5c                                                                    */
    apb1lpenr: VolatileCell<u32>,     /* rcc apb1 peripheral clock enable in low power mode register, address offset: 0x60 */
    apb2lpenr: VolatileCell<u32>,     /* rcc apb2 peripheral clock enable in low power mode register, address offset: 0x64 */
        reserved5: [u32; 2],          /* reserved, 0x68-0x6c                                                               */
    bdcr: VolatileCell<u32>,          /* rcc backup domain control register,                          address offset: 0x70 */
    csr: VolatileCell<u32>,           /* rcc clock control & status register,                         address offset: 0x74 */
        reserved6: [u32; 2],          /* reserved, 0x78-0x7c                                                               */
    sscgr: VolatileCell<u32>,         /* rcc spread spectrum clock generation register,               address offset: 0x80 */
    plli2scfgr: VolatileCell<u32>,    /* rcc plli2s configuration register,                           address offset: 0x84 */
}
// gpio
struct GpioType {
    moder: VolatileCell<u32>,    /* gpio port mode register,               address offset: 0x00      */
    otyper: VolatileCell<u32>,   /* gpio port output type register,        address offset: 0x04      */
    ospeedr: VolatileCell<u32>,  /* gpio port output speed register,       address offset: 0x08      */
    pupdr: VolatileCell<u32>,    /* gpio port pull-up/pull-down register,  address offset: 0x0c      */
    idr: VolatileCell<u32>,      /* gpio port input data register,         address offset: 0x10      */
    odr: VolatileCell<u32>,      /* gpio port output data register,        address offset: 0x14      */
    bsrrl: VolatileCell<u16>,    /* gpio port bit set/reset low register,  address offset: 0x18      */
    bsrrh: VolatileCell<u16>,    /* gpio port bit set/reset high register, address offset: 0x1a      */
    lckr: VolatileCell<u32>,     /* gpio port configuration lock register, address offset: 0x1c      */
    afr: [VolatileCell<u32>; 2], /* gpio alternate function registers,     address offset: 0x20-0x24 */
}
const PORT_D_BASE: u32 = 0x4002_0C00u32;
const RCC_BASE:    u32 = 0x4002_3800u32;
// ledky jsou na portu D, nebudeme to komplikovat
pub struct Pin {
  position: u32,
  port: *const GpioType,
}
impl Pin {
  pub fn new (pos:u32) -> Pin {
    Pin {position:pos, port: PORT_D_BASE as *const GpioType}
  }
  pub fn init (&self) {
    let cenadr = RCC_BASE as *const RccType;
    unsafe {
      (*cenadr).ahbenr.set(0x8u32);
      (*self.port).moder.set(1u32 << (2u32 * self.position));
    }
  }
  pub fn toggle (&self) {
    unsafe {
      (*self.port).odr.set((*self.port).odr.get() ^ (1u32 << self.position));
    }
  }
}

