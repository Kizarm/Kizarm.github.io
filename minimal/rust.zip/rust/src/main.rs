#![feature(lang_items,start,asm)]
#![no_std]
#![no_main]

use core::fmt::Arguments;

#[lang = "panic_fmt"]
#[no_mangle]
pub extern fn panic_fmt(_msg: Arguments,
                        _file: &'static str,
                        _line: u32) -> ! {
    loop {}
}
pub mod io;

// Application environment.

extern {
    static __STACK_BASE: u32;
}

pub type Handler = extern "C" fn();

#[repr(C, packed)]
pub struct ExceptionTable {
    pub initial_stack: *const u32,
    pub reset: unsafe extern "C" fn() -> !,
    /* neni potreba
    pub nmi:          Option<Handler>,
    pub hard_fault:   Option<Handler>,
    pub mm_fault:     Option<Handler>,
    pub bus_fault:    Option<Handler>,
    pub usage_fault:  Option<Handler>,
    pub _reserved0:   Option<Handler>,
    pub _reserved1:   Option<Handler>,
    pub _reserved2:   Option<Handler>,
    pub _reserved3:   Option<Handler>,
    pub sv_call:      Option<Handler>,
    pub debug_mon:    Option<Handler>,
    pub _reserved4:   Option<Handler>,
    pub pend_sv:      Option<Handler>,
    pub sys_tick:     Option<Handler>,
    */
}

unsafe impl Sync for ExceptionTable {}


/******************************************************************************/
fn wait () {
  let mut dly: u32 = 0x200000u32;
  while dly > 0 {
    unsafe {        // prevence optimalizace
      asm!("nop" :::: "volatile");
    }
    dly -= 1;
  }
}
/******************************************************************************/
// Application.

/// This function will be "called" by the processor at reset.  Note that none of
/// the C or Rust environment has been established --- in particular, this
/// function is responsible for initializing any global data it might need!
/// I've currently punted on this for simplicity.

pub unsafe extern fn reset_handler() -> ! {
  let blue = io::Pin::new (15u32);
  blue.init();
  loop {
    blue.toggle();
    wait();
  }
}

/// For predictability, I've mapped all architectural vectors to this routine.
/// Since we aren't enabling peripherals or faults, we can technically only take
/// NMI and HardFault --- but if someone builds on this code, they might trigger
/// something else.
/*
extern "C" fn trap() { loop {} }
*/
#[no_mangle]
#[link_section=".isr_vector"]
pub static ISR_VECTORS : ExceptionTable = ExceptionTable {
    initial_stack: unsafe { &__STACK_BASE },  // unsafe ref-to-ptr conversion
    reset: reset_handler,
/*  zatim neni potreba, ale je dobre vedet, ze to jde
    nmi: Some(trap),
    hard_fault: Some(trap),
    mm_fault: Some(trap),
    bus_fault: Some(trap),
    usage_fault: Some(trap),
    _reserved0: None,
    _reserved1: None,
    _reserved2: None,
    _reserved3: None,
    sv_call: Some(trap),
    debug_mon: Some(trap),
    _reserved4: None,
    pend_sv: Some(trap),
    sys_tick: Some(trap),
*/
};
